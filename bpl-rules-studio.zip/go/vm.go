package main

import (
	"bytes"
	"encoding/binary"
	"encoding/json"
	"fmt"
	"math"
	"strconv"
	"strings"
	"time"
)

// TraceStep represents a single executed instruction trace (matches TS TraceStep)
type TraceStep struct {
	CurrentNodeID    string                 `json:"currentNodeId"`
	NodeType         string                 `json:"nodeType"`
	Executed         bool                   `json:"executed"`
	VariableSnapshot map[string]interface{} `json:"variableSnapshot"`
	Logs             []string               `json:"logs"`
	Description      string                 `json:"description"`
}

// ExecNode is the runtime-executable representation of compiled bytecode
type ExecNode struct {
	ID        string
	Op        byte
	StrArgs   []string
	BoolArgs  []bool
	Blocks    [][]ExecNode
	JSONArgs  []string
}

// DecodeBytecode decodes raw binary bytes back into a root ExecNode tree
func DecodeBytecode(data []byte) (ExecNode, error) {
	if len(data) < 5 {
		return ExecNode{}, fmt.Errorf("bytecode too short")
	}

	// Verify Magic and Version
	if string(data[:4]) != "BPLG" {
		return ExecNode{}, fmt.Errorf("invalid binary magic header")
	}
	if data[4] != 1 {
		return ExecNode{}, fmt.Errorf("unsupported bytecode version: %d", data[4])
	}

	reader := bytes.NewReader(data[5:])
	return decodeNode(reader)
}

func readString(r *bytes.Reader) (string, error) {
	var length uint32
	if err := binary.Read(r, binary.BigEndian, &length); err != nil {
		return "", err
	}
	b := make([]byte, length)
	if _, err := r.Read(b); err != nil {
		return "", err
	}
	return string(b), nil
}

func readBool(r *bytes.Reader) (bool, error) {
	b, err := r.ReadByte()
	if err != nil {
		return false, err
	}
	return b == 1, nil
}

func decodeBlock(r *bytes.Reader) ([]ExecNode, error) {
	var count uint32
	if err := binary.Read(r, binary.BigEndian, &count); err != nil {
		return nil, err
	}
	nodes := make([]ExecNode, count)
	for i := uint32(0); i < count; i++ {
		node, err := decodeNode(r)
		if err != nil {
			return nil, err
		}
		nodes[i] = node
	}
	return nodes, nil
}

func decodeNode(r *bytes.Reader) (ExecNode, error) {
	id, err := readString(r)
	if err != nil {
		return ExecNode{}, err
	}
	op, err := r.ReadByte()
	if err != nil {
		return ExecNode{}, err
	}

	node := ExecNode{ID: id, Op: op}

	switch op {
	case OpScript:
		name, _ := readString(r)
		node.StrArgs = []string{name}
		block, err := decodeBlock(r)
		if err != nil {
			return ExecNode{}, err
		}
		node.Blocks = [][]ExecNode{block}

	case OpLog:
		msg, _ := readString(r)
		node.StrArgs = []string{msg}

	case OpAssign:
		variable, _ := readString(r)
		val, _ := readString(r)
		isIdent, _ := readBool(r)
		node.StrArgs = []string{variable, val}
		node.BoolArgs = []bool{isIdent}

	case OpJump:
		target, _ := readString(r)
		node.StrArgs = []string{target}

	case OpLabel:
		name, _ := readString(r)
		node.StrArgs = []string{name}

	case OpReturn:
		// No args

	case OpInclude:
		path, _ := readString(r)
		paramsJson, _ := readString(r)
		node.StrArgs = []string{path}
		node.JSONArgs = []string{paramsJson}

	case OpImport:
		file, _ := readString(r)
		node.StrArgs = []string{file}

	case OpValidate:
		condJson, _ := readString(r)
		errMsg, _ := readString(r)
		node.JSONArgs = []string{condJson}
		node.StrArgs = []string{errMsg}

	case OpClearScreen:
		// No args

	case OpCode:
		// No args

	case OpPrompt:
		msg, _ := readString(r)
		variable, _ := readString(r)
		node.StrArgs = []string{msg, variable}

	case OpGetKey:
		variable, _ := readString(r)
		node.StrArgs = []string{variable}

	case OpOnlyIf:
		variable, _ := readString(r)
		node.StrArgs = []string{variable}

		var caseCount uint32
		binary.Read(r, binary.BigEndian, &caseCount)
		node.JSONArgs = make([]string, caseCount)
		node.Blocks = make([][]ExecNode, caseCount)
		for i := uint32(0); i < caseCount; i++ {
			valsJson, _ := readString(r)
			node.JSONArgs[i] = valsJson
			block, _ := decodeBlock(r)
			node.Blocks[i] = block
		}

	case OpCallApi:
		url, _ := readString(r)
		paramsJson, _ := readString(r)
		respVar, _ := readString(r)
		node.StrArgs = []string{url, respVar}
		node.JSONArgs = []string{paramsJson}

	case OpSwitch:
		variable, _ := readString(r)
		node.StrArgs = []string{variable}

		var caseCount uint32
		binary.Read(r, binary.BigEndian, &caseCount)
		node.Blocks = make([][]ExecNode, caseCount+1) // +1 for Default block at the end
		node.JSONArgs = make([]string, caseCount)
		for i := uint32(0); i < caseCount; i++ {
			val, _ := readString(r)
			node.JSONArgs[i] = val
			block, _ := decodeBlock(r)
			node.Blocks[i] = block
		}
		// Default block
		defBlock, _ := decodeBlock(r)
		node.Blocks[caseCount] = defBlock

	case OpLoop:
		itemVar, _ := readString(r)
		colVar, _ := readString(r)
		node.StrArgs = []string{itemVar, colVar}
		block, _ := decodeBlock(r)
		node.Blocks = [][]ExecNode{block}

	case OpIf:
		condJson, _ := readString(r)
		node.JSONArgs = []string{condJson}

		// Read then block
		thenB, _ := decodeBlock(r)
		node.Blocks = append(node.Blocks, thenB)

		// Read else if blocks count
		var elifCount uint32
		binary.Read(r, binary.BigEndian, &elifCount)
		node.JSONArgs = append(node.JSONArgs, make([]string, elifCount)...)
		for i := uint32(0); i < elifCount; i++ {
			elifCondJson, _ := readString(r)
			node.JSONArgs[1+i] = elifCondJson // offset by 1 because index 0 is if condition
			elifB, _ := decodeBlock(r)
			node.Blocks = append(node.Blocks, elifB)
		}

		// Read else block
		elseB, _ := decodeBlock(r)
		node.Blocks = append(node.Blocks, elseB)

	case OpMacro:
		name, _ := readString(r)
		node.StrArgs = []string{name}
		block, _ := decodeBlock(r)
		node.Blocks = [][]ExecNode{block}
	}

	return node, nil
}

// BplVM represents our process execution virtual machine runtime
type BplVM struct {
	Variables   map[string]interface{}
	Logs        []string
	Trace       []TraceStep
	Halted      bool
	JumpToLabel string
	
	// Channels for handling synchronous pausing and user inputs
	PromptChan  chan string // JS sends prompted values here
	RequestChan chan map[string]interface{} // VM sends prompt/getkey requests to JS here
}

func NewVM(initialVars map[string]interface{}) *BplVM {
	if initialVars == nil {
		initialVars = make(map[string]interface{})
	}
	return &BplVM{
		Variables:   initialVars,
		Logs:        make([]string, 0),
		Trace:       make([]TraceStep, 0),
		PromptChan:  make(chan string),
		RequestChan: make(chan map[string]interface{}),
	}
}

// Execute triggers the main execution loop on the root decoded script block
func (vm *BplVM) Execute(root ExecNode) {
	vm.Logs = append(vm.Logs, "[System] Initializing compiled rules execution (Go Runtime).")
	vm.addStep(root.ID, "script", true, "Starting BPL script (Go Compiler VM)")

	if root.Op == OpScript {
		vm.evaluateBlock(root.Blocks[0])
	}

	vm.Logs = append(vm.Logs, "[System] Rule execution finished successfully.")
	vm.addStep(root.ID, "script", true, "Rule set completed.")
}

func (vm *BplVM) evaluateBlock(nodes []ExecNode) {
	for _, node := range nodes {
		if vm.Halted {
			return
		}

		// Handle jumps
		if vm.JumpToLabel != "" {
			if node.Op == OpLabel && node.StrArgs[0] == vm.JumpToLabel {
				vm.JumpToLabel = ""
				vm.addStep(node.ID, "label", true, fmt.Sprintf("Landing on label \"%s\" from jump.", node.StrArgs[0]))
			} else {
				vm.addStep(node.ID, "skip", false, fmt.Sprintf("Skipping (jumping to \"%s\").", vm.JumpToLabel))
				continue
			}
		}

		vm.evaluateNode(node)
	}
}

func (vm *BplVM) evaluateNode(node ExecNode) {
	if vm.Halted {
		return
	}

	switch node.Op {
	case OpLabel:
		vm.addStep(node.ID, "label", true, fmt.Sprintf("Label \"%s\"", node.StrArgs[0]))

	case OpLog:
		msg := vm.resolveLogMessage(node.StrArgs[0])
		vm.Logs = append(vm.Logs, fmt.Sprintf("[Log] %s", msg))
		vm.addStep(node.ID, "log", true, fmt.Sprintf("Log: %s", msg))

	case OpAssign:
		variable := node.StrArgs[0]
		valRaw := node.StrArgs[1]
		isIdent := node.BoolArgs[0]

		var assignedVal interface{} = valRaw
		if isIdent {
			assignedVal = vm.Variables[valRaw]
		} else if valRaw == "true" {
			assignedVal = true
		} else if valRaw == "false" {
			assignedVal = false
		} else if num, err := strconv.ParseFloat(valRaw, 64); err == nil && valRaw != "" {
			assignedVal = num
		}

		vm.Variables[variable] = assignedVal
		vm.Logs = append(vm.Logs, fmt.Sprintf("[Assign] Set %s = %v", variable, assignedVal))
		vm.addStep(node.ID, "assign", true, fmt.Sprintf("Set %s = %v", variable, assignedVal))

	case OpJump:
		vm.JumpToLabel = node.StrArgs[0]
		vm.Logs = append(vm.Logs, fmt.Sprintf("[Jump] Branch to label \"%s\"", node.StrArgs[0]))
		vm.addStep(node.ID, "jump", true, fmt.Sprintf("Jump to \"%s\"", node.StrArgs[0]))

	case OpReturn:
		vm.Halted = true
		vm.Logs = append(vm.Logs, "[Return] Explicit exit triggered.")
		vm.addStep(node.ID, "return", true, "Exit execution.")

	case OpInclude:
		path := node.StrArgs[0]
		vm.Logs = append(vm.Logs, fmt.Sprintf("[Include] Rendered template \"%s\"", path))
		vm.addStep(node.ID, "include", true, fmt.Sprintf("Include: %s", path))

	case OpImport:
		file := node.StrArgs[0]
		vm.Logs = append(vm.Logs, fmt.Sprintf("[Import] Dynamic rules import from file \"%s\"", file))
		vm.addStep(node.ID, "import", true, fmt.Sprintf("Import: %s", file))

	case OpValidate:
		var cond ConditionGroup
		json.Unmarshal([]byte(node.JSONArgs[0]), &cond)
		isPassed := vm.evaluateCondition(cond)
		if isPassed {
			vm.addStep(node.ID, "validation", true, "Validation check passed.")
		} else {
			vm.Halted = true
			errMsg := node.StrArgs[0]
			vm.Logs = append(vm.Logs, fmt.Sprintf("[ValidationError] Validation failed: %s", errMsg))
			vm.addStep(node.ID, "validation", true, fmt.Sprintf("Validate Fail: %s", errMsg))
		}

	case OpClearScreen:
		vm.Logs = append(vm.Logs, "[System] Screen Cleared")
		vm.addStep(node.ID, "clearscreen", true, "Clearscreen")

	case OpCode:
		vm.addStep(node.ID, "code", true, "Code marker node")

	case OpPrompt:
		msg := node.StrArgs[0]
		variable := node.StrArgs[1]

		// Ask Javascript environment for the prompt value (Non-blocking worker flow using channels!)
		vm.RequestChan <- map[string]interface{}{
			"type":     "prompt",
			"nodeId":   node.ID,
			"message":  msg,
			"variable": variable,
		}

		// Synchronously wait for response from JS thread
		newVal := <-vm.PromptChan
		
		var assignedVal interface{} = newVal
		if num, err := strconv.ParseFloat(newVal, 64); err == nil && newVal != "" {
			assignedVal = num
		} else if newVal == "true" {
			assignedVal = true
		} else if newVal == "false" {
			assignedVal = false
		}

		vm.Variables[variable] = assignedVal
		vm.Logs = append(vm.Logs, fmt.Sprintf("[Prompt] %s -> Input: %v", msg, assignedVal))
		vm.addStep(node.ID, "prompt", true, fmt.Sprintf("Prompt Response: %s = %v", variable, assignedVal))

	case OpGetKey:
		variable := node.StrArgs[0]

		vm.RequestChan <- map[string]interface{}{
			"type":     "getkey",
			"nodeId":   node.ID,
			"message":  "Press any key to continue...",
			"variable": variable,
		}

		newVal := <-vm.PromptChan
		vm.Variables[variable] = newVal
		vm.Logs = append(vm.Logs, fmt.Sprintf("[Getkey] Pressed Key: %s", newVal))
		vm.addStep(node.ID, "getkey", true, fmt.Sprintf("Key Pressed: %s", newVal))

	case OpOnlyIf:
		variable := node.StrArgs[0]
		switchVal := strings.ToLower(fmt.Sprintf("%v", vm.Variables[variable]))

		matched := false
		vm.addStep(node.ID, "only_if", true, fmt.Sprintf("Evaluating only_if branches on %s", variable))

		for i, jsonArg := range node.JSONArgs {
			if matched {
				break
			}
			var vals []string
			json.Unmarshal([]byte(jsonArg), &vals)

			isMatched := false
			for _, v := range vals {
				if strings.ToLower(v) == switchVal {
					isMatched = true
					break
				}
			}

			if isMatched {
				matched = true
				vm.Logs = append(vm.Logs, fmt.Sprintf("[OnlyIf] Branch matched: %v", vals))
				vm.evaluateBlock(node.Blocks[i])
			}
		}

	case OpCallApi:
		url := node.StrArgs[0]
		respVar := node.StrArgs[1]

		mockResp := 720
		if strings.Contains(url, "credit") {
			age, ok := vm.Variables["age"].(float64)
			if ok && age > 25 {
				mockResp = 740
			} else {
				mockResp = 650
			}
		} else if strings.Contains(url, "risk") {
			vm.Variables[respVar] = "Medium"
			vm.Logs = append(vm.Logs, fmt.Sprintf("[API Call] Fetched %s -> Set %s = Medium", url, respVar))
			vm.addStep(node.ID, "api-call", true, fmt.Sprintf("API response: %s = Medium", respVar))
			return
		}

		vm.Variables[respVar] = mockResp
		vm.Logs = append(vm.Logs, fmt.Sprintf("[API Call] Fetched %s -> Set %s = %v", url, respVar, mockResp))
		vm.addStep(node.ID, "api-call", true, fmt.Sprintf("API response: %s = %v", respVar, mockResp))

	case OpSwitch:
		variable := node.StrArgs[0]
		switchVal := strings.ToLower(fmt.Sprintf("%v", vm.Variables[variable]))
		matched := false

		vm.addStep(node.ID, "switch", true, fmt.Sprintf("Evaluating switch branches on %s = %s", variable, switchVal))

		casesCount := len(node.JSONArgs)
		for i := 0; i < casesCount; i++ {
			cVal := strings.ToLower(node.JSONArgs[i])
			if cVal == switchVal {
				matched = true
				vm.Logs = append(vm.Logs, fmt.Sprintf("[Switch] Branch case \"%s\" matched", node.JSONArgs[i]))
				vm.evaluateBlock(node.Blocks[i])
				break
			}
		}

		if !matched && len(node.Blocks[casesCount]) > 0 {
			vm.Logs = append(vm.Logs, "[Switch] No cases matched, executing default block")
			vm.evaluateBlock(node.Blocks[casesCount])
		}

	case OpLoop:
		itemVar := node.StrArgs[0]
		colVar := node.StrArgs[1]
		colRaw := vm.Variables[colVar]

		vm.addStep(node.ID, "loop", true, fmt.Sprintf("Looping over collection %s", colVar))

		items, isArray := colRaw.([]interface{})
		if isArray && len(items) > 0 {
			vm.Logs = append(vm.Logs, fmt.Sprintf("[Loop] Iterating over %d items in collection \"%s\"", len(items), colVar))
			backupVal := vm.Variables[itemVar]

			for idx, item := range items {
				if vm.Halted {
					break
				}
				// Flatten fields if item is an object/map
				if m, ok := item.(map[string]interface{}); ok {
					vm.Variables[itemVar] = m
					for k, v := range m {
						vm.Variables[k] = v
					}
				} else {
					vm.Variables[itemVar] = item
				}

				vm.Logs = append(vm.Logs, fmt.Sprintf("[Loop] --- Item %d ---", idx+1))
				vm.evaluateBlock(node.Blocks[0])
			}

			// Restore collection loop context
			if backupVal != nil {
				vm.Variables[itemVar] = backupVal
			} else {
				delete(vm.Variables, itemVar)
			}
		} else {
			vm.Logs = append(vm.Logs, fmt.Sprintf("[Loop] Collection \"%s\" empty or not an array. Skipping.", colVar))
		}

	case OpIf:
		var cond ConditionGroup
		json.Unmarshal([]byte(node.JSONArgs[0]), &cond)

		result := vm.evaluateCondition(cond)
		vm.addStep(node.ID, "if", result, fmt.Sprintf("Evaluating IF branch condition. Evaluated to: %t", result))

		if result {
			vm.Logs = append(vm.Logs, "[If] Condition matched. Executing then-block.")
			vm.evaluateBlock(node.Blocks[0])
		} else {
			elseifMatched := false
			// Node.Blocks offsets: index 0 is then-block. Index 1..N are else-ifs. Last is else block.
			// Node.JSONArgs offsets: index 0 is if condition. Index 1..N are else-if conditions.
			elifCount := len(node.JSONArgs) - 1
			for i := 0; i < elifCount; i++ {
				var elifCond ConditionGroup
				json.Unmarshal([]byte(node.JSONArgs[1+i]), &elifCond)
				elifResult := vm.evaluateCondition(elifCond)

				vm.addStep(node.ID, "else-if", elifResult, fmt.Sprintf("Evaluating ElseIf condition %d. Evaluated to: %t", i+1, elifResult))
				if elifResult {
					vm.Logs = append(vm.Logs, fmt.Sprintf("[If] ElseIf condition %d matched. Executing else-if-block.", i+1))
					vm.evaluateBlock(node.Blocks[1+i])
					elseifMatched = true
					break
				}
			}

			if !elseifMatched {
				elseBlockIdx := 1 + elifCount
				if elseBlockIdx < len(node.Blocks) && len(node.Blocks[elseBlockIdx]) > 0 {
					vm.Logs = append(vm.Logs, "[If] Conditions failed. Executing else-block.")
					vm.evaluateBlock(node.Blocks[elseBlockIdx])
				}
			}
		}

	case OpMacro:
		name := node.StrArgs[0]
		vm.addStep(node.ID, "macro", true, fmt.Sprintf("Executing Macro block: \"%s\"", name))
		vm.evaluateBlock(node.Blocks[0])
	}
}

func (vm *BplVM) resolveLogMessage(message string) string {
	msg := message
	for k, v := range vm.Variables {
		placeholder := fmt.Sprintf("${%s}", k)
		msg = strings.ReplaceAll(msg, placeholder, fmt.Sprintf("%v", v))
	}
	return msg
}

func (vm *BplVM) evaluateCondition(cond ConditionGroup) bool {
	if cond.Type == "condition-group" {
		if cond.Operator == "AND" {
			for _, sub := range cond.Conditions {
				if !vm.evaluateCondition(sub) {
					return false
				}
			}
			return true
		} else { // OR
			for _, sub := range cond.Conditions {
				if vm.evaluateCondition(sub) {
					return true
				}
			}
			return false
		}
	} else if cond.Single != nil {
		single := cond.Single
		rawVal := vm.Variables[single.Field]

		if single.Operator == OpExists {
			return rawVal != nil
		}
		if single.Operator == OpIsEmpty {
			if rawVal == nil {
				return true
			}
			if s, ok := rawVal.(string); ok && strings.TrimSpace(s) == "" {
				return true
			}
			if arr, ok := rawVal.([]interface{}); ok && len(arr) == 0 {
				return true
			}
			return false
		}

		varVal := rawVal
		checkVal := single.Value

		if single.IsValueIdentifier {
			if identVal, ok := vm.Variables[single.Value]; ok {
				checkVal = fmt.Sprintf("%v", identVal)
			} else {
				checkVal = ""
			}
		}

		return vm.compareValues(varVal, single.Operator, checkVal)
	}
	return false
}

func (vm *BplVM) compareValues(varVal interface{}, operator BplOperator, checkVal string) bool {
	varStr := ""
	if varVal != nil {
		varStr = fmt.Sprintf("%v", varVal)
	}

	// Double Coercion
	vNum, varIsNumeric := strconv.ParseFloat(varStr, 64)
	cNum, checkIsNumeric := strconv.ParseFloat(checkVal, 64)
	isNumeric := varIsNumeric == nil && checkIsNumeric == nil && varStr != "" && checkVal != ""

	// Boolean checks
	isVarBool := varStr == "true" || varStr == "false"
	isCheckBool := checkVal == "true" || checkVal == "false"
	if isVarBool && isCheckBool {
		vBool := varStr == "true"
		cBool := checkVal == "true"
		if operator == "equals" || operator == "==" {
			return vBool == cBool
		}
		if operator == "notEquals" || operator == "!=" {
			return vBool != cBool
		}
	}

	switch operator {
	case "equals", "==":
		if isNumeric {
			return math.Abs(vNum-cNum) < 1e-9
		}
		return strings.ToLower(varStr) == strings.ToLower(checkVal)

	case "notEquals", "!=":
		if isNumeric {
			return math.Abs(vNum-cNum) >= 1e-9
		}
		return strings.ToLower(varStr) != strings.ToLower(checkVal)

	case "greaterThan", ">":
		if isNumeric {
			return vNum > cNum
		}
		return strings.ToLower(varStr) > strings.ToLower(checkVal)

	case "lessThan", "<":
		if isNumeric {
			return vNum < cNum
		}
		return strings.ToLower(varStr) < strings.ToLower(checkVal)

	case "greaterThanOrEqual", ">=":
		if isNumeric {
			return vNum >= cNum
		}
		return strings.ToLower(varStr) >= strings.ToLower(checkVal)

	case "lessThanOrEqual", "<=":
		if isNumeric {
			return vNum <= cNum
		}
		return strings.ToLower(varStr) <= strings.ToLower(checkVal)

	case "contains":
		return strings.Contains(strings.ToLower(varStr), strings.ToLower(checkVal))

	case "startsWith":
		return strings.HasPrefix(strings.ToLower(varStr), strings.ToLower(checkVal))

	case "endsWith":
		return strings.HasSuffix(strings.ToLower(varStr), strings.ToLower(checkVal))

	case "in":
		parts := strings.Split(checkVal, ",")
		for _, p := range parts {
			if strings.TrimSpace(strings.ToLower(p)) == strings.ToLower(varStr) {
				return true
			}
		}
		return false

	case "notIn":
		parts := strings.Split(checkVal, ",")
		matched := false
		for _, p := range parts {
			if strings.TrimSpace(strings.ToLower(p)) == strings.ToLower(varStr) {
				matched = true
				break
			}
		}
		return !matched
	}

	return false
}

func (vm *BplVM) addStep(nodeID string, nodeType string, executed bool, description string) {
	snap := make(map[string]interface{})
	for k, v := range vm.Variables {
		snap[k] = v
	}
	logsCopy := make([]string, len(vm.Logs))
	copy(logsCopy, vm.Logs)

	vm.Trace = append(vm.Trace, TraceStep{
		CurrentNodeID:    nodeID,
		NodeType:         nodeType,
		Executed:         executed,
		VariableSnapshot: snap,
		Logs:             logsCopy,
		Description:      fmt.Sprintf("[%s] %s", strings.ToUpper(nodeType), description),
	})
}
