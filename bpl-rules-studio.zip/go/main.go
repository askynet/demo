//go:build !js
package main

import (
	"encoding/base64"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"sync"
	"time"
)

// Global map to hold active running VM states for interactive sessions
type ActiveSession struct {
	VM        *BplVM
	Variables map[string]interface{}
}

var (
	sessions     = make(map[string]*ActiveSession)
	sessionsMu   sync.Mutex
	sessionIDGen = 0
)

func main() {
	// 1. AST JSON Compilation Endpoint
	http.HandleFunc("/api/compile", handleCompile)

	// 2. Execute Compiled Binary (with support for intermediate user inputs)
	http.HandleFunc("/api/execute", handleExecute)

	// 3. Resume Execution with Interactive Prompt Output
	http.HandleFunc("/api/resume", handleResume)

	port := "8080"
	fmt.Printf("[Go Engine] Compiler and VM server listening on port %s...\n", port)
	if err := http.ListenAndServe(":"+port, nil); err != nil {
		fmt.Printf("Error starting server: %v\n", err)
	}
}

type CompileRequest struct {
	AST json.RawMessage `json:"ast"`
}

type CompileResponse struct {
	Binary string `json:"binary"` // Base64 encoded compiled bytecode
	Error  string `json:"error,omitempty"`
}

func handleCompile(w http.ResponseWriter, r *http.Request) {
	w.Header().Set("Content-Type", "application/json")
	w.Header().Set("Access-Control-Allow-Origin", "*")
	w.Header().Set("Access-Control-Allow-Methods", "POST, OPTIONS")
	w.Header().Set("Access-Control-Allow-Headers", "Content-Type")

	if r.Method == "OPTIONS" {
		return
	}

	if r.Method != "POST" {
		http.Error(w, "Method not allowed", http.StatusMethodNotAllowed)
		return
	}

	body, err := io.ReadAll(r.Body)
	if err != nil {
		json.NewEncoder(w).Encode(CompileResponse{Error: "Failed to read body"})
		return
	}

	var req CompileRequest
	if err := json.Unmarshal(body, &req); err != nil {
		json.NewEncoder(w).Encode(CompileResponse{Error: fmt.Sprintf("Invalid JSON: %v", err)})
		return
	}

	// Compile the AST to raw bytecode
	binBytes, err := CompileAST(req.AST)
	if err != nil {
		json.NewEncoder(w).Encode(CompileResponse{Error: fmt.Sprintf("Compilation failed: %v", err)})
		return
	}

	// Base64 encode for simple JSON transmission
	b64Str := base64.StdEncoding.EncodeToString(binBytes)

	json.NewEncoder(w).Encode(CompileResponse{
		Binary: "BPLG1:" + b64Str,
	})
}

type ExecuteRequest struct {
	BinaryStr string                 `json:"binary"`
	Variables map[string]interface{} `json:"variables"`
}

type ExecuteResponse struct {
	SessionID   string                 `json:"sessionId,omitempty"`
	Status      string                 `json:"status"` // "completed" or "suspended"
	Logs        []string               `json:"logs"`
	Trace       []TraceStep            `json:"trace"`
	Variables   map[string]interface{} `json:"variables"`
	PromptReq   map[string]interface{} `json:"promptRequest,omitempty"` // Prompts requested in this step
	Error       string                 `json:"error,omitempty"`
}

func handleExecute(w http.ResponseWriter, r *http.Request) {
	w.Header().Set("Content-Type", "application/json")
	w.Header().Set("Access-Control-Allow-Origin", "*")
	w.Header().Set("Access-Control-Allow-Methods", "POST, OPTIONS")
	w.Header().Set("Access-Control-Allow-Headers", "Content-Type")

	if r.Method == "OPTIONS" {
		return
	}

	if r.Method != "POST" {
		http.Error(w, "Method not allowed", http.StatusMethodNotAllowed)
		return
	}

	body, err := io.ReadAll(r.Body)
	if err != nil {
		json.NewEncoder(w).Encode(ExecuteResponse{Error: "Failed to read request"})
		return
	}

	var req ExecuteRequest
	if err := json.Unmarshal(body, &req); err != nil {
		json.NewEncoder(w).Encode(ExecuteResponse{Error: fmt.Sprintf("Invalid payload: %v", err)})
		return
	}

	// Decode B64 compiled string
	if len(req.BinaryStr) < 7 || req.BinaryStr[:6] != "BPLG1:" {
		json.NewEncoder(w).Encode(ExecuteResponse{Error: "Invalid binary format string (must start with BPLG1:)"})
		return
	}

	binBytes, err := base64.StdEncoding.DecodeString(req.BinaryStr[6:])
	if err != nil {
		json.NewEncoder(w).Encode(ExecuteResponse{Error: fmt.Sprintf("Invalid base64 payload: %v", err)})
		return
	}

	// Decode binary bytes back to ExecNode AST
	rootNode, err := DecodeBytecode(binBytes)
	if err != nil {
		json.NewEncoder(w).Encode(ExecuteResponse{Error: fmt.Sprintf("Bytecode decoding failed: %v", err)})
		return
	}

	// Initialize the virtual machine worker
	vm := NewVM(req.Variables)

	sessionsMu.Lock()
	sessionIDGen++
	sessID := fmt.Sprintf("sess_%d_%d", sessionIDGen, time.Now().UnixNano())
	sessions[sessID] = &ActiveSession{VM: vm, Variables: vm.Variables}
	sessionsMu.Unlock()

	// Launch VM execution in a separate Go Worker Goroutine
	var promptRequest map[string]interface{}
	status := "completed"

	go func() {
		vm.Execute(rootNode)
		close(vm.RequestChan) // Done executing
	}()

	// Monitor the worker channel for prompts/getkeys or completion
	select {
	case req, ok := <-vm.RequestChan:
		if ok {
			status = "suspended"
			promptRequest = req
		}
	case <-time.After(5 * time.Second): // Safety timeout
		status = "timeout"
	}

	// If execution is completed, prune the session
	if status == "completed" {
		sessionsMu.Lock()
		delete(sessions, sessID)
		sessionsMu.Unlock()
		sessID = ""
	}

	json.NewEncoder(w).Encode(ExecuteResponse{
		SessionID: sessID,
		Status:    status,
		Logs:      vm.Logs,
		Trace:     vm.Trace,
		Variables: vm.Variables,
		PromptReq: promptRequest,
	})
}

type ResumeRequest struct {
	SessionID string `json:"sessionId"`
	Value     string `json:"value"` // Input user entered
}

func handleResume(w http.ResponseWriter, r *http.Request) {
	w.Header().Set("Content-Type", "application/json")
	w.Header().Set("Access-Control-Allow-Origin", "*")
	w.Header().Set("Access-Control-Allow-Methods", "POST, OPTIONS")
	w.Header().Set("Access-Control-Allow-Headers", "Content-Type")

	if r.Method == "OPTIONS" {
		return
	}

	if r.Method != "POST" {
		http.Error(w, "Method not allowed", http.StatusMethodNotAllowed)
		return
	}

	body, err := io.ReadAll(r.Body)
	if err != nil {
		json.NewEncoder(w).Encode(ExecuteResponse{Error: "Failed to read request"})
		return
	}

	var req ResumeRequest
	if err := json.Unmarshal(body, &req); err != nil {
		json.NewEncoder(w).Encode(ExecuteResponse{Error: fmt.Sprintf("Invalid JSON: %v", err)})
		return
	}

	sessionsMu.Lock()
	sess, exists := sessions[req.SessionID]
	sessionsMu.Unlock()

	if !exists {
		json.NewEncoder(w).Encode(ExecuteResponse{Error: "Session not found or expired"})
		return
	}

	vm := sess.VM

	// Feed prompt input back into the blocking Go channel in the VM goroutine
	select {
	case vm.PromptChan <- req.Value:
		// Sent successfully
	case <-time.After(2 * time.Second):
		json.NewEncoder(w).Encode(ExecuteResponse{Error: "VM was not waiting for input"})
		return
	}

	// Wait for next prompt request or VM completion
	var promptRequest map[string]interface{}
	status := "completed"

	select {
	case nextReq, ok := <-vm.RequestChan:
		if ok {
			status = "suspended"
			promptRequest = nextReq
		}
	case <-time.After(5 * time.Second):
		status = "timeout"
	}

	if status == "completed" {
		sessionsMu.Lock()
		delete(sessions, req.SessionID)
		sessionsMu.Unlock()
	}

	json.NewEncoder(w).Encode(ExecuteResponse{
		SessionID: req.SessionID,
		Status:    status,
		Logs:      vm.Logs,
		Trace:     vm.Trace,
		Variables: vm.Variables,
		PromptReq: promptRequest,
	})
}
