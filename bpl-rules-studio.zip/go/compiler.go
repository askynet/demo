package main

import (
	"bytes"
	"encoding/binary"
	"encoding/json"
	"fmt"
)

// Opcodes for our custom BPL binary bytecode format
const (
	OpNop          byte = 0
	OpScript       byte = 1
	OpLog          byte = 2
	OpAssign       byte = 3
	OpJump         byte = 4
	OpLabel        byte = 5
	OpReturn       byte = 6
	OpInclude      byte = 7
	OpImport       byte = 8
	OpValidate     byte = 9
	OpClearScreen  byte = 10
	OpCode         byte = 11
	OpPrompt       byte = 12
	OpGetKey       byte = 13
	OpOnlyIf       byte = 14
	OpCallApi      byte = 15
	OpSwitch       byte = 16
	OpLoop         byte = 17
	OpIf           byte = 18
	OpMacro        byte = 19
)

// CompileAST compiles an AST JSON string into custom raw binary bytes
func CompileAST(astJson []byte) ([]byte, error) {
	var root ASTNode
	if err := json.Unmarshal(astJson, &root); err != nil {
		return nil, fmt.Errorf("failed to parse AST JSON: %v", err)
	}

	buf := new(bytes.Buffer)

	// 1. Write Magic Header (4 bytes)
	buf.Write([]byte("BPLG"))

	// 2. Write Version (1 byte)
	buf.WriteByte(1)

	// 3. Compile the root script node
	if err := compileNodeToBuffer(root, buf); err != nil {
		return nil, fmt.Errorf("compilation error: %v", err)
	}

	return buf.Bytes(), nil
}

// Helper to write string to buffer
func writeString(buf *bytes.Buffer, s string) {
	b := []byte(s)
	binary.Write(buf, binary.BigEndian, uint32(len(b)))
	buf.Write(b)
}

// Helper to write bool to buffer
func writeBool(buf *bytes.Buffer, b bool) {
	if b {
		buf.WriteByte(1)
	} else {
		buf.WriteByte(0)
	}
}

// Helper to compile a slice of ASTNodes
func compileBlockToBuffer(nodes []ASTNode, buf *bytes.Buffer) error {
	binary.Write(buf, binary.BigEndian, uint32(len(nodes)))
	for _, n := range nodes {
		if err := compileNodeToBuffer(n, buf); err != nil {
			return err
		}
	}
	return nil
}

// Main recursive compiler routine mapping AST nodes to packed bytecode instructions
func compileNodeToBuffer(node ASTNode, buf *bytes.Buffer) error {
	// Write Node ID for tracing (for frontend highlight support)
	writeString(buf, node.ID)

	switch node.Type {
	case "script":
		buf.WriteByte(OpScript)
		writeString(buf, node.Name)
		return compileBlockToBuffer(node.Children, buf)

	case "log":
		buf.WriteByte(OpLog)
		writeString(buf, node.Message)

	case "assign":
		buf.WriteByte(OpAssign)
		writeString(buf, node.Variable)
		writeString(buf, node.Value)
		writeBool(buf, node.IsValueIdentifier)

	case "jump":
		buf.WriteByte(OpJump)
		writeString(buf, node.Target)

	case "label":
		buf.WriteByte(OpLabel)
		writeString(buf, node.Name)

	case "return":
		buf.WriteByte(OpReturn)

	case "include":
		buf.WriteByte(OpInclude)
		writeString(buf, node.Path)
		// Write parameter slice as JSON string
		paramBytes, _ := json.Marshal(node.Parameters)
		writeString(buf, string(paramBytes))

	case "import":
		buf.WriteByte(OpImport)
		writeString(buf, node.File)

	case "validation":
		buf.WriteByte(OpValidate)
		// Serialize ConditionGroup to JSON string
		condBytes, _ := json.Marshal(node.Condition)
		writeString(buf, string(condBytes))
		writeString(buf, node.ErrorMessage)

	case "clearscreen":
		buf.WriteByte(OpClearScreen)

	case "code":
		buf.WriteByte(OpCode)

	case "prompt":
		buf.WriteByte(OpPrompt)
		writeString(buf, node.Message)
		writeString(buf, node.Variable)

	case "getkey":
		buf.WriteByte(OpGetKey)
		writeString(buf, node.Variable)

	case "only_if":
		buf.WriteByte(OpOnlyIf)
		writeString(buf, node.Variable)
		
		// Serialize cases to nested representation
		binary.Write(buf, binary.BigEndian, uint32(len(node.Cases)))
		for _, c := range node.Cases {
			// Write string list of matching values
			valsBytes, _ := json.Marshal(c.Values)
			writeString(buf, string(valsBytes))
			// Write case block
			if err := compileBlockToBuffer(c.Block, buf); err != nil {
				return err
			}
		}

	case "api-call":
		buf.WriteByte(OpCallApi)
		writeString(buf, node.Url)
		paramBytes, _ := json.Marshal(node.Parameters)
		writeString(buf, string(paramBytes))
		writeString(buf, node.ResponseVar)

	case "switch":
		buf.WriteByte(OpSwitch)
		writeString(buf, node.Variable)
		
		// Serialize branches
		binary.Write(buf, binary.BigEndian, uint32(len(node.Cases)))
		for _, c := range node.Cases {
			writeString(buf, c.Value)
			if err := compileBlockToBuffer(c.Block, buf); err != nil {
				return err
			}
		}
		// Serialize default branch
		if err := compileBlockToBuffer(node.DefaultBlock, buf); err != nil {
			return err
		}

	case "loop":
		buf.WriteByte(OpLoop)
		writeString(buf, node.ItemVar)
		writeString(buf, node.CollectionVar)
		if err := compileBlockToBuffer(node.Block, buf); err != nil {
			return err
		}

	case "if":
		buf.WriteByte(OpIf)
		condBytes, _ := json.Marshal(node.Condition)
		writeString(buf, string(condBytes))
		
		// Write then-block
		if err := compileBlockToBuffer(node.ThenBlock, buf); err != nil {
			return err
		}

		// Write else-if blocks count
		binary.Write(buf, binary.BigEndian, uint32(len(node.ElseIfBlocks)))
		for _, elif := range node.ElseIfBlocks {
			elifCondBytes, _ := json.Marshal(elif.Condition)
			writeString(buf, string(elifCondBytes))
			if err := compileBlockToBuffer(elif.Block, buf); err != nil {
				return err
			}
		}

		// Write else-block
		if err := compileBlockToBuffer(node.ElseBlock, buf); err != nil {
			return err
		}

	case "macro":
		buf.WriteByte(OpMacro)
		writeString(buf, node.Name)
		if err := compileBlockToBuffer(node.Block, buf); err != nil {
			return err
		}

	default:
		buf.WriteByte(OpNop)
	}

	return nil
}
