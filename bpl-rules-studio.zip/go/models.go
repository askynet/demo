package main

import (
	"encoding/json"
)

// BplOperator represents comparison operators
type BplOperator string

const (
	OpEquals             BplOperator = "equals"
	OpNotEquals          BplOperator = "notEquals"
	OpGreaterThan        BplOperator = "greaterThan"
	OpLessThan           BplOperator = "lessThan"
	OpGreaterThanOrEqual BplOperator = "greaterThanOrEqual"
	OpLessThanOrEqual    BplOperator = "lessThanOrEqual"
	OpContains           BplOperator = "contains"
	OpStartsWith         BplOperator = "startsWith"
	OpEndsWith           BplOperator = "endsWith"
	OpIn                 BplOperator = "in"
	OpNotIn              BplOperator = "notIn"
	OpExists             BplOperator = "exists"
	OpIsEmpty            BplOperator = "isEmpty"
)

// Condition represents a single comparison
type Condition struct {
	Field             string      `json:"field"`
	Operator          BplOperator `json:"operator"`
	Value             string      `json:"value"`
	IsValueIdentifier bool        `json:"isValueIdentifier,omitempty"`
}

// ConditionGroup represents compound conditions
type ConditionGroup struct {
	Type       string           `json:"type"` // "condition-group"
	Operator   string           `json:"operator"` // "AND" or "OR"
	Conditions []ConditionGroup `json:"conditions,omitempty"` // nested or single
	Single     *Condition       // Populated during unmarshalling if not a group
}

// UnmarshalJSON implements custom deserialization for Condition/ConditionGroup
func (cg *ConditionGroup) UnmarshalJSON(data []byte) error {
	type Alias ConditionGroup
	var aux Alias
	if err := json.Unmarshal(data, &aux); err != nil {
		return err
	}
	*cg = ConditionGroup(aux)

	// If it doesn't have "condition-group" type, it's a single Condition
	var raw map[string]interface{}
	if err := json.Unmarshal(data, &raw); err != nil {
		return err
	}

	if raw["type"] != "condition-group" {
		var cond Condition
		if err := json.Unmarshal(data, &cond); err == nil {
			cg.Single = &cond
		}
	}
	return nil
}

// ASTNode represents any generic BPL node
type ASTNode struct {
	ID                string            `json:"id"`
	Type              string            `json:"type"`
	Name              string            `json:"name,omitempty"`
	Message           string            `json:"message,omitempty"`
	Variable          string            `json:"variable,omitempty"`
	Value             string            `json:"value,omitempty"`
	IsValueIdentifier bool              `json:"isValueIdentifier,omitempty"`
	Target            string            `json:"target,omitempty"`
	Path              string            `json:"path,omitempty"`
	File              string            `json:"file,omitempty"`
	ErrorMessage      string            `json:"errorMessage,omitempty"`
	Url               string            `json:"url,omitempty"`
	ResponseVar       string            `json:"responseVar,omitempty"`
	Parameters        []string          `json:"parameters,omitempty"`
	Children          []ASTNode         `json:"children,omitempty"`
	ThenBlock         []ASTNode         `json:"thenBlock,omitempty"`
	ElseBlock         []ASTNode         `json:"elseBlock,omitempty"`
	ElseIfBlocks      []ElseIfBlock     `json:"elseIfBlocks,omitempty"`
	Cases             []CaseBlock       `json:"cases,omitempty"`
	DefaultBlock      []ASTNode         `json:"defaultBlock,omitempty"`
	Block             []ASTNode         `json:"block,omitempty"`
	Condition         *ConditionGroup   `json:"condition,omitempty"`
	ItemVar           string            `json:"itemVar,omitempty"`
	CollectionVar     string            `json:"collectionVar,omitempty"`
}

type ElseIfBlock struct {
	Condition ConditionGroup `json:"condition"`
	Block     []ASTNode      `json:"block"`
}

type CaseBlock struct {
	Value  string    `json:"value,omitempty"`  // for Switch
	Values []string  `json:"values,omitempty"` // for OnlyIf
	Block  []ASTNode `json:"block"`
}
