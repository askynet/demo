//go:build js && wasm
package main

import (
	"encoding/base64"
	"encoding/json"
	"fmt"
	"syscall/js"
)

var (
	activeVM *BplVM
)

func main() {
	c := make(chan struct{}, 0)

	// Expose Go functions to JS environment
	js.Global().Set("bplCompile", js.FuncOf(jsCompile))
	js.Global().Set("bplExecute", js.FuncOf(jsExecute))
	js.Global().Set("bplSubmitPromptResponse", js.FuncOf(jsSubmitPromptResponse))

	fmt.Println("[Go WASM Engine] VM loaded and ready.")

	// Keep Go WebAssembly runtime alive
	<-c
}

// jsCompile binds our Go compiler to the JS global scope
func jsCompile(this js.Value, args []js.Value) any {
	if len(args) < 1 {
		return "Error: missing AST JSON argument"
	}
	astStr := args[0].String()

	binBytes, err := CompileAST([]byte(astStr))
	if err != nil {
		return fmt.Sprintf("Error compiling: %v", err)
	}

	b64Str := base64.StdEncoding.EncodeToString(binBytes)
	return "BPLG1:" + b64Str
}

// jsExecute binds our Go virtual machine worker to the JS global scope
func jsExecute(this js.Value, args []js.Value) any {
	if len(args) < 2 {
		return "Error: missing parameters (binaryStr, initialVarsJson)"
	}
	binaryStr := args[0].String()
	varsJson := args[1].String()

	// Parse initial variables
	var vars map[string]interface{}
	if err := json.Unmarshal([]byte(varsJson), &vars); err != nil {
		return fmt.Sprintf("Error parsing variables JSON: %v", err)
	}

	// Validate binary header
	if len(binaryStr) < 7 || binaryStr[:6] != "BPLG1:" {
		return "Error: invalid binary header"
	}

	binBytes, err := base64.StdEncoding.DecodeString(binaryStr[6:])
	if err != nil {
		return fmt.Sprintf("Error decoding base64: %v", err)
	}

	rootNode, err := DecodeBytecode(binBytes)
	if err != nil {
		return fmt.Sprintf("Error decoding bytecode: %v", err)
	}

	// Instantiate VM
	activeVM = NewVM(vars)

	// Setup a background channel coordinator to communicate suspended prompts back to JS
	go func() {
		for req := range activeVM.RequestChan {
			// Trigger a JS event callback or postMessage to notify UI that we need user prompt input
			if onPromptFunc := js.Global().Get("onBplPromptRequired"); onPromptFunc.Type() == js.TypeFunction {
				reqJson, _ := json.Marshal(req)
				onPromptFunc.Invoke(string(reqJson))
			}
		}
	}()

	// Execute the bytecode synchronously in this call (as it is running inside a Worker thread)
	activeVM.Execute(rootNode)

	// Execution finished, return trace results to JS
	respMap := map[string]interface{}{
		"status":    "completed",
		"logs":      activeVM.Logs,
		"trace":     activeVM.Trace,
		"variables": activeVM.Variables,
	}

	respJson, _ := json.Marshal(respMap)
	return string(respJson)
}

// jsSubmitPromptResponse allows Javascript to feed prompt answers back to the VM channel
func jsSubmitPromptResponse(this js.Value, args []js.Value) any {
	if len(args) < 1 {
		return false
	}
	responseVal := args[0].String()

	if activeVM != nil {
		go func() {
			activeVM.PromptChan <- responseVal
		}()
		return true
	}
	return false
}
