/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

// Define Web Worker global typing
declare const self: Worker;

let wasmInstance: any = null;
let goRuntime: any = null;
let pendingPromptResolve: ((value: string) => void) | null = null;

// Helpers for condition evaluation matching BPL specifications
function compareValues(varVal: any, operator: string, checkVal: string): boolean {
  const varStr = varVal !== undefined && varVal !== null ? String(varVal) : '';
  const checkStr = checkVal;

  const isNumeric = varVal !== undefined && !isNaN(Number(varStr)) && !isNaN(Number(checkStr)) && varStr !== '' && checkStr !== '';
  const vNum = isNumeric ? Number(varStr) : NaN;
  const cNum = isNumeric ? Number(checkStr) : NaN;

  const isVarBool = varStr === 'true' || varStr === 'false';
  const isCheckBool = checkStr === 'true' || checkStr === 'false';
  if (isVarBool && isCheckBool) {
    const vBool = varStr === 'true';
    const cBool = checkStr === 'true';
    if (operator === 'equals' || operator === '==') return vBool === cBool;
    if (operator === 'notEquals' || operator === '!=') return vBool !== cBool;
  }

  switch (operator) {
    case 'equals':
    case '==':
      if (isNumeric) return vNum === cNum;
      return varStr.toLowerCase() === checkStr.toLowerCase();

    case 'notEquals':
    case '!=':
      if (isNumeric) return vNum !== cNum;
      return varStr.toLowerCase() !== checkStr.toLowerCase();

    case 'greaterThan':
    case '>':
      if (isNumeric) return vNum > cNum;
      return varStr.toLowerCase() > checkStr.toLowerCase();

    case 'lessThan':
    case '<':
      if (isNumeric) return vNum < cNum;
      return varStr.toLowerCase() < checkStr.toLowerCase();

    case 'greaterThanOrEqual':
    case '>=':
      if (isNumeric) return vNum >= cNum;
      return varStr.toLowerCase() >= checkStr.toLowerCase();

    case 'lessThanOrEqual':
    case '<=':
      if (isNumeric) return vNum <= cNum;
      return varStr.toLowerCase() <= checkStr.toLowerCase();

    case 'contains':
      return varStr.toLowerCase().includes(checkStr.toLowerCase());

    case 'startsWith':
      return varStr.toLowerCase().startsWith(checkStr.toLowerCase());

    case 'endsWith':
      return varStr.toLowerCase().endsWith(checkStr.toLowerCase());

    case 'in': {
      const list = checkStr.split(',').map((x) => x.trim().toLowerCase());
      return list.includes(varStr.toLowerCase());
    }

    case 'notIn': {
      const list = checkStr.split(',').map((x) => x.trim().toLowerCase());
      return !list.includes(varStr.toLowerCase());
    }

    default:
      return false;
  }
}

function evaluateCondition(cond: any, vars: any): boolean {
  if (!cond) return false;
  if (cond.type === 'condition-group' || 'operator' in cond) {
    const operator = cond.operator || 'AND';
    const conditions = cond.conditions || [];
    if (operator === 'AND') {
      return conditions.every((c: any) => evaluateCondition(c, vars));
    } else {
      return conditions.some((c: any) => evaluateCondition(c, vars));
    }
  } else {
    const rawVal = vars[cond.field];
    if (cond.operator === 'exists') {
      return rawVal !== undefined && rawVal !== null;
    }
    if (cond.operator === 'isEmpty') {
      if (rawVal === undefined || rawVal === null) return true;
      if (typeof rawVal === 'string' && rawVal.trim() === '') return true;
      if (Array.isArray(rawVal) && rawVal.length === 0) return true;
      return false;
    }

    let checkVal = cond.value;
    if (cond.isValueIdentifier) {
      checkVal = String(vars[cond.value] !== undefined ? vars[cond.value] : '');
    }
    return compareValues(rawVal, cond.operator, checkVal);
  }
}

function resolveLogMessage(message: string, vars: any): string {
  if (!message) return '';
  return message.replace(/\$\{([a-zA-Z_][a-zA-Z0-9_\.]*)\}/g, (_, varPath) => {
    const parts = varPath.split('.');
    let current: any = vars;
    for (const part of parts) {
      if (current === null || current === undefined) {
        return 'undefined';
      }
      current = current[part];
    }
    return current !== undefined ? String(current) : 'undefined';
  });
}

// Simulated Go BPL Compiler & Virtual Machine inside Worker Thread
class SimulatedGoVM {
  private variables: any = {};
  private logs: string[] = [];
  private trace: any[] = [];
  private halted: boolean = false;
  private jumpToLabel: string | null = null;
  private outputIncludes: any[] = [];

  constructor(initialVars: any) {
    this.variables = { ...initialVars };
  }

  public async run(ast: any): Promise<any> {
    this.logs = ['[Go Engine] VM initialized (Go VM Worker Fallback).', '[Go Engine] Spawning Worker Goroutine...'];
    this.trace = [];
    this.halted = false;
    this.jumpToLabel = null;
    this.outputIncludes = [];

    // Root node step
    this.addStep(ast.id, 'script', true, `Starting BPL script compiled bytecode: "${ast.name || 'Anonymous'}"`);

    if (ast.children && Array.isArray(ast.children)) {
      await this.evaluateBlock(ast.children);
    }

    this.logs.push('[Go Engine] Process finished successfully (exit status 0).');
    this.addStep(ast.id, 'script', true, 'Rule execution completed.');

    return {
      status: 'completed',
      logs: this.logs,
      trace: this.trace,
      variables: this.variables
    };
  }

  private async evaluateBlock(nodes: any[]) {
    for (const node of nodes) {
      if (this.halted) return;

      if (this.jumpToLabel !== null) {
        if (node.type === 'label' && node.name === this.jumpToLabel) {
          this.jumpToLabel = null;
          this.addStep(node.id, 'label', true, `Landing on label "${node.name}" from jump.`);
        } else {
          this.addStep(node.id, 'skip', false, `Skipping node (jumping to label "${this.jumpToLabel}").`);
          continue;
        }
      }

      await this.evaluateNode(node);
    }
  }

  private async evaluateNode(node: any) {
    if (this.halted) return;

    switch (node.type) {
      case 'label':
        this.addStep(node.id, 'label', true, `Label "${node.name}" declared.`);
        break;

      case 'log': {
        const msg = resolveLogMessage(node.message, this.variables);
        this.logs.push(`[Log] ${msg}`);
        this.addStep(node.id, 'log', true, `Log: ${msg}`);
        break;
      }

      case 'assign': {
        const originalVal = this.variables[node.variable];
        let assignedVal: any = node.value;

        if (node.isValueIdentifier) {
          assignedVal = this.variables[node.value];
        } else if (node.value === 'true') {
          assignedVal = true;
        } else if (node.value === 'false') {
          assignedVal = false;
        } else if (!isNaN(Number(node.value)) && node.value !== '') {
          assignedVal = Number(node.value);
        }

        this.variables[node.variable] = assignedVal;
        this.logs.push(`[Assign] Set ${node.variable} = ${String(assignedVal)}`);
        this.addStep(node.id, 'assign', true, `Set ${node.variable} = ${String(assignedVal)}`);
        break;
      }

      case 'jump':
        this.jumpToLabel = node.target;
        this.logs.push(`[Jump] Branch to label "${node.target}"`);
        this.addStep(node.id, 'jump', true, `Jump to "${node.target}"`);
        break;

      case 'return':
        this.halted = true;
        this.logs.push('[Return] Explicit VM return exit triggered.');
        this.addStep(node.id, 'return', true, 'Exit script execution.');
        break;

      case 'include':
        this.outputIncludes.push({ path: node.path, params: node.parameters || [] });
        this.logs.push(`[Include] Rendered booklet template fragment "${node.path}"`);
        this.addStep(node.id, 'include', true, `Include: ${node.path}`);
        break;

      case 'import':
        this.logs.push(`[Import] Loaded dynamic package "${node.file}"`);
        this.addStep(node.id, 'import', true, `Import: ${node.file}`);
        break;

      case 'validation': {
        const isPassed = evaluateCondition(node.condition, this.variables);
        if (isPassed) {
          this.addStep(node.id, 'validation', true, 'Validation check passed.');
        } else {
          this.halted = true;
          this.logs.push(`[ValidationError] Script validate failed: ${node.errorMessage}`);
          this.addStep(node.id, 'validation', true, `Validate Fail: ${node.errorMessage}`);
        }
        break;
      }

      case 'clearscreen':
        this.logs.push('[System] Console terminal screen cleared');
        this.addStep(node.id, 'clearscreen', true, 'Clear screen');
        break;

      case 'code':
        this.addStep(node.id, 'code', true, 'Inline code block execution');
        break;

      case 'prompt': {
        // Suspend VM execution, post message to main UI thread, and wait for resume input
        this.logs.push(`[Prompt Required] Suspending Goroutine thread on variable: "${node.variable}"`);
        
        self.postMessage({
          type: 'PROMPT_REQUIRED',
          payload: {
            message: node.message || `Enter value for ${node.variable}`,
            variable: node.variable,
            type: 'prompt',
            nodeId: node.id
          }
        });

        // Block on pending input response
        const responseVal = await new Promise<string>((resolve) => {
          pendingPromptResolve = resolve;
        });

        let typedVal: any = responseVal;
        if (!isNaN(Number(responseVal)) && responseVal !== '') {
          typedVal = Number(responseVal);
        } else if (responseVal === 'true') {
          typedVal = true;
        } else if (responseVal === 'false') {
          typedVal = false;
        }

        this.variables[node.variable] = typedVal;
        this.logs.push(`[Prompt] Response received: ${node.variable} = ${String(typedVal)}`);
        this.addStep(node.id, 'prompt', true, `Prompt response received: ${node.variable} = ${String(typedVal)}`);
        break;
      }

      case 'getkey': {
        this.logs.push(`[Getkey Required] Suspending Goroutine thread for keypress. Storing in: "${node.variable}"`);

        self.postMessage({
          type: 'PROMPT_REQUIRED',
          payload: {
            message: 'Press enter or any key to continue...',
            variable: node.variable,
            type: 'getkey',
            nodeId: node.id
          }
        });

        const responseKey = await new Promise<string>((resolve) => {
          pendingPromptResolve = resolve;
        });

        this.variables[node.variable] = responseKey || 'Enter';
        this.logs.push(`[Getkey] Pressed Key: ${responseKey}`);
        this.addStep(node.id, 'getkey', true, `Keypress detected: ${responseKey}`);
        break;
      }

      case 'api-call': {
        const url = node.url || '';
        const respVar = node.responseVar || 'api_response';
        let mockVal: any = 720;

        if (url.includes('credit')) {
          const age = Number(this.variables['age'] ?? 30);
          mockVal = age > 25 ? 750 : 610;
        } else if (url.includes('risk')) {
          mockVal = 'Low';
        }

        this.variables[respVar] = mockVal;
        this.logs.push(`[API Call] Resolved fetching ${url} -> Received ${respVar} = ${mockVal}`);
        this.addStep(node.id, 'api-call', true, `API Service Resolved: ${respVar} = ${mockVal}`);
        break;
      }

      case 'switch': {
        const val = String(this.variables[node.variable] ?? '');
        this.logs.push(`[Switch] Evaluating expression: ${node.variable} = "${val}"`);
        this.addStep(node.id, 'switch', true, `Switch evaluating branches on "${node.variable}"`);

        let matched = false;
        if (node.cases && Array.isArray(node.cases)) {
          for (const c of node.cases) {
            if (String(c.value).toLowerCase() === val.toLowerCase()) {
              matched = true;
              this.logs.push(`[Switch] Case matched: "${c.value}"`);
              await this.evaluateBlock(c.block || []);
              break;
            }
          }
        }

        if (!matched && node.defaultBlock) {
          this.logs.push('[Switch] Default case fallback matched.');
          await this.evaluateBlock(node.defaultBlock);
        }
        break;
      }

      case 'only_if': {
        const val = String(this.variables[node.variable] ?? '');
        this.logs.push(`[OnlyIf] Evaluating expression: ${node.variable} = "${val}"`);
        this.addStep(node.id, 'only_if', true, `Evaluating only_if conditional blocks on "${node.variable}"`);

        let matched = false;
        if (node.cases && Array.isArray(node.cases)) {
          for (const c of node.cases) {
            const values = c.values || [];
            const matches = values.some((v: any) => String(v).toLowerCase() === val.toLowerCase());
            if (matches) {
              matched = true;
              this.logs.push(`[OnlyIf] Case matched values: [${values.join(', ')}]`);
              await this.evaluateBlock(c.block || []);
              break;
            }
          }
        }
        break;
      }

      case 'loop': {
        const collection = this.variables[node.collectionVar];
        this.logs.push(`[Loop] Loop block initialization over collection "${node.collectionVar}"`);
        this.addStep(node.id, 'loop', true, `Iterating over collection "${node.collectionVar}"`);

        if (Array.isArray(collection) && collection.length > 0) {
          const backup = this.variables[node.itemVar];
          for (let i = 0; i < collection.length; i++) {
            if (this.halted) break;
            const item = collection[i];
            
            if (item && typeof item === 'object') {
              this.variables[node.itemVar] = item;
              Object.keys(item).forEach((k) => {
                this.variables[k] = item[k];
              });
            } else {
              this.variables[node.itemVar] = item;
            }

            this.logs.push(`[Loop] --- Loop Index [${i + 1}/${collection.length}] ---`);
            await this.evaluateBlock(node.block || []);
          }

          if (backup !== undefined) {
            this.variables[node.itemVar] = backup;
          } else {
            delete this.variables[node.itemVar];
          }
        } else {
          this.logs.push(`[Loop] Collection "${node.collectionVar}" is empty or invalid. Skipping.`);
        }
        break;
      }

      case 'if': {
        const result = evaluateCondition(node.condition, this.variables);
        this.addStep(node.id, 'if', result, `Condition check evaluated to: ${result ? 'TRUE' : 'FALSE'}`);

        if (result) {
          this.logs.push('[If] Condition matched. Executing nested statements.');
          await this.evaluateBlock(node.thenBlock || []);
        } else {
          let elseifMatched = false;
          if (node.elseIfBlocks && Array.isArray(node.elseIfBlocks)) {
            for (const elif of node.elseIfBlocks) {
              const elifRes = evaluateCondition(elif.condition, this.variables);
              this.addStep(node.id, 'else-if', elifRes, `Else-if check evaluated to: ${elifRes ? 'TRUE' : 'FALSE'}`);
              if (elifRes) {
                this.logs.push('[If] Else-if condition matched. Executing nested statements.');
                await this.evaluateBlock(elif.block || []);
                elseifMatched = true;
                break;
              }
            }
          }

          if (!elseifMatched && node.elseBlock) {
            this.logs.push('[If] Executing else statements fallback.');
            await this.evaluateBlock(node.elseBlock);
          }
        }
        break;
      }

      case 'macro':
        this.addStep(node.id, 'macro', true, `Executing Macro: "${node.name}"`);
        await this.evaluateBlock(node.block || []);
        break;
    }
  }

  private addStep(nodeId: string, nodeType: string, executed: boolean, description: string) {
    this.trace.push({
      currentNodeId: nodeId,
      nodeType,
      executed,
      variableSnapshot: { ...this.variables },
      logs: [...this.logs],
      description: `[Go VM] ${description}`
    });
  }
}

self.onmessage = async (e: MessageEvent) => {
  const { type, payload } = e.data;

  switch (type) {
    case 'INIT': {
      try {
        const wasmUrl = payload.wasmUrl;
        
        // Fetch and load the Go WebAssembly Binary (with dynamic fallback if unavailable)
        try {
          const response = await fetch(wasmUrl);
          if (!response.ok) {
            throw new Error(`Fetch failed with status ${response.status}`);
          }
          const buffer = await response.arrayBuffer();

          // Standard Go Wasm runner initialization
          // @ts-ignore
          if (typeof Go !== 'undefined') {
            // @ts-ignore
            const go = new Go(); 
            const result = await WebAssembly.instantiate(buffer, go.importObject);
            
            wasmInstance = result.instance;
            goRuntime = go;
            
            // @ts-ignore
            go.run(wasmInstance);

            // @ts-ignore
            self.onBplPromptRequired = (reqStr: string) => {
              const req = JSON.parse(reqStr);
              self.postMessage({
                type: 'PROMPT_REQUIRED',
                payload: req
              });
            };

            console.log('[Go WASM Engine] Successfully loaded WebAssembly.');
          } else {
            console.warn('[Go WASM Engine] Go runtime loader not found. Using simulation fallback.');
          }
        } catch (fetchErr) {
          console.log('[Go WASM Engine] WebAssembly fetch skipped or failed. Operating in high-fidelity Goroutine simulated VM mode.');
        }

        self.postMessage({ type: 'INIT_SUCCESS' });
      } catch (err: any) {
        self.postMessage({ type: 'INIT_FAILURE', payload: err.message });
      }
      break;
    }

    case 'COMPILE': {
      try {
        const astJsonStr = JSON.stringify(payload.ast);
        let binaryStr = '';
        
        if (wasmInstance) {
          // Call real Go WASM compiler function
          // @ts-ignore
          binaryStr = bplCompile(astJsonStr);
        } else {
          // Simulated packing compiler
          const b64 = btoa(encodeURIComponent(astJsonStr));
          binaryStr = 'BPLG1:' + b64;
        }
        self.postMessage({ type: 'COMPILE_SUCCESS', payload: binaryStr });
      } catch (err: any) {
        self.postMessage({ type: 'COMPILE_ERROR', payload: err.message });
      }
      break;
    }

    case 'EXECUTE': {
      try {
        const { binaryStr, variables, ast } = payload;

        if (wasmInstance) {
          const varsJsonStr = JSON.stringify(variables);
          // @ts-ignore
          const resultsJsonStr = bplExecute(binaryStr, varsJsonStr);
          const results = JSON.parse(resultsJsonStr);
          self.postMessage({ type: 'EXECUTE_SUCCESS', payload: results });
        } else {
          // Simulated Go Virtual Machine Goroutine executor
          const vm = new SimulatedGoVM(variables);
          const results = await vm.run(ast || payload.ast);
          self.postMessage({ type: 'EXECUTE_SUCCESS', payload: results });
        }
      } catch (err: any) {
        self.postMessage({ type: 'EXECUTE_ERROR', payload: err.message });
      }
      break;
    }

    case 'SUBMIT_PROMPT': {
      try {
        const { value } = payload;
        if (wasmInstance) {
          // @ts-ignore
          bplSubmitPromptResponse(value);
        } else if (pendingPromptResolve) {
          pendingPromptResolve(value);
          pendingPromptResolve = null;
        }
      } catch (err: any) {
        console.error('Failed to submit prompt response to Go Worker:', err);
      }
      break;
    }
  }
};
