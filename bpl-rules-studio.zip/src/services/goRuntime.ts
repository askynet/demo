/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface GoVMResults {
  status: 'completed' | 'failed' | 'suspended';
  logs: string[];
  trace: any[];
  variables: { [key: string]: any };
}

export class GoRuntimeService {
  private worker: Worker | null = null;
  private isInitialized = false;
  private initPromise: Promise<void> | null = null;

  /**
   * Spawns the Web Worker and loads the Go WebAssembly runtime binary.
   */
  public async initialize(wasmUrl: string = '/assets/go_compiler.wasm'): Promise<void> {
    if (this.isInitialized) return;
    if (this.initPromise) return this.initPromise;

    this.initPromise = new Promise((resolve, reject) => {
      try {
        // Spawn our BplWorker
        this.worker = new Worker(
          new URL('./bplWorker.ts', import.meta.url),
          { type: 'module' }
        );

        this.worker.onmessage = (e) => {
          const { type, payload } = e.data;
          if (type === 'INIT_SUCCESS') {
            this.isInitialized = true;
            resolve();
          } else if (type === 'INIT_FAILURE') {
            reject(new Error(`Failed to initialize Go WASM: ${payload}`));
          }
        };

        this.worker.postMessage({
          type: 'INIT',
          payload: { wasmUrl }
        });
      } catch (err) {
        reject(err);
      }
    });

    return this.initPromise;
  }

  /**
   * Compiles BPL AST JSON to a packed Go-BPL binary string
   */
  public async compile(ast: any): Promise<string> {
    await this.initialize();

    return new Promise((resolve, reject) => {
      if (!this.worker) return reject(new Error('Worker not initialized'));

      const messageHandler = (e: MessageEvent) => {
        const { type, payload } = e.data;
        if (type === 'COMPILE_SUCCESS') {
          cleanup();
          resolve(payload);
        } else if (type === 'COMPILE_ERROR') {
          cleanup();
          reject(new Error(payload));
        }
      };

      const cleanup = () => {
        this.worker?.removeEventListener('message', messageHandler);
      };

      this.worker.addEventListener('message', messageHandler);
      this.worker.postMessage({
        type: 'COMPILE',
        payload: { ast }
      });
    });
  }

  /**
   * Executes a compiled BPL binary in the background Go Worker,
   * prompting the user for input dynamically during execution as needed.
   * 
   * @param binaryStr The "BPLG1:..." compiled bytecode string
   * @param variables Initial variables
   * @param ast The source script AST node for simulation fallbacks
   * @param onPrompt Callback function that is triggered when a PROMPT or GETKEY is hit.
   *                 Should return a promise that resolves to the user input value.
   */
  public async execute(
    binaryStr: string,
    variables: { [key: string]: any },
    ast: any,
    onPrompt: (message: string, variable: string, type: 'prompt' | 'getkey') => Promise<string>
  ): Promise<GoVMResults> {
    await this.initialize();

    return new Promise((resolve, reject) => {
      if (!this.worker) return reject(new Error('Worker not initialized'));

      const messageHandler = async (e: MessageEvent) => {
        const { type, payload } = e.data;

        if (type === 'EXECUTE_SUCCESS') {
          cleanup();
          resolve(payload);
        } else if (type === 'EXECUTE_ERROR') {
          cleanup();
          reject(new Error(payload));
        } else if (type === 'PROMPT_REQUIRED') {
          const { message, variable, type: promptType } = payload;
          try {
            // Trigger UI prompt handler and await user response
            const response = await onPrompt(message, variable, promptType);
            
            // Post the user's input back to the worker to resume the VM goroutine channel
            this.worker?.postMessage({
              type: 'SUBMIT_PROMPT',
              payload: { value: response }
            });
          } catch (err) {
            cleanup();
            reject(new Error(`Execution cancelled on prompt: ${err}`));
          }
        }
      };

      const cleanup = () => {
        this.worker?.removeEventListener('message', messageHandler);
      };

      this.worker.addEventListener('message', messageHandler);
      this.worker.postMessage({
        type: 'EXECUTE',
        payload: { binaryStr, variables, ast }
      });
    });
  }
}

export const goRuntimeService = new GoRuntimeService();
