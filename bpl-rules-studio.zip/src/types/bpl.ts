/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export type BplOperator =
  | 'equals'
  | 'notEquals'
  | 'greaterThan'
  | 'lessThan'
  | 'greaterThanOrEqual'
  | 'lessThanOrEqual'
  | 'contains'
  | 'startsWith'
  | 'endsWith'
  | 'in'
  | 'notIn'
  | 'exists'
  | 'isEmpty';

export interface BplCondition {
  field: string;
  operator: BplOperator;
  value: string; // value as string, parsed as number/boolean inside interpreter
  isValueIdentifier?: boolean; // true if comparing to a variable, false if a constant literal
}

export interface BplConditionGroup {
  type: 'condition-group';
  operator: 'AND' | 'OR';
  conditions: (BplCondition | BplConditionGroup)[];
}

export type BplAstNode =
  | ScriptNode
  | IfNode
  | AssignNode
  | IncludeNode
  | ImportNode
  | JumpNode
  | LabelNode
  | ReturnNode
  | BlockNode
  | LogNode
  | ErrorNode
  | SwitchNode
  | LoopNode
  | ApiCallNode
  | ValidationNode
  | ClearscreenNode
  | CodeNode
  | OnlyIfNode
  | PromptNode
  | GetkeyNode
  | MacroNode;

export interface BaseNode {
  id: string; // unique ID for editing and rendering
  lineStart?: number; // for highlighting in the text editor
  lineEnd?: number;
  comment?: string;
  leadingComments?: string[];
  trailingComments?: string[];
}

export interface ScriptNode extends BaseNode {
  type: 'script';
  name: string;
  children: BplAstNode[];
}

export interface IfNode extends BaseNode {
  type: 'if';
  condition: BplCondition | BplConditionGroup; // Structured conditions group or single comparison
  thenBlock: BplAstNode[];
  elseIfBlocks?: { condition: BplCondition | BplConditionGroup; block: BplAstNode[] }[];
  elseBlock?: BplAstNode[];
}

export interface AssignNode extends BaseNode {
  type: 'assign';
  variable: string;
  value: string; // raw value representation (e.g. "Y", 18, true)
  isValueIdentifier?: boolean; // true if assigned value is a variable reference, false if literal
}

export interface IncludeNode extends BaseNode {
  type: 'include';
  path: string;
  parameters?: string[];
}

export interface ImportNode extends BaseNode {
  type: 'import';
  file: string;
}

export interface JumpNode extends BaseNode {
  type: 'jump';
  target: string;
}

export interface LabelNode extends BaseNode {
  type: 'label';
  name: string;
}

export interface ReturnNode extends BaseNode {
  type: 'return';
}

export interface BlockNode extends BaseNode {
  type: 'block';
  children: BplAstNode[];
}

export interface LogNode extends BaseNode {
  type: 'log';
  message: string;
}

export interface ErrorNode extends BaseNode {
  type: 'error';
  message: string;
}

export interface SwitchNode extends BaseNode {
  type: 'switch';
  variable: string;
  cases: { value: string; block: BplAstNode[] }[];
  defaultBlock?: BplAstNode[];
}

export interface LoopNode extends BaseNode {
  type: 'loop';
  itemVar: string;
  collectionVar: string;
  block: BplAstNode[];
}

export interface ApiCallNode extends BaseNode {
  type: 'api-call';
  url: string;
  parameters: string[];
  responseVar: string;
}

export interface ValidationNode extends BaseNode {
  type: 'validation';
  condition: BplCondition | BplConditionGroup;
  errorMessage: string;
}

export interface ClearscreenNode extends BaseNode {
  type: 'clearscreen';
}

export interface CodeNode extends BaseNode {
  type: 'code';
}

export interface OnlyIfNode extends BaseNode {
  type: 'only_if';
  variable: string;
  cases: { values: string[]; block: BplAstNode[] }[];
}

export interface PromptNode extends BaseNode {
  type: 'prompt';
  message: string;
  variable: string;
}

export interface GetkeyNode extends BaseNode {
  type: 'getkey';
  variable: string;
}

export interface MacroNode extends BaseNode {
  type: 'macro';
  name: string;
  block: BplAstNode[];
}

// Variables & Evaluation types
export type VariableValue = string | number | boolean | any[];

export interface VariableState {
  [name: string]: VariableValue;
}

export interface LogEntry {
  timestamp: string;
  nodeId: string;
  nodeType: string;
  message: string;
  variablesAfter?: VariableState;
}

export interface TraceStep {
  currentNodeId: string;
  nodeType: string;
  executed: boolean; // whether this node's action actually fired (e.g. if condition evaluated to true)
  variableSnapshot: VariableState;
  logs: string[];
  outputIncludes: { path: string; params: string[] }[];
  description: string;
}

export interface ParserError {
  line: number;
  column: number;
  message: string;
}
