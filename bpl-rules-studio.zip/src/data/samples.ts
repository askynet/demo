/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { ScriptNode } from '../types/bpl';

export interface BplSample {
  id: string;
  name: string;
  description: string;
  code: string;
  defaultVariables: { [key: string]: any };
  ast: ScriptNode;
}

export const BPL_SAMPLES: BplSample[] = [
  {
    id: 'arizona-et',
    name: 'Arizona ET Notice Eligibility',
    description: 'The standard BPL script determining Booklet notice and Eligibility for the State of Arizona.',
    code: `script "ET FOR ARIZONA"
{
  log "Starting eligibility check for Arizona ET Notice..."
  
  if (medical equals "Y")
  {
    assign "Eligible" to status
    assign "Approved" to reason
    jumpto bottom
  }
  
  if (
    medical equals "N" AND
    drugs equals "N"
  )
  {
    log "Checking funding eligibility"
    if (
      funding equals "A" OR
      funding equals "E"
    )
    {
      include "book/az/etnotice/2a" send(company, age)
      assign "RequiresReview" to status
    }
    else
    {
      include "book/az/etnotice/5a"
      assign "Denied" to status
    }
  }
  else
  {
    assign "Ineligible" to status
    assign "HighRisk" to reason
  }

  bottom::
  log "Process completed. Status: "
}
`,
    defaultVariables: {
      medical: 'N',
      drugs: 'N',
      funding: 'A',
      company: 'ZubenAI Inc.',
      age: 28,
      status: 'Pending',
      reason: 'None',
    },
    ast: {
      id: 'root-az',
      type: 'script',
      name: 'ET FOR ARIZONA',
      children: [
        {
          id: 'log-1',
          type: 'log',
          message: 'Starting eligibility check for Arizona ET Notice...',
        },
        {
          id: 'if-1',
          type: 'if',
          condition: {
            type: 'condition-group',
            operator: 'AND',
            conditions: [
              { field: 'medical', operator: 'equals', value: 'Y' }
            ]
          },
          thenBlock: [
            { id: 'assign-1', type: 'assign', variable: 'status', value: 'Eligible' },
            { id: 'assign-2', type: 'assign', variable: 'reason', value: 'Approved' },
            { id: 'jump-1', type: 'jump', target: 'bottom' }
          ]
        },
        {
          id: 'if-2',
          type: 'if',
          condition: {
            type: 'condition-group',
            operator: 'AND',
            conditions: [
              { field: 'medical', operator: 'equals', value: 'N' },
              { field: 'drugs', operator: 'equals', value: 'N' }
            ]
          },
          thenBlock: [
            { id: 'log-2', type: 'log', message: 'Checking funding eligibility' },
            {
              id: 'if-3',
              type: 'if',
              condition: {
                type: 'condition-group',
                operator: 'OR',
                conditions: [
                  { field: 'funding', operator: 'equals', value: 'A' },
                  { field: 'funding', operator: 'equals', value: 'E' }
                ]
              },
              thenBlock: [
                { id: 'include-1', type: 'include', path: 'book/az/etnotice/2a', parameters: ['company', 'age'] },
                { id: 'assign-3', type: 'assign', variable: 'status', value: 'RequiresReview' }
              ],
              elseBlock: [
                { id: 'include-2', type: 'include', path: 'book/az/etnotice/5a' },
                { id: 'assign-4', type: 'assign', variable: 'status', value: 'Denied' }
              ]
            }
          ],
          elseBlock: [
            { id: 'assign-5', type: 'assign', variable: 'status', value: 'Ineligible' },
            { id: 'assign-6', type: 'assign', variable: 'reason', value: 'HighRisk' }
          ]
        },
        {
          id: 'label-1',
          type: 'label',
          name: 'bottom',
        },
        {
          id: 'log-3',
          type: 'log',
          message: 'Process completed. Status: ',
        }
      ],
    },
  },
  {
    id: 'underwriting-risk',
    name: 'Underwriting Risk Assessment',
    description: 'Modernized rules using switch blocks, external API calls, loops over claims, and validation limits.',
    code: `script "UNDERWRITING RISK"
{
  log "Initiating risk underwriting profile analysis"

  validate age >= 18 or_error "Applicant must be at least 18 years old"
  
  log "Retrieving credit score via risk API"
  call api "https://api.riskassessment.com/credit" send(age) receive(creditScore)

  switch (riskClass)
  {
    case "Preferred":
    {
      assign 0.05 to riskPremiumMultiplier
      assign "LowRisk" to riskCategory
    }
    case "Standard":
    {
      assign 0.15 to riskPremiumMultiplier
      assign "MediumRisk" to riskCategory
    }
    default:
    {
      assign 0.40 to riskPremiumMultiplier
      assign "HighRisk" to riskCategory
    }
  }

  log "Looping over existing claims list"
  loop over claim in claims
  {
    if (claimAmount > 5000)
    {
      log "Large historical claim detected, raising premium multipliers"
      assign 1.5 to multiplierSurplus
    }
  }
}
`,
    defaultVariables: {
      age: 34,
      riskClass: 'Standard',
      claims: [
        { id: 'C01', claimAmount: 1200 },
        { id: 'C02', claimAmount: 7500 }
      ],
      creditScore: 0,
      riskPremiumMultiplier: 0,
      riskCategory: 'Unknown',
      multiplierSurplus: 1.0
    },
    ast: {
      id: 'root-risk',
      type: 'script',
      name: 'UNDERWRITING RISK',
      children: [
        {
          id: 'log-risk-1',
          type: 'log',
          message: 'Initiating risk underwriting profile analysis',
        },
        {
          id: 'validate-1',
          type: 'validation',
          condition: {
            type: 'condition-group',
            operator: 'AND',
            conditions: [
              { field: 'age', operator: 'greaterThanOrEqual', value: '18' }
            ]
          },
          errorMessage: 'Applicant must be at least 18 years old',
        },
        {
          id: 'log-risk-2',
          type: 'log',
          message: 'Retrieving credit score via risk API',
        },
        {
          id: 'api-1',
          type: 'api-call',
          url: 'https://api.riskassessment.com/credit',
          parameters: ['age'],
          responseVar: 'creditScore',
        },
        {
          id: 'switch-1',
          type: 'switch',
          variable: 'riskClass',
          cases: [
            {
              value: 'Preferred',
              block: [
                { id: 'assign-risk-1', type: 'assign', variable: 'riskPremiumMultiplier', value: '0.05' },
                { id: 'assign-risk-2', type: 'assign', variable: 'riskCategory', value: 'LowRisk' }
              ]
            },
            {
              value: 'Standard',
              block: [
                { id: 'assign-risk-3', type: 'assign', variable: 'riskPremiumMultiplier', value: '0.15' },
                { id: 'assign-risk-4', type: 'assign', variable: 'riskCategory', value: 'MediumRisk' }
              ]
            }
          ],
          defaultBlock: [
            { id: 'assign-risk-5', type: 'assign', variable: 'riskPremiumMultiplier', value: '0.40' },
            { id: 'assign-risk-6', type: 'assign', variable: 'riskCategory', value: 'HighRisk' }
          ]
        },
        {
          id: 'log-risk-3',
          type: 'log',
          message: 'Looping over existing claims list',
        },
        {
          id: 'loop-1',
          type: 'loop',
          itemVar: 'claim',
          collectionVar: 'claims',
          block: [
            {
              id: 'if-risk-claim',
              type: 'if',
              condition: {
                type: 'condition-group',
                operator: 'AND',
                conditions: [
                  { field: 'claimAmount', operator: 'greaterThan', value: '5000' }
                ]
              },
              thenBlock: [
                { id: 'log-risk-4', type: 'log', message: 'Large historical claim detected, raising premium multipliers' },
                { id: 'assign-risk-7', type: 'assign', variable: 'multiplierSurplus', value: '1.5' }
              ]
            }
          ]
        }
      ]
    }
  },
  {
    id: 'retail-discount',
    name: 'Retail Promotions Engine',
    description: 'Dynamic discount and tax rules for cart checkouts, evaluating thresholds and tier structures.',
    code: `script "RETAIL PROMOTIONS ENGINE"
{
  log "Processing cart order items..."
  
  if (cartTotal > 200)
  {
    log "Order value exceeds $200! Granting major discount and free include catalog."
    assign "Tier 1 Promo" to appliedCoupon
    assign 25 to discountAmount
    include "catalog/rewards/v1"
  }
  else
  {
    if (memberTier equals "Gold")
    {
      log "Loyalty Tier check: Gold member"
      assign "Loyalty Gold Coupon" to appliedCoupon
      assign 15 to discountAmount
    }
    else
    {
      assign "None" to appliedCoupon
      assign 0 to discountAmount
    }
  }

  log "Applying tax rate based on location"
  if (location equals "CA")
  {
    assign 0.085 to taxRate
  }
  else if (location equals "NY")
  {
    assign 0.08 to taxRate
  }
  else
  {
    assign 0.05 to taxRate
  }

  log "Processing complete."
}
`,
    defaultVariables: {
      cartTotal: 250,
      memberTier: 'Bronze',
      location: 'CA',
      appliedCoupon: 'Pending',
      discountAmount: 0,
      taxRate: 0.0
    },
    ast: {
      id: 'root-discount',
      type: 'script',
      name: 'RETAIL PROMOTIONS ENGINE',
      children: [
        {
          id: 'log-d-1',
          type: 'log',
          message: 'Processing cart order items...',
        },
        {
          id: 'if-d-1',
          type: 'if',
          condition: {
            type: 'condition-group',
            operator: 'AND',
            conditions: [
              { field: 'cartTotal', operator: 'greaterThan', value: '200' }
            ]
          },
          thenBlock: [
            { id: 'log-d-2', type: 'log', message: 'Order value exceeds $200! Granting major discount and free include catalog.' },
            { id: 'assign-d-1', type: 'assign', variable: 'appliedCoupon', value: 'Tier 1 Promo' },
            { id: 'assign-d-2', type: 'assign', variable: 'discountAmount', value: '25' },
            { id: 'include-d-1', type: 'include', path: 'catalog/rewards/v1' }
          ],
          elseBlock: [
            {
              id: 'if-d-2',
              type: 'if',
              condition: {
                type: 'condition-group',
                operator: 'AND',
                conditions: [
                  { field: 'memberTier', operator: 'equals', value: 'Gold' }
                ]
              },
              thenBlock: [
                { id: 'log-d-3', type: 'log', message: 'Loyalty Tier check: Gold member' },
                { id: 'assign-d-3', type: 'assign', variable: 'appliedCoupon', value: 'Loyalty Gold Coupon' },
                { id: 'assign-d-4', type: 'assign', variable: 'discountAmount', value: '15' }
              ],
              elseBlock: [
                { id: 'assign-d-5', type: 'assign', variable: 'appliedCoupon', value: 'None' },
                { id: 'assign-d-6', type: 'assign', variable: 'discountAmount', value: '0' }
              ]
            }
          ]
        },
        {
          id: 'log-d-4',
          type: 'log',
          message: 'Applying tax rate based on location',
        },
        {
          id: 'if-d-3',
          type: 'if',
          condition: {
            type: 'condition-group',
            operator: 'AND',
            conditions: [
              { field: 'location', operator: 'equals', value: 'CA' }
            ]
          },
          thenBlock: [
            { id: 'assign-d-7', type: 'assign', variable: 'taxRate', value: '0.085' }
          ],
          elseIfBlocks: [
            {
              condition: {
                type: 'condition-group',
                operator: 'AND',
                conditions: [
                  { field: 'location', operator: 'equals', value: 'NY' }
                ]
              },
              block: [
                { id: 'assign-d-8', type: 'assign', variable: 'taxRate', value: '0.08' }
              ]
            }
          ],
          elseBlock: [
            { id: 'assign-d-9', type: 'assign', variable: 'taxRate', value: '0.05' }
          ]
        },
        {
          id: 'log-d-5',
          type: 'log',
          message: 'Processing complete.',
        }
      ]
    }
  },
  {
    id: 'macro-reusable',
    name: 'Macro Logic Block demo',
    description: 'Demonstrates modular structure using reusable or nested macro blocks with validations and assignments.',
    code: `script "REUSABLE MACRO DEMO"
{
  log "Starting script with nested logic"
  assign 150 to baseSalary

  macro "calculate_bonuses"
  {
    log "Inside macro block: calculating bonus structures"
    if (yearsOfService >= 5)
    {
      assign 25 to bonusAmount
    }
    else
    {
      assign 10 to bonusAmount
    }
  }

  log "Post-macro script verification complete."
}
`,
    defaultVariables: {
      yearsOfService: 6,
      baseSalary: 0,
      bonusAmount: 0
    },
    ast: {
      id: 'root-macro-demo',
      type: 'script',
      name: 'REUSABLE MACRO DEMO',
      children: [
        {
          id: 'macro-l-1',
          type: 'log',
          message: 'Starting script with nested logic',
        },
        {
          id: 'macro-a-1',
          type: 'assign',
          variable: 'baseSalary',
          value: '150',
        },
        {
          id: 'macro-m-1',
          type: 'macro',
          name: 'calculate_bonuses',
          block: [
            {
              id: 'macro-l-2',
              type: 'log',
              message: 'Inside macro block: calculating bonus structures',
            },
            {
              id: 'macro-if-1',
              type: 'if',
              condition: {
                type: 'condition-group',
                operator: 'AND',
                conditions: [
                  { field: 'yearsOfService', operator: 'greaterThanOrEqual', value: '5' }
                ]
              },
              thenBlock: [
                { id: 'macro-a-2', type: 'assign', variable: 'bonusAmount', value: '25' }
              ],
              elseBlock: [
                { id: 'macro-a-3', type: 'assign', variable: 'bonusAmount', value: '10' }
              ]
            }
          ]
        },
        {
          id: 'macro-l-3',
          type: 'log',
          message: 'Post-macro script verification complete.',
        }
      ]
    }
  }
];
