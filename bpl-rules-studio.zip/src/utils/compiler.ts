/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { ScriptNode, BplAstNode, BplCondition, BplConditionGroup } from '../types/bpl';

export interface BplInstruction {
  op: string; // Opcode: 'SCRIPT' | 'LOG' | 'ASSIGN' | 'JUMP' | 'LABEL' | 'RETURN' | 'INCLUDE' | 'IMPORT' | 'VALIDATE' | 'CALL_API' | 'SWITCH' | 'LOOP' | 'IF'
  args: any[]; // Arguments for the instruction
}

export interface CompiledPayload {
  name: string;
  version: number;
  instructions: BplInstruction[];
}

/**
 * Compiles a single AST node into a list/tree of BPLInstructions
 */
export function compileNode(node: BplAstNode): BplInstruction {
  switch (node.type) {
    case 'script': {
      const sn = node as ScriptNode;
      return {
        op: 'SCRIPT',
        args: [sn.name, sn.children.map(compileNode)],
      };
    }
    case 'log': {
      return {
        op: 'LOG',
        args: [node.message],
      };
    }
    case 'assign': {
      return {
        op: 'ASSIGN',
        args: [node.variable, node.value, !!node.isValueIdentifier],
      };
    }
    case 'jump': {
      return {
        op: 'JUMP',
        args: [node.target],
      };
    }
    case 'label': {
      return {
        op: 'LABEL',
        args: [node.name],
      };
    }
    case 'return': {
      return {
        op: 'RETURN',
        args: [],
      };
    }
    case 'include': {
      return {
        op: 'INCLUDE',
        args: [node.path, node.parameters || []],
      };
    }
    case 'import': {
      return {
        op: 'IMPORT',
        args: [node.file],
      };
    }
    case 'validation': {
      return {
        op: 'VALIDATE',
        args: [node.condition, node.errorMessage],
      };
    }
    case 'clearscreen': {
      return {
        op: 'CLEARSCREEN',
        args: [],
      };
    }
    case 'code': {
      return {
        op: 'CODE',
        args: [],
      };
    }
    case 'prompt': {
      return {
        op: 'PROMPT',
        args: [node.message, node.variable],
      };
    }
    case 'getkey': {
      return {
        op: 'GETKEY',
        args: [node.variable],
      };
    }
    case 'only_if': {
      const compiledCases = node.cases.map(c => ({
        values: c.values,
        block: c.block.map(compileNode),
      }));
      return {
        op: 'ONLY_IF',
        args: [node.variable, compiledCases],
      };
    }
    case 'api-call': {
      return {
        op: 'CALL_API',
        args: [node.url, node.parameters || [], node.responseVar],
      };
    }
    case 'switch': {
      const compiledCases = node.cases.map(c => ({
        value: c.value,
        block: c.block.map(compileNode),
      }));
      const compiledDefault = node.defaultBlock ? node.defaultBlock.map(compileNode) : [];
      return {
        op: 'SWITCH',
        args: [node.variable, compiledCases, compiledDefault],
      };
    }
    case 'loop': {
      return {
        op: 'LOOP',
        args: [node.itemVar, node.collectionVar, node.block.map(compileNode)],
      };
    }
    case 'if': {
      const compiledThen = node.thenBlock.map(compileNode);
      const compiledElseIf = node.elseIfBlocks ? node.elseIfBlocks.map(elif => ({
        condition: elif.condition,
        block: elif.block.map(compileNode),
      })) : [];
      const compiledElse = node.elseBlock ? node.elseBlock.map(compileNode) : [];
      return {
        op: 'IF',
        args: [node.condition, compiledThen, compiledElseIf, compiledElse],
      };
    }
    default:
      return {
        op: 'NOP',
        args: [],
      };
  }
}

/**
 * Compiles a ScriptNode AST to the magic-prefixed "compiled binary" format
 */
export function compileAstToBinary(ast: ScriptNode): string {
  if (!ast) {
    throw new Error('No AST provided for compilation');
  }

  const payload: CompiledPayload = {
    name: ast.name,
    version: 1,
    instructions: ast.children.map(compileNode),
  };

  const jsonStr = JSON.stringify(payload);
  
  // Safe Base64 encoding for both Node.js and Browser environments
  let base64: string;
  if (typeof btoa === 'function') {
    base64 = btoa(encodeURIComponent(jsonStr).replace(/%([0-9A-F]{2})/g, (_, p1) => {
      return String.fromCharCode(parseInt(p1, 16));
    }));
  } else {
    base64 = Buffer.from(jsonStr, 'utf-8').toString('base64');
  }

  return `BPLB1:${base64}`;
}

/**
 * Decodes the "compiled binary" back into the CompiledPayload instructions list
 */
export function decodeBinaryToInstructions(binaryStr: string): CompiledPayload {
  if (!binaryStr.startsWith('BPLB1:')) {
    throw new Error('Invalid binary format or version mismatch. Must start with BPLB1:');
  }

  const base64 = binaryStr.substring(6);
  let jsonStr: string;

  if (typeof atob === 'function') {
    jsonStr = decodeURIComponent(atob(base64).split('').map((c) => {
      return '%' + ('00' + c.charCodeAt(0).toString(16)).slice(-2);
    }).join(''));
  } else {
    jsonStr = Buffer.from(base64, 'base64').toString('utf-8');
  }

  return JSON.parse(jsonStr) as CompiledPayload;
}
