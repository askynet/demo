/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import {
  BplAstNode,
  ScriptNode,
  BplConditionGroup,
  BplCondition,
  BplOperator,
  ParserError,
  IfNode,
  SwitchNode,
  LoopNode,
  OnlyIfNode,
  ClearscreenNode,
  CodeNode,
  PromptNode,
  GetkeyNode,
  ErrorNode,
} from '../types/bpl';

// Helper to generate unique IDs for nodes
let idCounter = 1;
export function generateId(prefix: string = 'node'): string {
  return `${prefix}-${idCounter++}-${Math.random().toString(36).substring(2, 7)}`;
}

/**
 * Token interface for lexical analysis
 */
interface Token {
  type: TokenType;
  value: string;
  line: number;
  column: number;
}

type TokenType =
  | 'SCRIPT'
  | 'IF'
  | 'ELSE'
  | 'ASSIGN'
  | 'TO'
  | 'INCLUDE'
  | 'SEND'
  | 'IMPORT'
  | 'JUMPTO'
  | 'LOG'
  | 'VALIDATE'
  | 'OR_ERROR'
  | 'CALL'
  | 'API'
  | 'RECEIVE'
  | 'SWITCH'
  | 'CASE'
  | 'DEFAULT'
  | 'LOOP'
  | 'OVER'
  | 'IN'
  | 'RETURN'
  | 'CLEARSCREEN'
  | 'CODE'
  | 'ONLY_IF'
  | 'PROMPT'
  | 'GETKEY'
  | 'ERROR'
  | 'MACRO'
  | 'IS'
  | 'IDENTIFIER'
  | 'STRING_LITERAL'
  | 'NUMBER_LITERAL'
  | 'OPERATOR'
  | 'AND'
  | 'OR'
  | 'LPAREN'
  | 'RPAREN'
  | 'LBRACE'
  | 'RBRACE'
  | 'LABEL_MARK' // ::
  | 'COMMA'
  | 'EOF';

/**
 * Tokenizer for BPL
 */
class Tokenizer {
  private source: string;
  private position: number = 0;
  private line: number = 1;
  private lineStart: number = 0;
  public comments: { text: string; line: number }[] = [];

  constructor(source: string) {
    this.source = source;
  }

  private isAtEnd(): boolean {
    return this.position >= this.source.length;
  }

  private peek(): string {
    if (this.isAtEnd()) return '';
    return this.source.charAt(this.position);
  }

  private peekNext(): string {
    if (this.position + 1 >= this.source.length) return '';
    return this.source.charAt(this.position + 1);
  }

  private advance(): string {
    const char = this.source.charAt(this.position);
    this.position++;
    if (char === '\n') {
      this.line++;
      this.lineStart = this.position;
    }
    return char;
  }

  private match(expected: string): boolean {
    if (this.isAtEnd()) return false;
    if (this.source.charAt(this.position) !== expected) return false;
    this.advance();
    return true;
  }

  private getColumn(): number {
    return this.position - this.lineStart + 1;
  }

  tokenize(): Token[] {
    const tokens: Token[] = [];

    while (!this.isAtEnd()) {
      const startPos = this.position;
      const startLine = this.line;
      const startCol = this.getColumn();
      const char = this.advance();

      // Skip whitespace
      if (char === ' ' || char === '\r' || char === '\t' || char === '\n') {
        continue;
      }

      // Skip comments
      if (char === ';') {
        // Semicolon single-line comment
        let commentText = ';';
        while (this.peek() !== '\n' && !this.isAtEnd()) {
          commentText += this.advance();
        }
        this.comments.push({ text: commentText, line: startLine });
        continue;
      }
      if (char === '/' && this.peek() === '/') {
        // Single-line comment
        let commentText = '//';
        this.advance(); // consume /
        while (this.peek() !== '\n' && !this.isAtEnd()) {
          commentText += this.advance();
        }
        this.comments.push({ text: commentText, line: startLine });
        continue;
      }
      if (char === '/' && this.peek() === '*') {
        // Block comment
        let commentText = '/*';
        this.advance(); // consume '*'
        while (!(this.peek() === '*' && this.peekNext() === '/') && !this.isAtEnd()) {
          commentText += this.advance();
        }
        if (!this.isAtEnd()) {
          commentText += this.advance(); // consume '*'
          commentText += this.advance(); // consume '/'
        }
        this.comments.push({ text: commentText, line: startLine });
        continue;
      }

      // Syntax operators & punctuation
      if (char === '(') {
        tokens.push({ type: 'LPAREN', value: '(', line: startLine, column: startCol });
        continue;
      }
      if (char === ')') {
        tokens.push({ type: 'RPAREN', value: ')', line: startLine, column: startCol });
        continue;
      }
      if (char === '{') {
        tokens.push({ type: 'LBRACE', value: '{', line: startLine, column: startCol });
        continue;
      }
      if (char === '}') {
        tokens.push({ type: 'RBRACE', value: '}', line: startLine, column: startCol });
        continue;
      }
      if (char === ',') {
        tokens.push({ type: 'COMMA', value: ',', line: startLine, column: startCol });
        continue;
      }
      if (char === ':' && this.peek() === ':') {
        this.advance(); // consume second :
        tokens.push({ type: 'LABEL_MARK', value: '::', line: startLine, column: startCol });
        continue;
      }

      // String literal
      if (char === '"' || char === "'") {
        const quoteType = char;
        let strVal = '';
        while (this.peek() !== quoteType && !this.isAtEnd()) {
          const c = this.advance();
          if (c === '\\' && this.peek() === quoteType) {
            strVal += this.advance(); // escaped quote
          } else {
            strVal += c;
          }
        }
        if (!this.isAtEnd()) {
          this.advance(); // consume closing quote
        }
        tokens.push({
          type: 'STRING_LITERAL',
          value: strVal,
          line: startLine,
          column: startCol,
        });
        continue;
      }

      // Numeric literal
      if (this.isDigit(char) || (char === '-' && this.isDigit(this.peek()))) {
        let numVal = char;
        while (this.isDigit(this.peek()) || this.peek() === '.') {
          numVal += this.advance();
        }
        tokens.push({
          type: 'NUMBER_LITERAL',
          value: numVal,
          line: startLine,
          column: startCol,
        });
        continue;
      }

      // Keywords and Identifiers
      if (this.isAlpha(char) || char === '_') {
        let text = char;
        while (this.isAlphaNumeric(this.peek()) || this.peek() === '_' || this.peek() === '.' || this.peek() === '-') {
          text += this.advance();
        }

        const upperText = text.toUpperCase();
        let type: TokenType = 'IDENTIFIER';

        // Check keywords
        switch (upperText) {
          case 'SCRIPT': type = 'SCRIPT'; break;
          case 'IF': type = 'IF'; break;
          case 'ELSE': type = 'ELSE'; break;
          case 'ASSIGN': type = 'ASSIGN'; break;
          case 'TO': type = 'TO'; break;
          case 'INCLUDE': type = 'INCLUDE'; break;
          case 'SEND': type = 'SEND'; break;
          case 'IMPORT': type = 'IMPORT'; break;
          case 'JUMPTO': type = 'JUMPTO'; break;
          case 'LOG': type = 'LOG'; break;
          case 'VALIDATE': type = 'VALIDATE'; break;
          case 'OR_ERROR': type = 'OR_ERROR'; break;
          case 'CALL': type = 'CALL'; break;
          case 'API': type = 'API'; break;
          case 'RECEIVE': type = 'RECEIVE'; break;
          case 'SWITCH': type = 'SWITCH'; break;
          case 'CASE': type = 'CASE'; break;
          case 'DEFAULT': type = 'DEFAULT'; break;
          case 'LOOP': type = 'LOOP'; break;
          case 'OVER': type = 'OVER'; break;
          case 'IN': type = 'IN'; break;
          case 'RETURN': type = 'RETURN'; break;
          case 'CLEARSCREEN': type = 'CLEARSCREEN'; break;
          case 'CODE': type = 'CODE'; break;
          case 'ONLY_IF': type = 'ONLY_IF'; break;
          case 'PROMPT': type = 'PROMPT'; break;
          case 'GETKEY': type = 'GETKEY'; break;
          case 'ERROR': type = 'ERROR'; break;
          case 'MACRO': type = 'MACRO'; break;
          case 'IS': type = 'IS'; break;
          case 'AND': type = 'AND'; break;
          case 'OR': type = 'OR'; break;
          case 'EQUALS':
          case 'NOTEQUALS':
          case 'NOT_EQUALS':
          case 'CONTAINS':
          case 'STARTSWITH':
          case 'STARTS_WITH':
          case 'ENDSWITH':
          case 'ENDS_WITH':
          case 'EXISTS':
          case 'ISEMPTY':
          case 'IS_EMPTY':
            type = 'OPERATOR';
            break;
        }

        // Handle specific symbols/operators like >=, <=, >, <, ==, !=
        if (text === '==') {
          tokens.push({ type: 'OPERATOR', value: 'equals', line: startLine, column: startCol });
          continue;
        }
        if (text === '!=' || text === '<>') {
          tokens.push({ type: 'OPERATOR', value: 'notEquals', line: startLine, column: startCol });
          continue;
        }
        if (text === '>') {
          tokens.push({ type: 'OPERATOR', value: 'greaterThan', line: startLine, column: startCol });
          continue;
        }
        if (text === '<') {
          tokens.push({ type: 'OPERATOR', value: 'lessThan', line: startLine, column: startCol });
          continue;
        }
        if (text === '>=') {
          tokens.push({ type: 'OPERATOR', value: 'greaterThanOrEqual', line: startLine, column: startCol });
          continue;
        }
        if (text === '<=') {
          tokens.push({ type: 'OPERATOR', value: 'lessThanOrEqual', line: startLine, column: startCol });
          continue;
        }

        tokens.push({ type: type, value: text, line: startLine, column: startCol });
        continue;
      }

      // Unrecognized character
      throw new Error(`Line ${this.line}, Column ${this.getColumn()}: Unexpected character '${char}'`);
    }

    tokens.push({ type: 'EOF', value: '', line: this.line, column: this.getColumn() });
    return tokens;
  }

  private isDigit(c: string): boolean {
    return c >= '0' && c <= '9';
  }

  private isAlpha(c: string): boolean {
    return (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z');
  }

  private isAlphaNumeric(c: string): boolean {
    return this.isAlpha(c) || this.isDigit(c);
  }
}

/**
 * Recursive Descent Parser for Booklet Policy Language (BPL)
 */
export class BplParser {
  private tokens: Token[] = [];
  private current: number = 0;
  private errors: ParserError[] = [];

  parse(source: string): { ast: ScriptNode | null; errors: ParserError[] } {
    this.current = 0;
    this.errors = [];
    let comments: { text: string; line: number }[] = [];
    try {
      const tokenizer = new Tokenizer(source);
      this.tokens = tokenizer.tokenize();
      comments = tokenizer.comments;
    } catch (err: any) {
      // Tokenizer error
      const match = err.message.match(/Line (\d+), Column (\d+): (.*)/);
      if (match) {
        this.errors.push({
          line: parseInt(match[1]),
          column: parseInt(match[2]),
          message: match[3],
        });
      } else {
        this.errors.push({ line: 1, column: 1, message: err.message });
      }
      return { ast: null, errors: this.errors };
    }

    try {
      const ast = this.parseScript();
      if (ast) {
        attachCommentsToAst(ast, comments);
      }
      return { ast, errors: this.errors };
    } catch (err: any) {
      // Parser error
      if (this.errors.length === 0) {
        this.errors.push({
          line: this.peek().line,
          column: this.peek().column,
          message: err.message || 'Syntax error',
        });
      }
      return { ast: null, errors: this.errors };
    }
  }

  private isAtEnd(): boolean {
    return this.peek().type === 'EOF';
  }

  private peek(): Token {
    return this.tokens[this.current];
  }

  private previous(): Token {
    return this.tokens[this.current - 1];
  }

  private advance(): Token {
    if (!this.isAtEnd()) this.current++;
    return this.previous();
  }

  private check(type: TokenType): boolean {
    if (this.isAtEnd()) return false;
    return this.peek().type === type;
  }

  private match(...types: TokenType[]): boolean {
    for (const type of types) {
      if (this.check(type)) {
        this.advance();
        return true;
      }
    }
    return false;
  }

  private consume(type: TokenType, message: string): Token {
    if (this.check(type)) return this.advance();
    throw this.error(this.peek(), message);
  }

  private error(token: Token, message: string): Error {
    const err: ParserError = {
      line: token.line,
      column: token.column,
      message: `${message} (found '${token.value}')`,
    };
    this.errors.push(err);
    return new Error(err.message);
  }

  /**
   * script "name" { children }
   */
  private parseScript(): ScriptNode {
    const startToken = this.consume('SCRIPT', "Expected keyword 'script'");
    const nameToken = this.consume('STRING_LITERAL', 'Expected script name as string literal');

    this.consume('LBRACE', "Expected '{' after script definition");

    const children: BplAstNode[] = [];
    while (!this.check('RBRACE') && !this.isAtEnd()) {
      try {
        const stmt = this.parseStatement();
        if (stmt) {
          children.push(stmt);
        }
      } catch (e) {
        this.synchronize();
      }
    }

    const endToken = this.consume('RBRACE', "Expected '}' at the end of the script");

    return {
      id: generateId('root'),
      type: 'script',
      name: nameToken.value,
      children,
      lineStart: startToken.line,
      lineEnd: endToken.line,
    };
  }

  private parseStatement(): BplAstNode {
    const startLine = this.peek().line;

    // Check for LABEL: identifier::
    if (this.check('IDENTIFIER') && this.tokens[this.current + 1]?.type === 'LABEL_MARK') {
      const labelToken = this.advance();
      this.advance(); // consume ::
      return {
        id: generateId('label'),
        type: 'label',
        name: labelToken.value,
        lineStart: startLine,
        lineEnd: labelToken.line,
      };
    }

    if (this.match('LOG')) {
      const msgToken = this.consume('STRING_LITERAL', 'Expected string message for log statement');
      return {
        id: generateId('log'),
        type: 'log',
        message: msgToken.value,
        lineStart: startLine,
        lineEnd: msgToken.line,
      };
    }

    if (this.match('ERROR')) {
      const msgToken = this.consume('STRING_LITERAL', 'Expected error message as string literal');
      return {
        id: generateId('error'),
        type: 'error',
        message: msgToken.value,
        lineStart: startLine,
        lineEnd: msgToken.line,
      };
    }

    if (this.match('ASSIGN')) {
      let valStr = '';
      let isValueIdentifier = false;
      if (this.match('STRING_LITERAL', 'NUMBER_LITERAL')) {
        valStr = this.previous().value;
      } else if (this.match('IDENTIFIER')) {
        valStr = this.previous().value; // dynamic variable assignment
        isValueIdentifier = true;
      } else {
        throw this.error(this.peek(), 'Expected string, number, or variable after assign');
      }

      this.consume('TO', "Expected keyword 'to' in assign statement");
      const varToken = this.consume('IDENTIFIER', 'Expected variable name for assignment');

      return {
        id: generateId('assign'),
        type: 'assign',
        variable: varToken.value,
        value: valStr,
        isValueIdentifier,
        lineStart: startLine,
        lineEnd: varToken.line,
      };
    }

    if (this.match('JUMPTO')) {
      const targetToken = this.consume('IDENTIFIER', 'Expected label name for jumpto statement');
      return {
        id: generateId('jump'),
        type: 'jump',
        target: targetToken.value,
        lineStart: startLine,
        lineEnd: targetToken.line,
      };
    }

    if (this.match('RETURN')) {
      return {
        id: generateId('return'),
        type: 'return',
        lineStart: startLine,
        lineEnd: startLine,
      };
    }

    if (this.match('CLEARSCREEN')) {
      return {
        id: generateId('clearscreen'),
        type: 'clearscreen',
        lineStart: startLine,
        lineEnd: startLine,
      };
    }

    if (this.match('CODE')) {
      return {
        id: generateId('code'),
        type: 'code',
        lineStart: startLine,
        lineEnd: startLine,
      };
    }

    if (this.match('PROMPT')) {
      const msgToken = this.consume('STRING_LITERAL', 'Expected message for prompt');
      this.consume('COMMA', "Expected ',' after prompt message");
      const varToken = this.consume('IDENTIFIER', 'Expected variable name for prompt input');
      return {
        id: generateId('prompt'),
        type: 'prompt',
        message: msgToken.value,
        variable: varToken.value,
        lineStart: startLine,
        lineEnd: varToken.line,
      };
    }

    if (this.match('GETKEY')) {
      const varToken = this.consume('IDENTIFIER', 'Expected variable name for getkey');
      return {
        id: generateId('getkey'),
        type: 'getkey',
        variable: varToken.value,
        lineStart: startLine,
        lineEnd: varToken.line,
      };
    }

    if (this.match('ONLY_IF')) {
      const varToken = this.consume('IDENTIFIER', 'Expected variable name for only_if block');
      this.consume('LBRACE', "Expected '{' to start only_if body");

      const cases: { values: string[]; block: BplAstNode[] }[] = [];

      while (!this.check('RBRACE') && !this.isAtEnd()) {
        const values: string[] = [];
        while (this.match('IS')) {
          let valStr = '';
          if (this.match('STRING_LITERAL', 'NUMBER_LITERAL')) {
            valStr = this.previous().value;
          } else {
            throw this.error(this.peek(), 'Expected string or number for is value');
          }
          values.push(valStr);
        }

        if (values.length === 0) {
          throw this.error(this.peek(), "Expected 'is' condition inside only_if");
        }

        this.consume('LBRACE', "Expected '{' to open only_if case block");
        const blockChildren: BplAstNode[] = [];
        while (!this.check('RBRACE') && !this.isAtEnd()) {
          blockChildren.push(this.parseStatement());
        }
        this.consume('RBRACE', "Expected '}' to close only_if case block");

        cases.push({ values, block: blockChildren });
      }

      this.consume('RBRACE', "Expected '}' to end only_if block");

      return {
        id: generateId('only_if'),
        type: 'only_if',
        variable: varToken.value,
        cases,
        lineStart: startLine,
        lineEnd: this.previous().line,
      };
    }

    if (this.match('INCLUDE')) {
      const pathToken = this.consume('STRING_LITERAL', 'Expected template path string for include');
      const parameters: string[] = [];

      if (this.match('SEND') || this.check('LPAREN')) {
        // Support either send(param1, param2) or just (param1, param2)
        const hasSend = this.previous().type === 'SEND';
        this.consume('LPAREN', "Expected '(' for parameters list");
        
        if (!this.check('RPAREN')) {
          do {
            const param = this.consume('IDENTIFIER', 'Expected parameter variable identifier');
            parameters.push(param.value);
          } while (this.match('COMMA'));
        }
        this.consume('RPAREN', "Expected ')' after parameter list");
      }

      return {
        id: generateId('include'),
        type: 'include',
        path: pathToken.value,
        parameters: parameters.length > 0 ? parameters : undefined,
        lineStart: startLine,
        lineEnd: this.previous().line,
      };
    }

    if (this.match('IMPORT')) {
      const fileToken = this.consume('STRING_LITERAL', 'Expected file path string for import');
      return {
        id: generateId('import'),
        type: 'import',
        file: fileToken.value,
        lineStart: startLine,
        lineEnd: fileToken.line,
      };
    }

    if (this.match('VALIDATE')) {
      const condition = this.parseConditionGroup();
      this.consume('OR_ERROR', "Expected 'or_error' after validation condition");
      const errToken = this.consume('STRING_LITERAL', 'Expected error message as string literal');

      return {
        id: generateId('validation'),
        type: 'validation',
        condition,
        errorMessage: errToken.value,
        lineStart: startLine,
        lineEnd: errToken.line,
      };
    }

    if (this.match('CALL')) {
      this.consume('API', "Expected keyword 'api' after 'call'");
      const urlToken = this.consume('STRING_LITERAL', 'Expected API endpoint URL string');
      const parameters: string[] = [];

      if (this.match('SEND') || this.check('LPAREN')) {
        if (this.previous().type === 'SEND') {
          this.consume('LPAREN', "Expected '(' after send");
        } else {
          this.consume('LPAREN', "Expected '('");
        }
        if (!this.check('RPAREN')) {
          do {
            parameters.push(this.consume('IDENTIFIER', 'Expected parameter identifier').value);
          } while (this.match('COMMA'));
        }
        this.consume('RPAREN', "Expected ')'");
      }

      this.consume('RECEIVE', "Expected keyword 'receive' in API call statement");
      const respVarToken = this.consume('IDENTIFIER', 'Expected response variable identifier');

      return {
        id: generateId('api-call'),
        type: 'api-call',
        url: urlToken.value,
        parameters,
        responseVar: respVarToken.value,
        lineStart: startLine,
        lineEnd: respVarToken.line,
      };
    }

    if (this.match('SWITCH')) {
      this.consume('LPAREN', "Expected '(' after switch");
      const varToken = this.consume('IDENTIFIER', 'Expected variable name for switch block');
      this.consume('RPAREN', "Expected ')' after switch variable");

      this.consume('LBRACE', "Expected '{' to start switch body");

      const cases: { value: string; block: BplAstNode[] }[] = [];
      let defaultBlock: BplAstNode[] | undefined = undefined;

      while (!this.check('RBRACE') && !this.isAtEnd()) {
        if (this.match('CASE')) {
          let caseVal = '';
          if (this.match('STRING_LITERAL', 'NUMBER_LITERAL')) {
            caseVal = this.previous().value;
          } else {
            throw this.error(this.peek(), 'Expected string or number for case label');
          }

          this.consume('LBRACE', "Expected '{' to open case block");
          const blockChildren: BplAstNode[] = [];
          while (!this.check('RBRACE') && !this.isAtEnd()) {
            blockChildren.push(this.parseStatement());
          }
          this.consume('RBRACE', "Expected '}' to close case block");
          cases.push({ value: caseVal, block: blockChildren });
        } else if (this.match('DEFAULT')) {
          this.consume('LBRACE', "Expected '{' to open default block");
          const blockChildren: BplAstNode[] = [];
          while (!this.check('RBRACE') && !this.isAtEnd()) {
            blockChildren.push(this.parseStatement());
          }
          this.consume('RBRACE', "Expected '}' to close default block");
          defaultBlock = blockChildren;
        } else {
          throw this.error(this.peek(), "Expected 'case' or 'default' inside switch");
        }
      }

      this.consume('RBRACE', "Expected '}' to end switch block");

      return {
        id: generateId('switch'),
        type: 'switch',
        variable: varToken.value,
        cases,
        defaultBlock,
        lineStart: startLine,
        lineEnd: this.previous().line,
      };
    }

    if (this.match('LOOP')) {
      this.consume('OVER', "Expected 'over' keyword for loop");
      const itemVar = this.consume('IDENTIFIER', 'Expected loop item variable name').value;
      this.consume('IN', "Expected 'in' keyword for loop");
      const collectionVar = this.consume('IDENTIFIER', 'Expected collection variable name').value;

      this.consume('LBRACE', "Expected '{' to open loop body");
      const block: BplAstNode[] = [];
      while (!this.check('RBRACE') && !this.isAtEnd()) {
        block.push(this.parseStatement());
      }
      this.consume('RBRACE', "Expected '}' to close loop body");

      return {
        id: generateId('loop'),
        type: 'loop',
        itemVar,
        collectionVar,
        block,
        lineStart: startLine,
        lineEnd: this.previous().line,
      };
    }

    if (this.match('MACRO')) {
      const nameToken = this.consume('STRING_LITERAL', 'Expected string name for macro block');

      this.consume('LBRACE', "Expected '{' to open macro body");
      const block: BplAstNode[] = [];
      while (!this.check('RBRACE') && !this.isAtEnd()) {
        block.push(this.parseStatement());
      }
      this.consume('RBRACE', "Expected '}' to close macro body");

      return {
        id: generateId('macro'),
        type: 'macro',
        name: nameToken.value,
        block,
        lineStart: startLine,
        lineEnd: this.previous().line,
      };
    }

    if (this.match('IF')) {
      this.consume('LPAREN', "Expected '(' after 'if'");
      const condition = this.parseConditionGroup();
      this.consume('RPAREN', "Expected ')' after if condition");

      const thenBlock: BplAstNode[] = [];
      if (this.match('LBRACE')) {
        while (!this.check('RBRACE') && !this.isAtEnd()) {
          thenBlock.push(this.parseStatement());
        }
        this.consume('RBRACE', "Expected '}' at end of then-block");
      } else {
        thenBlock.push(this.parseStatement());
      }

      const elseIfBlocks: { condition: BplCondition | BplConditionGroup; block: BplAstNode[] }[] = [];
      let elseBlock: BplAstNode[] | undefined = undefined;

      while (this.match('ELSE')) {
        if (this.match('IF')) {
          this.consume('LPAREN', "Expected '(' after 'else if'");
          const elifCond = this.parseConditionGroup();
          this.consume('RPAREN', "Expected ')' after else-if condition");

          const elifBlock: BplAstNode[] = [];
          if (this.match('LBRACE')) {
            while (!this.check('RBRACE') && !this.isAtEnd()) {
              elifBlock.push(this.parseStatement());
            }
            this.consume('RBRACE', "Expected '}' at end of else-if-block");
          } else {
            elifBlock.push(this.parseStatement());
          }
          elseIfBlocks.push({ condition: elifCond, block: elifBlock });
        } else {
          const elsBlock: BplAstNode[] = [];
          if (this.match('LBRACE')) {
            while (!this.check('RBRACE') && !this.isAtEnd()) {
              elsBlock.push(this.parseStatement());
            }
            this.consume('RBRACE', "Expected '}' to close else-block");
          } else {
            elsBlock.push(this.parseStatement());
          }
          elseBlock = elsBlock;
          break; // there can only be one else block and it must be the last
        }
      }

      return {
        id: generateId('if'),
        type: 'if',
        condition,
        thenBlock,
        elseIfBlocks: elseIfBlocks.length > 0 ? elseIfBlocks : undefined,
        elseBlock,
        lineStart: startLine,
        lineEnd: this.previous().line,
      };
    }

    // Unrecognized statement, throw error
    throw this.error(this.peek(), `Unexpected statement token`);
  }

  /**
   * Parses simple or nested conditions with AND/OR
   */
  private parseConditionGroup(): BplConditionGroup {
    const conditions: (BplCondition | BplConditionGroup)[] = [];
    let operator: 'AND' | 'OR' = 'AND';

    // Parse first condition
    const firstCond = this.parsePrimaryCondition();
    conditions.push(firstCond);

    while (this.check('AND') || this.check('OR')) {
      const opToken = this.advance();
      operator = opToken.type as 'AND' | 'OR';

      const nextCond = this.parsePrimaryCondition();
      conditions.push(nextCond);
    }

    return {
      type: 'condition-group',
      operator,
      conditions,
    };
  }

  private parsePrimaryCondition(): BplCondition | BplConditionGroup {
    if (this.match('LPAREN')) {
      const group = this.parseConditionGroup();
      this.consume('RPAREN', "Expected closing ')' for nested condition");
      return group;
    }

    const fieldToken = this.consume('IDENTIFIER', 'Expected field or variable name in condition');

    let op: BplOperator = 'equals';
    if (this.match('OPERATOR')) {
      const rawOp = this.previous().value.toLowerCase();
      // Normalize raw operators
      if (rawOp === 'equals' || rawOp === 'equal') op = 'equals';
      else if (rawOp === 'notequals' || rawOp === 'not_equals') op = 'notEquals';
      else if (rawOp === 'contains') op = 'contains';
      else if (rawOp === 'startswith' || rawOp === 'starts_with') op = 'startsWith';
      else if (rawOp === 'endswith' || rawOp === 'ends_with') op = 'endsWith';
      else if (rawOp === 'exists') op = 'exists';
      else if (rawOp === 'isempty' || rawOp === 'is_empty') op = 'isEmpty';
    } else {
      throw this.error(this.peek(), 'Expected operator in condition');
    }

    // unary operators do not need values
    if (op === 'exists' || op === 'isEmpty') {
      return {
        field: fieldToken.value,
        operator: op,
        value: '',
      };
    }

    let valStr = '';
    let isValueIdentifier = false;
    if (this.match('STRING_LITERAL', 'NUMBER_LITERAL')) {
      valStr = this.previous().value;
    } else if (this.match('IDENTIFIER')) {
      valStr = this.previous().value;
      isValueIdentifier = true;
    } else {
      throw this.error(this.peek(), 'Expected string, number, or identifier for condition value');
    }

    return {
      field: fieldToken.value,
      operator: op,
      value: valStr,
      isValueIdentifier,
    };
  }

  private synchronize(): void {
    this.advance();
    while (!this.isAtEnd()) {
      if (this.previous().type === 'RBRACE' || this.previous().type === 'LBRACE') return;

      switch (this.peek().type) {
        case 'SCRIPT':
        case 'IF':
        case 'ELSE':
        case 'ASSIGN':
        case 'INCLUDE':
        case 'IMPORT':
        case 'JUMPTO':
        case 'LOG':
        case 'ERROR':
        case 'VALIDATE':
        case 'CALL':
        case 'SWITCH':
        case 'LOOP':
        case 'RETURN':
          return;
      }
      this.advance();
    }
  }
}

/**
 * Converts a BplConditionGroup or BplCondition into text representation
 */
export function conditionToString(cond: BplCondition | BplConditionGroup): string {
  if ('type' in cond && cond.type === 'condition-group') {
    return cond.conditions
      .map((c) => {
        const str = conditionToString(c);
        if ('type' in c && c.type === 'condition-group') return `(${str})`;
        return str;
      })
      .join(` ${cond.operator} `);
  } else {
    const single = cond as BplCondition;
    let valStr = single.value;
    if (!single.isValueIdentifier && (isNaN(Number(valStr)) || valStr === '') && valStr !== 'true' && valStr !== 'false') {
      valStr = `"${valStr}"`;
    }
    
    // Convert operator back to human-readable form
    let opStr = single.operator as string;
    if (opStr === 'notEquals') opStr = 'not_equals';
    if (opStr === 'greaterThan') opStr = '>';
    if (opStr === 'lessThan') opStr = '<';
    if (opStr === 'greaterThanOrEqual') opStr = '>=';
    if (opStr === 'lessThanOrEqual') opStr = '<=';

    if (single.operator === 'exists' || single.operator === 'isEmpty') {
      return `${single.field} ${opStr}`;
    }

    return `${single.field} ${opStr} ${valStr}`;
  }
}

/**
 * Compiles a ScriptNode AST back to formal BPL text, preserving any associated comments
 */
export function astToBpl(node: BplAstNode, indent: number = 0): string {
  const pad = '  '.repeat(indent);

  // Pre-compile leading comments if they exist
  let leadingCode = '';
  if (node.leadingComments && node.leadingComments.length > 0) {
    leadingCode = node.leadingComments.map(c => `${pad}${c}`).join('\n') + '\n';
  }

  // Same-line comment if present
  const sameLineComment = node.comment ? `  ${node.comment}` : '';

  switch (node.type) {
    case 'script': {
      const scriptNode = node as ScriptNode;
      const childCode = scriptNode.children.map((c) => astToBpl(c, indent + 1)).join('\n');
      
      let trailingCommentsCode = '';
      if (scriptNode.trailingComments && scriptNode.trailingComments.length > 0) {
        trailingCommentsCode = '\n' + scriptNode.trailingComments.map(c => `${pad}${c}`).join('\n');
      }

      return leadingCode + `${pad}script "${scriptNode.name}"${sameLineComment}\n${pad}{\n${childCode}\n${pad}}${trailingCommentsCode}`;
    }

    case 'log': {
      return leadingCode + `${pad}log "${node.message}"${sameLineComment}`;
    }

    case 'error': {
      return leadingCode + `${pad}error "${node.message}"${sameLineComment}`;
    }

    case 'assign': {
      const assignNode = node as any;
      let valStr = assignNode.value;
      if (!assignNode.isValueIdentifier && (isNaN(Number(valStr)) || valStr === '') && valStr !== 'true' && valStr !== 'false') {
        valStr = `"${valStr}"`;
      }
      return leadingCode + `${pad}assign ${valStr} to ${assignNode.variable}${sameLineComment}`;
    }

    case 'jump': {
      return leadingCode + `${pad}jumpto ${node.target}${sameLineComment}`;
    }

    case 'label': {
      return leadingCode + `\n${pad}${node.name}::${sameLineComment}`;
    }

    case 'return': {
      return leadingCode + `${pad}return${sameLineComment}`;
    }

    case 'include': {
      const params = node.parameters && node.parameters.length > 0
        ? ` send(${node.parameters.join(', ')})`
        : '';
      return leadingCode + `${pad}include "${node.path}"${params}${sameLineComment}`;
    }

    case 'import': {
      return leadingCode + `${pad}import "${node.file}"${sameLineComment}`;
    }

    case 'validation': {
      const condStr = conditionToString(node.condition);
      return leadingCode + `${pad}validate ${condStr} or_error "${node.errorMessage}"${sameLineComment}`;
    }

    case 'clearscreen': {
      return leadingCode + `${pad}clearscreen${sameLineComment}`;
    }

    case 'code': {
      return leadingCode + `${pad}code${sameLineComment}`;
    }

    case 'prompt': {
      return leadingCode + `${pad}prompt "${node.message}", ${node.variable}${sameLineComment}`;
    }

    case 'getkey': {
      return leadingCode + `${pad}getkey ${node.variable}${sameLineComment}`;
    }

    case 'only_if': {
      let code = leadingCode + `${pad}only_if ${node.variable}${sameLineComment}\n${pad}{\n`;
      node.cases.forEach((c) => {
        c.values.forEach((v) => {
          const valRep = (isNaN(Number(v)) || v === '') && v !== 'true' && v !== 'false' ? `"${v}"` : v;
          code += `${pad}is ${valRep}\n`;
        });
        code += `${pad}{\n`;
        code += c.block.map((cb) => astToBpl(cb, indent + 1)).join('\n') + '\n';
        code += `${pad}}\n`;
      });
      code += `${pad}}`;
      return code;
    }

    case 'api-call': {
      const sendParams = node.parameters && node.parameters.length > 0
        ? ` send(${node.parameters.join(', ')})`
        : '';
      return leadingCode + `${pad}call api "${node.url}"${sendParams} receive(${node.responseVar})${sameLineComment}`;
    }

    case 'switch': {
      let code = leadingCode + `${pad}switch (${node.variable})${sameLineComment}\n${pad}{\n`;
      node.cases.forEach((c) => {
        code += `${pad}  case "${c.value}":\n${pad}  {\n`;
        code += c.block.map((cb) => astToBpl(cb, indent + 3)).join('\n') + '\n';
        code += `${pad}  }\n`;
      });
      if (node.defaultBlock && node.defaultBlock.length > 0) {
        code += `${pad}  default:\n${pad}  {\n`;
        code += node.defaultBlock.map((cb) => astToBpl(cb, indent + 3)).join('\n') + '\n';
        code += `${pad}  }\n`;
      }
      code += `${pad}}`;
      return code;
    }

    case 'loop': {
      let code = leadingCode + `${pad}loop over ${node.itemVar} in ${node.collectionVar}${sameLineComment}\n${pad}{\n`;
      code += node.block.map((cb) => astToBpl(cb, indent + 1)).join('\n') + '\n';
      code += `${pad}}`;
      return code;
    }

    case 'macro': {
      let code = leadingCode + `${pad}macro "${node.name}"${sameLineComment}\n${pad}{\n`;
      code += node.block.map((cb) => astToBpl(cb, indent + 1)).join('\n') + '\n';
      code += `${pad}}`;
      return code;
    }

    case 'if': {
      const condStr = conditionToString(node.condition);
      let code = leadingCode + `${pad}if (${condStr})${sameLineComment}\n${pad}{\n`;
      code += node.thenBlock.map((c) => astToBpl(c, indent + 1)).join('\n') + '\n';
      code += `${pad}}`;

      if (node.elseIfBlocks) {
        node.elseIfBlocks.forEach((elif) => {
          const elifCondStr = conditionToString(elif.condition);
          code += `\n${pad}else if (${elifCondStr})\n${pad}{\n`;
          code += elif.block.map((c) => astToBpl(c, indent + 1)).join('\n') + '\n';
          code += `${pad}}`;
        });
      }

      if (node.elseBlock) {
        code += `\n${pad}else\n${pad}{\n`;
        code += node.elseBlock.map((c) => astToBpl(c, indent + 1)).join('\n') + '\n';
        code += `${pad}}`;
      }

      return code;
    }

    default:
      return '';
  }
}

export function collectAllNodes(node: BplAstNode): BplAstNode[] {
  const list: BplAstNode[] = [node];
  if (node.type === 'script') {
    const sn = node as ScriptNode;
    sn.children.forEach(c => list.push(...collectAllNodes(c)));
  } else if (node.type === 'if') {
    const inod = node as IfNode;
    inod.thenBlock.forEach(c => list.push(...collectAllNodes(c)));
    if (inod.elseIfBlocks) {
      inod.elseIfBlocks.forEach(elif => {
        elif.block.forEach(c => list.push(...collectAllNodes(c)));
      });
    }
    if (inod.elseBlock) {
      inod.elseBlock.forEach(c => list.push(...collectAllNodes(c)));
    }
  } else if (node.type === 'switch') {
    const sn = node as SwitchNode;
    sn.cases.forEach(c => {
      c.block.forEach(cb => list.push(...collectAllNodes(cb)));
    });
    if (sn.defaultBlock) {
      sn.defaultBlock.forEach(cb => list.push(...collectAllNodes(cb)));
    }
  } else if (node.type === 'loop') {
    const ln = node as LoopNode;
    ln.block.forEach(c => list.push(...collectAllNodes(c)));
  } else if (node.type === 'macro') {
    const mn = node as any;
    mn.block.forEach(c => list.push(...collectAllNodes(c)));
  } else if (node.type === 'only_if') {
    const oin = node as OnlyIfNode;
    oin.cases.forEach(c => {
      c.block.forEach(cb => list.push(...collectAllNodes(cb)));
    });
  }
  return list;
}

export function attachCommentsToAst(rootNode: ScriptNode, comments: { text: string; line: number }[]) {
  const allNodes = collectAllNodes(rootNode);

  allNodes.forEach(n => {
    n.leadingComments = [];
    n.comment = undefined;
    n.trailingComments = [];
  });

  comments.forEach(comment => {
    const line = comment.line;
    const sameLineNodes = allNodes.filter(n => n.lineStart === line);
    if (sameLineNodes.length > 0) {
      let bestNode = sameLineNodes[0];
      for (const n of sameLineNodes) {
        if (n.type !== 'script') {
          bestNode = n;
        }
      }
      bestNode.comment = comment.text;
    } else {
      const subsequentNodes = allNodes.filter(n => n.lineStart !== undefined && n.lineStart > line);
      if (subsequentNodes.length > 0) {
        let closestNode = subsequentNodes[0];
        subsequentNodes.forEach(n => {
          if (n.lineStart! < closestNode.lineStart!) {
            closestNode = n;
          }
        });
        if (!closestNode.leadingComments) {
          closestNode.leadingComments = [];
        }
        closestNode.leadingComments.push(comment.text);
      } else {
        if (!rootNode.trailingComments) {
          rootNode.trailingComments = [];
        }
        rootNode.trailingComments.push(comment.text);
      }
    }
  });
}
