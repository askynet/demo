/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { motion } from 'motion/react';
import {
  BplAstNode,
  ScriptNode,
  IfNode,
  AssignNode,
  IncludeNode,
  ImportNode,
  JumpNode,
  LabelNode,
  ReturnNode,
  LogNode,
  ErrorNode,
  SwitchNode,
  LoopNode,
  ApiCallNode,
  ValidationNode,
  ClearscreenNode,
  CodeNode,
  PromptNode,
  GetkeyNode,
  OnlyIfNode,
  MacroNode,
} from '../types/bpl';

import {
  Settings,
  GitBranch,
  FileText,
  Bookmark,
  LogOut,
  Link,
  HelpCircle,
  Repeat,
  AlertOctagon,
  Database,
  ArrowRight,
  Eye,
  Play,
  CheckCircle2,
  XCircle,
  Monitor,
  Terminal,
  MessageSquare,
  Keyboard,
  ToggleLeft,
  Cpu,
} from 'lucide-react';

// Import modular node renderers
import LogNodeRenderer from './nodes/log/LogNodeRenderer';
import AssignNodeRenderer from './nodes/assign/AssignNodeRenderer';
import IncludeNodeRenderer from './nodes/include/IncludeNodeRenderer';
import ImportNodeRenderer from './nodes/import/ImportNodeRenderer';
import JumpNodeRenderer from './nodes/jump/JumpNodeRenderer';
import LabelNodeRenderer from './nodes/label/LabelNodeRenderer';
import ReturnNodeRenderer from './nodes/return/ReturnNodeRenderer';
import ErrorNodeRenderer from './nodes/error/ErrorNodeRenderer';
import ValidationNodeRenderer from './nodes/validation/ValidationNodeRenderer';
import ApiCallNodeRenderer from './nodes/api-call/ApiCallNodeRenderer';
import LoopNodeRenderer from './nodes/loop/LoopNodeRenderer';
import SwitchNodeRenderer from './nodes/switch/SwitchNodeRenderer';
import IfNodeRenderer from './nodes/if/IfNodeRenderer';
import ClearscreenNodeRenderer from './nodes/clearscreen/ClearscreenNodeRenderer';
import CodeNodeRenderer from './nodes/code/CodeNodeRenderer';
import PromptNodeRenderer from './nodes/prompt/PromptNodeRenderer';
import GetkeyNodeRenderer from './nodes/getkey/GetkeyNodeRenderer';
import OnlyIfNodeRenderer from './nodes/only_if/OnlyIfNodeRenderer';
import MacroNodeRenderer from './nodes/macro/MacroNodeRenderer';

interface VisualFlowProps {
  ast: ScriptNode;
  activeNodeId: string | null;
  executedNodeIds: Set<string>;
  skippedNodeIds: Set<string>;
  onSelectNode: (node: BplAstNode) => void;
  selectedNodeId: string | null;
  onAddNode: (targetNodeId: string, type: any) => void;
  onDeleteNode: (nodeId: string) => void;
}

export default function VisualFlow({
  ast,
  activeNodeId,
  executedNodeIds,
  skippedNodeIds,
  onSelectNode,
  selectedNodeId,
  onAddNode,
  onDeleteNode,
}: VisualFlowProps) {
  return (
    <div className="p-6 overflow-y-auto max-h-[calc(100vh-14rem)] space-y-4 select-none">
      <div className="flex items-center justify-between border-b border-gray-100 pb-3 mb-6">
        <div className="flex items-center gap-2">
          <div className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse" />
          <h2 className="text-sm font-semibold text-gray-700 uppercase tracking-wider">
            Flow Graph Designer
          </h2>
        </div>
        <div className="flex items-center gap-4 text-xs text-gray-400">
          <span className="flex items-center gap-1">
            <span className="w-2 h-2 rounded-full bg-indigo-500" /> Active
          </span>
          <span className="flex items-center gap-1">
            <span className="w-2 h-2 rounded-full bg-emerald-500" /> Executed
          </span>
          <span className="flex items-center gap-1">
            <span className="w-2 h-2 rounded-full bg-gray-300" /> Unreached
          </span>
        </div>
      </div>

      <div className="relative pl-4 border-l border-indigo-100 space-y-6">
        {/* Script Header */}
        <div className="relative -ml-[25px] flex items-center gap-3">
          <div className="w-4 h-4 rounded-full bg-indigo-600 border-4 border-white shadow-sm ring-1 ring-indigo-200 flex items-center justify-center" />
          <div className="bg-transparent border border-indigo-100 rounded-lg px-4 py-2 flex items-center gap-2">
            <Settings className="w-4 h-4 text-indigo-600" />
            <span className="text-xs font-semibold text-indigo-800 tracking-wide uppercase">
              Script: {ast.name}
            </span>
          </div>
        </div>

        {/* Start Insert Button */}
        <AddNodeButton onAdd={(type) => onAddNode('root', type)} className="-ml-[28px]" />

        {/* Children blocks */}
        <div className="space-y-4">
          {ast.children.map((child) => (
            <React.Fragment key={child.id}>
              <NodeRenderer
                node={child}
                activeNodeId={activeNodeId}
                executedNodeIds={executedNodeIds}
                skippedNodeIds={skippedNodeIds}
                onSelectNode={onSelectNode}
                selectedNodeId={selectedNodeId}
                onAddNode={onAddNode}
                onDeleteNode={onDeleteNode}
              />
              <AddNodeButton onAdd={(type) => onAddNode(child.id, type)} className="-ml-[28px]" />
            </React.Fragment>
          ))}
        </div>

        {/* Script Footer */}
        <div className="relative -ml-[25px] flex items-center gap-3 pt-4">
          <div className="w-4 h-4 rounded-full bg-gray-400 border-4 border-white shadow-sm ring-1 ring-gray-200" />
          <div className="bg-transparent border border-gray-100 rounded-lg px-3 py-1 text-xs text-gray-500">
            End Script
          </div>
        </div>
      </div>
    </div>
  );
}

interface NodeRendererProps {
  key?: string | number;
  node: BplAstNode;
  activeNodeId: string | null;
  executedNodeIds: Set<string>;
  skippedNodeIds: Set<string>;
  onSelectNode: (node: BplAstNode) => void;
  selectedNodeId: string | null;
  onAddNode: (targetNodeId: string, type: any) => void;
  onDeleteNode: (nodeId: string) => void;
}

function NodeRenderer({
  node,
  activeNodeId,
  executedNodeIds,
  skippedNodeIds,
  onSelectNode,
  selectedNodeId,
  onAddNode,
  onDeleteNode,
}: NodeRendererProps) {
  const isActive = activeNodeId === node.id;
  const isExecuted = executedNodeIds.has(node.id);
  const isSkipped = skippedNodeIds.has(node.id);

  const getStatusBorder = () => {
    if (isActive) return 'border-indigo-500 shadow-lg ring-2 ring-indigo-200 animate-pulse';
    if (isExecuted) return 'border-emerald-300 shadow-sm';
    if (isSkipped) return 'border-gray-200 opacity-40 grayscale';
    return 'border-gray-200';
  };

  const getStatusBg = () => {
    if (isActive) return 'bg-white';
    if (isExecuted) return 'bg-white';
    if (isSkipped) return 'bg-gray-50';
    return 'bg-white';
  };

  const handleSelect = (e: React.MouseEvent) => {
    e.stopPropagation();
    onSelectNode(node);
  };

  const statusBadge = (
    <StatusBadge isActive={isActive} isExecuted={isExecuted} isSkipped={isSkipped} />
  );

  const renderNestedNode = (cb: BplAstNode) => (
    <NodeRenderer
      key={cb.id}
      node={cb}
      activeNodeId={activeNodeId}
      executedNodeIds={executedNodeIds}
      skippedNodeIds={skippedNodeIds}
      onSelectNode={onSelectNode}
      selectedNodeId={selectedNodeId}
      onAddNode={onAddNode}
      onDeleteNode={onDeleteNode}
    />
  );

  const renderAddButton = (targetId: string, className?: string) => (
    <AddNodeButton
      onAdd={(type) => onAddNode(targetId, type)}
      className={className}
    />
  );

  // Modular switch-case routing to separate component files
  switch (node.type) {
    case 'log':
      return (
        <motion.div layout>
          <LogNodeRenderer
            node={node as LogNode}
            isActive={isActive}
            isExecuted={isExecuted}
            isSkipped={isSkipped}
            selectedNodeId={selectedNodeId}
            onSelect={handleSelect}
            onDelete={() => onDeleteNode(node.id)}
            statusBadge={statusBadge}
            getStatusBorder={getStatusBorder}
            getStatusBg={getStatusBg}
          />
        </motion.div>
      );

    case 'assign':
      return (
        <motion.div layout>
          <AssignNodeRenderer
            node={node as AssignNode}
            selectedNodeId={selectedNodeId}
            onSelect={handleSelect}
            onDelete={() => onDeleteNode(node.id)}
            statusBadge={statusBadge}
            getStatusBorder={getStatusBorder}
            getStatusBg={getStatusBg}
          />
        </motion.div>
      );

    case 'include':
      return (
        <motion.div layout>
          <IncludeNodeRenderer
            node={node as IncludeNode}
            selectedNodeId={selectedNodeId}
            onSelect={handleSelect}
            onDelete={() => onDeleteNode(node.id)}
            statusBadge={statusBadge}
            getStatusBorder={getStatusBorder}
            getStatusBg={getStatusBg}
          />
        </motion.div>
      );

    case 'import':
      return (
        <motion.div layout>
          <ImportNodeRenderer
            node={node as ImportNode}
            selectedNodeId={selectedNodeId}
            onSelect={handleSelect}
            onDelete={() => onDeleteNode(node.id)}
            statusBadge={statusBadge}
            getStatusBorder={getStatusBorder}
            getStatusBg={getStatusBg}
          />
        </motion.div>
      );

    case 'jump':
      return (
        <motion.div layout>
          <JumpNodeRenderer
            node={node as JumpNode}
            selectedNodeId={selectedNodeId}
            onSelect={handleSelect}
            onDelete={() => onDeleteNode(node.id)}
            statusBadge={statusBadge}
            getStatusBorder={getStatusBorder}
            getStatusBg={getStatusBg}
          />
        </motion.div>
      );

    case 'label':
      return (
        <motion.div layout>
          <LabelNodeRenderer
            node={node as LabelNode}
            isActive={isActive}
            selectedNodeId={selectedNodeId}
            onSelect={handleSelect}
            onDelete={() => onDeleteNode(node.id)}
          />
        </motion.div>
      );

    case 'return':
      return (
        <motion.div layout>
          <ReturnNodeRenderer
            node={node as ReturnNode}
            selectedNodeId={selectedNodeId}
            onSelect={handleSelect}
            onDelete={() => onDeleteNode(node.id)}
            statusBadge={statusBadge}
            getStatusBorder={getStatusBorder}
            getStatusBg={getStatusBg}
          />
        </motion.div>
      );

    case 'error':
      return (
        <motion.div layout>
          <ErrorNodeRenderer
            node={node as ErrorNode}
            selectedNodeId={selectedNodeId}
            onSelect={handleSelect}
            onDelete={() => onDeleteNode(node.id)}
            statusBadge={statusBadge}
            getStatusBorder={getStatusBorder}
            getStatusBg={getStatusBg}
          />
        </motion.div>
      );

    case 'validation':
      return (
        <motion.div layout>
          <ValidationNodeRenderer
            node={node as ValidationNode}
            selectedNodeId={selectedNodeId}
            onSelect={handleSelect}
            onDelete={() => onDeleteNode(node.id)}
            statusBadge={statusBadge}
            getStatusBorder={getStatusBorder}
            getStatusBg={getStatusBg}
          />
        </motion.div>
      );

    case 'api-call':
      return (
        <motion.div layout>
          <ApiCallNodeRenderer
            node={node as ApiCallNode}
            selectedNodeId={selectedNodeId}
            onSelect={handleSelect}
            onDelete={() => onDeleteNode(node.id)}
            statusBadge={statusBadge}
            getStatusBorder={getStatusBorder}
            getStatusBg={getStatusBg}
          />
        </motion.div>
      );

    case 'clearscreen':
      return (
        <motion.div layout>
          <ClearscreenNodeRenderer
            node={node as ClearscreenNode}
            selectedNodeId={selectedNodeId}
            onSelect={handleSelect}
            onDelete={() => onDeleteNode(node.id)}
            statusBadge={statusBadge}
            getStatusBorder={getStatusBorder}
            getStatusBg={getStatusBg}
          />
        </motion.div>
      );

    case 'code':
      return (
        <motion.div layout>
          <CodeNodeRenderer
            node={node as CodeNode}
            selectedNodeId={selectedNodeId}
            onSelect={handleSelect}
            onDelete={() => onDeleteNode(node.id)}
            statusBadge={statusBadge}
            getStatusBorder={getStatusBorder}
            getStatusBg={getStatusBg}
          />
        </motion.div>
      );

    case 'prompt':
      return (
        <motion.div layout>
          <PromptNodeRenderer
            node={node as PromptNode}
            selectedNodeId={selectedNodeId}
            onSelect={handleSelect}
            onDelete={() => onDeleteNode(node.id)}
            statusBadge={statusBadge}
            getStatusBorder={getStatusBorder}
            getStatusBg={getStatusBg}
          />
        </motion.div>
      );

    case 'getkey':
      return (
        <motion.div layout>
          <GetkeyNodeRenderer
            node={node as GetkeyNode}
            selectedNodeId={selectedNodeId}
            onSelect={handleSelect}
            onDelete={() => onDeleteNode(node.id)}
            statusBadge={statusBadge}
            getStatusBorder={getStatusBorder}
            getStatusBg={getStatusBg}
          />
        </motion.div>
      );

    case 'only_if':
      return (
        <motion.div layout>
          <OnlyIfNodeRenderer
            node={node as OnlyIfNode}
            selectedNodeId={selectedNodeId}
            onSelect={handleSelect}
            onDelete={() => onDeleteNode(node.id)}
            statusBadge={statusBadge}
            getStatusBorder={getStatusBorder}
            renderNode={renderNestedNode}
            renderAddButton={renderAddButton}
          />
        </motion.div>
      );

    case 'loop':
      return (
        <motion.div layout>
          <LoopNodeRenderer
            node={node as LoopNode}
            selectedNodeId={selectedNodeId}
            onSelect={handleSelect}
            onDelete={() => onDeleteNode(node.id)}
            statusBadge={statusBadge}
            getStatusBorder={getStatusBorder}
            renderNode={renderNestedNode}
            renderAddButton={renderAddButton}
          />
        </motion.div>
      );

    case 'macro':
      return (
        <motion.div layout>
          <MacroNodeRenderer
            node={node as any}
            selectedNodeId={selectedNodeId}
            onSelect={handleSelect}
            onDelete={() => onDeleteNode(node.id)}
            statusBadge={statusBadge}
            getStatusBorder={getStatusBorder}
            renderNode={renderNestedNode}
            renderAddButton={renderAddButton}
          />
        </motion.div>
      );

    case 'switch':
      return (
        <motion.div layout>
          <SwitchNodeRenderer
            node={node as SwitchNode}
            selectedNodeId={selectedNodeId}
            onSelect={handleSelect}
            onDelete={() => onDeleteNode(node.id)}
            statusBadge={statusBadge}
            getStatusBorder={getStatusBorder}
            renderNode={renderNestedNode}
            renderAddButton={renderAddButton}
          />
        </motion.div>
      );

    case 'if':
      return (
        <motion.div layout>
          <IfNodeRenderer
            node={node as IfNode}
            selectedNodeId={selectedNodeId}
            onSelect={handleSelect}
            onDelete={() => onDeleteNode(node.id)}
            statusBadge={statusBadge}
            getStatusBorder={getStatusBorder}
            renderNode={renderNestedNode}
            renderAddButton={renderAddButton}
          />
        </motion.div>
      );

    default:
      return null;
  }
}

interface StatusBadgeProps {
  isActive: boolean;
  isExecuted: boolean;
  isSkipped: boolean;
}

function StatusBadge({ isActive, isExecuted, isSkipped }: StatusBadgeProps) {
  if (isActive) {
    return (
      <span className="flex items-center gap-1 text-[9px] font-bold text-indigo-600 uppercase bg-indigo-50 px-1.5 py-0.5 rounded tracking-wide animate-pulse">
        <Play className="w-2.5 h-2.5 fill-indigo-600" /> Active
      </span>
    );
  }
  if (isExecuted) {
    return (
      <span className="flex items-center gap-0.5 text-[9px] font-bold text-emerald-600 uppercase bg-emerald-50 px-1.5 py-0.5 rounded tracking-wide">
        <CheckCircle2 className="w-2.5 h-2.5" /> Fired
      </span>
    );
  }
  if (isSkipped) {
    return (
      <span className="flex items-center gap-0.5 text-[9px] font-bold text-gray-400 uppercase bg-gray-100 px-1.5 py-0.5 rounded tracking-wide">
        <XCircle className="w-2.5 h-2.5" /> Skipped
      </span>
    );
  }
  return null;
}

interface AddNodeButtonProps {
  onAdd: (type: any) => void;
  className?: string;
}

function AddNodeButton({ onAdd, className = '' }: AddNodeButtonProps) {
  const [isOpen, setIsOpen] = React.useState(false);

  return (
    <div className={`relative group/add my-1.5 py-1 flex items-center justify-start ${className}`}>
      {/* Visual dotted connector line hover accent */}
      <div className="absolute left-0 right-0 h-px border-t border-dashed border-indigo-200/40 group-hover/add:border-indigo-400/80 transition" />
      
      <button
        onClick={(e) => {
          e.stopPropagation();
          setIsOpen(!isOpen);
        }}
        className="relative z-10 w-5 h-5 rounded-full bg-white hover:bg-indigo-500 border border-indigo-200 hover:border-indigo-500 flex items-center justify-center text-indigo-500 hover:text-white shadow-xs hover:shadow-md transition-all hover:scale-110 cursor-pointer"
        title="Insert node here"
      >
        <span className="text-[11px] font-bold leading-none">+</span>
      </button>

      {isOpen && (
        <>
          <div
            className="fixed inset-0 z-30"
            onClick={(e) => {
              e.stopPropagation();
              setIsOpen(false);
            }}
          />
          <div className="absolute top-7 left-1/2 -translate-x-1/2 bg-white border border-gray-150 rounded-xl shadow-xl py-1.5 min-w-[155px] z-40 flex flex-col gap-0.5 text-left text-xs font-semibold text-gray-700 animate-in fade-in slide-in-from-top-1 duration-150 max-h-60 overflow-y-auto">
            <div className="px-3 py-1 text-[9px] uppercase font-bold text-gray-400 border-b border-gray-100 mb-1 tracking-wider">
              Insert New Node
            </div>
            <button
              onClick={(e) => {
                e.stopPropagation();
                onAdd('log');
                setIsOpen(false);
              }}
              className="px-3 py-1.5 hover:bg-indigo-50 hover:text-indigo-600 flex items-center gap-2 transition text-left w-full cursor-pointer"
            >
              <Eye className="w-3.5 h-3.5 text-gray-400" />
              <span>System Log</span>
            </button>
            <button
              onClick={(e) => {
                e.stopPropagation();
                onAdd('assign');
                setIsOpen(false);
              }}
              className="px-3 py-1.5 hover:bg-indigo-50 hover:text-indigo-600 flex items-center gap-2 transition text-left w-full cursor-pointer"
            >
              <Bookmark className="w-3.5 h-3.5 text-gray-400" />
              <span>Assignment</span>
            </button>
            <button
              onClick={(e) => {
                e.stopPropagation();
                onAdd('include');
                setIsOpen(false);
              }}
              className="px-3 py-1.5 hover:bg-indigo-50 hover:text-indigo-600 flex items-center gap-2 transition text-left w-full cursor-pointer"
            >
              <FileText className="w-3.5 h-3.5 text-gray-400" />
              <span>Include Template</span>
            </button>
            <button
              onClick={(e) => {
                e.stopPropagation();
                onAdd('jump');
                setIsOpen(false);
              }}
              className="px-3 py-1.5 hover:bg-indigo-50 hover:text-indigo-600 flex items-center gap-2 transition text-left w-full cursor-pointer"
            >
              <ArrowRight className="w-3.5 h-3.5 text-gray-400" />
              <span>Jump Target</span>
            </button>
            <button
              onClick={(e) => {
                e.stopPropagation();
                onAdd('validation');
                setIsOpen(false);
              }}
              className="px-3 py-1.5 hover:bg-indigo-50 hover:text-indigo-600 flex items-center gap-2 transition text-left w-full cursor-pointer"
            >
              <AlertOctagon className="w-3.5 h-3.5 text-gray-400" />
              <span>Assertion Validation</span>
            </button>
            <button
              onClick={(e) => {
                e.stopPropagation();
                onAdd('if');
                setIsOpen(false);
              }}
              className="px-3 py-1.5 hover:bg-indigo-50 hover:text-indigo-600 flex items-center gap-2 transition text-left w-full cursor-pointer"
            >
              <GitBranch className="w-3.5 h-3.5 text-gray-400" />
              <span>Branch Validation</span>
            </button>
            <button
              onClick={(e) => {
                e.stopPropagation();
                onAdd('clearscreen');
                setIsOpen(false);
              }}
              className="px-3 py-1.5 hover:bg-indigo-50 hover:text-indigo-600 flex items-center gap-2 transition text-left w-full cursor-pointer"
            >
              <Monitor className="w-3.5 h-3.5 text-gray-400" />
              <span>Clear Screen</span>
            </button>
            <button
              onClick={(e) => {
                e.stopPropagation();
                onAdd('code');
                setIsOpen(false);
              }}
              className="px-3 py-1.5 hover:bg-indigo-50 hover:text-indigo-600 flex items-center gap-2 transition text-left w-full cursor-pointer"
            >
              <Terminal className="w-3.5 h-3.5 text-gray-400" />
              <span>Code Block</span>
            </button>
            <button
              onClick={(e) => {
                e.stopPropagation();
                onAdd('prompt');
                setIsOpen(false);
              }}
              className="px-3 py-1.5 hover:bg-indigo-50 hover:text-indigo-600 flex items-center gap-2 transition text-left w-full cursor-pointer"
            >
              <MessageSquare className="w-3.5 h-3.5 text-gray-400" />
              <span>Interactive Prompt</span>
            </button>
            <button
              onClick={(e) => {
                e.stopPropagation();
                onAdd('getkey');
                setIsOpen(false);
              }}
              className="px-3 py-1.5 hover:bg-indigo-50 hover:text-indigo-600 flex items-center gap-2 transition text-left w-full cursor-pointer"
            >
              <Keyboard className="w-3.5 h-3.5 text-gray-400" />
              <span>Get Keystroke</span>
            </button>
            <button
              onClick={(e) => {
                e.stopPropagation();
                onAdd('only_if');
                setIsOpen(false);
              }}
              className="px-3 py-1.5 hover:bg-indigo-50 hover:text-indigo-600 flex items-center gap-2 transition text-left w-full cursor-pointer"
            >
              <ToggleLeft className="w-3.5 h-3.5 text-gray-400" />
              <span>Only If Block</span>
            </button>
            <button
              onClick={(e) => {
                e.stopPropagation();
                onAdd('macro');
                setIsOpen(false);
              }}
              className="px-3 py-1.5 hover:bg-indigo-50 hover:text-indigo-600 flex items-center gap-2 transition text-left w-full cursor-pointer"
            >
              <Cpu className="w-3.5 h-3.5 text-gray-400" />
              <span>Macro Block</span>
            </button>
          </div>
        </>
      )}
    </div>
  );
}
