/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import {
  BplAstNode,
  ScriptNode,
  LabelNode,
  MacroNode,
} from '../types/bpl';
import {
  Settings,
  Award,
  X,
} from 'lucide-react';

// Import modular node editors
import LogNodeEditor from './nodes/log/LogNodeEditor';
import AssignNodeEditor from './nodes/assign/AssignNodeEditor';
import IncludeNodeEditor from './nodes/include/IncludeNodeEditor';
import ImportNodeEditor from './nodes/import/ImportNodeEditor';
import JumpNodeEditor from './nodes/jump/JumpNodeEditor';
import LabelNodeEditor from './nodes/label/LabelNodeEditor';
import ReturnNodeEditor from './nodes/return/ReturnNodeEditor';
import ErrorNodeEditor from './nodes/error/ErrorNodeEditor';
import ValidationNodeEditor from './nodes/validation/ValidationNodeEditor';
import ApiCallNodeEditor from './nodes/api-call/ApiCallNodeEditor';
import LoopNodeEditor from './nodes/loop/LoopNodeEditor';
import SwitchNodeEditor from './nodes/switch/SwitchNodeEditor';
import IfNodeEditor from './nodes/if/IfNodeEditor';
import ClearscreenNodeEditor from './nodes/clearscreen/ClearscreenNodeEditor';
import CodeNodeEditor from './nodes/code/CodeNodeEditor';
import PromptNodeEditor from './nodes/prompt/PromptNodeEditor';
import GetkeyNodeEditor from './nodes/getkey/GetkeyNodeEditor';
import OnlyIfNodeEditor from './nodes/only_if/OnlyIfNodeEditor';
import MacroNodeEditor from './nodes/macro/MacroNodeEditor';

interface NodeEditorProps {
  selectedNode: BplAstNode;
  onUpdateNodeProperty: (nodeId: string, updatedFields: Partial<BplAstNode>) => void;
  onClose: () => void;
  ast: ScriptNode | null;
}

export default function NodeEditor({
  selectedNode,
  onUpdateNodeProperty,
  onClose,
  ast,
}: NodeEditorProps) {
  // Recursively collect all label names in the AST
  const collectLabels = (nodes: BplAstNode[]): string[] => {
    const labels: string[] = [];
    const walk = (list: BplAstNode[]) => {
      for (const n of list) {
        if (n.type === 'label') {
          labels.push((n as LabelNode).name);
        } else if (n.type === 'if') {
          const ifNode = n as any;
          walk(ifNode.thenBlock);
          ifNode.elseIfBlocks?.forEach((elif: any) => walk(elif.block));
          if (ifNode.elseBlock) walk(ifNode.elseBlock);
        } else if (n.type === 'switch') {
          const swNode = n as any;
          swNode.cases.forEach((c: any) => walk(c.block));
          if (swNode.defaultBlock) walk(swNode.defaultBlock);
        } else if (n.type === 'loop') {
          walk((n as any).block);
        } else if (n.type === 'macro') {
          walk((n as any).block);
        } else if (n.type === 'only_if') {
          const oin = n as any;
          oin.cases.forEach((c: any) => walk(c.block));
        }
      }
    };
    if (nodes) walk(nodes);
    return Array.from(new Set(labels));
  };

  const availableLabels = ast ? collectLabels(ast.children) : [];

  const renderNodeSpecificEditor = () => {
    const handleUpdate = (updatedFields: any) => {
      onUpdateNodeProperty(selectedNode.id, updatedFields);
    };

    switch (selectedNode.type) {
      case 'log':
        return <LogNodeEditor node={selectedNode as any} onUpdate={handleUpdate} />;
      case 'assign':
        return <AssignNodeEditor node={selectedNode as any} onUpdate={handleUpdate} />;
      case 'include':
        return <IncludeNodeEditor node={selectedNode as any} onUpdate={handleUpdate} />;
      case 'import':
        return <ImportNodeEditor node={selectedNode as any} onUpdate={handleUpdate} />;
      case 'jump':
        return (
          <JumpNodeEditor
            node={selectedNode as any}
            onUpdate={handleUpdate}
            availableLabels={availableLabels}
          />
        );
      case 'label':
        return <LabelNodeEditor node={selectedNode as any} onUpdate={handleUpdate} />;
      case 'return':
        return <ReturnNodeEditor node={selectedNode as any} />;
      case 'error':
        return <ErrorNodeEditor node={selectedNode as any} onUpdate={handleUpdate} />;
      case 'validation':
        return <ValidationNodeEditor node={selectedNode as any} onUpdate={handleUpdate} />;
      case 'api-call':
        return <ApiCallNodeEditor node={selectedNode as any} onUpdate={handleUpdate} />;
      case 'loop':
        return <LoopNodeEditor node={selectedNode as any} onUpdate={handleUpdate} />;
      case 'macro':
        return <MacroNodeEditor node={selectedNode as MacroNode} onUpdate={handleUpdate} />;
      case 'switch':
        return <SwitchNodeEditor node={selectedNode as any} onUpdate={handleUpdate} />;
      case 'if':
        return <IfNodeEditor node={selectedNode as any} onUpdate={handleUpdate} />;
      case 'clearscreen':
        return <ClearscreenNodeEditor node={selectedNode as any} />;
      case 'code':
        return <CodeNodeEditor node={selectedNode as any} />;
      case 'prompt':
        return <PromptNodeEditor node={selectedNode as any} onUpdate={handleUpdate} />;
      case 'getkey':
        return <GetkeyNodeEditor node={selectedNode as any} onUpdate={handleUpdate} />;
      case 'only_if':
        return <OnlyIfNodeEditor node={selectedNode as any} onUpdate={handleUpdate} />;
      default:
        return (
          <div className="text-gray-400 italic text-center py-4 bg-slate-50 border border-dashed rounded-xl">
            No configurable options for this node type ({selectedNode.type}).
          </div>
        );
    }
  };

  return (
    <div className="bg-white border border-gray-100 rounded-xl p-5 shadow-xs space-y-4">
      {/* Header */}
      <div className="flex items-center justify-between border-b border-gray-50 pb-2.5">
        <div className="flex items-center gap-1.5 text-indigo-600 font-semibold text-xs uppercase tracking-wide">
          <Award className="w-4 h-4 text-indigo-500" /> Dynamic Node Editor
        </div>
        <button
          onClick={onClose}
          className="text-gray-400 hover:text-gray-600 font-bold p-1 hover:bg-gray-50 rounded-full transition"
          title="Close Node Editor"
        >
          <X className="w-4 h-4" />
        </button>
      </div>

      {/* Editor Body */}
      <div className="space-y-4 font-mono text-[11px]">
        {/* Node Metadata Row */}
        <div className="grid grid-cols-2 gap-2 border-b border-slate-50 pb-2">
          <div>
            <span className="text-[9px] uppercase font-bold text-gray-400 block mb-0.5">
              Node Type
            </span>
            <span className="inline-flex items-center px-2 py-0.5 rounded-md text-[10px] font-bold bg-indigo-50 text-indigo-700 border border-indigo-100 uppercase tracking-wider">
              {selectedNode.type}
            </span>
          </div>
          <div>
            <span className="text-[9px] uppercase font-bold text-gray-400 block mb-0.5">
              Node ID
            </span>
            <span className="text-gray-500 font-semibold select-all font-mono">
              {selectedNode.id}
            </span>
          </div>
        </div>

        {/* Render node-specific editor */}
        {renderNodeSpecificEditor()}
      </div>

      {/* Tip helper */}
      <div className="bg-slate-50 rounded-xl p-3 border border-slate-100 flex items-start gap-2 select-none">
        <Settings className="w-4 h-4 text-slate-400 shrink-0 mt-0.5 animate-spin-slow" />
        <p className="text-[10px] text-slate-500 font-sans leading-relaxed">
          Modifications automatically sync live to both the Flow Graph Designer canvas and the BPL DSL text source code representation.
        </p>
      </div>
    </div>
  );
}
