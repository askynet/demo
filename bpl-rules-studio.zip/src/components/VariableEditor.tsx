/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { VariableState } from '../types/bpl';
import { Plus, Trash2, Database, ToggleLeft, Hash, Type, HelpCircle } from 'lucide-react';

interface VariableEditorProps {
  variables: VariableState;
  onChangeVariables: (vars: VariableState) => void;
}

export default function VariableEditor({
  variables,
  onChangeVariables,
}: VariableEditorProps) {
  const [newVarName, setNewVarName] = useState('');
  const [newVarType, setNewVarType] = useState<'string' | 'number' | 'boolean'>('string');
  const [newVarValue, setNewVarValue] = useState('');

  const [jsonError, setJsonError] = useState<string | null>(null);

  const handleUpdateValue = (key: string, value: any) => {
    onChangeVariables({
      ...variables,
      [key]: value,
    });
  };

  const handleAddVariable = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newVarName.trim()) return;

    const key = newVarName.trim();
    let val: any = '';
    if (newVarType === 'number') {
      val = 0;
    } else if (newVarType === 'boolean') {
      val = false;
    }

    onChangeVariables({
      ...variables,
      [key]: val,
    });
    setNewVarName('');
    setNewVarValue('');
  };

  const handleDeleteVariable = (key: string) => {
    const updated = { ...variables };
    delete updated[key];
    onChangeVariables(updated);
  };

  const handleJsonChange = (key: string, textValue: string) => {
    try {
      const parsed = JSON.parse(textValue);
      setJsonError(null);
      handleUpdateValue(key, parsed);
    } catch (err: any) {
      setJsonError(err.message || 'Invalid JSON format');
    }
  };

  return (
    <div className="bg-white border border-gray-100 rounded-xl shadow-sm p-5 space-y-5">
      <div className="flex items-center gap-2 border-b border-gray-50 pb-3">
        <Database className="w-4 h-4 text-emerald-500" />
        <h3 className="text-sm font-semibold text-gray-800">
          Input Context (Variables)
        </h3>
      </div>

      {/* Variables List */}
      <div className="space-y-4 max-h-[25rem] overflow-y-auto pr-1">
        {Object.keys(variables).length === 0 ? (
          <p className="text-xs text-gray-400 italic text-center py-4">
            No active input variables defined. Add one below!
          </p>
        ) : (
          Object.entries(variables).map(([key, val]) => {
            const isArray = Array.isArray(val) || typeof val === 'object';
            
            return (
              <div
                key={key}
                className="group relative flex flex-col gap-1.5 p-3.5 bg-gray-50 hover:bg-gray-50/80 border border-gray-100 rounded-xl transition-all"
              >
                {/* Variable Label & Actions */}
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-1.5">
                    {typeof val === 'number' && <Hash className="w-3.5 h-3.5 text-blue-500" />}
                    {typeof val === 'boolean' && <ToggleLeft className="w-3.5 h-3.5 text-amber-500" />}
                    {typeof val === 'string' && <Type className="w-3.5 h-3.5 text-teal-500" />}
                    {isArray && <Database className="w-3.5 h-3.5 text-purple-500" />}
                    <span className="text-xs font-semibold text-gray-700 font-mono">
                      {key}
                    </span>
                  </div>
                  <button
                    onClick={() => handleDeleteVariable(key)}
                    className="opacity-0 group-hover:opacity-100 text-gray-400 hover:text-rose-500 p-1 rounded transition"
                    title="Delete context variable"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>

                {/* Variable Input Field based on types */}
                {isArray ? (
                  <div className="mt-1">
                    <span className="text-[10px] font-bold text-gray-400 uppercase tracking-wider block mb-1">
                      JSON Array Context
                    </span>
                    <textarea
                      defaultValue={JSON.stringify(val, null, 2)}
                      onChange={(e) => handleJsonChange(key, e.target.value)}
                      className="w-full h-24 p-1.5 bg-white border border-gray-200 rounded-lg text-[11px] font-mono focus:ring-1 focus:ring-indigo-500 focus:outline-none"
                    />
                    {jsonError && (
                      <span className="text-[10px] text-rose-500 font-mono block mt-1">
                        {jsonError}
                      </span>
                    )}
                  </div>
                ) : typeof val === 'boolean' ? (
                  <div className="flex items-center gap-3 mt-1 select-none">
                    <label className="relative inline-flex items-center cursor-pointer">
                      <input
                        type="checkbox"
                        checked={val}
                        onChange={(e) => handleUpdateValue(key, e.target.checked)}
                        className="sr-only peer"
                      />
                      <div className="w-8 h-4 bg-gray-200 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-3 after:w-3 after:transition-all peer-checked:bg-amber-500"></div>
                    </label>
                    <span className="text-xs font-semibold font-mono text-gray-600">
                      {val ? 'TRUE' : 'FALSE'}
                    </span>
                  </div>
                ) : typeof val === 'number' ? (
                  <div className="mt-1 flex items-center gap-2">
                    <input
                      type="range"
                      min="0"
                      max={key.toLowerCase().includes('score') ? "1000" : "500"}
                      value={val}
                      onChange={(e) => handleUpdateValue(key, Number(e.target.value))}
                      className="w-full h-1 bg-gray-200 rounded-lg appearance-none cursor-pointer accent-blue-500"
                    />
                    <input
                      type="number"
                      value={val}
                      onChange={(e) => handleUpdateValue(key, Number(e.target.value))}
                      className="w-16 p-1 bg-white border border-gray-200 rounded text-center text-xs font-mono font-bold text-gray-800"
                    />
                  </div>
                ) : (
                  <input
                    type="text"
                    value={val}
                    onChange={(e) => handleUpdateValue(key, e.target.value)}
                    className="w-full mt-1 px-2 py-1 bg-white border border-gray-200 rounded-lg text-xs font-mono text-gray-700 focus:ring-1 focus:ring-indigo-500 focus:outline-none"
                  />
                )}
              </div>
            );
          })
        )}
      </div>

      {/* Add New Variable Form */}
      <form onSubmit={handleAddVariable} className="border-t border-gray-50 pt-4 space-y-3">
        <div className="flex items-center justify-between">
          <span className="text-xs font-bold text-gray-500 uppercase tracking-wider">
            Add Custom Field
          </span>
        </div>
        <div className="grid grid-cols-2 gap-2">
          <input
            type="text"
            placeholder="Variable name"
            value={newVarName}
            onChange={(e) => setNewVarName(e.target.value)}
            className="px-2.5 py-1.5 border border-gray-200 rounded-lg text-xs focus:ring-1 focus:ring-indigo-500 focus:outline-none"
          />
          <select
            value={newVarType}
            onChange={(e) => setNewVarType(e.target.value as any)}
            className="px-2 py-1.5 border border-gray-200 bg-white rounded-lg text-xs focus:ring-1 focus:ring-indigo-500 focus:outline-none"
          >
            <option value="string">String ("Y")</option>
            <option value="number">Number (18)</option>
            <option value="boolean">Boolean</option>
          </select>
        </div>
        <button
          type="submit"
          disabled={!newVarName.trim()}
          className="w-full py-2 bg-emerald-500 hover:bg-emerald-600 disabled:opacity-50 text-white rounded-lg text-xs font-semibold flex items-center justify-center gap-1.5 transition shadow-sm cursor-pointer"
        >
          <Plus className="w-4 h-4" /> Add Variable
        </button>
      </form>
    </div>
  );
}
