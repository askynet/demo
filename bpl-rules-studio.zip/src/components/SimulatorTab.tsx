import React from 'react';
import { Play, Pause, ChevronLeft, ChevronRight, Sliders, FileText } from 'lucide-react';
import { TraceStep, VariableState } from '../types/bpl';

interface SimulatorTabProps {
  traceSteps: TraceStep[];
  currentStepIndex: number;
  setCurrentStepIndex: (idx: number | ((prev: number) => number)) => void;
  isPlaying: boolean;
  setIsPlaying: (playing: boolean | ((prev: boolean) => boolean)) => void;
  playbackSpeed: number;
  setPlaybackSpeed: (speed: number) => void;
  activeVariables: VariableState;
  activeLogs: string[];
  activeIncludes: any[];
}

export default function SimulatorTab({
  traceSteps,
  currentStepIndex,
  setCurrentStepIndex,
  isPlaying,
  setIsPlaying,
  playbackSpeed,
  setPlaybackSpeed,
  activeVariables,
  activeLogs,
  activeIncludes
}: SimulatorTabProps) {
  return (
    <div className="space-y-4 text-left">
      {/* Playback trace controls */}
      <div className="bg-slate-50 border border-gray-200/80 p-3 rounded-2xl flex flex-col space-y-3">
        <div className="flex items-center justify-between text-[11px] font-bold text-gray-500">
          <span>Step Player Controls</span>
          <span className="font-mono text-indigo-600 bg-white px-1.5 py-0.5 rounded border">
            Step {currentStepIndex + 1} / {traceSteps.length || 1}
          </span>
        </div>

        <div className="flex items-center justify-between gap-2">
          <div className="flex items-center gap-1">
            <button
              onClick={() => setCurrentStepIndex((prev) => Math.max(0, prev - 1))}
              disabled={currentStepIndex === 0 || traceSteps.length === 0}
              className="p-1.5 bg-white border border-gray-200 hover:bg-slate-50 disabled:opacity-40 rounded-lg text-slate-700 transition cursor-pointer"
              title="Step Backward"
            >
              <ChevronLeft className="w-3.5 h-3.5" />
            </button>

            <button
              onClick={() => setIsPlaying((p) => !p)}
              disabled={traceSteps.length === 0}
              className={`flex items-center gap-1 px-2.5 py-1 rounded-lg text-[10px] font-bold transition cursor-pointer ${
                isPlaying 
                  ? 'bg-amber-600 text-white' 
                  : 'bg-indigo-600 text-white'
              }`}
            >
              {isPlaying ? <Pause className="w-3 h-3" /> : <Play className="w-3 h-3" />}
              {isPlaying ? 'Pause' : 'Play'}
            </button>

            <button
              onClick={() => setCurrentStepIndex((prev) => Math.min(traceSteps.length - 1, prev + 1))}
              disabled={currentStepIndex >= traceSteps.length - 1 || traceSteps.length === 0}
              className="p-1.5 bg-white border border-gray-200 hover:bg-slate-50 disabled:opacity-40 rounded-lg text-slate-700 transition cursor-pointer"
              title="Step Forward"
            >
              <ChevronRight className="w-3.5 h-3.5" />
            </button>
          </div>

          {/* Playback speed selector */}
          <div className="flex items-center gap-1 bg-white border px-1.5 py-0.5 rounded-lg">
            {[1, 2, 5].map((spd) => (
              <button
                key={spd}
                onClick={() => setPlaybackSpeed(spd)}
                className={`px-1 py-0.2 rounded text-[8px] font-bold transition cursor-pointer ${
                  playbackSpeed === spd ? 'bg-indigo-50 text-indigo-600 font-extrabold' : 'text-slate-400'
                }`}
              >
                {spd}x
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Variables scope snapshot watchlist */}
      <div className="space-y-2">
        <span className="text-[10px] font-bold text-gray-400 uppercase tracking-widest block">Variable State Watcher:</span>
        <div className="space-y-1 max-h-[140px] overflow-y-auto pr-1">
          {Object.keys(activeVariables).length === 0 ? (
            <p className="text-[10px] text-gray-400 italic font-mono py-2 text-center">No active fields in scope.</p>
          ) : (
            Object.entries(activeVariables).map(([key, val]) => (
              <div key={key} className="flex items-center justify-between p-2 bg-slate-50 border rounded-lg text-[11px]">
                <span className="font-mono text-slate-600 truncate">{key}</span>
                <span className="font-mono font-bold text-indigo-600 bg-white border px-1.5 py-0.2 rounded">
                  {typeof val === 'boolean' ? (val ? 'TRUE' : 'FALSE') : String(val)}
                </span>
              </div>
            ))
          )}
        </div>
      </div>

      {/* Pathway step evaluation descriptions */}
      <div className="space-y-2">
        <span className="text-[10px] font-bold text-gray-400 uppercase tracking-widest block">Trace Step Sequence:</span>
        <div className="space-y-1 max-h-[150px] overflow-y-auto pr-1">
          {traceSteps.length === 0 ? (
            <p className="text-[10px] text-gray-400 italic py-2 text-center">Check visual rules compile status.</p>
          ) : (
            traceSteps.map((step, idx) => {
              const isCurrent = currentStepIndex === idx;
              return (
                <div
                  key={idx}
                  onClick={() => setCurrentStepIndex(idx)}
                  className={`p-2 rounded-xl border text-[11px] font-mono transition cursor-pointer ${
                    isCurrent
                      ? 'bg-indigo-50 border-indigo-200 text-indigo-900 font-bold'
                      : 'bg-white border-gray-150 hover:bg-slate-50 text-gray-600'
                  }`}
                >
                  <div className="flex items-center justify-between text-[9px] mb-0.5">
                    <span className="text-slate-400">STEP {idx + 1}</span>
                    <span className={`px-1 py-0.1 rounded text-[8px] font-bold ${step.executed ? 'bg-emerald-50 text-emerald-700' : 'bg-slate-100 text-gray-400'}`}>
                      {step.executed ? 'EXEC' : 'SKIP'}
                    </span>
                  </div>
                  <p className="line-clamp-2">{step.description || 'Instruction processed.'}</p>
                </div>
              );
            })
          )}
        </div>
      </div>

      {/* Included document templates output */}
      <div className="space-y-2">
        <span className="text-[10px] font-bold text-gray-400 uppercase tracking-widest block">Matched Document Outputs:</span>
        {activeIncludes.length === 0 ? (
          <p className="text-[10px] text-gray-400 italic py-2.5 text-center bg-slate-50 border border-dashed rounded-xl select-none">No document templates appended.</p>
        ) : (
          <div className="space-y-1.5 max-h-[120px] overflow-y-auto">
            {activeIncludes.map((inc, i) => (
              <div key={i} className="p-2 bg-sky-50 border border-sky-100 rounded-xl flex items-center justify-between">
                <span className="text-[10px] font-mono font-bold text-sky-800 truncate block">{inc.path}</span>
                <span className="text-[8px] bg-sky-200 text-sky-800 font-bold px-1.5 py-0.2 rounded uppercase shrink-0">Chunk</span>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Interactive diagnostic shell */}
      <div className="bg-slate-900 rounded-xl p-3 font-mono text-[9px] text-slate-300 space-y-1">
        <div className="flex items-center justify-between border-b border-slate-800 pb-1 text-slate-500 font-bold mb-1.5 select-none">
          <span>DIAGNOSTIC TRACE SHELL</span>
          <span className="text-teal-400 animate-pulse">READY</span>
        </div>
        <div className="max-h-[100px] overflow-y-auto space-y-1">
          {activeLogs.length === 0 ? (
            <p className="text-slate-600 italic">No output logs printed. Step simulator.</p>
          ) : (
            activeLogs.map((log, idx) => {
              let textClass = 'text-slate-300';
              if (log.includes('[Assign]')) textClass = 'text-teal-300';
              if (log.includes('[Include]')) textClass = 'text-sky-300';
              if (log.includes('[ValidationError]')) textClass = 'text-rose-400 font-bold';
              return (
                <div key={idx} className="flex items-start gap-1">
                  <span className="text-slate-600 select-none">&gt;</span>
                  <p className={`${textClass} leading-tight break-all`}>{log}</p>
                </div>
              );
            })
          )}
        </div>
      </div>
    </div>
  );
}
