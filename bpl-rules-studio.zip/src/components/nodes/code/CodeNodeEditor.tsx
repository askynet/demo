import React from 'react';
import { CodeNode } from '../../../types/bpl';

interface CodeNodeEditorProps {
  node: CodeNode;
}

export default function CodeNodeEditor({ node }: CodeNodeEditorProps) {
  return (
    <div className="space-y-2 p-3.5 bg-slate-50 border border-slate-150 rounded-xl text-slate-600 font-sans">
      <p className="text-xs leading-relaxed">
        The <code className="font-mono bg-slate-200 px-1.5 py-0.5 rounded text-indigo-700">code</code> instruction marks interactive terminal behavior in BPL scripts.
      </p>
      <p className="text-[10px] text-gray-400 leading-relaxed">
        This instruction does not take parameters.
      </p>
    </div>
  );
}
