import React from 'react';
import { GetkeyNode } from '../../../types/bpl';
import { Keyboard, Trash2 } from 'lucide-react';

interface GetkeyNodeRendererProps {
  node: GetkeyNode;
  selectedNodeId: string | null;
  onSelect: (e: React.MouseEvent) => void;
  onDelete: () => void;
  statusBadge: React.ReactNode;
  getStatusBorder: () => string;
  getStatusBg: () => string;
}

export default function GetkeyNodeRenderer({
  node,
  selectedNodeId,
  onSelect,
  onDelete,
  statusBadge,
  getStatusBorder,
  getStatusBg,
}: GetkeyNodeRendererProps) {
  return (
    <div
      onClick={onSelect}
      className={`flex items-start gap-3 p-3.5 border rounded-xl cursor-pointer transition-all duration-300 max-w-xl ${getStatusBorder()} ${getStatusBg()} ${selectedNodeId === node.id ? 'ring-2 ring-indigo-500 ring-offset-1' : ''}`}
    >
      <div className="p-2 rounded-lg bg-orange-50 text-orange-600">
        <Keyboard className="w-4 h-4" />
      </div>
      <div className="flex-1 min-w-0">
        <div className="flex items-center justify-between gap-2">
          <span className="text-[10px] font-bold text-orange-500 uppercase tracking-wider font-mono">
            Get Keystroke
          </span>
          <div className="flex items-center gap-1.5" onClick={(e) => e.stopPropagation()}>
            {statusBadge}
            <button
              onClick={onDelete}
              className="p-1 rounded text-gray-400 hover:text-rose-500 hover:bg-rose-50 transition cursor-pointer"
              title="Delete node"
            >
              <Trash2 className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
        <p className="text-xs text-orange-700 font-semibold mt-1">
          Pauses and waits for any single keyboard stroke.
        </p>
        {node.variable && (
          <div className="mt-2 text-xs flex items-center gap-1.5 font-semibold bg-orange-50/50 px-2 py-1 rounded-md w-fit">
            <span className="text-[9px] text-orange-500 uppercase font-bold">Store key in:</span>
            <span className="font-mono text-orange-700 bg-orange-100/50 px-1 py-0.2 rounded">{node.variable}</span>
          </div>
        )}
      </div>
    </div>
  );
}
