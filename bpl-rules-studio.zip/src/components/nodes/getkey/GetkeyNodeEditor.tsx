import React from 'react';
import { GetkeyNode } from '../../../types/bpl';
import { Database } from 'lucide-react';

interface GetkeyNodeEditorProps {
  node: GetkeyNode;
  onUpdate: (updatedFields: Partial<GetkeyNode>) => void;
}

export default function GetkeyNodeEditor({ node, onUpdate }: GetkeyNodeEditorProps) {
  return (
    <div className="space-y-3.5 font-mono text-[11px]">
      <div>
        <label className="text-[10px] uppercase font-bold text-gray-400 block mb-1">
          Target Storage Variable
        </label>
        <div className="relative">
          <Database className="absolute left-2.5 top-2 w-3.5 h-3.5 text-orange-400" />
          <input
            type="text"
            value={node.variable || ''}
            onChange={(e) => onUpdate({ variable: e.target.value })}
            placeholder="e.g. keyInput"
            className="w-full pl-8 pr-2.5 py-1.5 border border-gray-200 rounded-lg text-xs font-mono focus:ring-1 focus:ring-indigo-500 focus:outline-none bg-slate-50/50 font-bold"
          />
        </div>
      </div>
    </div>
  );
}
