import React from 'react';
import { IncludeNode } from '../../../types/bpl';
import { FileText, Trash2 } from 'lucide-react';

interface IncludeNodeRendererProps {
  node: IncludeNode;
  selectedNodeId: string | null;
  onSelect: (e: React.MouseEvent) => void;
  onDelete: () => void;
  statusBadge: React.ReactNode;
  getStatusBorder: () => string;
  getStatusBg: () => string;
}

export default function IncludeNodeRenderer({
  node,
  selectedNodeId,
  onSelect,
  onDelete,
  statusBadge,
  getStatusBorder,
  getStatusBg,
}: IncludeNodeRendererProps) {
  return (
    <div
      onClick={onSelect}
      className={`flex items-start gap-3 p-3.5 border rounded-xl cursor-pointer transition-all duration-300 max-w-xl ${getStatusBorder()} ${getStatusBg()} ${selectedNodeId === node.id ? 'ring-2 ring-indigo-500 ring-offset-1' : ''}`}
    >
      <div className="p-2 rounded-lg bg-sky-50 text-sky-600">
        <FileText className="w-4 h-4" />
      </div>
      <div className="flex-1 min-w-0">
        <div className="flex items-center justify-between gap-2">
          <span className="text-[10px] font-bold text-sky-500 uppercase tracking-wider">
            Include Template
          </span>
          <div className="flex items-center gap-1.5" onClick={(e) => e.stopPropagation()}>
            {statusBadge}
            <button
              onClick={onDelete}
              className="p-1 rounded text-gray-400 hover:text-rose-500 hover:bg-rose-50 transition cursor-pointer"
              title="Delete node"
            >
              <Trash2 className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
        <p className="text-xs font-semibold text-gray-800 mt-1 font-mono">
          "{node.path}"
        </p>
        {node.parameters && node.parameters.length > 0 && (
          <div className="flex items-center gap-1 mt-1.5">
            <span className="text-[9px] text-gray-400 uppercase font-semibold">Send Context:</span>
            <div className="flex flex-wrap gap-1">
              {node.parameters.map((p) => (
                <span key={p} className="text-[10px] font-mono bg-sky-50 text-sky-700 px-1.5 py-0.5 rounded">
                  {p}
                </span>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
