import React from 'react';
import { ErrorNode } from '../../../types/bpl';
import { AlertCircle } from 'lucide-react';

interface ErrorNodeEditorProps {
  node: ErrorNode;
  onUpdate: (updatedFields: Partial<ErrorNode>) => void;
}

export default function ErrorNodeEditor({ node, onUpdate }: ErrorNodeEditorProps) {
  return (
    <div className="space-y-1.5 font-mono text-[11px]">
      <label className="text-[10px] uppercase font-bold text-gray-400 block">
        Error / Exit Message
      </label>
      <div className="relative">
        <AlertCircle className="absolute left-2.5 top-2.5 w-3.5 h-3.5 text-rose-500" />
        <textarea
          rows={2}
          value={node.message}
          onChange={(e) => onUpdate({ message: e.target.value })}
          placeholder="Termination error description"
          className="w-full pl-8 pr-2.5 py-1.5 border border-gray-200 rounded-lg text-xs font-mono focus:ring-1 focus:ring-indigo-500 focus:outline-none bg-slate-50/50 leading-relaxed text-rose-700"
        />
      </div>
    </div>
  );
}
