import React from 'react';
import { ClearscreenNode } from '../../../types/bpl';

interface ClearscreenNodeEditorProps {
  node: ClearscreenNode;
}

export default function ClearscreenNodeEditor({ node }: ClearscreenNodeEditorProps) {
  return (
    <div className="font-sans text-xs text-gray-500 py-2">
      Clearscreen command has no properties to configure. It will wipe all previous prompt messages from the output log at runtime.
    </div>
  );
}
