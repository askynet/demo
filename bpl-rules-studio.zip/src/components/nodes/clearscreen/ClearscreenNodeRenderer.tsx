import React from 'react';
import { ClearscreenNode } from '../../../types/bpl';
import { Monitor, Trash2 } from 'lucide-react';

interface ClearscreenNodeRendererProps {
  node: ClearscreenNode;
  selectedNodeId: string | null;
  onSelect: (e: React.MouseEvent) => void;
  onDelete: () => void;
  statusBadge: React.ReactNode;
  getStatusBorder: () => string;
  getStatusBg: () => string;
}

export default function ClearscreenNodeRenderer({
  node,
  selectedNodeId,
  onSelect,
  onDelete,
  statusBadge,
  getStatusBorder,
  getStatusBg,
}: ClearscreenNodeRendererProps) {
  return (
    <div
      onClick={onSelect}
      className={`flex items-start gap-3 p-3.5 border rounded-xl cursor-pointer transition-all duration-300 max-w-xl ${getStatusBorder()} ${getStatusBg()} ${selectedNodeId === node.id ? 'ring-2 ring-indigo-500 ring-offset-1' : ''}`}
    >
      <div className="p-2 rounded-lg bg-sky-50 text-sky-600">
        <Monitor className="w-4 h-4" />
      </div>
      <div className="flex-1 min-w-0">
        <div className="flex items-center justify-between gap-2">
          <span className="text-[10px] font-bold text-sky-500 uppercase tracking-wider">
            Clear Screen
          </span>
          <div className="flex items-center gap-1.5" onClick={(e) => e.stopPropagation()}>
            {statusBadge}
            <button
              onClick={onDelete}
              className="p-1 rounded text-gray-400 hover:text-rose-500 hover:bg-rose-50 transition cursor-pointer"
              title="Delete node"
            >
              <Trash2 className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
        <p className="text-xs text-sky-700 font-semibold mt-1">
          Clears user interactive console/terminal interface.
        </p>
      </div>
    </div>
  );
}
