import React from 'react';
import { LoopNode } from '../../../types/bpl';
import { Repeat, Trash2 } from 'lucide-react';

interface LoopNodeRendererProps {
  node: LoopNode;
  onSelect: (e: React.MouseEvent) => void;
  selectedNodeId: string | null;
  onDelete: () => void;
  statusBadge: React.ReactNode;
  getStatusBorder: () => string;
  renderNode: (cb: any) => React.ReactNode;
  renderAddButton: (targetId: string, className?: string) => React.ReactNode;
}

export default function LoopNodeRenderer({
  node,
  onSelect,
  selectedNodeId,
  onDelete,
  statusBadge,
  getStatusBorder,
  renderNode,
  renderAddButton,
}: LoopNodeRendererProps) {
  return (
    <div
      className={`border rounded-xl p-4 transition-all duration-300 max-w-xl ${getStatusBorder()} bg-transparent`}
    >
      <div
        onClick={onSelect}
        className={`flex items-start gap-3 pb-3 cursor-pointer ${selectedNodeId === node.id ? 'bg-indigo-50/20 -mx-2 px-2 py-1 rounded' : ''}`}
      >
        <div className="p-2 rounded-lg bg-emerald-50 text-emerald-600">
          <Repeat className="w-4 h-4" />
        </div>
        <div className="flex-1">
          <div className="flex items-center justify-between gap-2">
            <span className="text-[10px] font-bold text-emerald-500 uppercase tracking-wider">
              Loop Iteration
            </span>
            <div className="flex items-center gap-1.5" onClick={(e) => e.stopPropagation()}>
              {statusBadge}
              <button
                onClick={onDelete}
                className="p-1 rounded text-gray-400 hover:text-rose-500 hover:bg-rose-50/50 transition cursor-pointer"
                title="Delete node"
              >
                <Trash2 className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
          <div className="flex items-center gap-1 mt-1 text-xs text-gray-700">
            <span>For each</span>
            <span className="font-mono font-bold text-emerald-600 bg-emerald-50 px-1.5 rounded">{node.itemVar}</span>
            <span>in</span>
            <span className="font-mono font-bold text-emerald-600 bg-emerald-50 px-1.5 rounded">{node.collectionVar}</span>
          </div>
        </div>
      </div>

      {/* Loop Inner lanes */}
      <div className="relative pl-6 ml-4 border-l-2 border-dashed border-emerald-200 mt-2 space-y-4 pt-2">
        <div className="absolute top-0 left-0 -ml-[5px] w-2.5 h-2.5 rounded-full bg-emerald-300" />
        {node.block.length === 0 ? (
          <div className="py-2 pl-2 border border-dashed border-emerald-100 rounded-lg bg-emerald-50/10 flex flex-col gap-2">
            <span className="text-[10px] text-emerald-500 font-medium italic">Empty block (no children)</span>
            {renderAddButton(`empty-loop-${node.id}`, "-ml-[36px]")}
          </div>
        ) : (
          node.block.map((cb) => (
            <React.Fragment key={cb.id}>
              {renderNode(cb)}
              {renderAddButton(cb.id, "-ml-[36px]")}
            </React.Fragment>
          ))
        )}
      </div>
    </div>
  );
}
