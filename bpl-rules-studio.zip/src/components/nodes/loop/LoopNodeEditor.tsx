import React from 'react';
import { LoopNode } from '../../../types/bpl';

interface LoopNodeEditorProps {
  node: LoopNode;
  onUpdate: (updatedFields: Partial<LoopNode>) => void;
}

export default function LoopNodeEditor({ node, onUpdate }: LoopNodeEditorProps) {
  return (
    <div className="space-y-3 font-mono text-[11px]">
      <div>
        <label className="text-[10px] uppercase font-bold text-gray-400 block mb-1">
          Item Variable (Iterator)
        </label>
        <input
          type="text"
          value={node.itemVar}
          onChange={(e) => onUpdate({ itemVar: e.target.value })}
          placeholder="e.g. item"
          className="w-full px-2.5 py-1.5 border border-gray-200 rounded-lg text-xs font-mono focus:ring-1 focus:ring-indigo-500 focus:outline-none bg-slate-50/50"
        />
      </div>
      <div>
        <label className="text-[10px] uppercase font-bold text-gray-400 block mb-1">
          Collection Variable
        </label>
        <input
          type="text"
          value={node.collectionVar}
          onChange={(e) => onUpdate({ collectionVar: e.target.value })}
          placeholder="e.g. list, databaseRows"
          className="w-full px-2.5 py-1.5 border border-gray-200 rounded-lg text-xs font-mono focus:ring-1 focus:ring-indigo-500 focus:outline-none bg-slate-50/50"
        />
      </div>
    </div>
  );
}
