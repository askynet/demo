import React from 'react';
import { OnlyIfNode } from '../../../types/bpl';
import { ToggleLeft, Trash2 } from 'lucide-react';

interface OnlyIfNodeRendererProps {
  node: OnlyIfNode;
  selectedNodeId: string | null;
  onSelect: (e: React.MouseEvent) => void;
  onDelete: () => void;
  statusBadge: React.ReactNode;
  getStatusBorder: () => string;
  renderNode: (cb: any) => React.ReactNode;
  renderAddButton: (targetId: string, className?: string) => React.ReactNode;
}

export default function OnlyIfNodeRenderer({
  node,
  selectedNodeId,
  onSelect,
  onDelete,
  statusBadge,
  getStatusBorder,
  renderNode,
  renderAddButton,
}: OnlyIfNodeRendererProps) {
  return (
    <div
      className={`border rounded-xl p-4 transition-all duration-300 max-w-xl ${getStatusBorder()} bg-transparent`}
    >
      <div
        onClick={onSelect}
        className={`flex items-start gap-3 pb-3 cursor-pointer ${selectedNodeId === node.id ? 'bg-indigo-50/20 -mx-2 px-2 py-1 rounded' : ''}`}
      >
        <div className="p-2 rounded-lg bg-teal-50 text-teal-600">
          <ToggleLeft className="w-4 h-4" />
        </div>
        <div className="flex-1">
          <div className="flex items-center justify-between gap-2">
            <span className="text-[10px] font-bold text-teal-500 uppercase tracking-wider font-mono">
              Only If Block
            </span>
            <div className="flex items-center gap-1.5" onClick={(e) => e.stopPropagation()}>
              {statusBadge}
              <button
                onClick={onDelete}
                className="p-1 rounded text-gray-400 hover:text-rose-500 hover:bg-rose-50/50 transition cursor-pointer"
                title="Delete node"
              >
                <Trash2 className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
          <div className="flex items-center gap-1 mt-1 text-xs text-gray-700">
            <span>Execute nested rules ONLY if</span>
            <span className="font-mono font-bold text-teal-600 bg-teal-50 px-1.5 rounded">{node.variable}</span>
          </div>
        </div>
      </div>

      {/* Case lanes */}
      <div className="mt-3 space-y-4">
        {node.cases.map((c, idx) => (
          <div key={idx} className="relative pl-6 ml-4 border-l border-teal-200">
            <div className="absolute top-2 left-0 -ml-[5px] w-2 h-2 rounded-full bg-teal-300" />
            <div className="flex items-center justify-between gap-2 mb-2">
              <div className="flex items-center gap-2 flex-wrap">
                <span className="text-[10px] uppercase font-bold text-teal-400">If Matches:</span>
                {c.values.map((v, vIdx) => (
                  <span key={vIdx} className="text-xs font-mono font-semibold bg-teal-50 text-teal-700 px-2 py-0.5 rounded border border-teal-100">
                    "{v}"
                  </span>
                ))}
              </div>
            </div>
            <div className="space-y-4 pt-1">
              {c.block.length === 0 ? (
                <div className="py-2 pl-2 border border-dashed border-teal-100 rounded-lg bg-teal-50/10 flex flex-col gap-2">
                  <span className="text-[10px] text-teal-500 font-medium italic">Empty block (no children)</span>
                  {renderAddButton(`empty-case-${node.id}-${idx}`, "-ml-[36px]")}
                </div>
              ) : (
                c.block.map((cb) => (
                  <React.Fragment key={cb.id}>
                    {renderNode(cb)}
                    {renderAddButton(cb.id, "-ml-[36px]")}
                  </React.Fragment>
                ))
              )}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
