import React from 'react';
import { OnlyIfNode } from '../../../types/bpl';
import { Plus, Trash2, X } from 'lucide-react';

interface OnlyIfNodeEditorProps {
  node: OnlyIfNode;
  onUpdate: (updatedFields: Partial<OnlyIfNode>) => void;
}

export default function OnlyIfNodeEditor({ node, onUpdate }: OnlyIfNodeEditorProps) {
  const handleVariableChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    onUpdate({ variable: e.target.value });
  };

  const handleAddCase = () => {
    const updatedCases = [
      ...(node.cases || []),
      {
        values: ['NewValue'],
        block: []
      }
    ];
    onUpdate({ cases: updatedCases });
  };

  const handleRemoveCase = (index: number) => {
    const updatedCases = (node.cases || []).filter((_, i) => i !== index);
    onUpdate({ cases: updatedCases });
  };

  const handleAddValue = (caseIndex: number) => {
    const updatedCases = (node.cases || []).map((c, i) => {
      if (i === caseIndex) {
        return {
          ...c,
          values: [...c.values, '']
        };
      }
      return c;
    });
    onUpdate({ cases: updatedCases });
  };

  const handleValueChange = (caseIndex: number, valueIndex: number, newValue: string) => {
    const updatedCases = (node.cases || []).map((c, i) => {
      if (i === caseIndex) {
        const newValues = [...c.values];
        newValues[valueIndex] = newValue;
        return {
          ...c,
          values: newValues
        };
      }
      return c;
    });
    onUpdate({ cases: updatedCases });
  };

  const handleRemoveValue = (caseIndex: number, valueIndex: number) => {
    const updatedCases = (node.cases || []).map((c, i) => {
      if (i === caseIndex) {
        const newValues = c.values.filter((_, vIdx) => vIdx !== valueIndex);
        return {
          ...c,
          values: newValues
        };
      }
      return c;
    });
    onUpdate({ cases: updatedCases });
  };

  return (
    <div className="space-y-4 font-mono text-[11px]">
      <div className="space-y-1.5">
        <label className="text-[10px] uppercase font-bold text-gray-400 block">
          Evaluation Variable
        </label>
        <input
          type="text"
          value={node.variable}
          onChange={handleVariableChange}
          placeholder="e.g. telehealth_net_ov_option"
          className="w-full px-2.5 py-1.5 border border-gray-200 rounded-lg text-xs font-mono focus:ring-1 focus:ring-indigo-500 focus:outline-none bg-slate-50/50"
        />
      </div>

      <div className="border-t border-gray-100 pt-3 space-y-3">
        <div className="flex items-center justify-between">
          <label className="text-[10px] uppercase font-bold text-gray-400">
            Cases & Matches
          </label>
          <button
            onClick={handleAddCase}
            className="flex items-center gap-1 text-[10px] bg-teal-50 hover:bg-teal-100 text-teal-700 px-2 py-1 rounded-md transition cursor-pointer animate-in fade-in zoom-in-95 duration-150"
          >
            <Plus className="w-3 h-3" /> Add Case
          </button>
        </div>

        <div className="space-y-3 max-h-[300px] overflow-y-auto pr-1">
          {(node.cases || []).map((c, caseIdx) => (
            <div key={caseIdx} className="bg-slate-50 border border-slate-100 rounded-lg p-2.5 space-y-2 relative">
              <div className="flex items-center justify-between">
                <span className="text-[9px] font-bold text-slate-400 uppercase">Case #{caseIdx + 1}</span>
                <button
                  onClick={() => handleRemoveCase(caseIdx)}
                  className="p-1 rounded text-gray-400 hover:text-rose-500 hover:bg-rose-50/50 transition cursor-pointer"
                  title="Remove case block"
                >
                  <Trash2 className="w-3 h-3" />
                </button>
              </div>

              <div className="space-y-1.5">
                <div className="flex items-center justify-between">
                  <span className="text-[9px] text-gray-500 font-semibold uppercase">Match values:</span>
                  <button
                    onClick={() => handleAddValue(caseIdx)}
                    className="text-[9.5px] text-teal-600 hover:underline flex items-center gap-0.5"
                  >
                    <Plus className="w-2.5 h-2.5" /> Add match
                  </button>
                </div>

                <div className="space-y-1">
                  {c.values.map((val, valIdx) => (
                    <div key={valIdx} className="flex items-center gap-1">
                      <input
                        type="text"
                        value={val}
                        onChange={(e) => handleValueChange(caseIdx, valIdx, e.target.value)}
                        placeholder="e.g. A"
                        className="flex-1 px-2 py-1 border border-gray-200 rounded text-[11px] font-mono focus:ring-1 focus:ring-teal-500 focus:outline-none bg-white"
                      />
                      {c.values.length > 1 && (
                        <button
                          onClick={() => handleRemoveValue(caseIdx, valIdx)}
                          className="p-1 rounded text-gray-400 hover:text-rose-500 hover:bg-rose-50 transition cursor-pointer"
                        >
                          <X className="w-3 h-3" />
                        </button>
                      )}
                    </div>
                  ))}
                </div>
              </div>
            </div>
          ))}

          {(node.cases || []).length === 0 && (
            <div className="text-center py-4 border border-dashed border-gray-150 rounded-lg text-gray-400 italic">
              No matching cases. Click 'Add Case' above to begin.
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
