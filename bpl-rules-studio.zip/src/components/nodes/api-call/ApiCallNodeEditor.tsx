import React from 'react';
import { ApiCallNode } from '../../../types/bpl';

interface ApiCallNodeEditorProps {
  node: ApiCallNode;
  onUpdate: (updatedFields: Partial<ApiCallNode>) => void;
}

export default function ApiCallNodeEditor({ node, onUpdate }: ApiCallNodeEditorProps) {
  return (
    <div className="space-y-3 font-mono text-[11px]">
      <div>
        <label className="text-[10px] uppercase font-bold text-gray-400 block mb-1">
          Endpoint URL
        </label>
        <input
          type="text"
          value={node.url}
          onChange={(e) => onUpdate({ url: e.target.value })}
          placeholder="e.g. https://api.service.com/validate"
          className="w-full px-2.5 py-1.5 border border-gray-200 rounded-lg text-xs font-mono focus:ring-1 focus:ring-indigo-500 focus:outline-none bg-slate-50/50"
        />
      </div>
      <div>
        <label className="text-[10px] uppercase font-bold text-gray-400 block mb-1">
          Response Variable
        </label>
        <input
          type="text"
          value={node.responseVar}
          onChange={(e) => onUpdate({ responseVar: e.target.value })}
          placeholder="e.g. apiResponse"
          className="w-full px-2.5 py-1.5 border border-gray-200 rounded-lg text-xs font-mono focus:ring-1 focus:ring-indigo-500 focus:outline-none bg-slate-50/50"
        />
      </div>
    </div>
  );
}
