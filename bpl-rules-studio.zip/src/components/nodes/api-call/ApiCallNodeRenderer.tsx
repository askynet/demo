import React from 'react';
import { ApiCallNode } from '../../../types/bpl';
import { Database, Trash2 } from 'lucide-react';

interface ApiCallNodeRendererProps {
  node: ApiCallNode;
  selectedNodeId: string | null;
  onSelect: (e: React.MouseEvent) => void;
  onDelete: () => void;
  statusBadge: React.ReactNode;
  getStatusBorder: () => string;
  getStatusBg: () => string;
}

export default function ApiCallNodeRenderer({
  node,
  selectedNodeId,
  onSelect,
  onDelete,
  statusBadge,
  getStatusBorder,
  getStatusBg,
}: ApiCallNodeRendererProps) {
  return (
    <div
      onClick={onSelect}
      className={`flex items-start gap-3 p-3.5 border rounded-xl cursor-pointer transition-all duration-300 max-w-xl ${getStatusBorder()} ${getStatusBg()} ${selectedNodeId === node.id ? 'ring-2 ring-indigo-500 ring-offset-1' : ''}`}
    >
      <div className="p-2 rounded-lg bg-violet-50 text-violet-600">
        <Database className="w-4 h-4" />
      </div>
      <div className="flex-1 min-w-0">
        <div className="flex items-center justify-between gap-2">
          <span className="text-[10px] font-bold text-violet-500 uppercase tracking-wider">
            Service API Call
          </span>
          <div className="flex items-center gap-1.5" onClick={(e) => e.stopPropagation()}>
            {statusBadge}
            <button
              onClick={onDelete}
              className="p-1 rounded text-gray-400 hover:text-rose-500 hover:bg-rose-50 transition cursor-pointer"
              title="Delete node"
            >
              <Trash2 className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
        <p className="text-xs font-semibold text-gray-800 mt-1 font-mono break-all bg-gray-50 p-1 rounded">
          {node.url}
        </p>
        <div className="mt-2 flex flex-col gap-1 text-xs">
          {node.parameters && node.parameters.length > 0 && (
            <div className="flex items-center gap-1">
              <span className="text-[9px] text-gray-400 font-bold uppercase">Payload send:</span>
              <div className="flex gap-1">
                {node.parameters.map((p) => (
                  <span key={p} className="text-[9px] bg-slate-100 text-slate-600 px-1 py-0.2 rounded font-mono">{p}</span>
                ))}
              </div>
            </div>
          )}
          <div className="flex items-center gap-1.5">
            <span className="text-[9px] text-gray-400 font-bold uppercase">Bind result:</span>
            <span className="text-[10px] font-mono font-semibold text-violet-700 bg-violet-50 px-1 py-0.5 rounded">
              {node.responseVar}
            </span>
          </div>
        </div>
      </div>
    </div>
  );
}
