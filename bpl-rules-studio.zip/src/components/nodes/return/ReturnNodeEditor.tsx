import React from 'react';
import { ReturnNode } from '../../../types/bpl';

interface ReturnNodeEditorProps {
  node: ReturnNode;
}

export default function ReturnNodeEditor({ node }: ReturnNodeEditorProps) {
  return (
    <div className="font-sans text-xs text-gray-500 py-2">
      This is a simple halt/exit command node. No configuration options are required. When reached, it will successfully stop the execution of the rules.
    </div>
  );
}
