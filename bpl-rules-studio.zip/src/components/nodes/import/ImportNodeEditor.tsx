import React from 'react';
import { ImportNode } from '../../../types/bpl';

interface ImportNodeEditorProps {
  node: ImportNode;
  onUpdate: (updatedFields: Partial<ImportNode>) => void;
}

export default function ImportNodeEditor({ node, onUpdate }: ImportNodeEditorProps) {
  return (
    <div className="space-y-1.5 font-mono text-[11px]">
      <label className="text-[10px] uppercase font-bold text-gray-400 block">
        Script File Path
      </label>
      <input
        type="text"
        value={node.file}
        onChange={(e) => onUpdate({ file: e.target.value })}
        placeholder="e.g. shared/rules_lib"
        className="w-full px-2.5 py-1.5 border border-gray-200 rounded-lg text-xs font-mono focus:ring-1 focus:ring-indigo-500 focus:outline-none bg-slate-50/50 text-indigo-700 font-bold"
      />
    </div>
  );
}
