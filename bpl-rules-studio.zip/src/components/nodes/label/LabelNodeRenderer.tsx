import React from 'react';
import { LabelNode } from '../../../types/bpl';
import { Trash2 } from 'lucide-react';

interface LabelNodeRendererProps {
  node: LabelNode;
  isActive: boolean;
  selectedNodeId: string | null;
  onSelect: (e: React.MouseEvent) => void;
  onDelete: () => void;
}

export default function LabelNodeRenderer({
  node,
  isActive,
  selectedNodeId,
  onSelect,
  onDelete,
}: LabelNodeRendererProps) {
  return (
    <div
      onClick={onSelect}
      className={`relative flex items-center justify-between -ml-[25px] w-fit p-1.5 px-3 border rounded-lg cursor-pointer bg-white border-slate-200 hover:border-slate-300 transition-all gap-3 ${selectedNodeId === node.id ? 'ring-2 ring-indigo-500 ring-offset-1' : ''}`}
    >
      <div className="flex items-center gap-2">
        <div className="w-2.5 h-2.5 rounded-full bg-slate-400 border-2 border-white shadow" />
        <span className="text-[10px] font-bold text-slate-500 font-mono tracking-wider">
          {node.name}::
        </span>
      </div>
      <div className="flex items-center gap-1.5" onClick={(e) => e.stopPropagation()}>
        {isActive && (
          <span className="w-2 h-2 rounded-full bg-indigo-500 animate-ping mr-1" />
        )}
        <button
          onClick={onDelete}
          className="p-0.5 rounded text-gray-400 hover:text-rose-500 hover:bg-rose-50 transition cursor-pointer"
          title="Delete node"
        >
          <Trash2 className="w-3 h-3" />
        </button>
      </div>
    </div>
  );
}
