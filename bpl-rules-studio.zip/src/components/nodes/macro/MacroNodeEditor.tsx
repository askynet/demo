import React from 'react';
import { MacroNode } from '../../../types/bpl';

interface MacroNodeEditorProps {
  node: MacroNode;
  onUpdate: (updatedFields: Partial<MacroNode>) => void;
}

export default function MacroNodeEditor({ node, onUpdate }: MacroNodeEditorProps) {
  return (
    <div className="space-y-3 font-mono text-[11px]">
      <div>
        <label className="text-[10px] uppercase font-bold text-gray-400 block mb-1">
          Macro Name
        </label>
        <input
          type="text"
          value={node.name}
          onChange={(e) => onUpdate({ name: e.target.value })}
          placeholder="e.g. core_checks"
          className="w-full px-2.5 py-1.5 border border-gray-200 rounded-lg text-xs font-mono focus:ring-1 focus:ring-indigo-500 focus:outline-none bg-slate-50/50"
        />
      </div>
    </div>
  );
}
