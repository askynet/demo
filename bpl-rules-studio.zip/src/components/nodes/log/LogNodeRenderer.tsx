import React from 'react';
import { LogNode } from '../../../types/bpl';
import { Eye, Trash2 } from 'lucide-react';

interface LogNodeRendererProps {
  node: LogNode;
  isActive: boolean;
  isExecuted: boolean;
  isSkipped: boolean;
  selectedNodeId: string | null;
  onSelect: (e: React.MouseEvent) => void;
  onDelete: () => void;
  statusBadge: React.ReactNode;
  getStatusBorder: () => string;
  getStatusBg: () => string;
}

export default function LogNodeRenderer({
  node,
  isActive,
  isExecuted,
  isSkipped,
  selectedNodeId,
  onSelect,
  onDelete,
  statusBadge,
  getStatusBorder,
  getStatusBg,
}: LogNodeRendererProps) {
  return (
    <div
      onClick={onSelect}
      className={`flex items-start gap-3 p-3.5 border rounded-xl cursor-pointer transition-all duration-300 max-w-xl ${getStatusBorder()} ${getStatusBg()} ${selectedNodeId === node.id ? 'ring-2 ring-indigo-500 ring-offset-1' : ''}`}
    >
      <div className="p-2 rounded-lg bg-gray-100 text-gray-600">
        <Eye className="w-4 h-4" />
      </div>
      <div className="flex-1 min-w-0">
        <div className="flex items-center justify-between gap-2">
          <span className="text-[10px] font-bold text-gray-400 uppercase tracking-wider">
            System Log
          </span>
          <div className="flex items-center gap-1.5" onClick={(e) => e.stopPropagation()}>
            {statusBadge}
            <button
              onClick={onDelete}
              className="p-1 rounded text-gray-400 hover:text-rose-500 hover:bg-rose-50 transition cursor-pointer"
              title="Delete node"
            >
              <Trash2 className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
        <p className="text-xs text-gray-700 font-mono mt-1 break-words">
          "{node.message}"
        </p>
      </div>
    </div>
  );
}
