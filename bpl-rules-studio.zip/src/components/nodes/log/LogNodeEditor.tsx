import React from 'react';
import { LogNode } from '../../../types/bpl';

interface LogNodeEditorProps {
  node: LogNode;
  onUpdate: (updatedFields: Partial<LogNode>) => void;
}

export default function LogNodeEditor({ node, onUpdate }: LogNodeEditorProps) {
  return (
    <div className="space-y-1.5 font-mono text-[11px]">
      <label className="text-[10px] uppercase font-bold text-gray-400 block">
        Log Message
      </label>
      <textarea
        rows={2}
        value={node.message}
        onChange={(e) => onUpdate({ message: e.target.value })}
        placeholder="System message. Supports variables like ${user.name}"
        className="w-full px-2.5 py-1.5 border border-gray-200 rounded-lg text-xs font-mono focus:ring-1 focus:ring-indigo-500 focus:outline-none bg-slate-50/50 leading-relaxed"
      />
    </div>
  );
}
