import React from 'react';
import { JumpNode } from '../../../types/bpl';

interface JumpNodeEditorProps {
  node: JumpNode;
  onUpdate: (updatedFields: Partial<JumpNode>) => void;
  availableLabels: string[];
}

export default function JumpNodeEditor({ node, onUpdate, availableLabels }: JumpNodeEditorProps) {
  return (
    <div className="space-y-3 font-mono text-[11px]">
      <div>
        <label className="text-[10px] uppercase font-bold text-gray-400 block mb-1">
          Target Label Name
        </label>
        <input
          type="text"
          value={node.target}
          onChange={(e) => onUpdate({ target: e.target.value })}
          placeholder="Target label to execute next"
          className="w-full px-2.5 py-1.5 border border-gray-200 rounded-lg text-xs font-mono focus:ring-1 focus:ring-indigo-500 focus:outline-none bg-slate-50/50 font-bold"
        />
      </div>

      {availableLabels.length > 0 && (
        <div>
          <span className="text-[9px] uppercase font-bold text-gray-400 block mb-1">
            Or select from known labels:
          </span>
          <div className="flex flex-wrap gap-1">
            {availableLabels.map((lbl) => (
              <button
                key={lbl}
                type="button"
                onClick={() => onUpdate({ target: lbl })}
                className={`px-2 py-0.5 rounded text-[10px] font-bold border transition ${
                  node.target === lbl
                    ? 'bg-amber-100 text-amber-800 border-amber-300'
                    : 'bg-gray-50 text-gray-600 border-gray-200 hover:bg-gray-100'
                }`}
              >
                {lbl}
              </button>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
