import React from 'react';
import { IfNode, BplConditionGroup } from '../../../types/bpl';
import ConditionEditor from '../ConditionEditor';

interface IfNodeEditorProps {
  node: IfNode;
  onUpdate: (updatedFields: Partial<IfNode>) => void;
}

export default function IfNodeEditor({ node, onUpdate }: IfNodeEditorProps) {
  const handleConditionChange = (updatedGroup: BplConditionGroup) => {
    onUpdate({ condition: updatedGroup });
  };

  return (
    <div className="space-y-3.5 font-mono text-[11px]">
      <div className="space-y-1.5">
        <label className="text-[10px] uppercase font-bold text-gray-400 block">
          Conditional Rule Criteria
        </label>
        <ConditionEditor condition={node.condition} onChange={handleConditionChange} />
      </div>
    </div>
  );
}
