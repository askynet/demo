import React from 'react';
import { IfNode } from '../../../types/bpl';
import { conditionToString } from '../../../utils/parser';
import { HelpCircle, Trash2 } from 'lucide-react';

interface IfNodeRendererProps {
  node: IfNode;
  selectedNodeId: string | null;
  onSelect: (e: React.MouseEvent) => void;
  onDelete: () => void;
  statusBadge: React.ReactNode;
  getStatusBorder: () => string;
  renderNode: (cb: any) => React.ReactNode;
  renderAddButton: (targetId: string, className?: string) => React.ReactNode;
}

export default function IfNodeRenderer({
  node,
  selectedNodeId,
  onSelect,
  onDelete,
  statusBadge,
  getStatusBorder,
  renderNode,
  renderAddButton,
}: IfNodeRendererProps) {
  const condText = typeof node.condition === 'string' ? node.condition : conditionToString(node.condition);

  return (
    <div
      className={`border rounded-xl p-4 transition-all duration-300 max-w-xl ${getStatusBorder()} bg-transparent`}
    >
      <div
        onClick={onSelect}
        className={`flex items-start gap-3 pb-3 cursor-pointer ${selectedNodeId === node.id ? 'bg-indigo-50/20 -mx-2 px-2 py-1 rounded' : ''}`}
      >
        <div className="p-2 rounded-lg bg-indigo-50 text-indigo-600">
          <HelpCircle className="w-4 h-4" />
        </div>
        <div className="flex-1">
          <div className="flex items-center justify-between gap-2">
            <span className="text-[10px] font-bold text-indigo-500 uppercase tracking-wider">
              If Conditional
            </span>
            <div className="flex items-center gap-1.5" onClick={(e) => e.stopPropagation()}>
              {statusBadge}
              <button
                onClick={onDelete}
                className="p-1 rounded text-gray-400 hover:text-rose-500 hover:bg-rose-50/50 transition cursor-pointer"
                title="Delete node"
              >
                <Trash2 className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
          <div className="mt-1">
            <span className="text-[10px] text-gray-400 font-bold uppercase block mb-0.5">Evaluate:</span>
            <span className="text-xs font-mono font-bold text-slate-800 bg-slate-50 p-1 rounded border border-slate-100 block">
              {condText}
            </span>
          </div>
        </div>
      </div>

      {/* Then Block lane */}
      <div className="mt-3 space-y-4">
        <div className="relative pl-6 ml-4 border-l border-indigo-200">
          <div className="absolute top-2 left-0 -ml-[5px] w-2 h-2 rounded-full bg-indigo-300" />
          <span className="text-[10px] uppercase font-bold text-indigo-400 block mb-2">Then Block</span>
          <div className="space-y-4 pt-1">
            {node.thenBlock.length === 0 ? (
              <div className="py-2 pl-2 border border-dashed border-indigo-100 rounded-lg bg-indigo-50/10 flex flex-col gap-2">
                <span className="text-[10px] text-indigo-500 font-medium italic">Empty block (no children)</span>
                {renderAddButton(`empty-then-${node.id}`, "-ml-[36px]")}
              </div>
            ) : (
              node.thenBlock.map((cb) => (
                <React.Fragment key={cb.id}>
                  {renderNode(cb)}
                  {renderAddButton(cb.id, "-ml-[36px]")}
                </React.Fragment>
              ))
            )}
          </div>
        </div>

        {/* ElseIf blocks */}
        {node.elseIfBlocks?.map((elif, idx) => {
          const elifCond = typeof elif.condition === 'string' ? elif.condition : conditionToString(elif.condition);
          return (
            <div key={idx} className="relative pl-6 ml-4 border-l border-indigo-200">
              <div className="absolute top-2 left-0 -ml-[5px] w-2 h-2 rounded-full bg-violet-300" />
              <div className="mb-2">
                <span className="text-[10px] uppercase font-bold text-indigo-400 block mb-0.5">ElseIf Block</span>
                <span className="text-[11px] font-mono font-bold text-slate-700 bg-slate-50 p-1 rounded border border-slate-100 block">
                  {elifCond}
                </span>
              </div>
              <div className="space-y-4 pt-1">
                {elif.block.length === 0 ? (
                  <div className="py-2 pl-2 border border-dashed border-violet-100 rounded-lg bg-violet-50/10 flex flex-col gap-2">
                    <span className="text-[10px] text-violet-500 font-medium italic">Empty block (no children)</span>
                    {renderAddButton(`empty-elseif-${node.id}-${idx}`, "-ml-[36px]")}
                  </div>
                ) : (
                  elif.block.map((cb) => (
                    <React.Fragment key={cb.id}>
                      {renderNode(cb)}
                      {renderAddButton(cb.id, "-ml-[36px]")}
                    </React.Fragment>
                  ))
                )}
              </div>
            </div>
          );
        })}

        {/* Else Block lane */}
        {node.elseBlock && (
          <div className="relative pl-6 ml-4 border-l border-indigo-200">
            <div className="absolute top-2 left-0 -ml-[5px] w-2 h-2 rounded-full bg-slate-300" />
            <span className="text-[10px] uppercase font-bold text-slate-400 block mb-2">Else Block</span>
            <div className="space-y-4 pt-1">
              {node.elseBlock.length === 0 ? (
                <div className="py-2 pl-2 border border-dashed border-slate-100 rounded-lg bg-slate-50/10 flex flex-col gap-2">
                  <span className="text-[10px] text-slate-500 font-medium italic">Empty block (no children)</span>
                  {renderAddButton(`empty-else-${node.id}`, "-ml-[36px]")}
                </div>
              ) : (
                node.elseBlock.map((cb) => (
                  <React.Fragment key={cb.id}>
                    {renderNode(cb)}
                    {renderAddButton(cb.id, "-ml-[36px]")}
                  </React.Fragment>
                ))
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
