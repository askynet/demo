import React from 'react';
import { SwitchNode } from '../../../types/bpl';
import { GitBranch, Trash2 } from 'lucide-react';

interface SwitchNodeRendererProps {
  node: SwitchNode;
  selectedNodeId: string | null;
  onSelect: (e: React.MouseEvent) => void;
  onDelete: () => void;
  statusBadge: React.ReactNode;
  getStatusBorder: () => string;
  renderNode: (cb: any) => React.ReactNode;
  renderAddButton: (targetId: string, className?: string) => React.ReactNode;
}

export default function SwitchNodeRenderer({
  node,
  selectedNodeId,
  onSelect,
  onDelete,
  statusBadge,
  getStatusBorder,
  renderNode,
  renderAddButton,
}: SwitchNodeRendererProps) {
  return (
    <div
      className={`border rounded-xl p-4 transition-all duration-300 max-w-xl ${getStatusBorder()} bg-transparent`}
    >
      <div
        onClick={onSelect}
        className={`flex items-start gap-3 pb-3 cursor-pointer ${selectedNodeId === node.id ? 'bg-indigo-50/20 -mx-2 px-2 py-1 rounded' : ''}`}
      >
        <div className="p-2 rounded-lg bg-purple-50 text-purple-600">
          <GitBranch className="w-4 h-4" />
        </div>
        <div className="flex-1">
          <div className="flex items-center justify-between gap-2">
            <span className="text-[10px] font-bold text-purple-500 uppercase tracking-wider">
              Switch Selector
            </span>
            <div className="flex items-center gap-1.5" onClick={(e) => e.stopPropagation()}>
              {statusBadge}
              <button
                onClick={onDelete}
                className="p-1 rounded text-gray-400 hover:text-rose-500 hover:bg-rose-50/50 transition cursor-pointer"
                title="Delete node"
              >
                <Trash2 className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
          <div className="flex items-center gap-1 mt-1 text-xs text-gray-700">
            <span>Evaluate Cases on</span>
            <span className="font-mono font-bold text-purple-600 bg-purple-50 px-1.5 rounded">{node.variable}</span>
          </div>
        </div>
      </div>

      {/* Switch Case lanes */}
      <div className="mt-3 space-y-4">
        {node.cases.map((c, idx) => (
          <div key={idx} className="relative pl-6 ml-4 border-l border-purple-200">
            <div className="absolute top-2 left-0 -ml-[5px] w-2 h-2 rounded-full bg-purple-300" />
            <div className="flex items-center justify-between gap-2 mb-2">
              <div className="flex items-center gap-2">
                <span className="text-[10px] uppercase font-bold text-purple-400">Case Match:</span>
                <span className="text-xs font-mono font-semibold bg-purple-50 text-purple-700 px-2 py-0.5 rounded border border-purple-100">
                  "{c.value}"
                </span>
              </div>
            </div>
            <div className="space-y-4 pt-1">
              {c.block.length === 0 ? (
                <div className="py-2 pl-2 border border-dashed border-purple-100 rounded-lg bg-purple-50/10 flex flex-col gap-2">
                  <span className="text-[10px] text-purple-500 font-medium italic">Empty block (no children)</span>
                  {renderAddButton(`empty-case-${node.id}-${idx}`, "-ml-[36px]")}
                </div>
              ) : (
                c.block.map((cb) => (
                  <React.Fragment key={cb.id}>
                    {renderNode(cb)}
                    {renderAddButton(cb.id, "-ml-[36px]")}
                  </React.Fragment>
                ))
              )}
            </div>
          </div>
        ))}

        {node.defaultBlock && (
          <div className="relative pl-6 ml-4 border-l border-purple-200">
            <div className="absolute top-2 left-0 -ml-[5px] w-2 h-2 rounded-full bg-slate-300" />
            <div className="flex items-center gap-2 mb-2">
              <span className="text-[10px] uppercase font-bold text-slate-400">Default Case</span>
            </div>
            <div className="space-y-4 pt-1">
              {node.defaultBlock.length === 0 ? (
                <div className="py-2 pl-2 border border-dashed border-purple-100 rounded-lg bg-purple-50/10 flex flex-col gap-2">
                  <span className="text-[10px] text-purple-500 font-medium italic">Empty block (no children)</span>
                  {renderAddButton(`empty-default-${node.id}`, "-ml-[36px]")}
                </div>
              ) : (
                node.defaultBlock.map((cb) => (
                  <React.Fragment key={cb.id}>
                    {renderNode(cb)}
                    {renderAddButton(cb.id, "-ml-[36px]")}
                  </React.Fragment>
                ))
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
