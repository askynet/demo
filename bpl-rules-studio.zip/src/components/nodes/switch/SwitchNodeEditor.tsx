import React from 'react';
import { SwitchNode } from '../../../types/bpl';

interface SwitchNodeEditorProps {
  node: SwitchNode;
  onUpdate: (updatedFields: Partial<SwitchNode>) => void;
}

export default function SwitchNodeEditor({ node, onUpdate }: SwitchNodeEditorProps) {
  return (
    <div className="space-y-1.5 font-mono text-[11px]">
      <label className="text-[10px] uppercase font-bold text-gray-400 block">
        Switch Variable Name
      </label>
      <input
        type="text"
        value={node.variable}
        onChange={(e) => onUpdate({ variable: e.target.value })}
        placeholder="e.g. scoreRating, riskLevel"
        className="w-full px-2.5 py-1.5 border border-gray-200 rounded-lg text-xs font-mono focus:ring-1 focus:ring-indigo-500 focus:outline-none bg-slate-50/50"
      />
    </div>
  );
}
