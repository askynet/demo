import React from 'react';
import { ValidationNode, BplConditionGroup } from '../../../types/bpl';
import ConditionEditor from '../ConditionEditor';

interface ValidationNodeEditorProps {
  node: ValidationNode;
  onUpdate: (updatedFields: Partial<ValidationNode>) => void;
}

export default function ValidationNodeEditor({ node, onUpdate }: ValidationNodeEditorProps) {
  const handleConditionChange = (updatedGroup: BplConditionGroup) => {
    onUpdate({ condition: updatedGroup });
  };

  return (
    <div className="space-y-3.5 font-mono text-[11px]">
      <div className="space-y-1.5">
        <label className="text-[10px] uppercase font-bold text-gray-400 block">
          Validation Condition Criteria
        </label>
        <ConditionEditor condition={node.condition} onChange={handleConditionChange} />
      </div>

      <div className="space-y-1.5">
        <label className="text-[10px] uppercase font-bold text-gray-400 block">
          On-Failure Error Message
        </label>
        <textarea
          rows={2}
          value={node.errorMessage}
          onChange={(e) => onUpdate({ errorMessage: e.target.value })}
          placeholder="Validation failed exception info"
          className="w-full px-2.5 py-1.5 border border-gray-200 rounded-lg text-xs font-mono focus:ring-1 focus:ring-indigo-500 focus:outline-none bg-slate-50/50 leading-relaxed text-rose-700"
        />
      </div>
    </div>
  );
}
