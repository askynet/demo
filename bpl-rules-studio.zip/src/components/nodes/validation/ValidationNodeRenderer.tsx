import React from 'react';
import { ValidationNode } from '../../../types/bpl';
import { conditionToString } from '../../../utils/parser';
import { AlertOctagon, Trash2 } from 'lucide-react';

interface ValidationNodeRendererProps {
  node: ValidationNode;
  selectedNodeId: string | null;
  onSelect: (e: React.MouseEvent) => void;
  onDelete: () => void;
  statusBadge: React.ReactNode;
  getStatusBorder: () => string;
  getStatusBg: () => string;
}

export default function ValidationNodeRenderer({
  node,
  selectedNodeId,
  onSelect,
  onDelete,
  statusBadge,
  getStatusBorder,
  getStatusBg,
}: ValidationNodeRendererProps) {
  const condText = typeof node.condition === 'string' ? node.condition : conditionToString(node.condition);

  return (
    <div
      onClick={onSelect}
      className={`flex items-start gap-3 p-3.5 border rounded-xl cursor-pointer transition-all duration-300 max-w-xl ${getStatusBorder()} ${getStatusBg()} ${selectedNodeId === node.id ? 'ring-2 ring-indigo-500 ring-offset-1' : ''}`}
    >
      <div className="p-2 rounded-lg bg-rose-50 text-rose-600">
        <AlertOctagon className="w-4 h-4" />
      </div>
      <div className="flex-1 min-w-0">
        <div className="flex items-center justify-between gap-2">
          <span className="text-[10px] font-bold text-rose-500 uppercase tracking-wider">
            Assertion Constraint
          </span>
          <div className="flex items-center gap-1.5" onClick={(e) => e.stopPropagation()}>
            {statusBadge}
            <button
              onClick={onDelete}
              className="p-1 rounded text-gray-400 hover:text-rose-500 hover:bg-rose-50 transition cursor-pointer"
              title="Delete node"
            >
              <Trash2 className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
        <div className="mt-1">
          <p className="text-xs text-gray-500">Require condition:</p>
          <p className="text-xs font-mono font-bold text-slate-800 mt-0.5 bg-slate-50 p-1 rounded border border-slate-100">
            {condText}
          </p>
          <div className="mt-2 text-xs text-rose-600 flex items-center gap-1.5 font-semibold bg-rose-50/50 p-1.5 rounded">
            <span className="text-[10px] bg-rose-200 text-rose-800 px-1 py-0.5 rounded font-bold uppercase">Or Error:</span>
            "{node.errorMessage}"
          </div>
        </div>
      </div>
    </div>
  );
}
