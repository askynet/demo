import React, { useState } from 'react';
import { Save, Globe, Trash2, Cpu, ChevronDown, ChevronUp, FileCode } from 'lucide-react';
import { ScriptNode, VariableState } from '../types/bpl';
import { decodeBinaryToInstructions } from '../utils/compiler';

interface SaveTabProps {
  handleSaveCurrentRule: () => void;
  handlePublishDeploy: () => void;
  isPublishing: boolean;
  ast: ScriptNode | null;
  publishProgress: number;
  publishLogs: string[];
  isPublished: boolean;
  selectedRuleId: string;
  ruleMetaName: string;
  setRuleMetaName: (name: string) => void;
  ruleMetaDesc: string;
  setRuleMetaDesc: (desc: string) => void;
  ruleMetaCategory: string;
  setRuleMetaCategory: (cat: string) => void;
  variables: VariableState;
  handleUpdateVariableValue: (key: string, val: any) => void;
  handleRemoveVariable: (key: string) => void;
  newVarName: string;
  setNewVarName: (name: string) => void;
  newVarType: 'string' | 'number' | 'boolean';
  setNewVarType: (type: 'string' | 'number' | 'boolean') => void;
  newVarVal: string;
  setNewVarVal: (val: string) => void;
  handleAddVariable: () => void;
  setImportNotification: (notif: { message: string; type: 'success' | 'error' } | null) => void;
  compiledBinary?: string;
}

export default function SaveTab({
  handleSaveCurrentRule,
  handlePublishDeploy,
  isPublishing,
  ast,
  publishProgress,
  publishLogs,
  isPublished,
  selectedRuleId,
  ruleMetaName,
  setRuleMetaName,
  ruleMetaDesc,
  setRuleMetaDesc,
  ruleMetaCategory,
  setRuleMetaCategory,
  variables,
  handleUpdateVariableValue,
  handleRemoveVariable,
  newVarName,
  setNewVarName,
  newVarType,
  setNewVarType,
  newVarVal,
  setNewVarVal,
  handleAddVariable,
  setImportNotification,
  compiledBinary
}: SaveTabProps) {
  const [isBinaryExpanded, setIsBinaryExpanded] = useState(false);

  let opcodesCount = 0;
  let decodedInstructions: any[] = [];
  let decodeError = '';
  if (compiledBinary) {
    try {
      const payload = decodeBinaryToInstructions(compiledBinary);
      decodedInstructions = payload.instructions || [];
      opcodesCount = decodedInstructions.length;
    } catch (e: any) {
      decodeError = e.message || 'Failed to decode binary';
    }
  }

  return (
    <div className="space-y-4 text-left">
      {/* Actions group */}
      <div className="bg-slate-50 border p-3 rounded-2xl space-y-2.5">
        <span className="text-[10px] font-bold text-gray-400 uppercase tracking-widest block">Database Commit & Deploy</span>
        <button
          onClick={handleSaveCurrentRule}
          className="w-full py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-[11px] font-bold shadow-md shadow-indigo-100 flex items-center justify-center gap-1.5 transition cursor-pointer"
        >
          <Save className="w-3.5 h-3.5" /> Save to Database
        </button>
        
        <button
          onClick={handlePublishDeploy}
          disabled={isPublishing || !ast}
          className="w-full py-2 bg-emerald-600 hover:bg-emerald-700 disabled:bg-slate-200 disabled:text-slate-400 text-white rounded-xl text-[11px] font-bold flex items-center justify-center gap-1.5 transition cursor-pointer"
        >
          <Globe className="w-3.5 h-3.5" /> {isPublishing ? 'Publishing...' : 'Publish to CDN Edge'}
        </button>
      </div>

      {/* Compiled Execution Binary Card */}
      {compiledBinary ? (
        <div className="bg-slate-900 text-slate-100 border border-slate-800 p-3.5 rounded-2xl space-y-2.5 font-sans shadow-md shadow-slate-900/10">
          <div className="flex items-center justify-between">
            <span className="text-[9px] font-extrabold text-slate-400 uppercase tracking-widest flex items-center gap-1.5">
              <Cpu className="w-3 h-3 text-indigo-400 animate-pulse" /> Compiled Execution Binary
            </span>
            <span className="px-1.5 py-0.5 bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 rounded text-[8px] font-extrabold tracking-wider">
              WORKER READY
            </span>
          </div>

          <div className="grid grid-cols-2 gap-2 text-[10px]">
            <div className="bg-slate-800/50 p-2 rounded-xl border border-slate-700/30">
              <span className="text-slate-400 block text-[8px] uppercase font-bold tracking-wider">Binary Payload Size</span>
              <span className="text-white font-mono font-bold text-xs">{(compiledBinary.length / 1024).toFixed(2)} KB</span>
              <span className="text-slate-400 block text-[8px]">{compiledBinary.length} chars</span>
            </div>
            <div className="bg-slate-800/50 p-2 rounded-xl border border-slate-700/30">
              <span className="text-slate-400 block text-[8px] uppercase font-bold tracking-wider">VM Opcodes</span>
              <span className="text-white font-mono font-bold text-xs">{opcodesCount} operations</span>
              <span className="text-slate-400 block text-[8px]">Version 1.0.0 (BPLB1)</span>
            </div>
          </div>

          <div className="space-y-1">
            <button
              onClick={() => setIsBinaryExpanded(!isBinaryExpanded)}
              className="w-full py-1.5 px-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-lg text-[9px] font-bold flex items-center justify-between transition cursor-pointer"
            >
              <span className="flex items-center gap-1"><FileCode className="w-3 h-3 text-slate-400" /> Inspect Payload Instructions</span>
              {isBinaryExpanded ? <ChevronUp className="w-3 h-3" /> : <ChevronDown className="w-3 h-3" />}
            </button>

            {isBinaryExpanded && (
              <div className="space-y-2">
                <div className="bg-slate-950 p-2 rounded-lg text-[8px] font-mono text-emerald-400 max-h-[140px] overflow-y-auto whitespace-pre-wrap leading-relaxed border border-slate-850">
                  {decodeError ? (
                    <span className="text-rose-400">{decodeError}</span>
                  ) : (
                    JSON.stringify(decodedInstructions, null, 2)
                  )}
                </div>
                <button
                  onClick={() => {
                    navigator.clipboard.writeText(compiledBinary);
                    setImportNotification({ message: 'Compiled binary copied to clipboard!', type: 'success' });
                  }}
                  className="w-full py-1 bg-indigo-600/30 hover:bg-indigo-600/40 text-indigo-300 hover:text-white rounded text-[8px] font-bold border border-indigo-500/20 cursor-pointer transition text-center"
                >
                  Copy Compiled Binary Payload String
                </button>
              </div>
            )}
          </div>
        </div>
      ) : (
        <div className="bg-slate-50 border border-slate-100 p-3 rounded-2xl text-center space-y-1">
          <Cpu className="w-5 h-5 text-slate-300 mx-auto" />
          <span className="text-[10px] font-bold text-slate-500 block">No execution binary generated</span>
          <span className="text-[8px] text-slate-400 block">Save or update your rule script to compile</span>
        </div>
      )}

      {/* Pipeline status */}
      {(isPublishing || isPublished) && (
        <div className="bg-slate-50 border p-3 rounded-2xl space-y-2 font-mono text-[9px] text-slate-600">
          <div className="flex items-center justify-between font-bold">
            <span>CDN PROVISIONING</span>
            <span>{publishProgress}%</span>
          </div>
          <div className="w-full h-1 bg-slate-200 rounded-full overflow-hidden">
            <div className="h-full bg-emerald-600 transition-all duration-300" style={{ width: `${publishProgress}%` }} />
          </div>
          {publishLogs.length > 0 && (
            <div className="bg-slate-900 text-slate-300 rounded-lg p-2 max-h-[80px] overflow-y-auto space-y-0.5 leading-snug">
              {publishLogs.map((log, i) => (
                <div key={i} className="truncate">{log}</div>
              ))}
            </div>
          )}
          {isPublished && (
            <div className="p-2 bg-emerald-50 border border-emerald-100 rounded-lg text-emerald-800 space-y-1 font-sans">
              <span className="font-bold block text-[10px]">✓ Active Endpoint v1</span>
              <button
                onClick={() => {
                  navigator.clipboard.writeText(`https://api.bpl-runtime.io/policies/v1/eval?id=${selectedRuleId}`);
                  setImportNotification({ message: 'Deployment endpoint copied!', type: 'success' });
                }}
                className="px-2 py-0.5 bg-white hover:bg-slate-50 border border-emerald-200 rounded text-[8px] font-bold block w-full text-center cursor-pointer transition"
              >
                Copy Trigger Endpoint URL
              </button>
            </div>
          )}
        </div>
      )}

      {/* Metadata config form */}
      <div className="space-y-3">
        <span className="text-[10px] font-bold text-gray-400 uppercase tracking-widest block">Rule Classification</span>
        <div className="space-y-2.5">
          <div className="space-y-0.5">
            <label className="text-[10px] font-bold text-gray-400 uppercase tracking-wider block">Rule Title</label>
            <input
              type="text"
              value={ruleMetaName}
              onChange={(e) => setRuleMetaName(e.target.value)}
              className="w-full px-2.5 py-1.5 border border-gray-200 rounded-lg text-xs font-bold bg-slate-50 focus:outline-none focus:ring-1 focus:ring-indigo-500 focus:bg-white transition"
            />
          </div>
          <div className="space-y-0.5">
            <label className="text-[10px] font-bold text-gray-400 uppercase tracking-wider block">Description</label>
            <textarea
              value={ruleMetaDesc}
              onChange={(e) => setRuleMetaDesc(e.target.value)}
              className="w-full h-16 px-2.5 py-1.5 border border-gray-200 rounded-lg text-xs font-semibold bg-slate-50 focus:outline-none focus:ring-1 focus:ring-indigo-500 focus:bg-white transition resize-none"
            />
          </div>
          <div className="space-y-0.5">
            <label className="text-[10px] font-bold text-gray-400 uppercase tracking-wider block">Category</label>
            <select
              value={ruleMetaCategory}
              onChange={(e) => setRuleMetaCategory(e.target.value)}
              className="w-full px-2.5 py-1.5 border border-gray-200 rounded-lg text-xs font-bold bg-slate-50 focus:outline-none cursor-pointer"
            >
              <option value="Financial">Financial Policy</option>
              <option value="Healthcare">Healthcare Protocol</option>
              <option value="Insurance">Insurance Underwriting</option>
              <option value="Logistics">Logistics / Operations</option>
              <option value="Security">Security Constraints</option>
            </select>
          </div>
        </div>
      </div>

      {/* Default Variables config */}
      <div className="border-t border-gray-100 pt-3 space-y-3">
        <span className="text-[10px] font-bold text-gray-400 uppercase tracking-widest block">Default State Variables Setup</span>
        
        {/* List */}
        <div className="space-y-1.5 max-h-[120px] overflow-y-auto">
          {Object.entries(variables).map(([key, val]) => (
            <div key={key} className="flex items-center justify-between p-2 bg-slate-50 border rounded-lg text-[10px] font-mono">
              <span className="text-slate-600 font-bold truncate max-w-[120px]">{key}</span>
              <div className="flex items-center gap-1.5">
                {typeof val === 'boolean' ? (
                  <button
                    onClick={() => handleUpdateVariableValue(key, !val)}
                    className={`px-1.5 py-0.2 rounded font-bold border text-[8px] cursor-pointer ${val ? 'bg-indigo-50 text-indigo-700' : 'bg-white text-gray-400'}`}
                  >
                    {val ? 'TRUE' : 'FALSE'}
                  </button>
                ) : (
                  <input
                    type={typeof val === 'number' ? 'number' : 'text'}
                    value={val}
                    onChange={(e) => {
                      const raw = e.target.value;
                      const parsed = typeof val === 'number' ? (Number(raw) || 0) : raw;
                      handleUpdateVariableValue(key, parsed);
                    }}
                    className="w-16 bg-white border rounded px-1 text-center font-bold text-indigo-600 focus:outline-none"
                  />
                )}
                <button onClick={() => handleRemoveVariable(key)} className="text-gray-400 hover:text-rose-600 transition"><Trash2 className="w-3 h-3" /></button>
              </div>
            </div>
          ))}
        </div>

        {/* Variable append form */}
        <div className="bg-slate-50 border p-2 rounded-xl space-y-1.5">
          <input
            type="text"
            placeholder="New field name"
            value={newVarName}
            onChange={(e) => setNewVarName(e.target.value)}
            className="w-full px-2 py-1 bg-white border rounded-lg text-[10px] font-mono"
          />
          <div className="grid grid-cols-2 gap-1">
            <select
              value={newVarType}
              onChange={(e: any) => setNewVarType(e.target.value)}
              className="px-1 py-1 bg-white border rounded-lg text-[10px] font-bold"
            >
              <option value="string">String</option>
              <option value="number">Number</option>
              <option value="boolean">Boolean</option>
            </select>
            {newVarType === 'boolean' ? (
              <select
                value={newVarVal}
                onChange={(e) => setNewVarVal(e.target.value)}
                className="px-1 py-1 bg-white border rounded-lg text-[10px] font-bold"
              >
                <option value="">Choose</option>
                <option value="true">True</option>
                <option value="false">False</option>
              </select>
            ) : (
              <input
                type={newVarType === 'number' ? 'number' : 'text'}
                placeholder="Default"
                value={newVarVal}
                onChange={(e) => setNewVarVal(e.target.value)}
                className="px-2 py-1 bg-white border rounded-lg text-[10px] font-mono"
              />
            )}
          </div>
          <button
            onClick={handleAddVariable}
            className="w-full py-1 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 rounded-lg text-[10px] font-bold transition cursor-pointer"
          >
            + Add Field
          </button>
        </div>
      </div>
    </div>
  );
}
