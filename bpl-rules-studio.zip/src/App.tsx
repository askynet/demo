/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from 'react';
import {
  BplAstNode,
  ScriptNode,
  TraceStep,
  VariableState,
  IfNode,
  SwitchNode,
  LoopNode,
  LogNode,
  AssignNode,
  IncludeNode,
  JumpNode,
  ValidationNode,
  ErrorNode,
  ClearscreenNode,
  CodeNode,
  PromptNode,
  GetkeyNode,
  OnlyIfNode,
  MacroNode
} from './types/bpl';
import { BplParser, astToBpl, generateId, collectAllNodes } from './utils/parser';
import { BplInterpreter } from './utils/interpreter';
import { BPL_SAMPLES } from './data/samples';
import { ruleService, Rule } from './services/ruleService';
import { goRuntimeService } from './services/goRuntime';
import { motion, AnimatePresence } from 'motion/react';
import VisualFlow from './components/VisualFlow';
import NodeEditor from './components/NodeEditor';
import ValidationTab from './components/ValidationTab';
import SimulatorTab from './components/SimulatorTab';
import SaveTab from './components/SaveTab';
import {
  FileText,
  Play,
  Pause,
  CheckCircle,
  Eye,
  AlertTriangle,
  FolderOpen,
  ChevronRight,
  ChevronLeft,
  ChevronsLeft,
  ChevronsRight,
  Search,
  Filter,
  RefreshCw,
  Terminal,
  BookOpen,
  Sparkles,
  Award,
  Cpu,
  Hash,
  ToggleLeft,
  Type,
  Database,
  Upload,
  X,
  FolderPlus,
  Trash2,
  Save,
  Plus,
  Server,
  List,
  Calendar,
  Clock,
  ArrowRightLeft,
  ArrowLeft,
  Copy,
  Download,
  Check,
  Globe,
  Activity,
  Layers,
  Settings,
  ShieldCheck,
  Sliders,
  Sparkle
} from 'lucide-react';

export default function App() {
  // Rules database state
  const [rules, setRules] = useState<Rule[]>([]);
  const [selectedRuleId, setSelectedRuleId] = useState<string>('');
  const [code, setCode] = useState('');
  const [variables, setVariables] = useState<VariableState>({});
  const [ast, setAst] = useState<ScriptNode | null>(null);
  const [errors, setErrors] = useState<any[]>([]);
  const [selectedNode, setSelectedNode] = useState<BplAstNode | null>(null);
  const isVisualUpdateRef = useRef(false);
  const [rightPanelTab, setRightPanelTab] = useState<'properties' | 'validate' | 'test' | 'settings'>('properties');
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);

  // Metadata editor state for selected rule
  const [ruleMetaName, setRuleMetaName] = useState('');
  const [ruleMetaDesc, setRuleMetaDesc] = useState('');
  const [ruleMetaCategory, setRuleMetaCategory] = useState('Financial');

  // New rule creation wizard states
  const [isNewRuleWizardOpen, setIsNewRuleWizardOpen] = useState(false);
  const [wizardStep, setWizardStep] = useState<'choice' | 'scratch' | 'import'>('choice');
  const [wizardName, setWizardName] = useState('');
  const [wizardDesc, setWizardDesc] = useState('');
  const [wizardCategory, setWizardCategory] = useState('Financial');
  const [wizardPasteCode, setWizardPasteCode] = useState('');
  const [dragActive, setDragActive] = useState(false);

  // Legacy BPL Importer states
  const [isLegacyImporterOpen, setIsLegacyImporterOpen] = useState(false);
  const [importerPasteCode, setImporterPasteCode] = useState('');
  const [importerName, setImporterName] = useState('Legacy Evaluator Rule');
  const [importerDesc, setImporterDesc] = useState('Legacy Booklet Policy parsed and compiled');
  const [importerCategory, setImporterCategory] = useState('Financial');
  const [importerErrors, setImporterErrors] = useState<any[]>([]);
  const [importerIsValid, setImporterIsValid] = useState(true);
  const [isOverwritingActiveRule, setIsOverwritingActiveRule] = useState(false);
  const [importerDragActive, setImporterDragActive] = useState(false);

  // API load state
  const [isApiLoading, setIsApiLoading] = useState(false);
  const [importNotification, setImportNotification] = useState<{ message: string; type: 'success' | 'error' } | null>(null);

  // Pagination & Filtering for high-scale Rules Table (145,000+ rules)
  const [dbSearch, setDbSearch] = useState('');
  const [dbPage, setDbPage] = useState(1);
  const [dbCategory, setDbCategory] = useState('all');
  const [totalRules, setTotalRules] = useState(0);
  const dbLimit = 8; // Row capacity per view limit

  // Interpreter trace states
  const [traceSteps, setTraceSteps] = useState<TraceStep[]>([]);
  const [currentStepIndex, setCurrentStepIndex] = useState(0);
  const [isPlaying, setIsPlaying] = useState(false);
  const [playbackSpeed, setPlaybackSpeed] = useState(1); // 0.5x, 1x, 2x, 5x
  const timerRef = useRef<NodeJS.Timeout | null>(null);
  const importerGutterRef = useRef<HTMLDivElement>(null);

  // Publisher simulation states
  const [isPublishing, setIsPublishing] = useState(false);
  const [publishProgress, setPublishProgress] = useState(0);
  const [publishLogs, setPublishLogs] = useState<string[]>([]);
  const [publishEnvironment, setPublishEnvironment] = useState<'staging' | 'prod-us-east' | 'prod-global-cdn'>('staging');
  const [isPublished, setIsPublished] = useState(false);
  const [publishedVersion, setPublishedVersion] = useState('v1.0.0');

  // Go VM Executor states
  const [isVmExecutorOpen, setIsVmExecutorOpen] = useState(false);
  const [vmSelectedRuleId, setVmSelectedRuleId] = useState<string>('');
  const [vmRuleDetail, setVmRuleDetail] = useState<Rule | null>(null);
  const [vmInputVars, setVmInputVars] = useState<VariableState>({});
  const [vmLogs, setVmLogs] = useState<string[]>([]);
  const [vmStatus, setVmStatus] = useState<'idle' | 'compiling' | 'running' | 'paused' | 'completed' | 'failed'>('idle');
  const [vmTrace, setVmTrace] = useState<any[]>([]);
  const [vmActivePrompt, setVmActivePrompt] = useState<{
    message: string;
    variable: string;
    type: 'prompt' | 'getkey';
    resolve: (val: string) => void;
  } | null>(null);
  const [vmPromptInput, setVmPromptInput] = useState('');
  const [vmRegistryList, setVmRegistryList] = useState<Rule[]>([]);
  const [vmActiveTraceStep, setVmActiveTraceStep] = useState<number>(-1);

  // Trigger modal and populate registry entries
  const openVmExecutor = async () => {
    setIsVmExecutorOpen(true);
    setVmStatus('idle');
    setVmLogs([]);
    setVmTrace([]);
    setVmActiveTraceStep(-1);
    setVmActivePrompt(null);
    setVmPromptInput('');
    
    try {
      const res = await ruleService.fetchRules('', 1, 100, 'all');
      setVmRegistryList(res.rules);
    } catch (err) {
      console.error("Failed to load rules for VM selection:", err);
    }

    if (selectedRuleId) {
      setVmSelectedRuleId(selectedRuleId);
    } else {
      try {
        const res = await ruleService.fetchRules('', 1, 1, 'all');
        if (res.rules.length > 0) {
          setVmSelectedRuleId(res.rules[0].id);
        }
      } catch (err) {
        console.error(err);
      }
    }
  };

  // Sync rule details when VM selection changes
  useEffect(() => {
    if (!vmSelectedRuleId) return;
    const loadVmRule = async () => {
      try {
        const rule = await ruleService.fetchRuleById(vmSelectedRuleId);
        setVmRuleDetail(rule);
        setVmInputVars(rule.defaultVariables || {});
      } catch (err) {
        console.error("Failed to fetch full rule detail:", err);
      }
    };
    loadVmRule();
  }, [vmSelectedRuleId]);

  // Execute BPL script using background worker Go runtime
  const startVmExecution = async () => {
    if (!vmRuleDetail) return;
    setVmStatus('compiling');
    setVmLogs(['[Go Compiler] Initializing compile sequence on Goroutine pool...', '[Go Compiler] Validating Booklet Policy Language (BPL) AST elements...']);
    setVmTrace([]);
    setVmActiveTraceStep(-1);
    
    try {
      const astToCompile = vmRuleDetail.ast;
      if (!astToCompile) {
        throw new Error("No AST structure found for this policy. Please save or edit first.");
      }

      // Compile the AST inside our Web Worker Go Compiler
      const compiledBinary = await goRuntimeService.compile(astToCompile);
      
      setVmLogs((prev) => [
        ...prev,
        `[Go Compiler] AST compiled successfully. Bytecode footprint: ${compiledBinary.length} bytes.`,
        `[Go Compiler] Packing output header: ${compiledBinary.substring(0, 15)}...`,
        `[Go Engine] VM initialized. Spawning background execution worker thread...`
      ]);

      setVmStatus('running');

      const results = await goRuntimeService.execute(
        compiledBinary,
        vmInputVars,
        astToCompile,
        async (message, variable, type) => {
          return new Promise<string>((resolve) => {
            setVmStatus('paused');
            setVmLogs((prev) => [
              ...prev,
              `[Go VM - Channel Blocked] Goroutine thread paused on input channel. Storing in variable "${variable}"`
            ]);
            setVmActivePrompt({
              message,
              variable,
              type,
              resolve: (val) => {
                setVmActivePrompt(null);
                setVmStatus('running');
                resolve(val);
              }
            });
            setVmPromptInput('');
          });
        }
      );

      // Successfully finished execution
      setVmLogs(results.logs);
      setVmTrace(results.trace);
      if (results.trace.length > 0) {
        setVmActiveTraceStep(results.trace.length - 1);
      }
      setVmStatus('completed');
    } catch (err: any) {
      setVmStatus('failed');
      setVmLogs((prev) => [
        ...prev,
        `[Go VM - Panic Error] Execution aborted. Cause: ${err.message || err}`
      ]);
    }
  };

  // Parser & Interpreter instances
  const parser = useRef(new BplParser());
  const interpreter = useRef(new BplInterpreter());

  // Reload rules list on search, page, or category change
  useEffect(() => {
    const loadRulesData = async () => {
      setIsApiLoading(true);
      try {
        const data = await ruleService.fetchRules(dbSearch, dbPage, dbLimit, dbCategory);
        setRules(data.rules);
        setTotalRules(data.total);

        // Auto-select first rule on load if none selected
        if (data.rules.length > 0 && !selectedRuleId && dbPage === 1 && !dbSearch) {
          const firstRule = data.rules[0];
          setSelectedRuleId(firstRule.id);
          const detailedRule = await ruleService.fetchRuleById(firstRule.id);
          let ruleCode = detailedRule.code;
          let ruleAst = detailedRule.ast;
          if (!ruleCode && ruleAst) {
            ruleCode = astToBpl(ruleAst);
          }
          setCode(ruleCode || '');
          setVariables(detailedRule.defaultVariables || {});
          setRuleMetaName(detailedRule.name);
          setRuleMetaDesc(detailedRule.description || '');
          setRuleMetaCategory(detailedRule.category || 'Financial');
          
          if (ruleAst) {
            setAst(ruleAst);
          } else if (ruleCode) {
            const { ast: parsedAst } = parser.current.parse(ruleCode);
            if (parsedAst) setAst(parsedAst);
          } else {
            setAst(null);
          }
        }
      } catch (err: any) {
        console.error('Error fetching rules:', err);
        setImportNotification({ message: 'Failed to fetch rules from backend database.', type: 'error' });
      } finally {
        setIsApiLoading(false);
      }
    };

    const delayDebounceFn = setTimeout(() => {
      loadRulesData();
    }, dbSearch ? 250 : 0);

    return () => clearTimeout(delayDebounceFn);
  }, [dbSearch, dbPage, dbCategory]);

  // Reset page to 1 on filter changes
  useEffect(() => {
    setDbPage(1);
  }, [dbSearch, dbCategory]);

  // Auto-clear notification toast
  useEffect(() => {
    if (importNotification) {
      const timer = setTimeout(() => {
        setImportNotification(null);
      }, 5000);
      return () => clearTimeout(timer);
    }
  }, [importNotification]);

  // Parse code on input change and sync AST
  useEffect(() => {
    if (isVisualUpdateRef.current) {
      isVisualUpdateRef.current = false;
      const { errors: parserErrors } = parser.current.parse(code);
      setErrors(parserErrors);
      return;
    }
    const { ast: parsedAst, errors: parserErrors } = parser.current.parse(code);
    setErrors(parserErrors);
    if (parsedAst) {
      setAst(parsedAst);
    }
  }, [code]);

  // Execute interpreter on AST or variables change to gather execution steps
  useEffect(() => {
    if (ast) {
      const steps = interpreter.current.execute(ast, variables);
      setTraceSteps(steps);
      setCurrentStepIndex(0);
    } else {
      setTraceSteps([]);
      setCurrentStepIndex(0);
    }
  }, [ast, variables]);

  // Auto playback trigger for trace sessions
  useEffect(() => {
    if (isPlaying) {
      const delay = 1000 / playbackSpeed;
      timerRef.current = setInterval(() => {
        setCurrentStepIndex((prev) => {
          if (prev < traceSteps.length - 1) {
            return prev + 1;
          } else {
            setIsPlaying(false);
            return prev;
          }
        });
      }, delay);
    } else {
      if (timerRef.current) {
        clearInterval(timerRef.current);
      }
    }

    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [isPlaying, playbackSpeed, traceSteps]);

  // Select active rule from DB
  const handleSelectRule = async (ruleId: string) => {
    setIsApiLoading(true);
    setSelectedNode(null);
    setRightPanelTab('properties');
    setIsSidebarOpen(false);
    try {
      const rule = await ruleService.fetchRuleById(ruleId);
      setSelectedRuleId(rule.id);
      
      let ruleCode = rule.code;
      let ruleAst = rule.ast;
      if (!ruleCode && ruleAst) {
        ruleCode = astToBpl(ruleAst);
      }
      setCode(ruleCode || '');
      setVariables(rule.defaultVariables || {});
      setRuleMetaName(rule.name);
      setRuleMetaDesc(rule.description || '');
      setRuleMetaCategory(rule.category || 'Financial');
      
      if (ruleAst) {
        setAst(ruleAst);
      } else if (ruleCode) {
        const { ast: parsedAst } = parser.current.parse(ruleCode);
        if (parsedAst) {
          setAst(parsedAst);
        } else {
          setAst(null);
        }
      } else {
        setAst(null);
      }
      setIsPlaying(false);
      setImportNotification({ message: `Loaded Policy: ${rule.name}`, type: 'success' });
    } catch (err: any) {
      console.error('Error loading rule details:', err);
      setImportNotification({ message: 'Failed to fetch rule details from database.', type: 'error' });
    } finally {
      setIsApiLoading(false);
    }
  };

  // Save current rule metadata & code to database
  const handleSaveCurrentRule = async () => {
    if (!selectedRuleId) {
      setImportNotification({ message: 'Select or create a rule before saving.', type: 'error' });
      return;
    }
    setIsApiLoading(true);
    try {
      const updated = await ruleService.updateRule(selectedRuleId, {
        name: ruleMetaName,
        description: ruleMetaDesc,
        category: ruleMetaCategory,
        ast: ast,
        defaultVariables: variables
      });
      // Update local rules array list
      setRules((prev) => prev.map((r) => (r.id === selectedRuleId ? updated : r)));
      setImportNotification({ message: `Saved changes to "${updated.name}" successfully!`, type: 'success' });
    } catch (err: any) {
      console.error('Error updating rule:', err);
      setImportNotification({ message: 'Failed to save changes to database server.', type: 'error' });
    } finally {
      setIsApiLoading(false);
    }
  };

  // Duplicate active rule
  const handleDuplicateRule = async (rule: Rule, e: React.MouseEvent) => {
    e.stopPropagation();
    setIsApiLoading(true);
    try {
      const cloneName = `${rule.name} (Copy)`;
      const newRule = await ruleService.createRule({
        name: cloneName,
        description: rule.description || 'Duplicated policy rule',
        ...(rule.ast ? { ast: rule.ast } : { code: rule.code }),
        defaultVariables: rule.defaultVariables || {}
      });
      
      // Update categories as well
      await ruleService.updateRule(newRule.id, { category: rule.category || 'Financial' });

      setRules((prev) => [newRule, ...prev]);
      setTotalRules((t) => t + 1);
      setSelectedRuleId(newRule.id);
      
      let ruleCode = newRule.code;
      if (!ruleCode && newRule.ast) {
        ruleCode = astToBpl(newRule.ast);
      }
      setCode(ruleCode || '');
      setVariables(newRule.defaultVariables || {});
      setRuleMetaName(cloneName);
      setRuleMetaDesc(rule.description || '');
      setRuleMetaCategory(rule.category || 'Financial');

      setImportNotification({ message: `Duplicated rule into: "${cloneName}"`, type: 'success' });
    } catch (err: any) {
      console.error('Error duplicating rule:', err);
      setImportNotification({ message: 'Failed to duplicate rule on server.', type: 'error' });
    } finally {
      setIsApiLoading(false);
    }
  };

  // Delete rule
  const handleDeleteRule = async (ruleId: string, e: React.MouseEvent) => {
    e.stopPropagation();
    if (!window.confirm('Are you sure you want to permanently delete this rule from the database?')) return;

    setIsApiLoading(true);
    try {
      await ruleService.deleteRule(ruleId);
      const remaining = rules.filter((r) => r.id !== ruleId);
      setRules(remaining);
      setTotalRules((t) => t - 1);
      setImportNotification({ message: 'Rule deleted from database successfully.', type: 'success' });

      if (selectedRuleId === ruleId) {
        if (remaining.length > 0) {
          handleSelectRule(remaining[0].id);
        } else {
          setSelectedRuleId('');
          setCode('');
          setVariables({});
          setAst(null);
          setRuleMetaName('');
          setRuleMetaDesc('');
        }
      }
    } catch (err: any) {
      console.error('Error deleting rule:', err);
      setImportNotification({ message: 'Failed to delete rule from database.', type: 'error' });
    } finally {
      setIsApiLoading(false);
    }
  };

  // Wizard Handlers
  const handleWizardScratchSubmit = async () => {
    if (!wizardName.trim()) return;
    setIsApiLoading(true);
    try {
      const baseCode = `script "${wizardName}"
{
  log "Initial baseline verification for ${wizardName}..."
  assign "InitialValue" to status
}
`;
      const { ast: parsedAst } = parser.current.parse(baseCode);
      const newRule = await ruleService.createRule({
        name: wizardName,
        description: wizardDesc,
        ast: parsedAst,
        defaultVariables: { status: 'Pending' }
      });

      // Update category
      const updated = await ruleService.updateRule(newRule.id, { category: wizardCategory });

      setRules((prev) => [updated, ...prev]);
      setTotalRules((t) => t + 1);
      setSelectedRuleId(updated.id);
      setCode(baseCode);
      setVariables(updated.defaultVariables || {});
      setRuleMetaName(updated.name);
      setRuleMetaDesc(updated.description || '');
      setRuleMetaCategory(updated.category || 'Financial');

      if (parsedAst) setAst(parsedAst);

      setImportNotification({ message: `Created rule "${updated.name}" from scratch!`, type: 'success' });
      closeNewRuleWizard();
    } catch (err: any) {
      console.error('Error creating scratch rule:', err);
      setImportNotification({ message: 'Failed to create new rule on database.', type: 'error' });
    } finally {
      setIsApiLoading(false);
    }
  };

  const handleWizardImportSubmit = async () => {
    if (!wizardName.trim() || !wizardPasteCode.trim()) return;
    setIsApiLoading(true);
    try {
      // Validate code first
      const { errors: parseErrors } = parser.current.parse(wizardPasteCode);
      if (parseErrors.length > 0) {
        throw new Error(`Syntax error: ${parseErrors[0].message} at line ${parseErrors[0].line}`);
      }

      const { ast: parsedAst } = parser.current.parse(wizardPasteCode);
      const newRule = await ruleService.createRule({
        name: wizardName,
        description: wizardDesc,
        ast: parsedAst,
        defaultVariables: { status: 'Imported' }
      });

      // Update category
      const updated = await ruleService.updateRule(newRule.id, { category: wizardCategory });

      setRules((prev) => [updated, ...prev]);
      setTotalRules((t) => t + 1);
      setSelectedRuleId(updated.id);
      setCode(wizardPasteCode);
      setVariables(updated.defaultVariables || {});
      setRuleMetaName(updated.name);
      setRuleMetaDesc(updated.description || '');
      setRuleMetaCategory(updated.category || 'Financial');

      if (parsedAst) setAst(parsedAst);

      setImportNotification({ message: `Imported and compiled Booklet Policy: "${updated.name}"`, type: 'success' });
      closeNewRuleWizard();
    } catch (err: any) {
      console.error('Error importing rule:', err);
      setImportNotification({ message: err.message || 'Failed to import and compile policy.', type: 'error' });
    } finally {
      setIsApiLoading(false);
    }
  };

  const closeNewRuleWizard = () => {
    setIsNewRuleWizardOpen(false);
    setWizardStep('choice');
    setWizardName('');
    setWizardDesc('');
    setWizardPasteCode('');
    setWizardCategory('Financial');
  };

  // Helper to count nodes and compile metrics for pasted code
  const getImporterMetrics = () => {
    if (!importerPasteCode.trim()) return null;
    try {
      const { ast: parsedAst } = parser.current.parse(importerPasteCode);
      if (!parsedAst) return null;

      let logs = 0;
      let conditionals = 0;
      let assignments = 0;
      let validations = 0;
      let loops = 0;
      let switches = 0;
      let total = 0;

      const traverse = (n: BplAstNode) => {
        total++;
        if (n.type === 'log') logs++;
        else if (n.type === 'if') conditionals++;
        else if (n.type === 'assign') assignments++;
        else if (n.type === 'validation') validations++;
        else if (n.type === 'loop') loops++;
        else if (n.type === 'switch') switches++;

        if (n.type === 'script') {
          (n as any).children?.forEach(traverse);
        } else if (n.type === 'if') {
          const ifN = n as any;
          ifN.thenBlock?.forEach(traverse);
          ifN.elseIfBlocks?.forEach((elif: any) => elif.block?.forEach(traverse));
          ifN.elseBlock?.forEach(traverse);
        } else if (n.type === 'switch') {
          const swN = n as any;
          swN.cases?.forEach((c: any) => c.block?.forEach(traverse));
          swN.defaultBlock?.forEach(traverse);
        } else if (n.type === 'loop') {
          (n as any).block?.forEach(traverse);
        } else if (n.type === 'macro') {
          (n as any).block?.forEach(traverse);
        } else if (n.type === 'only_if') {
          const oif = n as any;
          oif.cases?.forEach((c: any) => c.block?.forEach(traverse));
        }
      };

      traverse(parsedAst);
      return { total, logs, conditionals, assignments, validations, loops, switches };
    } catch {
      return null;
    }
  };

  const handleImporterCodeChange = (val: string) => {
    setImporterPasteCode(val);
    if (!val.trim()) {
      setImporterErrors([]);
      setImporterIsValid(true);
      return;
    }
    const { errors: parseErrors } = parser.current.parse(val);
    setImporterErrors(parseErrors);
    setImporterIsValid(parseErrors.length === 0);
  };

  const handleImporterFileUpload = (file: File) => {
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (e) => {
      const text = e.target?.result;
      if (typeof text === 'string') {
        handleImporterCodeChange(text);
        const scriptMatch = text.match(/script\s+"([^"]+)"/i);
        if (scriptMatch && scriptMatch[1] && !isOverwritingActiveRule) {
          setImporterName(scriptMatch[1]);
        }
      }
    };
    reader.readAsText(file);
  };

  const handleImporterDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === "dragenter" || e.type === "dragover") {
      setImporterDragActive(true);
    } else if (e.type === "dragleave") {
      setImporterDragActive(false);
    }
  };

  const handleImporterDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setImporterDragActive(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      handleImporterFileUpload(e.dataTransfer.files[0]);
    }
  };

  const handleImporterSubmit = async () => {
    if (!importerPasteCode.trim()) return;
    setIsApiLoading(true);

    try {
      // Validate code first
      const { ast: parsedAst, errors: parseErrors } = parser.current.parse(importerPasteCode);
      if (parseErrors.length > 0) {
        setImporterErrors(parseErrors);
        setImporterIsValid(false);
        throw new Error(`Syntax validation failed with ${parseErrors.length} error(s). Please correct them to import.`);
      }

      if (!parsedAst) {
        throw new Error("Could not construct visual flow from code.");
      }

      if (isOverwritingActiveRule) {
        // Overwrite active rule
        if (!selectedRuleId) {
          throw new Error("No active rule selected to overwrite.");
        }

        const updated = await ruleService.updateRule(selectedRuleId, {
          ast: parsedAst,
        });

        setRules((prev) => prev.map((r) => r.id === selectedRuleId ? updated : r));
        setCode(astToBpl(parsedAst));
        setAst(parsedAst);

        setImportNotification({
          message: `Overwrote and updated visual flow for "${ruleMetaName}"`,
          type: 'success',
        });
      } else {
        // Import as new rule
        const finalName = importerName.trim() || parsedAst.name || 'Legacy Imported Rule';
        const newRule = await ruleService.createRule({
          name: finalName,
          description: importerDesc,
          ast: parsedAst,
          defaultVariables: { status: 'Legacy Imported' }
        });

        // Update category
        const updated = await ruleService.updateRule(newRule.id, { category: importerCategory });

        setRules((prev) => [updated, ...prev]);
        setTotalRules((t) => t + 1);
        setSelectedRuleId(updated.id);
        setCode(astToBpl(parsedAst));
        setVariables(updated.defaultVariables || {});
        setRuleMetaName(updated.name);
        setRuleMetaDesc(updated.description || '');
        setRuleMetaCategory(updated.category || 'Financial');
        setAst(parsedAst);

        setImportNotification({
          message: `Legacy policy "${updated.name}" imported and compiled to visual flow!`,
          type: 'success',
        });
      }

      setIsLegacyImporterOpen(false);
    } catch (err: any) {
      console.error('Importer error:', err);
      setImportNotification({
        message: err.message || 'Failed to import and convert legacy code.',
        type: 'error',
      });
    } finally {
      setIsApiLoading(false);
    }
  };

  // Drag and drop BPL file upload for Wizard
  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true);
    } else if (e.type === "dragleave") {
      setDragActive(false);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    const file = e.dataTransfer.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (event) => {
        const content = event.target?.result;
        if (typeof content === 'string') {
          setWizardPasteCode(content);
          // Try to grab script name from file if empty
          if (!wizardName) {
            const match = content.match(/script\s+"([^"]+)"/);
            if (match && match[1]) {
              setWizardName(match[1]);
            } else {
              setWizardName(file.name.replace(/\.[^/.]+$/, ""));
            }
          }
        }
      };
      reader.readAsText(file);
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (event) => {
        const content = event.target?.result;
        if (typeof content === 'string') {
          setWizardPasteCode(content);
          if (!wizardName) {
            const match = content.match(/script\s+"([^"]+)"/);
            if (match && match[1]) {
              setWizardName(match[1]);
            } else {
              setWizardName(file.name.replace(/\.[^/.]+$/, ""));
            }
          }
        }
      };
      reader.readAsText(file);
    }
  };

  // Formatter and baseline restorer
  const handleFormatCode = () => {
    if (ast) {
      const formatted = astToBpl(ast);
      setCode(formatted);
    }
  };

  const handleResetCode = () => {
    const baseline = rules.find((r) => r.id === selectedRuleId);
    if (baseline) {
      setCode(baseline.code);
      setVariables(baseline.defaultVariables || {});
    }
  };

  // Add / Delete active variable definitions
  const [newVarName, setNewVarName] = useState('');
  const [newVarType, setNewVarType] = useState<'string' | 'number' | 'boolean'>('string');
  const [newVarVal, setNewVarVal] = useState('');

  const handleAddVariable = () => {
    if (!newVarName.trim()) return;
    let typedValue: any = newVarVal;
    if (newVarType === 'number') {
      typedValue = Number(newVarVal) || 0;
    } else if (newVarType === 'boolean') {
      typedValue = newVarVal.toLowerCase() === 'true';
    }
    setVariables((prev) => ({ ...prev, [newVarName.trim()]: typedValue }));
    setNewVarName('');
    setNewVarVal('');
  };

  const handleRemoveVariable = (key: string) => {
    setVariables((prev) => {
      const copy = { ...prev };
      delete copy[key];
      return copy;
    });
  };

  const handleUpdateVariableValue = (key: string, value: any) => {
    setVariables((prev) => ({ ...prev, [key]: value }));
  };

  // Run simulated deployment for Publish step
  const handlePublishDeploy = () => {
    if (!ast) return;
    setIsPublishing(true);
    setPublishProgress(5);
    setPublishLogs([]);
    setIsPublished(false);

    const stages = [
      { prg: 15, log: '✨ Compiling rule AST trees into Booklet byte-arrays...' },
      { prg: 35, log: `🔒 Verifying policy signatures and integrity checklist... (Passed)` },
      { prg: 55, log: `📡 Registering rule namespace: "org.policies.${ruleMetaName.toLowerCase().replace(/[^a-z0-9]/g, '_')}"` },
      { prg: 75, log: `🌐 Spreading compiled policy blocks to all Edge Cache nodes globally...` },
      { prg: 90, log: `🚀 Running validation suite check on CDN gateways... (100% checks passed)` },
      { prg: 100, log: `✅ ACTIVE. Policy loaded on live routers. Endpoint deployed!` }
    ];

    let currentStage = 0;
    const interval = setInterval(() => {
      if (currentStage < stages.length) {
        setPublishProgress(stages[currentStage].prg);
        setPublishLogs((prev) => [...prev, `[${new Date().toLocaleTimeString()}] ${stages[currentStage].log}`]);
        currentStage++;
      } else {
        clearInterval(interval);
        setIsPublishing(false);
        setIsPublished(true);
        setPublishedVersion(`v1.${Math.floor(Math.random() * 10)}.${Math.floor(Math.random() * 50)}`);
      }
    }, 850);
  };

  // Tracing variables extraction for Test step
  const currentStep: TraceStep | undefined = traceSteps[currentStepIndex];
  const activeNodeId = currentStep ? currentStep.currentNodeId : null;
  const activeVariables = currentStep ? currentStep.variableSnapshot : variables;
  const activeLogs = currentStep ? currentStep.logs : [];
  const activeIncludes = currentStep ? currentStep.outputIncludes : [];
  const currentDescription = currentStep ? currentStep.description : '';

  // Download raw rule as BPL file
  const handleDownloadBplFile = (rule: Rule) => {
    const element = document.createElement("a");
    const file = new Blob([rule.code], { type: 'text/plain;charset=utf-8' });
    element.href = URL.createObjectURL(file);
    element.download = `${rule.name.toLowerCase().replace(/\s+/g, '_')}.bpl`;
    document.body.appendChild(element);
    element.click();
    document.body.removeChild(element);
  };

  // Helper recursive functions for Visual AST updates
  const updateNodeInTree = (nodes: BplAstNode[], nodeId: string, fields: Partial<BplAstNode>): boolean => {
    for (let i = 0; i < nodes.length; i++) {
      const node = nodes[i];
      if (node.id === nodeId) {
        nodes[i] = { ...node, ...fields } as BplAstNode;
        return true;
      }
      if (node.type === 'if') {
        const ifNode = node as IfNode;
        if (updateNodeInTree(ifNode.thenBlock, nodeId, fields)) return true;
        if (ifNode.elseBlock && updateNodeInTree(ifNode.elseBlock, nodeId, fields)) return true;
        if (ifNode.elseIfBlocks) {
          for (const elif of ifNode.elseIfBlocks) {
            if (updateNodeInTree(elif.block, nodeId, fields)) return true;
          }
        }
      } else if (node.type === 'switch') {
        const swNode = node as SwitchNode;
        for (const c of swNode.cases) {
          if (updateNodeInTree(c.block, nodeId, fields)) return true;
        }
        if (swNode.defaultBlock && updateNodeInTree(swNode.defaultBlock, nodeId, fields)) return true;
      } else if (node.type === 'only_if') {
        const onlyIfNode = node as any;
        for (const c of onlyIfNode.cases) {
          if (updateNodeInTree(c.block, nodeId, fields)) return true;
        }
      } else if (node.type === 'loop') {
        const loopNode = node as LoopNode;
        if (updateNodeInTree(loopNode.block, nodeId, fields)) return true;
      } else if (node.type === 'macro') {
        const macroNode = node as any;
        if (updateNodeInTree(macroNode.block, nodeId, fields)) return true;
      }
    }
    return false;
  };

  const deleteNodeFromTree = (nodes: BplAstNode[], nodeId: string): boolean => {
    for (let i = 0; i < nodes.length; i++) {
      const node = nodes[i];
      if (node.id === nodeId) {
        nodes.splice(i, 1);
        return true;
      }
      if (node.type === 'if') {
        const ifNode = node as IfNode;
        if (deleteNodeFromTree(ifNode.thenBlock, nodeId)) return true;
        if (ifNode.elseBlock && deleteNodeFromTree(ifNode.elseBlock, nodeId)) return true;
        if (ifNode.elseIfBlocks) {
          for (const elif of ifNode.elseIfBlocks) {
            if (deleteNodeFromTree(elif.block, nodeId)) return true;
          }
        }
      } else if (node.type === 'switch') {
        const swNode = node as SwitchNode;
        for (const c of swNode.cases) {
          if (deleteNodeFromTree(c.block, nodeId)) return true;
        }
        if (swNode.defaultBlock && deleteNodeFromTree(swNode.defaultBlock, nodeId)) return true;
      } else if (node.type === 'only_if') {
        const onlyIfNode = node as any;
        for (const c of onlyIfNode.cases) {
          if (deleteNodeFromTree(c.block, nodeId)) return true;
        }
      } else if (node.type === 'loop') {
        const loopNode = node as LoopNode;
        if (deleteNodeFromTree(loopNode.block, nodeId)) return true;
      } else if (node.type === 'macro') {
        const macroNode = node as any;
        if (deleteNodeFromTree(macroNode.block, nodeId)) return true;
      }
    }
    return false;
  };

  const findNodeInTree = (nodes: BplAstNode[], nodeId: string): BplAstNode | null => {
    for (let i = 0; i < nodes.length; i++) {
      const node = nodes[i];
      if (node.id === nodeId) {
        return node;
      }
      if (node.type === 'if') {
        const ifNode = node as IfNode;
        const found = findNodeInTree(ifNode.thenBlock, nodeId);
        if (found) return found;
        if (ifNode.elseBlock) {
          const f = findNodeInTree(ifNode.elseBlock, nodeId);
          if (f) return f;
        }
        if (ifNode.elseIfBlocks) {
          for (const elif of ifNode.elseIfBlocks) {
            const f = findNodeInTree(elif.block, nodeId);
            if (f) return f;
          }
        }
      } else if (node.type === 'switch') {
        const swNode = node as SwitchNode;
        for (const c of swNode.cases) {
          const found = findNodeInTree(c.block, nodeId);
          if (found) return found;
        }
        if (swNode.defaultBlock) {
          const found = findNodeInTree(swNode.defaultBlock, nodeId);
          if (found) return found;
        }
      } else if (node.type === 'only_if') {
        const onlyIfNode = node as any;
        for (const c of onlyIfNode.cases) {
          const found = findNodeInTree(c.block, nodeId);
          if (found) return found;
        }
      } else if (node.type === 'loop') {
        const loopNode = node as LoopNode;
        const found = findNodeInTree(loopNode.block, nodeId);
        if (found) return found;
      } else if (node.type === 'macro') {
        const macroNode = node as any;
        const found = findNodeInTree(macroNode.block, nodeId);
        if (found) return found;
      }
    }
    return null;
  };

  const addNodeToTree = (nodes: BplAstNode[], targetNodeId: string, newNode: BplAstNode): boolean => {
    if (targetNodeId === 'root') {
      nodes.unshift(newNode);
      return true;
    }

    if (targetNodeId.startsWith('empty-')) {
      const parts = targetNodeId.split('-');
      const type = parts[1];
      const hasIndex = type === 'case' || type === 'elseif';
      const containerNodeId = hasIndex
        ? parts.slice(2, parts.length - 1).join('-')
        : parts.slice(2).join('-');
      const indexValue = hasIndex ? parseInt(parts[parts.length - 1], 10) : 0;

      const container = findNodeInTree(nodes, containerNodeId);
      if (container) {
        if (type === 'case') {
          const caseIdx = indexValue;
          if (container.type === 'switch') {
            const swNode = container as SwitchNode;
            if (swNode.cases[caseIdx]) {
              swNode.cases[caseIdx].block.push(newNode);
              return true;
            }
          } else if (container.type === 'only_if') {
            const onlyIfNode = container as any;
            if (onlyIfNode.cases[caseIdx]) {
              onlyIfNode.cases[caseIdx].block.push(newNode);
              return true;
            }
          }
        } else if (type === 'default') {
          if (container.type === 'switch') {
            const swNode = container as SwitchNode;
            if (!swNode.defaultBlock) {
              swNode.defaultBlock = [];
            }
            swNode.defaultBlock.push(newNode);
            return true;
          }
        } else if (type === 'then') {
          if (container.type === 'if') {
            const ifNode = container as IfNode;
            if (!ifNode.thenBlock) {
              ifNode.thenBlock = [];
            }
            ifNode.thenBlock.push(newNode);
            return true;
          }
        } else if (type === 'else') {
          if (container.type === 'if') {
            const ifNode = container as IfNode;
            if (!ifNode.elseBlock) {
              ifNode.elseBlock = [];
            }
            ifNode.elseBlock.push(newNode);
            return true;
          }
        } else if (type === 'elseif') {
          const elifIdx = indexValue;
          if (container.type === 'if') {
            const ifNode = container as IfNode;
            if (ifNode.elseIfBlocks && ifNode.elseIfBlocks[elifIdx]) {
              ifNode.elseIfBlocks[elifIdx].block.push(newNode);
              return true;
            }
          }
        } else if (type === 'loop') {
          if (container.type === 'loop') {
            const loopNode = container as LoopNode;
            if (!loopNode.block) {
              loopNode.block = [];
            }
            loopNode.block.push(newNode);
            return true;
          }
        } else if (type === 'macro') {
          if (container.type === 'macro') {
            const macroNode = container as any;
            if (!macroNode.block) {
              macroNode.block = [];
            }
            macroNode.block.push(newNode);
            return true;
          }
        }
      }
    }

    for (let i = 0; i < nodes.length; i++) {
      const node = nodes[i];
      if (node.id === targetNodeId) {
        nodes.splice(i + 1, 0, newNode);
        return true;
      }
      if (node.type === 'if') {
        const ifNode = node as IfNode;
        if (addNodeToTree(ifNode.thenBlock, targetNodeId, newNode)) return true;
        if (ifNode.elseBlock && addNodeToTree(ifNode.elseBlock, targetNodeId, newNode)) return true;
        if (ifNode.elseIfBlocks) {
          for (const elif of ifNode.elseIfBlocks) {
            if (addNodeToTree(elif.block, targetNodeId, newNode)) return true;
          }
        }
      } else if (node.type === 'switch') {
        const swNode = node as SwitchNode;
        for (const c of swNode.cases) {
          if (addNodeToTree(c.block, targetNodeId, newNode)) return true;
        }
        if (swNode.defaultBlock && addNodeToTree(swNode.defaultBlock, targetNodeId, newNode)) return true;
      } else if (node.type === 'only_if') {
        const onlyIfNode = node as any;
        for (const c of onlyIfNode.cases) {
          if (addNodeToTree(c.block, targetNodeId, newNode)) return true;
        }
      } else if (node.type === 'loop') {
        const loopNode = node as LoopNode;
        if (addNodeToTree(loopNode.block, targetNodeId, newNode)) return true;
      } else if (node.type === 'macro') {
        const macroNode = node as any;
        if (addNodeToTree(macroNode.block, targetNodeId, newNode)) return true;
      }
    }
    return false;
  };

  const handleVisualUpdateNodeProperty = (nodeId: string, updatedFields: Partial<BplAstNode>) => {
    if (!ast) return;
    const clone = JSON.parse(JSON.stringify(ast)) as ScriptNode;
    const found = updateNodeInTree(clone.children, nodeId, updatedFields);
    if (found) {
      isVisualUpdateRef.current = true;
      const newCode = astToBpl(clone);
      setCode(newCode);
      setAst(clone);
      if (selectedNode && selectedNode.id === nodeId) {
        setSelectedNode({ ...selectedNode, ...updatedFields } as BplAstNode);
      }
    }
  };

  const handleVisualDeleteNode = (nodeId: string) => {
    if (!ast) return;
    const clone = JSON.parse(JSON.stringify(ast)) as ScriptNode;
    const found = deleteNodeFromTree(clone.children, nodeId);
    if (found) {
      isVisualUpdateRef.current = true;
      const newCode = astToBpl(clone);
      setCode(newCode);
      setAst(clone);
      if (selectedNode?.id === nodeId) {
        setSelectedNode(null);
      }
      setImportNotification({ message: 'Node deleted successfully.', type: 'success' });
    }
  };

  const handleVisualAddNode = (targetNodeId: string, type: string) => {
    console.log('add new', targetNodeId, type);
    if (!ast) return;
    let newNode: BplAstNode;

    if (type === 'log') {
      newNode = {
        id: generateId('log'),
        type: 'log',
        message: 'New system log statement'
      } as LogNode;
    } else if (type === 'error') {
      newNode = {
        id: generateId('error'),
        type: 'error',
        message: 'A termination error occurred'
      } as ErrorNode;
    } else if (type === 'assign') {
      newNode = {
        id: generateId('assign'),
        type: 'assign',
        variable: 'status',
        value: 'Approved',
        isValueIdentifier: false
      } as AssignNode;
    } else if (type === 'include') {
      newNode = {
        id: generateId('include'),
        type: 'include',
        path: 'core/shared-rules'
      } as IncludeNode;
    } else if (type === 'jump') {
      newNode = {
        id: generateId('jump'),
        type: 'jump',
        target: 'exitLabel'
      } as JumpNode;
    } else if (type === 'validation') {
      newNode = {
        id: generateId('validation'),
        type: 'validation',
        condition: {
          field: 'status',
          operator: 'equals',
          value: 'active'
        },
        errorMessage: 'Assertion constraint violated'
      } as ValidationNode;
    } else if (type === 'clearscreen') {
      newNode = {
        id: generateId('clearscreen'),
        type: 'clearscreen'
      } as ClearscreenNode;
    } else if (type === 'code') {
      newNode = {
        id: generateId('code'),
        type: 'code'
      } as CodeNode;
    } else if (type === 'prompt') {
      newNode = {
        id: generateId('prompt'),
        type: 'prompt',
        message: 'Enter user feedback',
        variable: 'userInput'
      } as PromptNode;
    } else if (type === 'getkey') {
      newNode = {
        id: generateId('getkey'),
        type: 'getkey',
        variable: 'pressedKey'
      } as GetkeyNode;
    } else if (type === 'only_if') {
      newNode = {
        id: generateId('only_if'),
        type: 'only_if',
        variable: 'status',
        cases: [
          {
            values: ['active'],
            block: [
              {
                id: generateId('log'),
                type: 'log',
                message: 'Active status block matched'
              }
            ]
          }
        ]
      } as OnlyIfNode;
    } else if (type === 'if') {
      newNode = {
        id: generateId('if'),
        type: 'if',
        condition: {
          field: 'status',
          operator: 'equals',
          value: 'active'
        },
        thenBlock: [
          {
            id: generateId('log'),
            type: 'log',
            message: 'Conditional block matched'
          }
        ],
        elseBlock: []
      } as IfNode;
    } else if (type === 'macro') {
      newNode = {
        id: generateId('macro'),
        type: 'macro',
        name: 'custom_logic',
        block: []
      } as MacroNode;
    } else {
      return;
    }

    const clone = JSON.parse(JSON.stringify(ast)) as ScriptNode;
    const found = addNodeToTree(clone.children, targetNodeId, newNode);
    if (found) {
      isVisualUpdateRef.current = true;
      const newCode = astToBpl(clone);
      setCode(newCode);
      setAst(clone);
      setSelectedNode(newNode);
      setRightPanelTab('properties');
      setIsSidebarOpen(true);
      setImportNotification({ message: `Added new ${type} node to visual path.`, type: 'success' });
    }
  };

  // Walk the AST recursively to render a custom hierarchy component for Validate Step
  const renderAstNodeElement = (node: BplAstNode, depth: number = 0) => {
    const isNodeExecuting = activeNodeId === node.id;
    let detailsStr = '';
    let icon = <Layers className="w-3.5 h-3.5 text-indigo-500" />;

    if (node.type === 'log') {
      detailsStr = `message: "${(node as any).message}"`;
      icon = <Terminal className="w-3.5 h-3.5 text-teal-500" />;
    } else if (node.type === 'assign') {
      detailsStr = `var: "${(node as any).variable}" ➜ val: "${(node as any).value}"`;
      icon = <Sliders className="w-3.5 h-3.5 text-emerald-500" />;
    } else if (node.type === 'include') {
      detailsStr = `template: "${(node as any).path}"`;
      icon = <FileText className="w-3.5 h-3.5 text-sky-500" />;
    } else if (node.type === 'jump') {
      detailsStr = `target: "${(node as any).target}"`;
      icon = <ArrowRightLeft className="w-3.5 h-3.5 text-amber-500" />;
    } else if (node.type === 'if') {
      const ifNode = node as IfNode;
      const formatCond = (cond: any): string => {
        if (!cond) return '';
        if (cond.type === 'condition-group' || cond.conditions) {
          return (cond.conditions || []).map((c: any) => formatCond(c)).join(` ${cond.operator || 'AND'} `);
        }
        return `${cond.field || ''} ${cond.operator || ''} ${cond.value || ''}`;
      };
      detailsStr = `IF [ ${formatCond(ifNode.condition)} ]`;
      icon = <Sliders className="w-3.5 h-3.5 text-indigo-600" />;
    } else if (node.type === 'switch') {
      detailsStr = `SWITCH [ ${(node as any).variable} ]`;
      icon = <Layers className="w-3.5 h-3.5 text-violet-500" />;
    } else if (node.type === 'loop') {
      detailsStr = `LOOP over ${(node as any).collection}`;
      icon = <RefreshCw className="w-3.5 h-3.5 text-fuchsia-500 animate-spin-slow" />;
    } else if (node.type === 'macro') {
      detailsStr = `MACRO: "${(node as any).name}"`;
      icon = <Cpu className="w-3.5 h-3.5 text-indigo-500" />;
    } else if (node.type === 'only_if') {
      detailsStr = `ONLY_IF [ ${(node as any).variable} ]`;
      icon = <ToggleLeft className="w-3.5 h-3.5 text-indigo-500" />;
    } else if (node.type === 'clearscreen') {
      detailsStr = `CLEAR SCREEN`;
      icon = <Layers className="w-3.5 h-3.5 text-orange-500" />;
    } else if (node.type === 'code') {
      detailsStr = `CODE BLOCK`;
      icon = <Terminal className="w-3.5 h-3.5 text-gray-500" />;
    } else if (node.type === 'prompt') {
      detailsStr = `PROMPT [ ${(node as any).variable} ]: "${(node as any).message}"`;
      icon = <Terminal className="w-3.5 h-3.5 text-pink-500" />;
    } else if (node.type === 'getkey') {
      detailsStr = `GETKEY [ ${(node as any).variable} ]`;
      icon = <Terminal className="w-3.5 h-3.5 text-blue-500" />;
    } else if (node.type === 'error') {
      detailsStr = `ERROR EXIT: "${(node as any).message}"`;
      icon = <AlertTriangle className="w-3.5 h-3.5 text-red-500" />;
    }

    return (
      <div key={node.id} className="space-y-1">
        <div 
          className={`flex items-center gap-2 px-3 py-2 rounded-xl text-xs border transition ${
            isNodeExecuting 
              ? 'bg-indigo-50 border-indigo-200 text-indigo-900 font-semibold shadow-xs' 
              : 'bg-white border-gray-150 hover:bg-slate-50 text-gray-700'
          }`}
          style={{ marginLeft: `${depth * 20}px` }}
        >
          <span className="text-[10px] uppercase font-mono font-bold bg-slate-150 text-slate-600 px-1.5 py-0.5 rounded">
            {node.type}
          </span>
          <div className="shrink-0">{icon}</div>
          <span className="font-mono text-gray-600 truncate">{detailsStr}</span>
          <span className="ml-auto text-[9px] font-mono text-gray-400">ID: {node.id.split('-')[1] || node.id}</span>
        </div>

        {/* Children Blocks */}
        {node.type === 'if' && (
          <div className="space-y-1">
            <div className="text-[9px] font-bold text-slate-400 uppercase tracking-widest pl-4" style={{ marginLeft: `${(depth + 1) * 20}px` }}>THEN Block</div>
            {(node as IfNode).thenBlock.map(child => renderAstNodeElement(child, depth + 1))}
            {(node as IfNode).elseBlock && (node as IfNode).elseBlock!.length > 0 && (
              <>
                <div className="text-[9px] font-bold text-slate-400 uppercase tracking-widest pl-4" style={{ marginLeft: `${(depth + 1) * 20}px` }}>ELSE Block</div>
                {(node as IfNode).elseBlock!.map(child => renderAstNodeElement(child, depth + 1))}
              </>
            )}
          </div>
        )}

        {node.type === 'switch' && (
          <div className="space-y-1">
            {(node as SwitchNode).cases.map((c, idx) => (
              <div key={idx} className="space-y-1">
                <div className="text-[9px] font-bold text-slate-400 uppercase tracking-widest pl-4" style={{ marginLeft: `${(depth + 1) * 20}px` }}>CASE: "{c.value}"</div>
                {c.block.map(child => renderAstNodeElement(child, depth + 1))}
              </div>
            ))}
            {(node as SwitchNode).defaultBlock && (
              <div className="space-y-1">
                <div className="text-[9px] font-bold text-slate-400 uppercase tracking-widest pl-4" style={{ marginLeft: `${(depth + 1) * 20}px` }}>DEFAULT CASE</div>
                {(node as SwitchNode).defaultBlock!.map(child => renderAstNodeElement(child, depth + 1))}
              </div>
            )}
          </div>
        )}

        {node.type === 'loop' && (
          <div className="space-y-1">
            <div className="text-[9px] font-bold text-slate-400 uppercase tracking-widest pl-4" style={{ marginLeft: `${(depth + 1) * 20}px` }}>LOOP Block</div>
            {(node as LoopNode).block.map(child => renderAstNodeElement(child, depth + 1))}
          </div>
        )}

        {node.type === 'macro' && (
          <div className="space-y-1">
            <div className="text-[9px] font-bold text-slate-400 uppercase tracking-widest pl-4" style={{ marginLeft: `${(depth + 1) * 20}px` }}>MACRO Block</div>
            {(node as any).block.map((child: any) => renderAstNodeElement(child, depth + 1))}
          </div>
        )}

        {node.type === 'only_if' && (
          <div className="space-y-1">
            {(node as any).cases.map((c: any, idx: number) => (
              <div key={idx} className="space-y-1">
                <div className="text-[9px] font-bold text-slate-400 uppercase tracking-widest pl-4" style={{ marginLeft: `${(depth + 1) * 20}px` }}>CASE: "{c.values.join(', ')}"</div>
                {c.block.map((child: any) => renderAstNodeElement(child, depth + 1))}
              </div>
            ))}
          </div>
        )}
      </div>
    );
  };

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col text-gray-800 antialiased font-sans">
      
      {/* 1. Header bar */}
      <header className="bg-white border-b border-gray-200/80 px-6 py-4 flex flex-col md:flex-row md:items-center justify-between gap-4 sticky top-0 z-40 shadow-xs">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-indigo-600 rounded-xl text-white shadow-md shadow-indigo-100">
            <Cpu className="w-5 h-5" />
          </div>
          <div>
            <h1 className="text-base font-bold text-gray-900 tracking-tight">
              BPL Rules Studio
            </h1>
            <p className="text-[10px] text-gray-400 font-semibold uppercase tracking-wider">
              Booklet Policy Language Enterprise IDE
            </p>
          </div>
        </div>

        {/* Global actions */}
        <div className="flex flex-wrap items-center gap-3">
          <span className="hidden sm:flex items-center gap-1.5 text-[10px] bg-slate-100 text-slate-600 px-2.5 py-1 rounded-lg font-bold uppercase tracking-wider border border-gray-200/40">
            <Server className="w-3.5 h-3.5 text-slate-500 shrink-0" /> Live DB API Connected
          </span>

          {selectedRuleId && (
            <div className="flex items-center gap-2 bg-indigo-50/60 border border-indigo-100 rounded-xl px-3 py-1 text-xs">
              <span className="text-[10px] uppercase font-bold tracking-wider text-indigo-500">Active Rule:</span>
              <span className="font-semibold text-indigo-900 truncate max-w-[120px]">{ruleMetaName || 'Loading...'}</span>
            </div>
          )}

          <button
            onClick={openVmExecutor}
            className="flex items-center gap-1.5 px-3.5 py-1.5 bg-emerald-50 hover:bg-emerald-100 border border-emerald-250 hover:border-emerald-300 text-emerald-800 rounded-xl text-xs font-bold shadow-xs transition cursor-pointer"
            id="btn-trigger-go-vm"
          >
            <Play className="w-3.5 h-3.5 text-emerald-600 shrink-0 fill-current animate-pulse" />
            <span>Go WASM Executor</span>
          </button>

          <button
            onClick={() => {
              setIsOverwritingActiveRule(false);
              setImporterPasteCode('');
              setImporterName('Legacy Evaluator Rule');
              setImporterDesc('Legacy Booklet Policy parsed and compiled');
              setImporterCategory('Financial');
              setImporterErrors([]);
              setImporterIsValid(true);
              setIsLegacyImporterOpen(true);
            }}
            className="flex items-center gap-1.5 px-3.5 py-1.5 bg-white hover:bg-slate-50 border border-gray-250 hover:border-gray-300 text-slate-700 rounded-xl text-xs font-bold shadow-xs transition cursor-pointer"
            id="btn-trigger-legacy-importer"
          >
            <Upload className="w-3.5 h-3.5 text-indigo-600 shrink-0" />
            <span>Import Legacy BPL</span>
          </button>

          <button
            onClick={() => setIsNewRuleWizardOpen(true)}
            className="flex items-center gap-1.5 px-3.5 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white border border-indigo-700 rounded-xl text-xs font-bold shadow-xs transition cursor-pointer"
            id="btn-trigger-new-wizard"
          >
            <Plus className="w-3.5 h-3.5" />
            New Rule
          </button>
        </div>
      </header>

      {/* 3. Workspace body block */}
      <main className="flex-1 p-6">
        <AnimatePresence mode="wait">
          {!selectedRuleId ? (
            <motion.div
              key="registry-table"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              className="space-y-6"
            >
              <div className="bg-white border border-gray-200/80 rounded-2xl shadow-sm overflow-hidden space-y-4 p-6">
                {/* Search and Filters toolbar */}
                <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-gray-100 pb-4">
                  <div>
                    <h2 className="text-base font-bold text-gray-900 tracking-tight">Enterprise Rules Registry</h2>
                    <p className="text-xs text-gray-400">Search and manage Booklet Policy scripts stored securely in server database.</p>
                  </div>

                  <div className="flex flex-wrap items-center gap-3">
                    {/* Search */}
                    <div className="relative w-64">
                      <Search className="w-4 h-4 text-gray-400 absolute left-3 top-2.5" />
                      <input
                        type="text"
                        value={dbSearch}
                        onChange={(e) => setDbSearch(e.target.value)}
                        placeholder="Search 145,000+ rules..."
                        className="w-full pl-9 pr-4 py-2 bg-slate-50 border border-gray-250 rounded-xl text-xs font-semibold focus:outline-none focus:ring-1 focus:ring-indigo-500 focus:bg-white transition"
                      />
                    </div>

                    {/* Category Pill select list */}
                    <div className="flex items-center gap-1.5 bg-slate-100 p-1 rounded-xl">
                      {['all', 'Financial', 'Healthcare', 'Insurance', 'Logistics'].map((cat) => (
                        <button
                          key={cat}
                          onClick={() => setDbCategory(cat)}
                          className={`px-3 py-1.5 rounded-lg text-xs font-bold transition cursor-pointer ${
                            dbCategory === cat
                              ? 'bg-indigo-600 text-white shadow-xs'
                              : 'text-gray-500 hover:text-gray-800'
                          }`}
                        >
                          {cat === 'all' ? 'All' : cat}
                        </button>
                      ))}
                    </div>
                  </div>
                </div>

                {/* Rules table list */}
                <div className="overflow-x-auto">
                  {isApiLoading && rules.length === 0 ? (
                    <div className="py-24 text-center">
                      <RefreshCw className="w-8 h-8 animate-spin text-indigo-600 mx-auto mb-3" />
                      <span className="text-xs font-bold text-gray-500">Querying database indexes...</span>
                    </div>
                  ) : rules.length === 0 ? (
                    <div className="py-24 text-center">
                      <AlertTriangle className="w-8 h-8 text-amber-500 mx-auto mb-2" />
                      <p className="text-sm font-bold text-gray-700">No matching policies found</p>
                      <p className="text-xs text-gray-400 mt-1">Try clarifying filters or create a new policy script to start.</p>
                      <button
                        onClick={() => { setDbSearch(''); setDbCategory('all'); }}
                        className="mt-4 px-4 py-2 bg-indigo-550 hover:bg-indigo-600 text-white text-xs font-bold rounded-xl transition shadow-xs"
                      >
                        Reset Search Filters
                      </button>
                    </div>
                  ) : (
                    <table className="w-full border-collapse text-left text-xs">
                      <thead>
                        <tr className="border-b border-gray-150 text-gray-400 font-bold uppercase tracking-wider text-[10px] bg-slate-50/50">
                          <th className="py-3 px-4">Policy Code / Name</th>
                          <th className="py-3 px-4 hidden md:table-cell">Description</th>
                          <th className="py-3 px-4">Category</th>
                          <th className="py-3 px-4 hidden sm:table-cell">Variables</th>
                          <th className="py-3 px-4 text-right">Actions</th>
                        </tr>
                      </thead>
                      <tbody>
                        {rules.map((rule) => {
                          const varCount = Object.keys(rule.defaultVariables || {}).length;
                          return (
                            <tr
                              key={rule.id}
                              onClick={() => handleSelectRule(rule.id)}
                              className="border-b border-gray-100 hover:bg-slate-50/75 transition cursor-pointer select-none"
                            >
                              <td className="py-3 px-4 font-bold text-gray-900">
                                <div className="flex items-center gap-2">
                                  <div className="p-1.5 bg-indigo-50 text-indigo-600 rounded-lg">
                                    <FileText className="w-3.5 h-3.5" />
                                  </div>
                                  <div className="min-w-0">
                                    <span className="block truncate font-bold text-slate-800">{rule.name}</span>
                                    <span className="text-[9px] font-mono text-gray-400 font-semibold uppercase">{rule.id.split('-')[0]}</span>
                                  </div>
                                </div>
                              </td>
                              <td className="py-3 px-4 text-gray-500 hidden md:table-cell max-w-xs truncate">
                                {rule.description || 'No description provided.'}
                              </td>
                              <td className="py-3 px-4">
                                <span className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded-full text-[10px] font-bold bg-indigo-50 text-indigo-700 border border-indigo-100">
                                  {rule.category || 'Financial'}
                                </span>
                              </td>
                              <td className="py-3 px-4 hidden sm:table-cell">
                                <span className="font-mono font-bold text-slate-500 text-[11px] bg-slate-100 px-1.5 py-0.5 rounded-md">
                                  {varCount} declared
                                </span>
                              </td>
                              <td className="py-3 px-4 text-right" onClick={(e) => e.stopPropagation()}>
                                <div className="flex items-center justify-end gap-1">
                                  <button
                                    onClick={() => handleSelectRule(rule.id)}
                                    className="p-1.5 hover:bg-indigo-50 hover:text-indigo-600 rounded-lg transition cursor-pointer text-gray-500"
                                    title="Edit Policy"
                                  >
                                    <Eye className="w-4 h-4" />
                                  </button>
                                  <button
                                    onClick={(e) => handleDuplicateRule(rule, e)}
                                    className="p-1.5 hover:bg-indigo-50 hover:text-indigo-600 rounded-lg transition cursor-pointer text-gray-500"
                                    title="Duplicate Policy"
                                  >
                                    <Copy className="w-4 h-4" />
                                  </button>
                                  <button
                                    onClick={() => handleDownloadBplFile(rule)}
                                    className="p-1.5 hover:bg-indigo-50 hover:text-indigo-600 rounded-lg transition cursor-pointer text-gray-500"
                                    title="Download raw .bpl code"
                                  >
                                    <Download className="w-4 h-4" />
                                  </button>
                                  <button
                                    onClick={(e) => handleDeleteRule(rule.id, e)}
                                    className="p-1.5 hover:bg-rose-50 hover:text-rose-600 rounded-lg transition cursor-pointer text-gray-500 hover:text-rose-500"
                                    title="Delete permanently"
                                  >
                                    <Trash2 className="w-4 h-4" />
                                  </button>
                                </div>
                              </td>
                            </tr>
                          );
                        })}
                      </tbody>
                    </table>
                  )}
                </div>

                {/* Pagination Controls */}
                {totalRules > dbLimit && (
                  <div className="flex items-center justify-between border-t border-gray-100 pt-4 text-xs font-semibold select-none">
                    <span className="text-gray-400">Showing rows {((dbPage - 1) * dbLimit) + 1} - {Math.min(totalRules, dbPage * dbLimit)} of {totalRules} total entries</span>
                    <div className="flex items-center gap-1.5">
                      <button
                        onClick={() => setDbPage(1)}
                        disabled={dbPage === 1 || isApiLoading}
                        className="p-2 bg-white border border-gray-200 hover:border-gray-300 disabled:opacity-40 rounded-xl transition cursor-pointer"
                      >
                        <ChevronsLeft className="w-4 h-4" />
                      </button>
                      <button
                        onClick={() => setDbPage((p) => Math.max(1, p - 1))}
                        disabled={dbPage === 1 || isApiLoading}
                        className="p-2 bg-white border border-gray-200 hover:border-gray-300 disabled:opacity-40 rounded-xl transition cursor-pointer"
                      >
                        <ChevronLeft className="w-4 h-4" />
                      </button>

                      <div className="flex items-center gap-1 bg-slate-50 border px-3 py-1.5 rounded-xl font-mono">
                        <span className="text-[10px] text-gray-400 uppercase font-bold">Page</span>
                        <input
                          type="number"
                          min="1"
                          max={Math.ceil(totalRules / dbLimit)}
                          value={dbPage}
                          onChange={(e) => {
                            const val = parseInt(e.target.value, 10);
                            if (val > 0 && val <= Math.ceil(totalRules / dbLimit)) {
                              setDbPage(val);
                            }
                          }}
                          className="w-10 text-center font-bold text-indigo-600 bg-transparent focus:outline-none text-xs"
                        />
                        <span className="text-[10px] text-gray-400">/ {Math.ceil(totalRules / dbLimit)}</span>
                      </div>

                      <button
                        onClick={() => setDbPage((p) => Math.min(Math.ceil(totalRules / dbLimit), p + 1))}
                        disabled={dbPage >= Math.ceil(totalRules / dbLimit) || isApiLoading}
                        className="p-2 bg-white border border-gray-200 hover:border-gray-300 disabled:opacity-40 rounded-xl transition cursor-pointer"
                      >
                        <ChevronRight className="w-4 h-4" />
                      </button>
                      <button
                        onClick={() => setDbPage(Math.ceil(totalRules / dbLimit))}
                        disabled={dbPage >= Math.ceil(totalRules / dbLimit) || isApiLoading}
                        className="p-2 bg-white border border-gray-200 hover:border-gray-300 disabled:opacity-40 rounded-xl transition cursor-pointer"
                      >
                        <ChevronsRight className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                )}
              </div>
            </motion.div>
          ) : (
            /* Split screen layout: visual canvas + right tabs */
            <motion.div
              key="unified-designer"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              className="space-y-6"
            >
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
                
                {/* Canvas (Col Span 12 if sidebar closed, else 8) */}
                <div className={`${isSidebarOpen ? 'lg:col-span-8' : 'lg:col-span-12'} flex flex-col space-y-6 transition-all duration-300`}>
                  <div className="bg-white border border-gray-200/80 rounded-2xl shadow-sm overflow-hidden flex flex-col h-full min-h-[550px]">
                    
                    {/* Canvas Header */}
                    <div className="bg-slate-50 border-b border-gray-200/80 px-4 py-3 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 select-none">
                      <div className="flex items-center gap-3">
                        <button
                          onClick={() => setSelectedRuleId('')}
                          className="flex items-center gap-1.5 px-3 py-1.5 bg-white border border-gray-250 hover:bg-slate-100 hover:border-gray-300 text-slate-700 rounded-xl text-xs font-bold shadow-xs transition cursor-pointer"
                          title="Back to Table Registry"
                        >
                          <ArrowLeft className="w-3.5 h-3.5 text-indigo-600" />
                          <span>Registry</span>
                        </button>
                        <div className="h-5 w-px bg-gray-200/80 hidden sm:block" />
                        <Terminal className="w-4 h-4 text-indigo-500 hidden sm:block" />
                        <span className="text-xs font-bold text-slate-800 font-mono hidden sm:inline">Visual Flow Canvas</span>
                        {errors.length > 0 ? (
                          <span className="flex items-center gap-1 text-[9px] bg-rose-50 text-rose-700 font-bold px-2 py-0.5 rounded-full border border-rose-100">
                            <AlertTriangle className="w-3 h-3 text-rose-500" /> Compiler Errors
                          </span>
                        ) : (
                          <span className="flex items-center gap-1 text-[9px] bg-emerald-50 text-emerald-700 font-bold px-2 py-0.5 rounded-full border border-emerald-100">
                            <CheckCircle className="w-3 h-3 text-emerald-500" /> Valid BPL Syntax
                          </span>
                        )}
                      </div>
 
                      {/* Sub-tab shortcuts */}
                      <div className="flex items-center gap-1.5 self-stretch sm:self-auto justify-end">
                        <button
                          onClick={() => {
                            setIsOverwritingActiveRule(true);
                            setImporterPasteCode(code); // Populate with active rule's legacy code
                            setImporterErrors([]);
                            setImporterIsValid(true);
                            setIsLegacyImporterOpen(true);
                          }}
                          className="px-2.5 py-1.5 bg-white hover:bg-slate-100 border border-gray-250 hover:border-gray-350 text-slate-700 hover:text-indigo-600 rounded-xl text-xs font-bold flex items-center gap-1 transition cursor-pointer shadow-2xs"
                          title="Overwrite this visual flow with pasted legacy BPL code"
                        >
                          <Upload className="w-3.5 h-3.5 text-indigo-500 shrink-0" />
                          <span className="hidden md:inline">Import BPL Code</span>
                        </button>

                        <button
                          onClick={() => {
                            if (isSidebarOpen && rightPanelTab === 'properties') {
                              setIsSidebarOpen(false);
                            } else {
                              setRightPanelTab('properties');
                              setIsSidebarOpen(true);
                            }
                          }}
                          className={`px-2.5 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1 transition cursor-pointer ${
                            isSidebarOpen && rightPanelTab === 'properties'
                              ? 'bg-indigo-600 text-white shadow-xs border border-indigo-700'
                              : 'text-gray-600 hover:text-gray-900 hover:bg-slate-100 border border-transparent'
                          }`}
                          title="Properties Editor"
                        >
                          <Sliders className="w-3.5 h-3.5" /> <span className="hidden md:inline">Properties</span>
                        </button>
                        <button
                          onClick={() => {
                            if (isSidebarOpen && rightPanelTab === 'validate') {
                              setIsSidebarOpen(false);
                            } else {
                              setRightPanelTab('validate');
                              setIsSidebarOpen(true);
                              setSelectedNode(null);
                            }
                          }}
                          className={`px-2.5 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1 transition cursor-pointer ${
                            isSidebarOpen && rightPanelTab === 'validate'
                              ? 'bg-indigo-600 text-white shadow-xs border border-indigo-700'
                              : 'text-gray-600 hover:text-gray-900 hover:bg-slate-100 border border-transparent'
                          }`}
                          title="Validation View"
                        >
                          <CheckCircle className="w-3.5 h-3.5" /> <span className="hidden md:inline">Validate</span>
                        </button>
                        <button
                          onClick={() => {
                            if (isSidebarOpen && rightPanelTab === 'test') {
                              setIsSidebarOpen(false);
                            } else {
                              setRightPanelTab('test');
                              setIsSidebarOpen(true);
                              setSelectedNode(null);
                            }
                          }}
                          className={`px-2.5 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1 transition cursor-pointer ${
                            isSidebarOpen && rightPanelTab === 'test'
                              ? 'bg-indigo-600 text-white shadow-xs border border-indigo-700'
                              : 'text-gray-650 hover:text-gray-900 hover:bg-slate-100 border border-transparent'
                          }`}
                          title="Test Sandbox"
                        >
                          <Play className="w-3.5 h-3.5" /> <span>Test Sandbox</span>
                        </button>
                        <button
                          onClick={() => {
                            if (isSidebarOpen && rightPanelTab === 'settings') {
                              setIsSidebarOpen(false);
                            } else {
                              setRightPanelTab('settings');
                              setIsSidebarOpen(true);
                              setSelectedNode(null);
                            }
                          }}
                          className={`px-2.5 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1 transition cursor-pointer ${
                            isSidebarOpen && rightPanelTab === 'settings'
                              ? 'bg-indigo-600 text-white shadow-xs border border-indigo-700'
                              : 'text-gray-650 hover:text-gray-900 hover:bg-slate-100 border border-transparent'
                          }`}
                          title="Policy Settings"
                        >
                          <Settings className="w-3.5 h-3.5" /> <span className="hidden md:inline">Settings</span>
                        </button>
                      </div>
                    </div>
 
                    {/* Canvas body */}
                    <div className="flex-1 overflow-y-auto bg-slate-50">
                      {ast ? (
                        <VisualFlow
                          ast={ast}
                          activeNodeId={activeNodeId}
                          executedNodeIds={new Set(traceSteps.slice(0, currentStepIndex + 1).filter(s => s.executed).map(s => s.currentNodeId))}
                          skippedNodeIds={new Set(traceSteps.slice(0, currentStepIndex + 1).filter(s => !s.executed).map(s => s.currentNodeId))}
                          onSelectNode={(node) => {
                            setSelectedNode(node);
                            setRightPanelTab('properties');
                            setIsSidebarOpen(true);
                          }}
                          selectedNodeId={selectedNode ? selectedNode.id : null}
                          onAddNode={handleVisualAddNode}
                          onDeleteNode={handleVisualDeleteNode}
                        />
                      ) : (
                        <div className="flex-1 flex flex-col items-center justify-center py-24 text-center">
                          <AlertTriangle className="w-8 h-8 text-amber-500 mx-auto mb-2" />
                          <p className="text-sm font-bold text-gray-700">Invalid Syntax</p>
                          <p className="text-xs text-gray-400 mt-1">
                            Fix parser violations to render the flow.
                          </p>
                        </div>
                      )}
                    </div>

                    {/* Error indicator bar */}
                    {errors.length > 0 && (
                      <div className="bg-rose-50 border-t border-rose-100 p-3 flex items-start gap-2 text-[11px] text-rose-800 font-medium">
                        <AlertTriangle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
                        <div>
                          <span className="font-bold block">Line {errors[0].line || 1}: Syntax parsing failed</span>
                          <span className="text-rose-600">{errors[0].message}</span>
                        </div>
                      </div>
                    )}
                  </div>
                </div>

                {/* Sidebar (Col Span 4) */}
                {isSidebarOpen && (
                  <div className="lg:col-span-4 bg-white border border-gray-200/80 rounded-2xl shadow-sm overflow-hidden flex flex-col min-h-[550px]">
                    
                    {/* Sidebar Header */}
                    <div className="bg-slate-50 border-b border-gray-200 flex items-center justify-between px-4 py-3 select-none shrink-0">
                      <div className="flex items-center gap-2 text-slate-800 font-bold text-xs tracking-tight">
                        {rightPanelTab === 'properties' && (
                          <>
                            <Sliders className="w-4 h-4 text-indigo-600" />
                            <span>Block Properties</span>
                          </>
                        )}
                        {rightPanelTab === 'validate' && (
                          <>
                            <CheckCircle className="w-4 h-4 text-indigo-600" />
                            <span>Syntax Validation</span>
                          </>
                        )}
                        {rightPanelTab === 'test' && (
                          <>
                            <Play className="w-4 h-4 text-indigo-600" />
                            <span>Test Sandbox</span>
                          </>
                        )}
                        {rightPanelTab === 'settings' && (
                          <>
                            <Settings className="w-4 h-4 text-indigo-600" />
                            <span>Policy Settings</span>
                          </>
                        )}
                      </div>

                      {/* Close button */}
                      <button
                        onClick={() => {
                          setIsSidebarOpen(false);
                          setSelectedNode(null);
                        }}
                        className="p-1.5 hover:bg-slate-200/60 rounded-lg transition text-gray-450 hover:text-gray-700 cursor-pointer"
                        title="Collapse Sidebar"
                      >
                        <X className="w-4 h-4" />
                      </button>
                    </div>

                    {/* Sidebar Body */}
                    <div className="p-4 flex-1 overflow-y-auto max-h-[620px]">
                      
                      {rightPanelTab === 'properties' && (
                        <div className="space-y-4">
                          {selectedNode && ast ? (
                            <NodeEditor
                              selectedNode={selectedNode}
                              onUpdateNodeProperty={handleVisualUpdateNodeProperty}
                              onClose={() => {
                                setSelectedNode(null);
                                setIsSidebarOpen(false);
                              }}
                              ast={ast}
                            />
                          ) : (
                            <div className="py-16 px-4 text-center space-y-4">
                              <div className="p-4 bg-indigo-50 border border-indigo-100 rounded-full inline-block text-indigo-600">
                                <Sliders className="w-8 h-8" />
                              </div>
                              <div>
                                <h3 className="text-xs font-bold text-gray-900 uppercase tracking-wider">No Block Selected</h3>
                                <p className="text-[11px] text-gray-400 mt-1.5 leading-relaxed">
                                  Click any conditional branch, logic block, or logging statement in the flow canvas on the left to inspect, modify variables, or change state properties instantly.
                                </p>
                              </div>
                            </div>
                          )}
                        </div>
                      )}

                      {rightPanelTab === 'validate' && (
                        <ValidationTab
                          errors={errors}
                          ast={ast}
                          renderAstNodeElement={renderAstNodeElement}
                        />
                      )}

                      {rightPanelTab === 'test' && (
                        <SimulatorTab
                          traceSteps={traceSteps}
                          currentStepIndex={currentStepIndex}
                          setCurrentStepIndex={setCurrentStepIndex}
                          isPlaying={isPlaying}
                          setIsPlaying={setIsPlaying}
                          playbackSpeed={playbackSpeed}
                          setPlaybackSpeed={setPlaybackSpeed}
                          activeVariables={activeVariables}
                          activeLogs={activeLogs}
                          activeIncludes={activeIncludes}
                        />
                      )}

                      {rightPanelTab === 'settings' && (
                        <SaveTab
                          handleSaveCurrentRule={handleSaveCurrentRule}
                          handlePublishDeploy={handlePublishDeploy}
                          isPublishing={isPublishing}
                          ast={ast}
                          publishProgress={publishProgress}
                          publishLogs={publishLogs}
                          isPublished={isPublished}
                          selectedRuleId={selectedRuleId}
                          ruleMetaName={ruleMetaName}
                          setRuleMetaName={setRuleMetaName}
                          ruleMetaDesc={ruleMetaDesc}
                          setRuleMetaDesc={setRuleMetaDesc}
                          ruleMetaCategory={ruleMetaCategory}
                          setRuleMetaCategory={setRuleMetaCategory}
                          variables={variables}
                          handleUpdateVariableValue={handleUpdateVariableValue}
                          handleRemoveVariable={handleRemoveVariable}
                          newVarName={newVarName}
                          setNewVarName={setNewVarName}
                          newVarType={newVarType}
                          setNewVarType={setNewVarType}
                          newVarVal={newVarVal}
                          setNewVarVal={setNewVarVal}
                          handleAddVariable={handleAddVariable}
                          setImportNotification={setImportNotification}
                          compiledBinary={rules.find((r) => r.id === selectedRuleId)?.compiledBinary}
                        />
                      )}

                    </div>
                  </div>
                )}

              </div>
            </motion.div>
          )}
        </AnimatePresence>
</main>

      {/* 5. GO WASM VM EXECUTOR MODAL */}
      <AnimatePresence>
        {isVmExecutorOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            {/* Backdrop */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => {
                if (vmStatus !== 'running' && vmStatus !== 'paused') {
                  setIsVmExecutorOpen(false);
                }
              }}
              className="absolute inset-0 bg-slate-900/60 backdrop-blur-xs"
            />

            {/* Modal Box */}
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 15 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 15 }}
              className="relative w-full max-w-4xl bg-white border border-gray-150 rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]"
            >
              {/* Modal Header */}
              <div className="bg-gradient-to-r from-emerald-600 to-teal-700 text-white px-6 py-4 flex items-center justify-between">
                <div className="flex items-center gap-2.5">
                  <div className="p-1 bg-white/10 rounded-lg">
                    <Cpu className="w-5 h-5 text-emerald-200" />
                  </div>
                  <div>
                    <h3 className="text-sm font-bold tracking-tight flex items-center gap-1.5">
                      Go WASM Interpreter & VM Engine
                      <span className="text-[9px] bg-emerald-500/30 text-emerald-100 font-mono px-1.5 py-0.5 rounded border border-emerald-400/20">
                        Multi-Thread Worker
                      </span>
                    </h3>
                    <p className="text-[10px] text-emerald-100/80">Execute rules natively with compiler-bytecode state visualization</p>
                  </div>
                </div>
                <button
                  onClick={() => setIsVmExecutorOpen(false)}
                  disabled={vmStatus === 'running'}
                  className="p-1 rounded-lg hover:bg-white/10 text-white/80 hover:text-white transition cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              {/* Modal Body */}
              <div className="p-6 overflow-y-auto flex-1 grid grid-cols-1 lg:grid-cols-12 gap-6 min-h-0 bg-slate-50/50">
                
                {/* Left Side: Registry & Input State (5 columns) */}
                <div className="lg:col-span-5 space-y-5 flex flex-col">
                  {/* Registry Rule Picker */}
                  <div className="bg-white border border-gray-150 p-4 rounded-xl shadow-xs space-y-3">
                    <label className="block text-[11px] font-bold text-gray-500 uppercase tracking-wider">
                      Select Rule Registry
                    </label>
                    <select
                      value={vmSelectedRuleId}
                      onChange={(e) => setVmSelectedRuleId(e.target.value)}
                      disabled={vmStatus === 'running' || vmStatus === 'paused'}
                      className="w-full bg-slate-50 border border-gray-250 rounded-xl px-3 py-2 text-xs font-semibold focus:outline-none focus:ring-1 focus:ring-emerald-500 focus:bg-white transition disabled:opacity-60"
                    >
                      <option value="">-- Choose a Rule --</option>
                      {vmRegistryList.map((r) => (
                        <option key={r.id} value={r.id}>
                          {r.name} {r.category ? `(${r.category})` : ''} {r.isVirtual ? ' [Virtual Pool]' : ''}
                        </option>
                      ))}
                    </select>
                    {vmRuleDetail && (
                      <div className="p-3 bg-slate-50 rounded-lg border border-gray-100 space-y-1.5 text-slate-600">
                        <div className="text-xs font-bold text-gray-800">{vmRuleDetail.name}</div>
                        <p className="text-[10px] leading-relaxed line-clamp-2">{vmRuleDetail.description || 'No description provided.'}</p>
                        <div className="flex items-center gap-2 text-[9px] font-mono font-bold text-slate-400">
                          <span className="bg-slate-200 text-slate-600 px-1.5 py-0.5 rounded uppercase">{vmRuleDetail.category || 'Financial'}</span>
                          <span>Updated: {new Date(vmRuleDetail.updatedAt || vmRuleDetail.createdAt).toLocaleDateString()}</span>
                        </div>
                      </div>
                    )}
                  </div>

                  {/* Input Variables Configurator */}
                  <div className="bg-white border border-gray-150 p-4 rounded-xl shadow-xs space-y-3 flex-1 flex flex-col min-h-[220px]">
                    <div className="flex items-center justify-between">
                      <label className="block text-[11px] font-bold text-gray-500 uppercase tracking-wider">
                        Initial Input State
                      </label>
                      <button
                        type="button"
                        onClick={() => {
                          const key = `var_${Math.floor(Math.random() * 1000)}`;
                          setVmInputVars((prev) => ({ ...prev, [key]: '' }));
                        }}
                        disabled={vmStatus === 'running' || vmStatus === 'paused'}
                        className="text-[10px] font-bold text-emerald-600 hover:text-emerald-700 flex items-center gap-1 cursor-pointer disabled:opacity-50"
                      >
                        <Plus className="w-3 h-3" />
                        Add Key
                      </button>
                    </div>

                    <div className="flex-1 overflow-y-auto space-y-2 pr-1 max-h-[240px]">
                      {Object.keys(vmInputVars).length === 0 ? (
                        <div className="text-center py-8 text-gray-400 text-[11px]">
                          No initial input variables configured.
                        </div>
                      ) : (
                        Object.keys(vmInputVars).map((k) => (
                          <div key={k} className="flex items-center gap-2">
                            <input
                              type="text"
                              value={k}
                              onChange={(e) => {
                                const newKey = e.target.value.replace(/[^a-zA-Z0-9_]/g, '');
                                if (newKey !== k) {
                                  const { [k]: val, ...rest } = vmInputVars;
                                  setVmInputVars({ ...rest, [newKey]: val });
                                }
                              }}
                              placeholder="variable_name"
                              disabled={vmStatus === 'running' || vmStatus === 'paused'}
                              className="w-1/3 bg-slate-50 border border-gray-250 rounded-lg px-2 py-1 text-[11px] font-mono font-bold focus:outline-none focus:ring-1 focus:ring-emerald-500 focus:bg-white disabled:opacity-60"
                            />
                            <input
                              type="text"
                              value={
                                typeof vmInputVars[k] === 'object'
                                  ? JSON.stringify(vmInputVars[k])
                                  : String(vmInputVars[k])
                              }
                              onChange={(e) => {
                                const raw = e.target.value;
                                let parsed: any = raw;
                                if (raw === 'true') parsed = true;
                                else if (raw === 'false') parsed = false;
                                else if (!isNaN(Number(raw)) && raw !== '') parsed = Number(raw);
                                else {
                                  try {
                                    if (raw.startsWith('[') || raw.startsWith('{')) {
                                      parsed = JSON.parse(raw);
                                    }
                                  } catch (_) {}
                                }
                                setVmInputVars((prev) => ({ ...prev, [k]: parsed }));
                              }}
                              placeholder="Value (string, number, list...)"
                              disabled={vmStatus === 'running' || vmStatus === 'paused'}
                              className="flex-1 bg-slate-50 border border-gray-250 rounded-lg px-2 py-1 text-[11px] font-mono focus:outline-none focus:ring-1 focus:ring-emerald-500 focus:bg-white disabled:opacity-60"
                            />
                            <button
                              type="button"
                              onClick={() => {
                                const { [k]: _, ...rest } = vmInputVars;
                                setVmInputVars(rest);
                              }}
                              disabled={vmStatus === 'running' || vmStatus === 'paused'}
                              className="p-1 rounded text-red-500 hover:bg-red-50 disabled:opacity-50 cursor-pointer"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        ))
                      )}
                    </div>
                  </div>
                </div>

                {/* Right Side: VM execution Console & Interactive Prompt (7 columns) */}
                <div className="lg:col-span-7 flex flex-col space-y-4">
                  {/* Trigger Action Box */}
                  <div className="bg-white border border-gray-150 p-4 rounded-xl shadow-xs flex items-center justify-between">
                    <div>
                      <div className="text-xs font-bold text-gray-800">Ready to execute in Goroutine pool?</div>
                      <p className="text-[10px] text-gray-400">Trigger standard binary compilation and WASM loop.</p>
                    </div>

                    <button
                      onClick={startVmExecution}
                      disabled={!vmRuleDetail || vmStatus === 'running' || vmStatus === 'paused'}
                      className="flex items-center gap-2 px-5 py-2.5 bg-emerald-600 hover:bg-emerald-700 disabled:bg-slate-200 text-white disabled:text-gray-400 border border-emerald-700 disabled:border-gray-200 rounded-xl text-xs font-bold shadow-md transition cursor-pointer disabled:cursor-not-allowed"
                    >
                      {vmStatus === 'running' || vmStatus === 'paused' ? (
                        <RefreshCw className="w-4 h-4 animate-spin animate-spin-slow" />
                      ) : (
                        <Play className="w-4 h-4 fill-current text-white shrink-0" />
                      )}
                      <span>
                        {vmStatus === 'idle'
                          ? 'Execute Go VM'
                          : vmStatus === 'completed' || vmStatus === 'failed'
                          ? 'Restart Execution'
                          : 'VM Processing...'}
                      </span>
                    </button>
                  </div>

                  {/* Status Indicator Bar */}
                  <div className="flex items-center justify-between px-2 text-[11px]">
                    <span className="text-gray-500 font-bold">GOROUTINE VM STATUS</span>
                    <div className="flex items-center gap-1.5">
                      <span className={`w-2 h-2 rounded-full ${
                        vmStatus === 'idle' ? 'bg-gray-400' :
                        vmStatus === 'compiling' ? 'bg-amber-400 animate-pulse' :
                        vmStatus === 'running' ? 'bg-emerald-400 animate-ping' :
                        vmStatus === 'paused' ? 'bg-pink-400 animate-pulse' :
                        vmStatus === 'completed' ? 'bg-emerald-500' : 'bg-red-500'
                      }`} />
                      <span className="font-bold text-gray-700 uppercase font-mono">
                        {vmStatus}
                      </span>
                    </div>
                  </div>

                  {/* Dynamic interactive Prompt suspension overlay */}
                  {vmStatus === 'paused' && vmActivePrompt && (
                    <motion.div
                      initial={{ scale: 0.98, opacity: 0 }}
                      animate={{ scale: 1, opacity: 1 }}
                      className="p-4 bg-gradient-to-br from-pink-50 to-rose-50 border border-pink-200 rounded-xl space-y-3 shadow-md"
                    >
                      <div className="flex items-start gap-2.5">
                        <div className="p-1.5 bg-pink-500 text-white rounded-lg animate-bounce">
                          <Terminal className="w-4 h-4" />
                        </div>
                        <div className="space-y-1">
                          <div className="text-xs font-bold text-pink-900">
                            VM Suspended: Channel input request detected
                          </div>
                          <p className="text-[11px] text-pink-700 leading-relaxed">
                            {vmActivePrompt.message}
                          </p>
                        </div>
                      </div>

                      <div className="flex items-center gap-2">
                        {vmActivePrompt.type === 'getkey' ? (
                          <div className="flex-1 flex gap-2">
                            {['Enter', 'KeyA', 'KeyS', 'Space', 'Escape'].map((k) => (
                              <button
                                key={k}
                                type="button"
                                onClick={() => vmActivePrompt.resolve(k)}
                                className="px-3 py-1.5 bg-white hover:bg-pink-100 border border-pink-200 text-pink-700 text-[10px] font-mono font-bold rounded-lg cursor-pointer transition"
                              >
                                {k}
                              </button>
                            ))}
                          </div>
                        ) : (
                          <>
                            <input
                              type="text"
                              value={vmPromptInput}
                              onChange={(e) => setVmPromptInput(e.target.value)}
                              onKeyDown={(e) => {
                                if (e.key === 'Enter') {
                                  vmActivePrompt.resolve(vmPromptInput);
                                }
                              }}
                              placeholder={`Enter value for: ${vmActivePrompt.variable}`}
                              autoFocus
                              className="flex-1 bg-white border border-pink-300 rounded-xl px-3 py-1.5 text-xs font-mono focus:outline-none focus:ring-1 focus:ring-pink-500"
                            />
                            <button
                              type="button"
                              onClick={() => vmActivePrompt.resolve(vmPromptInput)}
                              className="px-4 py-1.5 bg-pink-600 hover:bg-pink-700 text-white font-bold text-xs rounded-xl transition cursor-pointer"
                            >
                              Submit to VM
                            </button>
                          </>
                        )}
                      </div>
                    </motion.div>
                  )}

                  {/* Terminal Logs View */}
                  <div className="flex-1 flex flex-col min-h-[160px] bg-slate-950 text-slate-100 rounded-2xl overflow-hidden shadow-inner border border-slate-900">
                    <div className="bg-slate-900/50 px-4 py-2 border-b border-slate-900 flex items-center justify-between text-[10px] font-mono text-slate-400">
                      <div className="flex items-center gap-1.5">
                        <Terminal className="w-3.5 h-3.5 text-emerald-500" />
                        <span>Go Worker VM Logs Console</span>
                      </div>
                      <span>Stdout/Stderr</span>
                    </div>

                    <div className="flex-1 p-4 overflow-y-auto font-mono text-[11px] leading-relaxed space-y-1.5">
                      {vmLogs.length === 0 ? (
                        <div className="text-slate-500 text-center py-12 italic">
                          Console idle. Click "Execute Go VM" to run selected Booklet Policy.
                        </div>
                      ) : (
                        vmLogs.map((log, idx) => {
                          let color = 'text-slate-300';
                          if (log.includes('[Go Compiler]')) color = 'text-amber-400';
                          else if (log.includes('[System]') || log.includes('[Go Engine]')) color = 'text-emerald-400 font-semibold';
                          else if (log.includes('[ValidationError]')) color = 'text-rose-400 font-semibold';
                          else if (log.includes('[Go VM Thread') || log.includes('[Prompt Required]')) color = 'text-pink-400';
                          else if (log.includes('[Log]')) color = 'text-cyan-300';
                          else if (log.includes('[Assign]')) color = 'text-teal-300';
                          else if (log.includes('[Jump]')) color = 'text-indigo-300';

                          return (
                            <div key={idx} className={`${color} break-all border-l-2 border-transparent hover:border-slate-800 pl-1.5`}>
                              {log}
                            </div>
                          );
                        })
                      )}
                    </div>
                  </div>

                  {/* Trace Navigation & Variable Snapshots */}
                  {vmTrace.length > 0 && (
                    <div className="bg-white border border-gray-150 rounded-xl p-4 shadow-xs space-y-3">
                      <div className="flex items-center justify-between">
                        <h4 className="text-[11px] font-bold text-gray-500 uppercase tracking-wider">
                          VM Ticks Trace Visualization ({vmTrace.length} Steps)
                        </h4>
                        <span className="text-[10px] text-gray-400 font-mono font-bold">
                          Step {vmActiveTraceStep + 1} / {vmTrace.length}
                        </span>
                      </div>

                      {/* Slider Navigation */}
                      <div className="flex items-center gap-3">
                        <button
                          type="button"
                          disabled={vmActiveTraceStep <= 0}
                          onClick={() => setVmActiveTraceStep((p) => Math.max(0, p - 1))}
                          className="p-1 rounded hover:bg-slate-100 disabled:opacity-40 cursor-pointer text-gray-600"
                        >
                          <ChevronLeft className="w-4 h-4" />
                        </button>
                        <input
                          type="range"
                          min={0}
                          max={vmTrace.length - 1}
                          value={vmActiveTraceStep}
                          onChange={(e) => setVmActiveTraceStep(Number(e.target.value))}
                          className="flex-1 accent-emerald-600 h-1.5 bg-slate-150 rounded-lg cursor-pointer"
                        />
                        <button
                          type="button"
                          disabled={vmActiveTraceStep >= vmTrace.length - 1}
                          onClick={() => setVmActiveTraceStep((p) => Math.min(vmTrace.length - 1, p + 1))}
                          className="p-1 rounded hover:bg-slate-100 disabled:opacity-40 cursor-pointer text-gray-600"
                        >
                          <ChevronRight className="w-4 h-4" />
                        </button>
                      </div>

                      {/* Active Trace Step Inspection */}
                      {vmActiveTraceStep >= 0 && vmTrace[vmActiveTraceStep] && (
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-3 pt-1 border-t border-slate-100">
                          {/* Step description */}
                          <div className="space-y-1.5 bg-slate-50 p-2.5 rounded-lg border border-slate-100">
                            <div className="text-[10px] font-bold text-slate-400 uppercase font-mono">
                              Step {vmActiveTraceStep + 1} Action
                            </div>
                            <div className="text-xs font-bold text-slate-800 leading-relaxed flex items-center gap-2">
                              <span className="px-1.5 py-0.5 bg-slate-200 text-slate-600 rounded text-[9px] uppercase font-mono">
                                {vmTrace[vmActiveTraceStep].nodeType}
                              </span>
                              <span className="truncate">
                                {vmTrace[vmActiveTraceStep].description}
                              </span>
                            </div>
                          </div>

                          {/* Variable state snapshot */}
                          <div className="space-y-1.5 bg-slate-50 p-2.5 rounded-lg border border-slate-100 flex flex-col max-h-[140px] overflow-hidden">
                            <div className="text-[10px] font-bold text-slate-400 uppercase font-mono">
                              Variable State Snapshot
                            </div>
                            <div className="flex-1 overflow-y-auto text-[10px] font-mono text-slate-600 space-y-1">
                              {Object.keys(vmTrace[vmActiveTraceStep].variableSnapshot || {}).length === 0 ? (
                                <div className="text-slate-400 italic">No variables in state context.</div>
                              ) : (
                                Object.entries(vmTrace[vmActiveTraceStep].variableSnapshot).map(([k, v]) => (
                                  <div key={k} className="flex justify-between border-b border-dashed border-slate-100 py-0.5">
                                    <span className="text-slate-800 font-bold">{k}:</span>
                                    <span>{typeof v === 'object' ? JSON.stringify(v) : String(v)}</span>
                                  </div>
                                ))
                              )}
                            </div>
                          </div>
                        </div>
                      )}
                    </div>
                  )}

                </div>
              </div>

              {/* Modal Footer */}
              <div className="bg-slate-50 px-6 py-4 border-t border-gray-150 flex items-center justify-between text-[11px] text-gray-500 font-mono">
                <span>Go compiler targeting binary format: BPLG version 1</span>
                <span>Active Core Thread: Background Service Worker</span>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* 4. CREATION WIZARD MODAL (Ask Option Import old .bpl file OR Start Scratch) */}
      <AnimatePresence>
        {isNewRuleWizardOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            {/* Backdrop */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={closeNewRuleWizard}
              className="absolute inset-0 bg-slate-900/60 backdrop-blur-xs"
            />

            {/* Modal Box */}
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 15 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 15 }}
              className="relative w-full max-w-lg bg-white border border-gray-150 rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]"
            >
              {/* Modal Header */}
              <div className="bg-gradient-to-r from-indigo-600 to-indigo-700 text-white px-6 py-4 flex items-center justify-between">
                <div className="flex items-center gap-2.5">
                  <div className="p-1 bg-white/10 rounded-lg">
                    <Database className="w-4 h-4 text-indigo-200" />
                  </div>
                  <div>
                    <h3 className="text-sm font-bold tracking-tight">Policy Rule Wizard</h3>
                    <p className="text-[10px] text-indigo-200/80">Integrate rules securely into database</p>
                  </div>
                </div>
                <button
                  onClick={closeNewRuleWizard}
                  className="p-1 rounded-lg hover:bg-white/10 text-white/80 hover:text-white transition cursor-pointer"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              {/* Modal Wizard Screens */}
              <div className="p-6 overflow-y-auto space-y-5">
                
                {/* SCREEN 1: CHOICE DECISION CARD SELECTION */}
                {wizardStep === 'choice' && (
                  <div className="space-y-4">
                    <div className="text-center">
                      <span className="text-xs font-bold text-gray-700">How would you like to build this policy?</span>
                      <p className="text-[11px] text-gray-400 mt-1">Choose starting from scratch or upload older .bpl source files.</p>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      {/* Scratch Card */}
                      <div 
                        onClick={() => setWizardStep('scratch')}
                        className="p-5 border-2 border-gray-200 hover:border-indigo-500 hover:bg-slate-50/50 rounded-xl text-center cursor-pointer transition group"
                      >
                        <div className="p-3 bg-indigo-50 group-hover:bg-indigo-100 rounded-2xl text-indigo-600 inline-block mb-3 transition">
                          <Plus className="w-6 h-6" />
                        </div>
                        <h4 className="font-bold text-gray-900 text-xs">Start New (From Scratch)</h4>
                        <p className="text-[10px] text-gray-400 mt-1">Create baseline script template variables and start writing.</p>
                      </div>

                      {/* Import BPL Card */}
                      <div 
                        onClick={() => setWizardStep('import')}
                        className="p-5 border-2 border-gray-200 hover:border-indigo-500 hover:bg-slate-50/50 rounded-xl text-center cursor-pointer transition group"
                      >
                        <div className="p-3 bg-emerald-50 group-hover:bg-emerald-100 rounded-2xl text-emerald-600 inline-block mb-3 transition">
                          <Upload className="w-6 h-6" />
                        </div>
                        <h4 className="font-bold text-gray-900 text-xs">Import Old .bpl File</h4>
                        <p className="text-[10px] text-gray-400 mt-1">Upload existing .bpl script file or paste policy code segment.</p>
                      </div>
                    </div>
                  </div>
                )}

                {/* SCREEN 2: FROM SCRATCH DETAILS */}
                {wizardStep === 'scratch' && (
                  <div className="space-y-4">
                    <div className="flex items-center gap-1.5 text-xs text-indigo-600 font-bold cursor-pointer" onClick={() => setWizardStep('choice')}>
                      <ChevronLeft className="w-4 h-4" /> Change Creation Method
                    </div>

                    <div className="space-y-3.5">
                      <div className="space-y-1">
                        <label className="text-[10px] font-bold text-gray-400 uppercase tracking-wider block">Rule Script Name *</label>
                        <input
                          type="text"
                          value={wizardName}
                          onChange={(e) => setWizardName(e.target.value)}
                          placeholder="e.g. Credit Score Validation Policy"
                          className="w-full px-3.5 py-2 border border-gray-200 rounded-xl text-xs font-semibold focus:outline-none"
                          autoFocus
                        />
                      </div>

                      <div className="space-y-1">
                        <label className="text-[10px] font-bold text-gray-400 uppercase tracking-wider block">Description / Purpose</label>
                        <textarea
                          value={wizardDesc}
                          onChange={(e) => setWizardDesc(e.target.value)}
                          placeholder="Evaluate loan requests against applicant parameters..."
                          className="w-full h-20 px-3.5 py-2 border border-gray-200 rounded-xl text-xs font-semibold focus:outline-none"
                        />
                      </div>

                      <div className="space-y-1">
                        <label className="text-[10px] font-bold text-gray-400 uppercase tracking-wider block">Classification Category</label>
                        <select
                          value={wizardCategory}
                          onChange={(e) => setWizardCategory(e.target.value)}
                          className="w-full px-3 py-2 border border-gray-200 rounded-xl text-xs font-semibold focus:outline-none"
                        >
                          <option value="Financial">Financial Policy</option>
                          <option value="Healthcare">Healthcare Protocol</option>
                          <option value="Insurance">Insurance Underwriting</option>
                          <option value="Logistics">Logistics / Operations</option>
                          <option value="Security">Security Constraints</option>
                        </select>
                      </div>
                    </div>
                  </div>
                )}

                {/* SCREEN 3: IMPORT OLD BPL FILE */}
                {wizardStep === 'import' && (
                  <div className="space-y-4">
                    <div className="flex items-center gap-1.5 text-xs text-indigo-600 font-bold cursor-pointer" onClick={() => setWizardStep('choice')}>
                      <ChevronLeft className="w-4 h-4" /> Change Creation Method
                    </div>

                    <div className="space-y-3.5">
                      <div className="grid grid-cols-2 gap-3">
                        <div className="space-y-1">
                          <label className="text-[10px] font-bold text-gray-400 uppercase tracking-wider block">Policy Name *</label>
                          <input
                            type="text"
                            value={wizardName}
                            onChange={(e) => setWizardName(e.target.value)}
                            placeholder="Imported policy name"
                            className="w-full px-3 py-1.5 border border-gray-200 rounded-xl text-xs font-semibold focus:outline-none"
                          />
                        </div>

                        <div className="space-y-1">
                          <label className="text-[10px] font-bold text-gray-400 uppercase tracking-wider block">Classification</label>
                          <select
                            value={wizardCategory}
                            onChange={(e) => setWizardCategory(e.target.value)}
                            className="w-full px-3 py-1.5 border border-gray-200 rounded-xl text-xs font-semibold focus:outline-none"
                          >
                            <option value="Financial">Financial Policy</option>
                            <option value="Healthcare">Healthcare Protocol</option>
                            <option value="Insurance">Insurance Underwriting</option>
                            <option value="Logistics">Logistics / Operations</option>
                            <option value="Security">Security Constraints</option>
                          </select>
                        </div>
                      </div>

                      {/* Drag & Drop BPL file */}
                      <div
                        onDragEnter={handleDrag}
                        onDragOver={handleDrag}
                        onDragLeave={handleDrag}
                        onDrop={handleDrop}
                        className={`relative border-2 border-dashed rounded-xl p-4 text-center transition flex flex-col items-center justify-center cursor-pointer ${
                          dragActive
                            ? 'border-indigo-500 bg-indigo-50/40'
                            : 'border-gray-250 hover:border-indigo-400 bg-slate-50/50 hover:bg-white'
                        }`}
                      >
                        <input
                          type="file"
                          accept=".bpl,.txt"
                          className="absolute inset-0 opacity-0 cursor-pointer"
                          onChange={handleFileChange}
                        />
                        <Upload className="w-6 h-6 text-indigo-500 mb-1" />
                        <span className="text-[11px] font-bold text-slate-700 block">Drag & drop your old BPL file here</span>
                        <span className="text-[9px] text-gray-400">or click to browse local files</span>
                      </div>

                      {/* Paste area */}
                      <div className="space-y-1">
                        <label className="text-[10px] font-bold text-gray-400 uppercase tracking-wider block">Or Paste Raw BPL Source Code</label>
                        <textarea
                          value={wizardPasteCode}
                          onChange={(e) => setWizardPasteCode(e.target.value)}
                          placeholder={`script "My Old Policy"\n{\n  log "Evaluating legacy parameters"\n  assign "Verified" to status\n}`}
                          className="w-full h-32 px-3 py-2 border border-gray-200 rounded-xl text-xs font-mono focus:outline-none bg-slate-50/40 focus:bg-white"
                          spellCheck="false"
                        />
                      </div>
                    </div>
                  </div>
                )}

              </div>

              {/* Modal Footer */}
              <div className="px-6 py-4 bg-gray-50 border-t border-gray-150 flex items-center justify-end gap-3">
                <button
                  onClick={closeNewRuleWizard}
                  className="px-4 py-2 border border-gray-200 rounded-xl text-xs font-bold text-gray-600 hover:bg-gray-100 transition cursor-pointer"
                >
                  Cancel
                </button>

                {wizardStep === 'scratch' && (
                  <button
                    disabled={!wizardName.trim() || isApiLoading}
                    onClick={handleWizardScratchSubmit}
                    className={`px-4 py-2 rounded-xl text-xs font-bold shadow-sm transition flex items-center gap-1.5 cursor-pointer ${
                      wizardName.trim() && !isApiLoading
                        ? 'bg-indigo-600 text-white hover:bg-indigo-700'
                        : 'bg-gray-200 text-gray-400 cursor-not-allowed'
                    }`}
                  >
                    Create Baseline
                  </button>
                )}

                {wizardStep === 'import' && (
                  <button
                    disabled={!wizardName.trim() || !wizardPasteCode.trim() || isApiLoading}
                    onClick={handleWizardImportSubmit}
                    className={`px-4 py-2 rounded-xl text-xs font-bold shadow-sm transition flex items-center gap-1.5 cursor-pointer ${
                      wizardName.trim() && wizardPasteCode.trim() && !isApiLoading
                        ? 'bg-indigo-600 text-white hover:bg-indigo-700'
                        : 'bg-gray-200 text-gray-400 cursor-not-allowed'
                    }`}
                  >
                    Compile & Import
                  </button>
                )}
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* 5. LEGACY BPL IMPORTER MODAL */}
      <AnimatePresence>
        {isLegacyImporterOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            {/* Backdrop */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsLegacyImporterOpen(false)}
              className="absolute inset-0 bg-slate-900/60 backdrop-blur-xs"
            />

            {/* Modal Box */}
            <motion.div
              initial={{ opacity: 0, scale: 0.97, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.97, y: 20 }}
              className="relative bg-white border border-gray-250 rounded-2xl shadow-2xl w-full max-w-[96vw] xl:max-w-7xl h-[92vh] md:h-[88vh] lg:h-[90vh] overflow-hidden flex flex-col z-10"
            >
              {/* Modal Header */}
              <div className="bg-white border-b border-gray-200 px-6 py-4 flex items-center justify-between shrink-0">
                <div className="flex items-center gap-2.5">
                  <Cpu className="w-5 h-5 text-indigo-600" />
                  <div>
                    <h3 className="text-sm font-bold tracking-tight text-gray-950">Legacy BPL Importer & Syntax Compiler</h3>
                    <p className="text-[10px] text-gray-500">Validate code syntax in real-time and convert to visual flows instantly</p>
                  </div>
                </div>
                <button
                  onClick={() => setIsLegacyImporterOpen(false)}
                  className="p-1.5 rounded-lg hover:bg-gray-100 text-gray-400 hover:text-gray-700 transition cursor-pointer"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              {/* Modal Content */}
              <div className="p-6 flex-1 overflow-hidden grid grid-cols-1 lg:grid-cols-12 gap-6 min-h-0">
                {/* Left Side: Inputs and Dark Code Editor Area (Col Span 7) */}
                <div className="lg:col-span-7 flex flex-col h-full overflow-hidden space-y-4 min-h-0">
                  {isOverwritingActiveRule ? (
                    <div className="bg-indigo-50/75 border border-indigo-100 rounded-xl p-4 text-xs space-y-1 shrink-0">
                      <div className="flex items-center gap-1.5 font-bold text-indigo-900">
                        <AlertTriangle className="w-4 h-4 text-indigo-600" />
                        <span>Replacing Active Rule Flow</span>
                      </div>
                      <p className="text-gray-650 leading-relaxed text-[11px]">
                        You are pasting legacy code to replace the visual flow of <strong className="text-indigo-950 font-bold">"{ruleMetaName}"</strong>. Saving will overwrite its active syntax and automatically redraw all nodes.
                      </p>
                    </div>
                  ) : (
                    <div className="grid grid-cols-1 sm:grid-cols-12 gap-4 shrink-0">
                      <div className="sm:col-span-8 space-y-1">
                        <label className="text-[10px] font-bold text-gray-400 uppercase tracking-wider block">Policy Name *</label>
                        <input
                          type="text"
                          value={importerName}
                          onChange={(e) => setImporterName(e.target.value)}
                          placeholder="e.g. Legacy Credit Verification Policy"
                          className="w-full px-3.5 py-2 bg-white border border-gray-200 rounded-xl text-xs font-semibold text-gray-800 focus:outline-none focus:ring-1 focus:ring-indigo-500/50 focus:border-indigo-500 transition"
                        />
                      </div>
                      <div className="sm:col-span-4 space-y-1">
                        <label className="text-[10px] font-bold text-gray-400 uppercase tracking-wider block">Category</label>
                        <select
                          value={importerCategory}
                          onChange={(e) => setImporterCategory(e.target.value)}
                          className="w-full px-3.5 py-2 bg-white border border-gray-200 rounded-xl text-xs font-semibold text-gray-800 focus:outline-none focus:ring-1 focus:ring-indigo-500/50 focus:border-indigo-500 transition"
                        >
                          <option value="Financial">Financial Policy</option>
                          <option value="Healthcare">Healthcare Protocol</option>
                          <option value="Insurance">Insurance Underwriting</option>
                          <option value="Logistics">Logistics / Operations</option>
                          <option value="Security">Security Constraints</option>
                        </select>
                      </div>
                      <div className="sm:col-span-12 space-y-1">
                        <label className="text-[10px] font-bold text-gray-400 uppercase tracking-wider block">Description / Context</label>
                        <input
                          type="text"
                          value={importerDesc}
                          onChange={(e) => setImporterDesc(e.target.value)}
                          placeholder="Provide context or description for this imported BPL script"
                          className="w-full px-3.5 py-2 bg-white border border-gray-200 rounded-xl text-xs font-semibold text-gray-800 focus:outline-none focus:ring-1 focus:ring-indigo-500/50 focus:border-indigo-500 transition"
                        />
                      </div>
                    </div>
                  )}

                  {/* Code Input Field Area */}
                  <div className="flex-1 flex flex-col space-y-2 overflow-hidden min-h-0">
                    <div className="flex items-center justify-between shrink-0">
                      <label className="text-[10px] font-bold text-gray-400 uppercase tracking-wider block">
                        BPL Source Code Editor
                      </label>
                      
                      {/* Templates shortcuts */}
                      <div className="flex items-center gap-2">
                        <span className="text-[9px] text-gray-400 font-bold uppercase tracking-wider">Load Sample:</span>
                        <button
                          type="button"
                          onClick={() => handleImporterCodeChange(
`script "Simple Loan Checker"
{
  log "Initializing loan score check"
  assign 720 to credit_score
  if (credit_score >= 700)
  {
    log "Excellent score! Standard loan pre-approved."
    assign "Approved" to status
  }
  else
  {
    log "Score below threshold. Checking manual overrides."
    assign "UnderReview" to status
  }
}`
                          )}
                          className="px-2.5 py-1 bg-gray-50 hover:bg-gray-100 border border-gray-200 rounded text-[10px] font-mono text-gray-600 transition cursor-pointer"
                        >
                          Checker
                        </button>
                        <button
                          type="button"
                          onClick={() => handleImporterCodeChange(
`script "Risk Evaluation"
{
  log "Starting risk analysis"
  assign "high" to account_tier
  
  if (account_tier == "high")
  {
    assign 0.05 to interest_rate
    log "Assigned premium tier interest rate"
  }
  else if (account_tier == "medium")
  {
    assign 0.08 to interest_rate
  }
  else
  {
    assign 0.12 to interest_rate
    log "Assigned standard high risk tier rate"
  }
  
  validate (interest_rate <= 0.10) or_error "Interest rate exceeds limits"
}`
                          )}
                          className="px-2.5 py-1 bg-gray-50 hover:bg-gray-100 border border-gray-200 rounded text-[10px] font-mono text-gray-600 transition cursor-pointer"
                        >
                          Risk Analysis
                        </button>
                      </div>
                    </div>

                    {/* Custom Dark Theme IDE Code Editor with Drag-and-Drop + File Upload */}
                    <div
                      onDragEnter={handleImporterDrag}
                      onDragOver={handleImporterDrag}
                      onDragLeave={handleImporterDrag}
                      onDrop={handleImporterDrop}
                      className="flex-1 min-h-0 rounded-xl bg-[#090D16] border border-slate-800/80 flex flex-col overflow-hidden shadow-inner relative group"
                    >
                      {/* Editor Sub-Header / Info Bar */}
                      <div className="bg-[#0e1422] border-b border-slate-800/60 px-4 py-2 flex items-center justify-between text-[10px] font-mono text-slate-400 select-none shrink-0">
                        <div className="flex items-center gap-1.5">
                          <span className="w-1.5 h-1.5 rounded-full bg-indigo-500 animate-pulse"></span>
                          <span>• BOOKLET POLICY LANGUAGE (BPL) EDITOR</span>
                        </div>
                        <div className="flex items-center gap-3">
                          <label
                            htmlFor="importer-file-uploader"
                            className="flex items-center gap-1 bg-indigo-950/50 hover:bg-indigo-900 border border-indigo-900/60 hover:border-indigo-800 text-indigo-300 hover:text-indigo-200 px-2.5 py-0.5 rounded cursor-pointer transition text-[9px] font-bold uppercase tracking-wide shrink-0"
                          >
                            <Upload className="w-3 h-3" />
                            <span>Upload BPL File</span>
                          </label>
                          <input
                            type="file"
                            id="importer-file-uploader"
                            accept=".bpl,.txt"
                            onChange={(e) => {
                              if (e.target.files && e.target.files[0]) {
                                handleImporterFileUpload(e.target.files[0]);
                              }
                              e.target.value = '';
                            }}
                            className="hidden"
                          />
                          <span>Lines: {Math.max(1, importerPasteCode.split('\n').length)}</span>
                          <span>Chars: {importerPasteCode.length}</span>
                        </div>
                      </div>

                      {/* Editor Canvas Gutter + Area */}
                      <div className="flex-1 flex overflow-hidden min-h-0 relative">
                        {/* Gutter Line Numbers */}
                        <div
                          ref={importerGutterRef}
                          className="bg-[#05080e] border-r border-slate-800/60 text-slate-600 text-right pr-3 pl-4 select-none py-4 overflow-hidden font-mono text-[11px] leading-5 shrink-0"
                          style={{ pointerEvents: 'none' }}
                        >
                          {Array.from({ length: Math.max(1, importerPasteCode.split('\n').length) }).map((_, idx) => (
                            <div key={idx}>{idx + 1}</div>
                          ))}
                        </div>

                        {/* Textarea */}
                        <textarea
                          value={importerPasteCode}
                          onChange={(e) => handleImporterCodeChange(e.target.value)}
                          onScroll={(e) => {
                            if (importerGutterRef.current) {
                              importerGutterRef.current.scrollTop = e.currentTarget.scrollTop;
                            }
                          }}
                          placeholder={`script "My Old Policy"\n{\n  log "Evaluating legacy parameters"\n  assign "Verified" to status\n}`}
                          className="flex-1 bg-transparent text-[#e4e7eb] font-mono text-xs focus:outline-none resize-none leading-5 w-full h-full py-4 px-4 selection:bg-indigo-500/40 overflow-auto outline-none scrollbar-thin scrollbar-thumb-slate-800/80 scrollbar-track-transparent"
                          spellCheck="false"
                        />
                      </div>

                      {/* Gorgeous drag & drop hover indicator overlay */}
                      {importerDragActive && (
                        <div
                          className="absolute inset-0 bg-slate-950/95 z-20 flex flex-col items-center justify-center border-2 border-dashed border-indigo-500 rounded-xl m-1.5 text-center backdrop-blur-xs transition-all"
                        >
                          <div className="p-4 bg-indigo-950/50 rounded-full border border-indigo-500/30 mb-3 animate-bounce">
                            <Upload className="w-8 h-8 text-indigo-400" />
                          </div>
                          <p className="text-xs font-bold text-indigo-100 uppercase tracking-wide">Drop legacy file here to import</p>
                          <p className="text-[10px] text-slate-400 mt-1.5 max-w-[200px] leading-relaxed">
                            Release to instantly parse, validate syntax, and draw the visual rule nodes
                          </p>
                        </div>
                      )}
                    </div>
                  </div>
                </div>

                {/* Right Side: Compiler Diagnostics & Live Stats (Col Span 5) */}
                <div className="lg:col-span-5 bg-slate-50 border border-gray-200 rounded-2xl p-6 flex flex-col h-full overflow-y-auto space-y-5 min-h-0">
                  <div className="shrink-0">
                    <h4 className="text-[10px] font-bold text-slate-500 uppercase tracking-wider">Compiler Diagnostics</h4>
                    <p className="text-[11px] text-gray-450 mt-0.5">Real-time parser feedback and statement visualization</p>
                  </div>

                  <div className="flex-1 flex flex-col justify-center min-h-0">
                    {!importerPasteCode.trim() ? (
                      <div className="text-center py-12 px-4 space-y-3">
                        <Terminal className="w-8 h-8 text-gray-300 mx-auto animate-pulse" />
                        <span className="text-[11px] font-bold text-slate-600 block">Waiting for BPL source code</span>
                        <p className="text-[10px] text-gray-400 leading-relaxed max-w-xs mx-auto">
                          Paste legacy Booklet Policy Language (BPL) rules in the dark editor or select a sample template above to begin.
                        </p>
                      </div>
                    ) : !importerIsValid ? (
                      <div className="bg-rose-50 border border-rose-100 rounded-xl p-5 space-y-4 text-left">
                        <div className="flex items-center gap-1.5 text-rose-800 font-bold text-xs">
                          <AlertTriangle className="w-4 h-4 text-rose-600" />
                          <span>Syntax Validation Failed</span>
                        </div>
                        <div className="space-y-2 text-[11px] text-rose-750 font-medium max-h-[220px] overflow-y-auto pr-1">
                          {importerErrors.map((err, i) => (
                            <div key={i} className="border-l-2 border-rose-400 pl-3 py-1.5 bg-rose-50/50 rounded-r text-left leading-relaxed">
                              <span className="font-bold text-rose-800">Line {err.line}, Col {err.column}:</span> {err.message}
                            </div>
                          ))}
                        </div>
                        <p className="text-[10px] text-gray-400 leading-relaxed pt-3 border-t border-rose-100/50 text-left">
                          BPL statements must be wrapped in a main "script Name" block. Ensure all parentheses, braces, and string quotes are closed properly.
                        </p>
                      </div>
                    ) : (
                      <div className="space-y-5 text-left h-full flex flex-col justify-start">
                        {/* Compiled successfully card */}
                        <div className="bg-emerald-50 border border-emerald-100 rounded-xl p-4 flex items-start gap-3.5 text-left shrink-0">
                          <CheckCircle className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
                          <div>
                            <span className="text-xs font-bold text-emerald-800 block">Syntax Validated Successfully!</span>
                            <span className="text-[10px] text-emerald-600 font-medium leading-normal">Ready to convert and generate interactive visual flow canvas.</span>
                          </div>
                        </div>

                        {/* Compiler statistics / metrics */}
                        {getImporterMetrics() && (
                          <div className="bg-white border border-gray-200 rounded-xl p-5 space-y-4 shadow-sm flex-1 overflow-y-auto">
                            <span className="text-[10px] font-bold text-slate-450 uppercase tracking-wider block">Flow Canvas Mapping Metrics</span>
                            
                            <div className="grid grid-cols-2 gap-3.5 text-[11px]">
                              <div className="p-3 bg-slate-50 border border-gray-200/60 rounded-xl shadow-xs">
                                <span className="text-slate-400 block font-semibold text-[10px]">Total Nodes</span>
                                <strong className="text-slate-800 font-bold text-sm">{getImporterMetrics()?.total}</strong>
                              </div>
                              <div className="p-3 bg-slate-50 border border-gray-200/60 rounded-xl shadow-xs">
                                <span className="text-slate-400 block font-semibold text-[10px]">Conditionals (If)</span>
                                <strong className="text-indigo-600 font-bold text-sm">{getImporterMetrics()?.conditionals}</strong>
                              </div>
                              <div className="p-3 bg-slate-50 border border-gray-200/60 rounded-xl shadow-xs">
                                <span className="text-slate-400 block font-semibold text-[10px]">Assignments</span>
                                <strong className="text-slate-800 font-bold text-sm">{getImporterMetrics()?.assignments}</strong>
                              </div>
                              <div className="p-3 bg-slate-50 border border-gray-200/60 rounded-xl shadow-xs">
                                <span className="text-slate-400 block font-semibold text-[10px]">Terminal Logs</span>
                                <strong className="text-slate-800 font-bold text-sm">{getImporterMetrics()?.logs}</strong>
                              </div>
                            </div>

                            <div className="border-t border-gray-100 pt-4 space-y-2.5 text-[10px] text-slate-550 font-medium">
                              <span className="font-bold text-slate-600 block uppercase tracking-wider text-[9px]">Included Visual Node Generation:</span>
                              <div className="flex flex-wrap gap-1.5">
                                {getImporterMetrics()?.logs! > 0 && (
                                  <span className="px-2.5 py-1 bg-indigo-50 text-indigo-700 rounded-md border border-indigo-100 font-bold font-mono">
                                    {getImporterMetrics()?.logs} Logs
                                  </span>
                                )}
                                {getImporterMetrics()?.assignments! > 0 && (
                                  <span className="px-2.5 py-1 bg-slate-100 text-slate-700 rounded-md border border-slate-200 font-bold font-mono">
                                    {getImporterMetrics()?.assignments} State Vars
                                  </span>
                                )}
                                {getImporterMetrics()?.conditionals! > 0 && (
                                  <span className="px-2.5 py-1 bg-amber-50 text-amber-700 rounded-md border border-amber-100 font-bold font-mono">
                                    {getImporterMetrics()?.conditionals} Logic Decisions
                                  </span>
                                )}
                                {getImporterMetrics()?.validations! > 0 && (
                                  <span className="px-2.5 py-1 bg-emerald-50 text-emerald-700 rounded-md border border-emerald-100 font-bold font-mono">
                                    {getImporterMetrics()?.validations} Assertions
                                  </span>
                                )}
                                {getImporterMetrics()?.loops! > 0 && (
                                  <span className="px-2.5 py-1 bg-purple-50 text-purple-700 rounded-md border border-purple-100 font-bold font-mono">
                                    {getImporterMetrics()?.loops} Loops
                                  </span>
                                )}
                              </div>
                            </div>
                          </div>
                        )}
                      </div>
                    )}
                  </div>
                </div>
              </div>

              {/* Modal Footer */}
              <div className="px-6 py-4 bg-gray-50 border-t border-gray-200/80 flex items-center justify-end gap-3 shrink-0">
                <button
                  type="button"
                  onClick={() => setIsLegacyImporterOpen(false)}
                  className="px-4.5 py-2 border border-gray-200 text-gray-600 hover:bg-gray-100 rounded-xl text-xs font-bold transition cursor-pointer"
                >
                  Cancel
                </button>

                <button
                  disabled={!importerPasteCode.trim() || !importerIsValid || (!isOverwritingActiveRule && !importerName.trim()) || isApiLoading}
                  onClick={handleImporterSubmit}
                  className={`px-4.5 py-2 rounded-xl text-xs font-bold shadow-sm transition flex items-center gap-1.5 cursor-pointer ${
                    importerPasteCode.trim() && importerIsValid && (isOverwritingActiveRule || importerName.trim()) && !isApiLoading
                      ? 'bg-indigo-600 text-white hover:bg-indigo-700'
                      : 'bg-gray-100 text-gray-400 cursor-not-allowed border border-gray-200'
                  }`}
                >
                  {isApiLoading ? (
                    <span>Compiling...</span>
                  ) : isOverwritingActiveRule ? (
                    <>
                      <Check className="w-3.5 h-3.5" />
                      <span>Compile & Overwrite Flow</span>
                    </>
                  ) : (
                    <>
                      <Check className="w-3.5 h-3.5" />
                      <span>Compile & Convert to Flow</span>
                    </>
                  )}
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Action Notification Toast */}
      <AnimatePresence>
        {importNotification && (
          <motion.div
            initial={{ opacity: 0, y: 20, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 20, scale: 0.95 }}
            className="fixed bottom-6 right-6 z-50"
          >
            <div className={`flex items-center gap-3 px-4 py-3 rounded-xl border shadow-lg ${
              importNotification.type === 'success'
                ? 'bg-emerald-50 border-emerald-100 text-emerald-800'
                : 'bg-rose-50 border-rose-100 text-rose-800'
            }`}>
              {importNotification.type === 'success' ? (
                <CheckCircle className="w-4 h-4 text-emerald-600 shrink-0" />
              ) : (
                <AlertTriangle className="w-4 h-4 text-rose-600 shrink-0" />
              )}
              <div className="text-xs font-bold">
                {importNotification.message}
              </div>
              <button
                onClick={() => setImportNotification(null)}
                className="p-0.5 rounded hover:bg-white/50 transition shrink-0 ml-1 cursor-pointer"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
