/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import express from 'express';
import path from 'path';
import fs from 'fs';
import { createServer as createViteServer } from 'vite';
import { GoogleGenAI } from '@google/genai';
import dotenv from 'dotenv';
import { BplParser } from './src/utils/parser';
import { compileAstToBinary } from './src/utils/compiler';

dotenv.config();

const app = express();
app.use(express.json());

const PORT = 3000;

const RULES_FILE_PATH = path.join(process.cwd(), 'rules_store.json');

// Helper to load rules
function getStoredRules() {
  let rules: any[] = [];
  let isLoaded = false;
  try {
    if (fs.existsSync(RULES_FILE_PATH)) {
      const data = fs.readFileSync(RULES_FILE_PATH, 'utf8');
      rules = JSON.parse(data);
      isLoaded = true;
    }
  } catch (error) {
    console.error('Error reading rules from file:', error);
  }

  if (!isLoaded) {
    // Fallback / Initial seed rules
    const baseline = [
      {
        id: 'arizona-et',
        name: 'Arizona ET Notice Eligibility',
        description: 'The standard BPL script determining Booklet notice and Eligibility for the State of Arizona.',
        code: `script "ET FOR ARIZONA"
{
  log "Starting eligibility check for Arizona ET Notice..."
  
  if (medical equals "Y")
  {
    assign "Eligible" to status
    assign "Approved" to reason
    jumpto bottom
  }
  
  if (
    medical equals "N" AND
    drugs equals "N"
  )
  {
    log "Checking funding eligibility"
    if (
      funding equals "A" OR
      funding equals "E"
    )
    {
      include "book/az/etnotice/2a" send(company, age)
      assign "RequiresReview" to status
    }
    else
    {
      include "book/az/etnotice/5a"
      assign "Denied" to status
    }
  }
  else
  {
    assign "Ineligible" to status
    assign "HighRisk" to reason
  }

  bottom::
  log "Process completed. Status: "
}
`,
        defaultVariables: {
          medical: 'N',
          drugs: 'N',
          funding: 'A',
          company: 'ZubenAI Inc.',
          age: 28,
          status: 'Pending',
          reason: 'None',
        },
        createdAt: new Date().toISOString()
      },
      {
        id: 'claims-triage',
        name: 'Automated Claims Triage Policy',
        description: 'Routing insurance or claim events into FastTrack vs Manual Review based on risk and age.',
        code: `script "Claims Triage Script"
{
  log "Beginning Automated Claims Triage..."
  
  if (claimAmount greaterThan 5000)
  {
    log "High-value claim. Enforcing secondary validation."
    assign "SecondaryReview" to triageStatus
    
    if (hasSupportingDocs equals false)
    {
      validate claimAmount lessThan 10000 or_error "Missing documentation for extreme value claim"
    }
  }
  else
  {
    if (claimAgeDays greaterThan 30)
    {
      log "Delayed claim auto-approved to meet SLA."
      assign "AutoApproved" to triageStatus
    }
    else
    {
      assign "FastTrack" to triageStatus
    }
  }
}
`,
        defaultVariables: {
          claimAmount: 6200,
          hasSupportingDocs: false,
          claimAgeDays: 14,
          triageStatus: 'Unassigned'
        },
        createdAt: new Date().toISOString()
      }
    ];

    try {
      fs.writeFileSync(RULES_FILE_PATH, JSON.stringify(baseline, null, 2), 'utf8');
    } catch (err) {
      console.error('Failed to write seed rules:', err);
    }
    rules = baseline;
  }

  // Ensure all rules are migrated to contain AST + Compiled Binary and omit 'nodes' and raw 'code'
  let needsSave = false;
  const parser = new BplParser();
  rules.forEach((rule: any) => {
    // 1. If nodes list exists, delete it
    if ('nodes' in rule) {
      delete rule.nodes;
      needsSave = true;
    }

    // 2. If AST is missing, generate it from code
    if (!rule.ast && rule.code) {
      const { ast } = parser.parse(rule.code);
      if (ast) {
        rule.ast = ast;
        needsSave = true;
      }
    }

    // 3. If compiledBinary is missing and we have an AST, compile it
    if (!rule.compiledBinary && rule.ast) {
      try {
        rule.compiledBinary = compileAstToBinary(rule.ast);
        needsSave = true;
      } catch (e) {
        console.error('Failed to compile AST for rule during migration:', rule.id, e);
      }
    }

    // 4. Remove code since we now only serve AST & compiled binary (UI decompiles AST to code as needed)
    if ('code' in rule) {
      delete rule.code;
      needsSave = true;
    }
  });

  if (needsSave) {
    try {
      fs.writeFileSync(RULES_FILE_PATH, JSON.stringify(rules, null, 2), 'utf8');
    } catch (err) {
      console.error('Failed to save migrated rules:', err);
    }
  }

  return rules;
}

// Helper to save rules
function saveStoredRules(rules: any[]) {
  try {
    fs.writeFileSync(RULES_FILE_PATH, JSON.stringify(rules, null, 2), 'utf8');
  } catch (error) {
    console.error('Error saving rules to file:', error);
    throw new Error('Failed to save rules to disk');
  }
}

// Lazy initialize Gemini client to avoid crashes if API key is not yet set
let aiClient: GoogleGenAI | null = null;
function getGeminiClient() {
  if (!aiClient) {
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      throw new Error('GEMINI_API_KEY environment variable is required');
    }
    aiClient = new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        },
      },
    });
  }
  return aiClient;
}

// BPL Rules Assistant System prompt
const SYSTEM_INSTRUCTION = `You are an expert system and policy engineer specialized in Booklet Policy Language (BPL), an AST-based declarative rules engine syntax.
Your task is to help the user generate, explain, or optimize BPL scripts.

Format guidelines:
BPL scripts always follow this strict syntax pattern:
script "SCRIPT NAME"
{
  // comments
  log "Log message with \${variable} variable interpolation"
  assign "Value" to variable
  assign 100 to numericVariable
  
  if (condition operator value) {
    // block
  } else if (another condition) {
    // block
  } else {
    // block
  }
  
  include "book/fragment/path" send(variable1, variable2)
  import "another-script.bpl"
  jumpto labelName
  labelName::
  return
  
  // Modern engine enhancements:
  validate condition operator value or_error "Custom Error Message"
  call api "https://api.endpoint.com" send(param1) receive(responseVar)
  switch (switchVariable) {
    case "A": {
      // block
    }
    default: {
      // block
    }
  }
  loop over item in collection {
    // block
  }
}

Operators allowed in conditions:
- equals
- notEquals
- greaterThan
- lessThan
- greaterThanOrEqual
- lessThanOrEqual
- contains
- startsWith
- endsWith
- exists
- isEmpty

Keep scripts elegant and standard. Do not use generic programming languages like Javascript inside blocks, always output valid BPL syntax. When generating, ALWAYS output ONLY the raw BPL block (inside a markdown block or as text).`;

/**
 * Endpoint to generate a BPL script from user text
 */
app.post('/api/gemini/generate', async (req, res) => {
  try {
    const { prompt } = req.body;
    if (!prompt) {
      return res.status(400).json({ error: 'Prompt is required' });
    }

    const ai = getGeminiClient();
    const response = await ai.models.generateContent({
      model: 'gemini-3.5-flash',
      contents: `Translate the following natural language rule requirement into a clean, complete, and syntactically valid Booklet Policy Language (BPL) script. Include appropriate comments, logs, variables, and include statements.

Requirements:
${prompt}`,
      config: {
        systemInstruction: `${SYSTEM_INSTRUCTION}\nAlways return the compiled BPL code inside a single standard markdown code block \`\`\`bpl ... \`\`\``,
        temperature: 0.2,
      },
    });

    const text = response.text || '';
    // Extract the BPL block from the markdown
    const codeMatch = text.match(/```(?:bpl|json|text)?\n([\s\S]*?)\n```/) || text.match(/```([\s\S]*?)```/);
    const code = codeMatch ? codeMatch[1].trim() : text.trim();

    res.json({ code, rawResponse: text });
  } catch (error: any) {
    console.error('Gemini generate error:', error);
    res.status(500).json({ error: error.message || 'Failed to generate rules script' });
  }
});

/**
 * Endpoint to explain BPL rules
 */
app.post('/api/gemini/explain', async (req, res) => {
  try {
    const { bplCode } = req.body;
    if (!bplCode) {
      return res.status(400).json({ error: 'Bpl code is required' });
    }

    const ai = getGeminiClient();
    const response = await ai.models.generateContent({
      model: 'gemini-3.5-flash',
      contents: `Please explain this Booklet Policy Language (BPL) rules script in plain, clear, and professional language for a policy analyst. 
Highlight:
1. Its core objective
2. The key variable inputs and outputs (including assignments)
3. The decision trees / logical flows
4. Any document/template includes or integrations
5. Potential edge cases or assumptions

BPL Script:
${bplCode}`,
      config: {
        systemInstruction: SYSTEM_INSTRUCTION,
        temperature: 0.3,
      },
    });

    res.json({ explanation: response.text });
  } catch (error: any) {
    console.error('Gemini explain error:', error);
    res.status(500).json({ error: error.message || 'Failed to explain rules script' });
  }
});

/**
 * Endpoint to optimize BPL rules
 */
app.post('/api/gemini/optimize', async (req, res) => {
  try {
    const { bplCode } = req.body;
    if (!bplCode) {
      return res.status(400).json({ error: 'Bpl code is required' });
    }

    const ai = getGeminiClient();
    const response = await ai.models.generateContent({
      model: 'gemini-3.5-flash',
      contents: `Act as a policy quality auditor. Analyze the following Booklet Policy Language (BPL) script and recommend optimizations.
Check for:
1. Redundant condition branches or logic flaws
2. Variables that are read but never declared or set in assignments (missing context inputs)
3. Unreachable states or infinite loop possibilities
4. Modern rules engine improvements (suggest loops, validations, switches where appropriate)

BPL Script:
${bplCode}`,
      config: {
        systemInstruction: `${SYSTEM_INSTRUCTION}\nOutput your audit response in structured Markdown format, with a list of suggestions and, if applicable, an optimized BPL code block.`,
        temperature: 0.3,
      },
    });

    res.json({ optimization: response.text });
  } catch (error: any) {
    console.error('Gemini optimize error:', error);
    res.status(500).json({ error: error.message || 'Failed to optimize rules script' });
  }
});

// High-scale Virtual Rules engine to support 145,000+ rules dynamically
function getVirtualRules(search: string = '', page: number = 1, limit: number = 10, category: string = 'all') {
  const realRules = getStoredRules();
  
  const templates = [
    {
      prefix: 'Financial Policy',
      category: 'Financial',
      desc: 'Automated credit limit check and validation rules.',
      vars: { limit: 10000, creditScore: 720, income: 85000, authorized: false },
      code: (name: string) => `script "${name}"
{
  log "Evaluating financial eligibility for ${name}..."
  if (creditScore greaterThan 700 AND income greaterThan 50000)
  {
    assign true to authorized
    log "Credit authorization approved"
  }
  else
  {
    assign false to authorized
    log "Requires manual underwriting review"
  }
}`
    },
    {
      prefix: 'Healthcare Triage Protocol',
      category: 'Healthcare',
      desc: 'Check state eligibility for emergency or standard medical booklet notices.',
      vars: { urgent: true, state: 'AZ', age: 34, triageLevel: 'Standard' },
      code: (name: string) => `script "${name}"
{
  log "Checking medical triage routing..."
  if (urgent equals true)
  {
    assign "Emergency" to triageLevel
    include "triage/critical/pathway" send(state)
  }
  else
  {
    assign "StandardOutpatient" to triageLevel
  }
}`
    },
    {
      prefix: 'Claims Liability Validation',
      category: 'Insurance',
      desc: 'Deductible and auto-claim liability checklist evaluation.',
      vars: { deductible: 500, repairEstimate: 1200, liabilityPercent: 50, fastTrack: false },
      code: (name: string) => `script "${name}"
{
  log "Processing repair claim threshold..."
  if (repairEstimate greaterThan deductible AND liabilityPercent lessThan 50)
  {
    assign true to fastTrack
    log "Approved for automatic liability fast-track payment."
  }
}`
    },
    {
      prefix: 'Supply Chain Routing',
      category: 'Logistics',
      desc: 'Automatic courier selection based on courier weight and country destination.',
      vars: { weightKg: 12, destCountry: 'CA', priority: 'Air', carrier: 'Pending' },
      code: (name: string) => `script "${name}"
{
  log "Computing supply route cost..."
  if (weightKg lessThan 15 AND destCountry equals "CA")
  {
    assign "PriorityPostal" to carrier
  }
  else
  {
    assign "GlobalFreight" to carrier
  }
}`
    },
    {
      prefix: 'Risk & Fraud Compliance',
      category: 'Security',
      desc: 'Evaluation of transactions against high risk geo lists and fraud scores.',
      vars: { fraudScore: 84, geoIpCountry: 'UA', isHighRisk: false },
      code: (name: string) => `script "${name}"
{
  log "Assessing risk fraud compliance..."
  if (fraudScore greaterThan 75 OR geoIpCountry equals "UA")
  {
    assign true to isHighRisk
    validate fraudScore lessThan 90 or_error "Immediate security transaction block"
  }
}`
    }
  ];

  const totalVirtual = 145000;
  
  // Filter real rules
  let filteredReal = realRules.filter((r: any) => {
    if (category !== 'all' && category !== 'custom') {
      return false;
    }
    if (search) {
      const s = search.toLowerCase();
      return r.name.toLowerCase().includes(s) || r.description.toLowerCase().includes(s);
    }
    return true;
  });

  filteredReal = filteredReal.map((r: any) => ({ ...r, category: 'Custom' }));

  const searchLower = search.trim().toLowerCase();

  if (searchLower) {
    // Generate matches based on search term
    const mockTotalMatched = Math.min(12500, Math.max(120, searchLower.charCodeAt(0) * 12 + searchLower.length * 5));
    const startIdx = (page - 1) * limit;
    const endIdx = startIdx + limit;
    
    const virtualRulesToReturn: any[] = [];
    for (let i = startIdx; i < endIdx && i < mockTotalMatched; i++) {
      const tempIdx = (i + searchLower.charCodeAt(0)) % templates.length;
      const t = templates[tempIdx];
      const ruleNum = 1000 + i;
      const name = `${t.prefix} Match #${ruleNum} for "${search}"`;
      const id = `v-${tempIdx}-${ruleNum}`;
      
      virtualRulesToReturn.push({
        id,
        name,
        description: `High-scale index rule: match found for query "${search}". ${t.desc}`,
        category: t.category,
        createdAt: new Date(Date.now() - i * 18 * 60 * 60 * 1000).toISOString(),
        isVirtual: true
      });
    }

    return {
      rules: page === 1 ? [...filteredReal, ...virtualRulesToReturn].slice(0, limit) : virtualRulesToReturn,
      total: filteredReal.length + mockTotalMatched,
      page,
      limit
    };
  } else {
    // Return standard sequential paginated virtual pool
    const startOverall = (page - 1) * limit;
    const endOverall = startOverall + limit;
    const results: any[] = [];

    // Filter by requested category first
    const activeTemplates = category === 'all' 
      ? templates 
      : templates.filter(t => t.category.toLowerCase() === category.toLowerCase());

    const isCustomFiltered = category === 'custom';
    
    // Scale count relative to category filter
    let calculatedTotal = totalVirtual;
    if (category !== 'all' && !isCustomFiltered) {
      calculatedTotal = Math.floor(totalVirtual / templates.length);
    } else if (isCustomFiltered) {
      calculatedTotal = 0;
    }

    const overallTotalCount = (category === 'all' || isCustomFiltered ? filteredReal.length : 0) + calculatedTotal;

    for (let i = startOverall; i < endOverall && i < overallTotalCount; i++) {
      if (i < filteredReal.length && (category === 'all' || isCustomFiltered)) {
        results.push(filteredReal[i]);
      } else {
        const virtualIdx = i - (category === 'all' || isCustomFiltered ? filteredReal.length : 0);
        if (virtualIdx < calculatedTotal) {
          const t = activeTemplates[virtualIdx % activeTemplates.length];
          const ruleNum = 100000 + virtualIdx * (category === 'all' ? 1 : templates.length);
          const name = `${t.prefix} #${ruleNum}`;
          const id = `v-${templates.indexOf(t)}-${ruleNum}`;

          results.push({
            id,
            name,
            description: `High-scale virtual production rule script for ${t.category} operations. ${t.desc}`,
            category: t.category,
            createdAt: new Date(Date.now() - virtualIdx * 12 * 60 * 60 * 1000).toISOString(),
            isVirtual: true
          });
        }
      }
    }

    return {
      rules: results,
      total: overallTotalCount,
      page,
      limit
    };
  }
}

/**
 * API endpoints to manage BPL Rules
 */
app.get('/api/rules', (req, res) => {
  try {
    const search = String(req.query.search || '');
    const category = String(req.query.category || 'all');
    const page = Math.max(1, parseInt(String(req.query.page || '1'), 10));
    const limit = Math.max(1, Math.min(100, parseInt(String(req.query.limit || '10'), 10)));

    const result = getVirtualRules(search, page, limit, category);
    res.json(result);
  } catch (error: any) {
    res.status(500).json({ error: error.message || 'Failed to list rules' });
  }
});

app.get('/api/rules/:id', (req, res) => {
  try {
    const id = req.params.id;
    if (id.startsWith('v-')) {
      const parts = id.split('-');
      const tempIdx = parseInt(parts[1], 10);
      const ruleNum = parseInt(parts[2], 10);
      
      const templates = [
        {
          prefix: 'Financial Policy',
          category: 'Financial',
          desc: 'Automated credit limit check and validation rules.',
          vars: { limit: 10000, creditScore: 720, income: 85000, authorized: false },
          code: (name: string) => `script "${name}"
{
  log "Evaluating financial eligibility for ${name}..."
  if (creditScore greaterThan 700 AND income greaterThan 50000)
  {
    assign true to authorized
    log "Credit authorization approved"
  }
  else
  {
    assign false to authorized
    log "Requires manual underwriting review"
  }
}`
        },
        {
          prefix: 'Healthcare Triage Protocol',
          category: 'Healthcare',
          desc: 'Check state eligibility for emergency or standard medical booklet notices.',
          vars: { urgent: true, state: 'AZ', age: 34, triageLevel: 'Standard' },
          code: (name: string) => `script "${name}"
{
  log "Checking medical triage routing..."
  if (urgent equals true)
  {
    assign "Emergency" to triageLevel
    include "triage/critical/pathway" send(state)
  }
  else
  {
    assign "StandardOutpatient" to triageLevel
  }
}`
        },
        {
          prefix: 'Claims Liability Validation',
          category: 'Insurance',
          desc: 'Deductible and auto-claim liability checklist evaluation.',
          vars: { deductible: 500, repairEstimate: 1200, liabilityPercent: 50, fastTrack: false },
          code: (name: string) => `script "${name}"
{
  log "Processing repair claim threshold..."
  if (repairEstimate greaterThan deductible AND liabilityPercent lessThan 50)
  {
    assign true to fastTrack
    log "Approved for automatic liability fast-track payment."
  }
}`
        },
        {
          prefix: 'Supply Chain Routing',
          category: 'Logistics',
          desc: 'Automatic courier selection based on courier weight and country destination.',
          vars: { weightKg: 12, destCountry: 'CA', priority: 'Air', carrier: 'Pending' },
          code: (name: string) => `script "${name}"
{
  log "Computing supply route cost..."
  if (weightKg lessThan 15 AND destCountry equals "CA")
  {
    assign "PriorityPostal" to carrier
  }
  else
  {
    assign "GlobalFreight" to carrier
  }
}`
        },
        {
          prefix: 'Risk & Fraud Compliance',
          category: 'Security',
          desc: 'Evaluation of transactions against high risk geo lists and fraud scores.',
          vars: { fraudScore: 84, geoIpCountry: 'UA', isHighRisk: false },
          code: (name: string) => `script "${name}"
{
  log "Assessing risk fraud compliance..."
  if (fraudScore greaterThan 75 OR geoIpCountry equals "UA")
  {
    assign true to isHighRisk
    validate fraudScore lessThan 90 or_error "Immediate security transaction block"
  }
}`
        }
      ];

      const t = templates[tempIdx % templates.length];
      const name = `${t.prefix} #${ruleNum}`;
      const desc = `High-scale virtual production rule script for ${t.category} operations. ${t.desc}`;
      
      const codeStr = t.code(name);
      const parser = new BplParser();
      const { ast: parsedAst } = parser.parse(codeStr);
      let binaryStr = '';
      if (parsedAst) {
        try {
          binaryStr = compileAstToBinary(parsedAst);
        } catch (e) {
          console.error('Failed to compile virtual rule:', e);
        }
      }

      return res.json({
        id,
        name,
        description: desc,
        category: t.category,
        ast: parsedAst,
        compiledBinary: binaryStr,
        defaultVariables: t.vars,
        createdAt: new Date(Date.now() - ruleNum * 12 * 60 * 60 * 1000).toISOString(),
        isVirtual: true
      });
    }

    const rules = getStoredRules();
    const rule = rules.find((r: any) => r.id === req.params.id);
    if (!rule) {
      return res.status(404).json({ error: 'Rule not found' });
    }
    res.json(rule);
  } catch (error: any) {
    res.status(500).json({ error: error.message || 'Failed to get rule details' });
  }
});

app.post('/api/rules', (req, res) => {
  try {
    const { name, description, code, ast, defaultVariables } = req.body;
    if (!name || (!code && !ast)) {
      return res.status(400).json({ error: 'Name and either code or ast are required' });
    }
    const rules = getStoredRules();
    const newId = name.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, '') || `rule-${Date.now()}`;
    
    let finalId = newId;
    let counter = 1;
    while (rules.some((r: any) => r.id === finalId)) {
      finalId = `${newId}-${counter}`;
      counter++;
    }

    const newRule: any = {
      id: finalId,
      name,
      description: description || '',
      defaultVariables: defaultVariables || {},
      createdAt: new Date().toISOString()
    };

    let targetAst = ast;
    if (!targetAst && code) {
      const parser = new BplParser();
      const { ast: parsedAst } = parser.parse(code);
      targetAst = parsedAst;
    }

    if (!targetAst) {
      return res.status(400).json({ error: 'Failed to compile/parse BPL rules' });
    }

    newRule.ast = targetAst;
    try {
      newRule.compiledBinary = compileAstToBinary(targetAst);
    } catch (e: any) {
      return res.status(400).json({ error: `Compilation error: ${e.message}` });
    }

    rules.push(newRule);
    saveStoredRules(rules);
    res.status(201).json(newRule);
  } catch (error: any) {
    res.status(500).json({ error: error.message || 'Failed to create rule' });
  }
});

app.put('/api/rules/:id', (req, res) => {
  try {
    const id = req.params.id;
    const { name, description, code, ast, defaultVariables } = req.body;
    const rules = getStoredRules();
    
    let index = rules.findIndex((r: any) => r.id === id);
    if (index === -1 && id.startsWith('v-')) {
      // Promoting virtual rule to active custom rule database on-the-fly!
      const promotedRule: any = {
        id: id,
        name: name || `Promoted Rule ${id}`,
        description: description || 'Promoted virtual rule script.',
        defaultVariables: defaultVariables || {},
        createdAt: new Date().toISOString()
      };
      
      let targetAst = ast;
      if (!targetAst && code) {
        const parser = new BplParser();
        const { ast: parsedAst } = parser.parse(code);
        targetAst = parsedAst;
      }
      
      if (!targetAst) {
        return res.status(400).json({ error: 'Failed to compile promoted rule AST' });
      }
      
      promotedRule.ast = targetAst;
      try {
        promotedRule.compiledBinary = compileAstToBinary(targetAst);
      } catch (e: any) {
        return res.status(400).json({ error: `Compilation error: ${e.message}` });
      }

      rules.push(promotedRule);
      saveStoredRules(rules);
      return res.json(promotedRule);
    } else if (index === -1) {
      return res.status(404).json({ error: 'Rule not found' });
    }

    const updatedRule: any = {
      ...rules[index],
      ...(name && { name }),
      ...(description !== undefined && { description }),
      ...(defaultVariables && { defaultVariables }),
      updatedAt: new Date().toISOString()
    };

    let targetAst = ast;
    if (!targetAst && code) {
      const parser = new BplParser();
      const { ast: parsedAst } = parser.parse(code);
      targetAst = parsedAst;
    }

    if (targetAst) {
      updatedRule.ast = targetAst;
      try {
        updatedRule.compiledBinary = compileAstToBinary(targetAst);
      } catch (e: any) {
        return res.status(400).json({ error: `Compilation error: ${e.message}` });
      }
    }

    // Explicitly make sure code and nodes are never stored
    delete updatedRule.code;
    delete updatedRule.nodes;

    rules[index] = updatedRule;
    saveStoredRules(rules);
    res.json(updatedRule);
  } catch (error: any) {
    res.status(500).json({ error: error.message || 'Failed to update rule' });
  }
});

app.delete('/api/rules/:id', (req, res) => {
  try {
    const id = req.params.id;
    const rules = getStoredRules();
    const filtered = rules.filter((r: any) => r.id !== id);
    if (filtered.length === rules.length && !id.startsWith('v-')) {
      return res.status(404).json({ error: 'Rule not found' });
    }
    saveStoredRules(filtered);
    res.json({ success: true, message: 'Rule deleted successfully' });
  } catch (error: any) {
    res.status(500).json({ error: error.message || 'Failed to delete rule' });
  }
});

/**
 * Server health check
 */
app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', hasApiKey: !!process.env.GEMINI_API_KEY });
});

// Configure Vite middleware in development or static folder in production
async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
