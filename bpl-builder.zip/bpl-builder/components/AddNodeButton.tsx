import { ArrowRightCircle, CornerDownLeft, Cpu, Download, Equal, FileText, Flag, FolderOpen, GitBranch, Keyboard, MessageSquare, MonitorX, Repeat, ShieldCheck, Split } from "lucide-react";
import React from "react";
import { INodeType, NODE_TYPE } from "../types/bpl";

interface AddNodeButtonProps {
    onAdd: (type: INodeType) => void;
    className?: string;
}

export const AddNodeButton = ({ onAdd, className }: AddNodeButtonProps) => {
    const [isOpen, setIsOpen] = React.useState(false);

    return (
        <div className={`relative group/add my-1.5 py-1 flex items-center justify-start ${className}`}>
            {/* Visual dotted connector line hover accent */}
            <div className="absolute left-0 right-0 h-px border-t border-dashed border-indigo-400 group-hover/add:border-indigo-600/80 transition" />

            <button
                onClick={(e) => {
                    e.stopPropagation();
                    setIsOpen(!isOpen);
                }}
                className="relative z-10 w-5 h-5 rounded-full bg-white hover:bg-indigo-500 border border-indigo-200 hover:border-indigo-500 flex items-center justify-center text-indigo-500 hover:text-white shadow-xs hover:shadow-md transition-all hover:scale-110 cursor-pointer"
                title="Insert node here"
            >
                <span className="text-[11px] font-bold leading-none">+</span>
            </button>

            {isOpen && (
                <>
                    <div
                        className="fixed inset-0 z-30"
                        onClick={(e) => {
                            e.stopPropagation();
                            setIsOpen(false);
                        }}
                    />
                    <div className="absolute top-7 left-1/2 -translate-x-1/2 bg-white border border-gray-200 rounded-xl shadow-xl py-1.5 min-w-[155px] z-40 flex flex-col gap-0.5 text-left text-xs font-semibold text-gray-700 animate-in fade-in slide-in-from-top-1 duration-150 max-h-60 overflow-y-auto">
                        <div className="px-3 py-1 text-[9px] uppercase font-bold text-gray-400 border-b border-gray-100 mb-1 tracking-wider">
                            Insert New Node
                        </div>
                        {/* If */}
                        <button
                            onClick={(e) => {
                                e.stopPropagation();
                                onAdd(NODE_TYPE.IF);
                                setIsOpen(false);
                            }}
                            className="px-3 py-1.5 hover:bg-indigo-50 hover:text-indigo-600 flex items-center gap-2 transition text-left w-full cursor-pointer"
                        >
                            <GitBranch className="w-3.5 h-3.5 text-gray-400" />
                            <span>If Condition</span>
                        </button>

                        {/* Only If */}
                        <button
                            onClick={(e) => {
                                e.stopPropagation();
                                onAdd(NODE_TYPE.ONLY_IF);
                                setIsOpen(false);
                            }}
                            className="px-3 py-1.5 hover:bg-indigo-50 hover:text-indigo-600 flex items-center gap-2 transition text-left w-full cursor-pointer"
                        >
                            <Split className="w-3.5 h-3.5 text-gray-400" />
                            <span>Only If</span>
                        </button>

                        {/* Assign */}
                        <button
                            onClick={(e) => {
                                e.stopPropagation();
                                onAdd(NODE_TYPE.ASSIGN);
                                setIsOpen(false);
                            }}
                            className="px-3 py-1.5 hover:bg-indigo-50 hover:text-indigo-600 flex items-center gap-2 transition text-left w-full cursor-pointer"
                        >
                            <Equal className="w-3.5 h-3.5 text-gray-400" />
                            <span>Assign</span>
                        </button>

                        {/* Prompt */}
                        <button
                            onClick={(e) => {
                                e.stopPropagation();
                                onAdd(NODE_TYPE.PROMPT);
                                setIsOpen(false);
                            }}
                            className="px-3 py-1.5 hover:bg-indigo-50 hover:text-indigo-600 flex items-center gap-2 transition text-left w-full cursor-pointer"
                        >
                            <MessageSquare className="w-3.5 h-3.5 text-gray-400" />
                            <span>Prompt</span>
                        </button>

                        {/* Log */}
                        <button
                            onClick={(e) => {
                                e.stopPropagation();
                                onAdd(NODE_TYPE.LOG);
                                setIsOpen(false);
                            }}
                            className="px-3 py-1.5 hover:bg-indigo-50 hover:text-indigo-600 flex items-center gap-2 transition text-left w-full cursor-pointer"
                        >
                            <FileText className="w-3.5 h-3.5 text-gray-400" />
                            <span>Log</span>
                        </button>

                        {/* Include */}
                        <button
                            onClick={(e) => {
                                e.stopPropagation();
                                onAdd('include');
                                setIsOpen(false);
                            }}
                            className="px-3 py-1.5 hover:bg-indigo-50 hover:text-indigo-600 flex items-center gap-2 transition text-left w-full cursor-pointer"
                        >
                            <FolderOpen className="w-3.5 h-3.5 text-gray-400" />
                            <span>Include</span>
                        </button>

                        {/* Import */}
                        <button
                            onClick={(e) => {
                                e.stopPropagation();
                                onAdd('import');
                                setIsOpen(false);
                            }}
                            className="px-3 py-1.5 hover:bg-indigo-50 hover:text-indigo-600 flex items-center gap-2 transition text-left w-full cursor-pointer"
                        >
                            <Download className="w-3.5 h-3.5 text-gray-400" />
                            <span>Import</span>
                        </button>

                        {/* Validation */}
                        <button
                            onClick={(e) => {
                                e.stopPropagation();
                                onAdd('validation');
                                setIsOpen(false);
                            }}
                            className="px-3 py-1.5 hover:bg-indigo-50 hover:text-indigo-600 flex items-center gap-2 transition text-left w-full cursor-pointer"
                        >
                            <ShieldCheck className="w-3.5 h-3.5 text-gray-400" />
                            <span>Validation</span>
                        </button>

                        {/* Jump */}
                        <button
                            onClick={(e) => {
                                e.stopPropagation();
                                onAdd('jump');
                                setIsOpen(false);
                            }}
                            className="px-3 py-1.5 hover:bg-indigo-50 hover:text-indigo-600 flex items-center gap-2 transition text-left w-full cursor-pointer"
                        >
                            <ArrowRightCircle className="w-3.5 h-3.5 text-gray-400" />
                            <span>Jump To</span>
                        </button>

                        {/* Label */}
                        <button
                            onClick={(e) => {
                                e.stopPropagation();
                                onAdd('label');
                                setIsOpen(false);
                            }}
                            className="px-3 py-1.5 hover:bg-indigo-50 hover:text-indigo-600 flex items-center gap-2 transition text-left w-full cursor-pointer"
                        >
                            <Flag className="w-3.5 h-3.5 text-gray-400" />
                            <span>Label</span>
                        </button>

                        {/* Return */}
                        <button
                            onClick={(e) => {
                                e.stopPropagation();
                                onAdd('return');
                                setIsOpen(false);
                            }}
                            className="px-3 py-1.5 hover:bg-indigo-50 hover:text-indigo-600 flex items-center gap-2 transition text-left w-full cursor-pointer"
                        >
                            <CornerDownLeft className="w-3.5 h-3.5 text-gray-400" />
                            <span>Return</span>
                        </button>

                        {/* Get Key */}
                        <button
                            onClick={(e) => {
                                e.stopPropagation();
                                onAdd('getkey');
                                setIsOpen(false);
                            }}
                            className="px-3 py-1.5 hover:bg-indigo-50 hover:text-indigo-600 flex items-center gap-2 transition text-left w-full cursor-pointer"
                        >
                            <Keyboard className="w-3.5 h-3.5 text-gray-400" />
                            <span>Get Key</span>
                        </button>

                        {/* macro node */}
                        <button
                            onClick={(e) => {
                                e.stopPropagation();
                                onAdd(NODE_TYPE.MARCRO);
                                setIsOpen(false);
                            }}
                            className="px-3 py-1.5 hover:bg-indigo-50 hover:text-indigo-600 flex items-center gap-2 transition text-left w-full cursor-pointer"
                        >
                            <Cpu className="w-3.5 h-3.5 text-gray-400" />
                            <span>Macro Block</span>
                        </button>

                        {/* Clear Screen */}
                        <button
                            onClick={(e) => {
                                e.stopPropagation();
                                onAdd('clearscreen');
                                setIsOpen(false);
                            }}
                            className="px-3 py-1.5 hover:bg-indigo-50 hover:text-indigo-600 flex items-center gap-2 transition text-left w-full cursor-pointer"
                        >
                            <MonitorX className="w-3.5 h-3.5 text-gray-400" />
                            <span>Clear Screen</span>
                        </button>
                    </div>
                </>
            )}
        </div>
    );
}