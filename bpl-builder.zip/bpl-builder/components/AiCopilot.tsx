/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Sparkles, Eye, ShieldAlert, ArrowRight, Loader2, RefreshCw } from 'lucide-react';

interface AiCopilotProps {
  bplCode: string;
  onApplyGeneratedCode: (code: string) => void;
}

type TabType = 'generate' | 'explain' | 'optimize';

export default function AiCopilot({ bplCode, onApplyGeneratedCode }: AiCopilotProps) {
  const [activeTab, setActiveTab] = useState<TabType>('generate');
  const [prompt, setPrompt] = useState('');
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState('');
  const [generatedCode, setGeneratedCode] = useState('');
  const [error, setError] = useState<string | null>(null);

  const handleGenerate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!prompt.trim()) return;

    setLoading(true);
    setError(null);
    setResult('');
    setGeneratedCode('');

    try {
      const res = await fetch('/api/gemini/generate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ prompt }),
      });

      if (!res.ok) {
        const errData = await res.json();
        throw new Error(errData.error || 'Failed to generate code');
      }

      const data = await res.json();
      setGeneratedCode(data.code);
      setResult(data.rawResponse);
    } catch (err: any) {
      setError(err.message || 'An error occurred during rules generation.');
    } finally {
      setLoading(false);
    }
  };

  const handleExplain = async () => {
    setLoading(true);
    setError(null);
    setResult('');

    try {
      const res = await fetch('/api/gemini/explain', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ bplCode }),
      });

      if (!res.ok) {
        const errData = await res.json();
        throw new Error(errData.error || 'Failed to explain code');
      }

      const data = await res.json();
      setResult(data.explanation || '');
    } catch (err: any) {
      setError(err.message || 'An error occurred during analysis.');
    } finally {
      setLoading(false);
    }
  };

  const handleOptimize = async () => {
    setLoading(true);
    setError(null);
    setResult('');

    try {
      const res = await fetch('/api/gemini/optimize', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ bplCode }),
      });

      if (!res.ok) {
        const errData = await res.json();
        throw new Error(errData.error || 'Failed to optimize code');
      }

      const data = await res.json();
      setResult(data.optimization || '');
    } catch (err: any) {
      setError(err.message || 'An error occurred during audit.');
    } finally {
      setLoading(false);
    }
  };

  const handleApply = () => {
    if (generatedCode) {
      onApplyGeneratedCode(generatedCode);
      setGeneratedCode('');
      setResult('');
      setPrompt('');
    }
  };

  // Safe client-side lightweight Markdown renderer to support clean styling
  const renderMarkdown = (md: string) => {
    if (!md) return null;

    const lines = md.split('\n');
    let inCodeBlock = false;
    let codeContent: string[] = [];

    return lines.map((line, idx) => {
      // Toggle code blocks
      if (line.startsWith('```')) {
        if (inCodeBlock) {
          inCodeBlock = false;
          const content = codeContent.join('\n');
          codeContent = [];
          return (
            <pre key={idx} className="bg-slate-900 text-slate-100 p-3 rounded-lg overflow-x-auto font-mono text-[10px] my-2 select-all">
              <code>{content}</code>
            </pre>
          );
        } else {
          inCodeBlock = true;
          return null;
        }
      }

      if (inCodeBlock) {
        codeContent.push(line);
        return null;
      }

      // Headers
      if (line.startsWith('### ')) {
        return <h4 key={idx} className="text-xs font-bold text-gray-800 mt-4 mb-2 uppercase tracking-wide">{line.replace('### ', '')}</h4>;
      }
      if (line.startsWith('## ')) {
        return <h3 key={idx} className="text-sm font-bold text-gray-900 mt-5 mb-2 border-b border-gray-100 pb-1">{line.replace('## ', '')}</h3>;
      }
      if (line.startsWith('# ')) {
        return <h2 key={idx} className="text-base font-bold text-gray-900 mt-6 mb-3">{line.replace('# ', '')}</h2>;
      }

      // Bullet lists
      if (line.trim().startsWith('- ') || line.trim().startsWith('* ')) {
        const cleanText = line.replace(/^[\s]*[-*]\s+/, '');
        return (
          <li key={idx} className="text-xs text-gray-600 ml-4 list-disc my-1 leading-relaxed">
            {parseInlineStyles(cleanText)}
          </li>
        );
      }

      // Number list
      if (/^\d+\.\s/.test(line.trim())) {
        const cleanText = line.replace(/^\d+\.\s+/, '');
        return (
          <li key={idx} className="text-xs text-gray-600 ml-4 list-decimal my-1 leading-relaxed">
            {parseInlineStyles(cleanText)}
          </li>
        );
      }

      if (line.trim() === '') {
        return <div key={idx} className="h-2" />;
      }

      // Normal paragraph
      return (
        <p key={idx} className="text-xs text-gray-600 my-1.5 leading-relaxed">
          {parseInlineStyles(line)}
        </p>
      );
    });
  };

  const parseInlineStyles = (text: string) => {
    // Regex for bold **text** or *italic*
    const parts = text.split(/(\*\*.*?\*\*|\*.*?\*|`.*?`)/);
    return parts.map((part, i) => {
      if (part.startsWith('**') && part.endsWith('**')) {
        return <strong key={i} className="font-bold text-gray-800">{part.slice(2, -2)}</strong>;
      }
      if (part.startsWith('*') && part.endsWith('*')) {
        return <em key={i} className="italic text-gray-700">{part.slice(1, -1)}</em>;
      }
      if (part.startsWith('`') && part.endsWith('`')) {
        return <code key={i} className="font-mono bg-gray-100 text-rose-600 px-1 py-0.2 rounded text-[10px]">{part.slice(1, -1)}</code>;
      }
      return part;
    });
  };

  return (
    <div className="bg-white border border-gray-100 rounded-xl shadow-sm p-5 flex flex-col h-full space-y-4">
      {/* Copilot Brand Header */}
      <div className="flex items-center justify-between border-b border-gray-50 pb-3">
        <div className="flex items-center gap-2">
          <div className="p-1 rounded-lg bg-indigo-50 text-indigo-600 animate-pulse">
            <Sparkles className="w-4 h-4 fill-indigo-100" />
          </div>
          <h3 className="text-sm font-semibold text-gray-800">
            BPL Rules Assistant
          </h3>
        </div>
      </div>

      {/* Tabs Menu */}
      <div className="flex items-center gap-1 bg-gray-50 border border-gray-100 p-1 rounded-lg">
        <button
          onClick={() => { setActiveTab('generate'); setResult(''); setError(null); }}
          className={`flex-1 py-1.5 rounded-md text-xs font-semibold transition flex items-center justify-center gap-1 cursor-pointer ${activeTab === 'generate' ? 'bg-white text-indigo-600 shadow-sm' : 'text-gray-500 hover:text-gray-800'}`}
        >
          <Sparkles className="w-3.5 h-3.5" /> Synthesize
        </button>
        <button
          onClick={() => { setActiveTab('explain'); setResult(''); setError(null); handleExplain(); }}
          className={`flex-1 py-1.5 rounded-md text-xs font-semibold transition flex items-center justify-center gap-1 cursor-pointer ${activeTab === 'explain' ? 'bg-white text-indigo-600 shadow-sm' : 'text-gray-500 hover:text-gray-800'}`}
        >
          <Eye className="w-3.5 h-3.5" /> Explain
        </button>
        <button
          onClick={() => { setActiveTab('optimize'); setResult(''); setError(null); handleOptimize(); }}
          className={`flex-1 py-1.5 rounded-md text-xs font-semibold transition flex items-center justify-center gap-1 cursor-pointer ${activeTab === 'optimize' ? 'bg-white text-indigo-600 shadow-sm' : 'text-gray-500 hover:text-gray-800'}`}
        >
          <ShieldAlert className="w-3.5 h-3.5" /> Audit
        </button>
      </div>

      {/* Main Tab Area */}
      <div className="flex-1 flex flex-col overflow-hidden min-h-[15rem]">
        {loading ? (
          <div className="flex-1 flex flex-col items-center justify-center space-y-2 text-gray-400 py-12">
            <Loader2 className="w-6 h-6 animate-spin text-indigo-500" />
            <span className="text-xs font-medium font-mono">Consulting Gemini flash...</span>
          </div>
        ) : error ? (
          <div className="flex-1 bg-rose-50 border border-rose-100 p-4 rounded-xl text-xs text-rose-800 space-y-2">
            <p className="font-bold">Error communicating with API:</p>
            <p className="font-mono">{error}</p>
            <p className="text-[10px] text-gray-400">Please make sure your GEMINI_API_KEY is configured in the Secrets panel.</p>
          </div>
        ) : (
          <div className="flex-1 flex flex-col overflow-y-auto space-y-4 max-h-[35rem] pr-1">
            {activeTab === 'generate' && !result && (
              <form onSubmit={handleGenerate} className="space-y-3">
                <p className="text-xs text-gray-500 leading-relaxed">
                  Describe what your BPL rule should accomplish in plain English. Gemini will generate a syntactically valid BPL script.
                </p>
                <textarea
                  value={prompt}
                  onChange={(e) => setPrompt(e.target.value)}
                  placeholder="e.g. If user age is less than 18, assign Status = 'Denied' and Include 'notice/minor'. Otherwise, call API 'https://api.verif.com' to fetch validation status and set multiplier to 1.0."
                  className="w-full h-24 p-3 bg-gray-50 border border-gray-200 rounded-xl text-xs focus:ring-1 focus:ring-indigo-500 focus:outline-none placeholder:text-gray-400"
                />
                <button
                  type="submit"
                  disabled={!prompt.trim()}
                  className="w-full py-2 bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50 text-white font-semibold rounded-lg text-xs flex items-center justify-center gap-1.5 transition shadow-sm cursor-pointer"
                >
                  <Sparkles className="w-4 h-4 fill-white/20" /> Generate Policy Script
                </button>
              </form>
            )}

            {result && (
              <div className="space-y-4">
                {/* Generated Code Quick Apply Action */}
                {activeTab === 'generate' && generatedCode && (
                  <div className="bg-indigo-50 border border-indigo-100 p-3 rounded-xl flex items-center justify-between">
                    <span className="text-[11px] font-medium text-indigo-900">
                      BPL Script Synthesized!
                    </span>
                    <button
                      onClick={handleApply}
                      className="px-2.5 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg text-[10px] font-bold flex items-center gap-1 transition shadow-sm cursor-pointer"
                    >
                      Apply to Workspace <ArrowRight className="w-3 h-3" />
                    </button>
                  </div>
                )}

                {/* Explanation or Audit markdown results */}
                <div className="prose select-text">
                  {renderMarkdown(result)}
                </div>

                {/* Re-trigger action button */}
                {activeTab !== 'generate' && (
                  <button
                    onClick={activeTab === 'explain' ? handleExplain : handleOptimize}
                    className="w-full py-1.5 bg-gray-50 hover:bg-gray-100 border border-gray-200 rounded-lg text-xs text-gray-600 flex items-center justify-center gap-1 cursor-pointer"
                  >
                    <RefreshCw className="w-3.5 h-3.5" /> Recalculate Audit
                  </button>
                )}
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
