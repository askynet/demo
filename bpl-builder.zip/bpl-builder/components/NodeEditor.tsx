/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import {
  BplAstNode,
  ScriptNode,
  IfNode,
  LabelNode,
  SwitchNode,
  LoopNode,
  NODE_TYPE,
} from '../types/bpl';
import {
  Settings,
} from 'lucide-react';
import { LogNodeEditor } from './Nodes/LogNode';
import { AssignNodeEditor } from './Nodes/AssignNode';
import { IncludeNodeEditor } from './Nodes/IncludeNode';
import { JumpNodeEditor } from './Nodes/JumpNode';
import { LabelNodeEditor } from './Nodes/LabelNode';
import { ErrorNodeEditor } from './Nodes/EditorNode';
import { LoopNodeEditor } from './Nodes/LoopNode';
import { SwitchNodeEditor } from './Nodes/SwitchNode';
import { ValidationNodeEditor } from './Nodes/ValidationNode';
import { ConditionalNodeEditor } from './Nodes/ConditionNode';
import { OnlyIfNodeEditor } from './Nodes/OnlyIfNode';
import { PromptNodeEditor } from './Nodes/PromptNode';
import { MacroNodeEditor } from './Nodes/MacroNode';

interface NodeEditorProps {
  selectedNode: BplAstNode;
  onUpdateNodeProperty: (nodeId: string, updatedFields: Partial<BplAstNode>) => void;
  onClose?: () => void;
  ast: ScriptNode | null;
}

export default function NodeEditor({
  selectedNode,
  onUpdateNodeProperty,
  ast,
}: NodeEditorProps) {
  // Recursively collect all label names in the AST
  const collectLabels = (nodes: BplAstNode[]): string[] => {
    const labels: string[] = [];
    const walk = (list: BplAstNode[]) => {
      for (const n of list) {
        if (n.type === 'label') {
          labels.push((n as LabelNode).name);
        } else if (n.type === 'if') {
          const ifNode = n as IfNode;
          walk(ifNode.thenBlock);
          ifNode.elseIfBlocks?.forEach((elif) => walk(elif.block));
          if (ifNode.elseBlock) walk(ifNode.elseBlock);
        } else if (n.type === 'switch') {
          const swNode = n as SwitchNode;
          swNode.cases.forEach((c) => walk(c.block));
          if (swNode.defaultBlock) walk(swNode.defaultBlock);
        } else if (n.type === 'loop') {
          walk((n as LoopNode).block);
        }
      }
    };
    if (nodes) walk(nodes);
    return Array.from(new Set(labels));
  };

  const availableLabels = ast ? collectLabels(ast.children) : [];

  return (
    <div className="bg-white space-y-4">
      {/* Editor Body */}
      <div className="space-y-4 font-mono text-[11px]">
        {/* Node Metadata Row */}
        <div className="grid grid-cols-2 gap-2 border-b border-slate-50 pb-2">
          <div>
            <span className="text-[9px] uppercase font-bold text-gray-400 block mb-0.5">
              Node Type
            </span>
            <span className="inline-flex items-center px-2 py-0.5 rounded-md text-[10px] font-bold bg-indigo-50 text-indigo-700 border border-indigo-100 uppercase tracking-wider">
              {selectedNode.type}
            </span>
          </div>
          <div>
            <span className="text-[9px] uppercase font-bold text-gray-400 block mb-0.5">
              Node ID
            </span>
            <span className="text-gray-500 font-semibold select-all font-mono">
              {selectedNode.id}
            </span>
          </div>
        </div>

        {/* Dynamic Property Inputs based on type */}

        {/* LOG NODE */}
        {selectedNode.type === 'log' && <LogNodeEditor
          node={selectedNode}
          onUpdateNodeProperty={onUpdateNodeProperty}
        />}

        {/* ASSIGN NODE */}
        {selectedNode.type === 'assign' && <AssignNodeEditor
          node={selectedNode}
          onUpdateNodeProperty={onUpdateNodeProperty}
        />}

        {/* INCLUDE NODE */}
        {selectedNode.type === 'include' && <IncludeNodeEditor
          node={selectedNode}
          onUpdateNodeProperty={onUpdateNodeProperty}
        />}

        {/* JUMP NODE */}
        {selectedNode.type === 'jump' && <JumpNodeEditor
          node={selectedNode}
          onUpdateNodeProperty={onUpdateNodeProperty}
          availableLabels={availableLabels}
        />}

        {/* LABEL NODE */}
        {selectedNode.type === 'label' && <LabelNodeEditor
          node={selectedNode}
          onUpdateNodeProperty={onUpdateNodeProperty}
        />}

        {/* ERROR NODE */}
        {selectedNode.type === 'error' && <ErrorNodeEditor
          node={selectedNode}
          onUpdateNodeProperty={onUpdateNodeProperty}
        />}

        {/* LOOP NODE */}
        {selectedNode.type === 'loop' && <LoopNodeEditor
          node={selectedNode}
          onUpdateNodeProperty={onUpdateNodeProperty}
        />}

        {/* SWITCH NODE */}
        {selectedNode.type === 'switch' && <SwitchNodeEditor
          node={selectedNode}
          onUpdateNodeProperty={onUpdateNodeProperty}
        />}

        {/* VALIDATION NODE */}
        {selectedNode.type === 'validation' && <ValidationNodeEditor
          node={selectedNode}
          onUpdateNodeProperty={onUpdateNodeProperty}
        />}

        {/* IF NODE */}
        {selectedNode.type === 'if' && (
          <div className="space-y-3.5">
            <div className="space-y-1.5">
              <label className="text-[10px] uppercase font-bold text-gray-400 block">
                Conditional Rule Criteria
              </label>
              <ConditionalNodeEditor node={selectedNode} cond={(selectedNode as IfNode).condition} onUpdateNodeProperty={onUpdateNodeProperty} />
            </div>
          </div>
        )}

        {/* IF NODE */}
        {selectedNode.type === NODE_TYPE.ONLY_IF && <OnlyIfNodeEditor
          node={selectedNode}
          onUpdateNodeProperty={onUpdateNodeProperty}
        />}

        {/* PROMPT NODE */}
        {selectedNode.type === NODE_TYPE.PROMPT && <PromptNodeEditor
          node={selectedNode}
          onUpdateNodeProperty={onUpdateNodeProperty}
        />}

        {/* PROMPT NODE */}
        {selectedNode.type === NODE_TYPE.MARCRO && <MacroNodeEditor
          node={selectedNode}
          onUpdateNodeProperty={onUpdateNodeProperty}
        />}
      </div>

      {/* Tip helper */}
      <div className="bg-slate-50 rounded-xl p-3 border border-slate-100 flex items-start gap-2 select-none">
        <Settings className="w-4 h-4 text-slate-400 shrink-0 mt-0.5 animate-spin-slow" />
        <p className="text-[10px] text-slate-500 font-sans leading-relaxed">
          Modifications automatically sync live to both the Flow Graph Designer canvas and the BPL DSL text source code representation.
        </p>
      </div>
    </div>
  );
}
