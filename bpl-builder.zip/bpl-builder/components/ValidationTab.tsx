import React from 'react';
import { ShieldCheck, Layers } from 'lucide-react';
import { ScriptNode, BplAstNode } from '../types/bpl';

interface ValidationTabProps {
  errors: any[];
  ast: ScriptNode | null;
  renderAstNodeElement: (node: BplAstNode, depth?: number) => React.ReactNode;
}

export default function ValidationTab({
  errors,
  ast,
  renderAstNodeElement
}: ValidationTabProps) {
  return (
    <div className="space-y-5 text-left">
      <div className="bg-slate-50/50 border border-gray-200 p-4 rounded-2xl flex items-center justify-between gap-3">
        <div className="flex items-center gap-2">
          <ShieldCheck className="w-5 h-5 text-indigo-600" />
          <div className="min-w-0">
            <h4 className="text-[11px] font-bold text-gray-900 uppercase">BPL Syntax Compile</h4>
            <p className="text-[10px] text-gray-400">Lexical Grammatical review</p>
          </div>
        </div>
        {errors.length === 0 ? (
          <span className="text-[9px] bg-emerald-50 border border-emerald-200 text-emerald-700 px-2 py-0.5 rounded uppercase font-bold tracking-wider">PASS</span>
        ) : (
          <span className="text-[9px] bg-rose-50 border border-rose-200 text-rose-700 px-2 py-0.5 rounded uppercase font-bold tracking-wider">BLOCK</span>
        )}
      </div>

      {/* AST Hierarchy */}
      <div className="border-t border-gray-100 pt-4 space-y-3">
        <span className="text-[10px] font-bold text-gray-400 uppercase tracking-widest block">Abstract Syntax Tree (AST) Hierarchy:</span>
        <div className="bg-slate-50 border border-gray-200 rounded-xl p-3 overflow-y-auto max-h-[250px] space-y-1.5">
          {errors.length > 0 ? (
            <p className="text-[10px] text-rose-600 italic font-mono">AST Generation Aborted: Compiler Syntax Error detected.</p>
          ) : ast ? (
            <div className="space-y-1.5">
              <div className="flex items-center gap-1.5 px-2 py-1 bg-indigo-900 text-indigo-100 rounded-lg font-mono text-[10px]">
                <Layers className="w-3 h-3 text-indigo-300" />
                <span className="font-bold">ROOT: "{ast.name}"</span>
              </div>
              <div className="pl-3 border-l border-indigo-100 ml-2 space-y-1.5">
                {ast.children.map((childNode) => renderAstNodeElement(childNode, 0))}
              </div>
            </div>
          ) : (
            <p className="text-[10px] text-gray-400 italic font-mono">No compiled AST active.</p>
          )}
        </div>
      </div>
    </div>
  );
}
