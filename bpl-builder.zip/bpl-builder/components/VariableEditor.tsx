/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { VariableState } from '../types/bpl';
import { Plus, Trash2, Database, ToggleLeft, Hash, Type, HelpCircle, ChevronDown, ChevronUp } from 'lucide-react';

interface VariableEditorProps {
  variables: VariableState;
  handleRemoveVariable: (key: string) => void;
  handleUpdateVariableValue: (key: string, val: any) => void;
  onChangeVariables?: (vars: VariableState) => void;
}

export default function VariableEditor({
  variables,
  handleRemoveVariable,
  handleUpdateVariableValue
}: VariableEditorProps) {
  const [newVarName, setNewVarName] = useState('');
  const [newVarType, setNewVarType] = useState<'string' | 'number' | 'boolean'>('string');
  const [showVars, setShowVars] = useState<boolean>(true);

  const handleAddVariable = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newVarName.trim()) return;

    const key = newVarName.trim();
    let val: any = '';
    if (newVarType === 'number') {
      val = 0;
    } else if (newVarType === 'boolean') {
      val = false;
    }

    handleUpdateVariableValue(key, val);
  };

  return (
    <div className="bg-white border border-gray-100 rounded-xl shadow-sm p-5 space-y-3">
      <div className='flex items-center justify-between'>
        <div className="flex items-center gap-2">
          <Database className="w-4 h-4 text-emerald-500" />
          <h3 className="text-sm font-semibold text-gray-800">
            Input Context (Variables)
          </h3>
        </div>
        <span className='p-1.5 hover:bg-slate-200 hover:rounded cursor-pointer' onClick={() => setShowVars(!showVars)}>
          {
            showVars && <ChevronDown size={15} />
          }
          {
            !showVars && <ChevronUp size={15} />
          }
        </span>
      </div>

      {
        showVars && <>
          <div className='border-b border-slate-100'></div>
          {/* Variables List */}
          <div className="space-y-3 max-h-[25rem] overflow-y-auto pr-1 pt-2">
            {Object.keys(variables).length === 0 ? (
              <p className="text-xs text-gray-400 italic text-center py-4">
                No active input variables defined. Add one below!
              </p>
            ) : (
              Object.entries(variables).map(([key, val]) => {
                const isArray = Array.isArray(val) || typeof val === 'object';

                return (
                  <div key={key} className="flex items-center justify-between p-2 bg-slate-50 border border-gray-200 rounded-lg text-[10px] font-mono">
                    <div className="flex items-center gap-1.5">
                      {typeof val === 'number' && <Hash className="w-3.5 h-3.5 text-blue-500" />}
                      {typeof val === 'boolean' && <ToggleLeft className="w-3.5 h-3.5 text-amber-500" />}
                      {typeof val === 'string' && <Type className="w-3.5 h-3.5 text-teal-500" />}
                      {isArray && <Database className="w-3.5 h-3.5 text-purple-500" />}
                      <span className="text-xs font-semibold text-gray-700 font-mono">
                        {key}
                      </span>
                    </div>
                    <div className="flex items-center gap-1.5">
                      {typeof val === 'boolean' ? (
                        <button
                          onClick={() => handleUpdateVariableValue(key, !val)}
                          className={`px-2 py-0.5 rounded font-bold border text-[8px] cursor-pointer ${val ? 'bg-indigo-50 text-indigo-700' : 'bg-white text-gray-400'}`}
                        >
                          {val ? 'TRUE' : 'FALSE'}
                        </button>
                      ) : (
                        <input
                          type={typeof val === 'number' ? 'number' : 'text'}
                          value={val}
                          onChange={(e) => {
                            const raw = e.target.value;
                            const parsed = typeof val === 'number' ? (Number(raw) || 0) : raw;
                            handleUpdateVariableValue(key, parsed);
                          }}
                          className="w-20 bg-white border rounded px-1 text-center font-bold text-indigo-600 focus:outline-none"
                        />
                      )}
                      <button onClick={() => handleRemoveVariable(key)} className="text-gray-400 hover:text-rose-600 transition"><Trash2 className="w-3 h-3" /></button>
                    </div>
                  </div>
                )
              })
            )}
          </div>

          {/* Add New Variable Form */}
          <form onSubmit={handleAddVariable} className="border-t border-gray-50 pt-4 space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-gray-500 uppercase tracking-wider">
                Add Custom Field
              </span>
            </div>
            <div className="grid grid-cols-2 gap-2">
              <input
                type="text"
                placeholder="Variable name"
                value={newVarName}
                onChange={(e) => setNewVarName(e.target.value)}
                className="px-2.5 py-1.5 border border-gray-200 rounded-lg text-xs focus:ring-1 focus:ring-indigo-500 focus:outline-none"
              />
              <select
                value={newVarType}
                onChange={(e) => setNewVarType(e.target.value as any)}
                className="px-2 py-1.5 border border-gray-200 bg-white rounded-lg text-xs focus:ring-1 focus:ring-indigo-500 focus:outline-none"
              >
                <option value="string">String ("Y")</option>
                <option value="number">Number (18)</option>
                <option value="boolean">Boolean</option>
              </select>
            </div>
            <button
              type="submit"
              disabled={!newVarName.trim()}
              className="w-full py-2 bg-emerald-500 hover:bg-emerald-600 disabled:opacity-50 text-white rounded-lg text-xs font-semibold flex items-center justify-center gap-1.5 transition shadow-sm cursor-pointer"
            >
              <Plus className="w-4 h-4" /> Add Variable
            </button>
          </form>
        </>
      }
    </div>
  );
}
