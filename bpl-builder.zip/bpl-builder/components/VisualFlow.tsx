/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  BplAstNode,
  ScriptNode,
  IfNode,
  AssignNode,
  IncludeNode,
  ImportNode,
  JumpNode,
  LabelNode,
  ReturnNode,
  LogNode,
  ErrorNode,
  SwitchNode,
  LoopNode,
  ApiCallNode,
  ValidationNode,
  BplConditionGroup,
  INodeType,
  NODE_TYPE,
  OnlyIfNode,
  ClearscreenNode,
} from '../types/bpl';
import { conditionToString } from '../utils/parser';
import {
  Settings,
  GitBranch,
  FileText,
  Bookmark,
  LogOut,
  Sparkles,
  Link,
  HelpCircle,
  Repeat,
  AlertOctagon,
  CornerDownRight,
  Database,
  ArrowRight,
  Eye,
  Play,
  CheckCircle2,
  XCircle,
  Trash2,
} from 'lucide-react';
import { AddNodeButton } from './AddNodeButton';
import GetKeyNodeRenderer from './Nodes/GetKeyNode';
import { OnlyIfNodeRenderer } from './Nodes/OnlyIfNode';
import { PromptNodeRenderer } from './Nodes/PromptNode';
import IfNodeRenderer from './Nodes/IfNode';
import { MacroNodeRenderer } from './Nodes/MacroNode';

interface VisualFlowProps {
  ast: ScriptNode;
  activeNodeId: string | null;
  executedNodeIds: Set<string>;
  skippedNodeIds: Set<string>;
  onSelectNode: (node: BplAstNode) => void;
  selectedNodeId: string | null;
  onAddNode: (targetNodeId: string, type: INodeType) => void;
  onDeleteNode: (nodeId: string) => void;
}

export default function VisualFlow({
  ast,
  activeNodeId,
  executedNodeIds,
  skippedNodeIds,
  onSelectNode,
  selectedNodeId,
  onAddNode,
  onDeleteNode,
}: VisualFlowProps) {
  return (
    <div className="p-6 overflow-y-auto max-h-[calc(100vh-14rem)] space-y-4 select-none">
      <div className="relative pl-4 border-l border-indigo-100 space-y-6">
        {/* Script Header */}
        <div className="relative -ml-[25px] flex items-center gap-3">
          <div className="w-4 h-4 rounded-full bg-indigo-600 border-4 border-white shadow-sm ring-1 ring-indigo-200 flex items-center justify-center" />
          <div className="bg-transparent border border-indigo-100 rounded-lg px-4 py-2 flex items-center gap-2">
            <Settings className="w-4 h-4 text-indigo-600" />
            <span className="text-xs font-semibold text-indigo-800 tracking-wide uppercase">
              Script: {ast.name}
            </span>
          </div>
        </div>

        {/* Start Insert Button */}
        <AddNodeButton onAdd={(type) => onAddNode('root', type)} className="-ml-[28px]" />

        {/* Children blocks */}
        <div className="space-y-4">
          {ast.children.map((child) => (
            <React.Fragment key={child.id}>
              <NodeRenderer
                node={child}
                activeNodeId={activeNodeId}
                executedNodeIds={executedNodeIds}
                skippedNodeIds={skippedNodeIds}
                onSelectNode={onSelectNode}
                selectedNodeId={selectedNodeId}
                onAddNode={onAddNode}
                onDeleteNode={onDeleteNode}
              />
              <AddNodeButton onAdd={(type) => onAddNode(child.id, type)} className="-ml-[28px]" />
            </React.Fragment>
          ))}
        </div>

        {/* Script Footer */}
        <div className="relative -ml-[25px] flex items-center gap-3 pt-4">
          <div className="w-4 h-4 rounded-full bg-gray-400 border-4 border-white shadow-sm ring-1 ring-gray-200" />
          <div className="bg-transparent border border-gray-100 rounded-lg px-3 py-1 text-xs text-gray-500">
            End Script
          </div>
        </div>
      </div>
    </div>
  );
}

interface NodeRendererProps {
  key?: string | number;
  node: BplAstNode;
  activeNodeId: string | null;
  executedNodeIds: Set<string>;
  skippedNodeIds: Set<string>;
  onSelectNode: (node: BplAstNode) => void;
  selectedNodeId: string | null;
  onAddNode: (targetNodeId: string, type: INodeType) => void;
  onDeleteNode: (nodeId: string) => void;
}

function NodeRenderer({
  node,
  activeNodeId,
  executedNodeIds,
  skippedNodeIds,
  onSelectNode,
  selectedNodeId,
  onAddNode,
  onDeleteNode,
}: NodeRendererProps) {
  const isActive = activeNodeId === node.id;
  const isExecuted = executedNodeIds.has(node.id);
  const isSkipped = skippedNodeIds.has(node.id);

  const getStatusBorder = () => {
    if (isActive) return 'border-indigo-500 shadow-lg ring-2 ring-indigo-200 animate-pulse';
    if (isExecuted) return 'border-emerald-300 shadow-sm';
    if (isSkipped) return 'border-gray-200 opacity-40 grayscale';
    return 'border-gray-200';
  };

  const getStatusBg = () => {
    if (isActive) return 'bg-white';
    if (isExecuted) return 'bg-white';
    if (isSkipped) return 'bg-gray-50';
    return 'bg-white';
  };

  const handleSelect = (e: React.MouseEvent) => {
    e.stopPropagation();
    onSelectNode(node);
  };

  const renderAddButton = (targetId: string, className?: string) => (
    <AddNodeButton
      onAdd={(type) => onAddNode(targetId, type)}
      className={className}
    />
  );

  const statusBadge = (
    <StatusBadge isActive={isActive} isExecuted={isExecuted} isSkipped={isSkipped} />
  );

  const renderNestedNode = (cb: BplAstNode) => (
    <NodeRenderer
      key={cb.id}
      node={cb}
      activeNodeId={activeNodeId}
      executedNodeIds={executedNodeIds}
      skippedNodeIds={skippedNodeIds}
      onSelectNode={onSelectNode}
      selectedNodeId={selectedNodeId}
      onAddNode={onAddNode}
      onDeleteNode={onDeleteNode}
    />
  );

  switch (node.type) {
    case 'log': {
      const logNode = node as LogNode;
      return (
        <motion.div
          layout
          onClick={handleSelect}
          className={`flex items-start gap-3 p-3.5 border rounded-xl cursor-pointer transition-all duration-300 max-w-xl ${getStatusBorder()} ${getStatusBg()} ${selectedNodeId === node.id ? 'ring-2 ring-indigo-500 ring-offset-1' : ''}`}
        >
          <div className="p-2 rounded-lg bg-gray-100 text-gray-600">
            <Eye className="w-4 h-4" />
          </div>
          <div className="flex-1 min-w-0">
            <div className="flex items-center justify-between gap-2">
              <span className="text-[10px] font-bold text-gray-400 uppercase tracking-wider">
                System Log
              </span>
              <div className="flex items-center gap-1.5" onClick={(e) => e.stopPropagation()}>
                <StatusBadge isActive={isActive} isExecuted={isExecuted} isSkipped={isSkipped} />
                <button
                  onClick={() => onDeleteNode(node.id)}
                  className="p-1 rounded text-gray-400 hover:text-rose-500 hover:bg-rose-50 transition cursor-pointer"
                  title="Delete node"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
            <p className="text-xs text-gray-700 font-mono mt-1 break-words">
              "{logNode.message}"
            </p>
          </div>
        </motion.div>
      );
    }

    case 'assign': {
      const assignNode = node as AssignNode;
      return (
        <motion.div
          layout
          onClick={handleSelect}
          className={`flex items-start gap-3 p-3.5 border rounded-xl cursor-pointer transition-all duration-300 max-w-xl ${getStatusBorder()} ${getStatusBg()} ${selectedNodeId === node.id ? 'ring-2 ring-indigo-500 ring-offset-1' : ''}`}
        >
          <div className="p-2 rounded-lg bg-teal-50 text-teal-600">
            <Bookmark className="w-4 h-4" />
          </div>
          <div className="flex-1 min-w-0">
            <div className="flex items-center justify-between gap-2">
              <span className="text-[10px] font-bold text-teal-500 uppercase tracking-wider">
                Assignment
              </span>
              <div className="flex items-center gap-1.5" onClick={(e) => e.stopPropagation()}>
                <StatusBadge isActive={isActive} isExecuted={isExecuted} isSkipped={isSkipped} />
                <button
                  onClick={() => onDeleteNode(node.id)}
                  className="p-1 rounded text-gray-400 hover:text-rose-500 hover:bg-rose-50 transition cursor-pointer"
                  title="Delete node"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
            <div className="flex items-center gap-1.5 mt-1 font-mono text-xs text-gray-700">
              <span className="font-semibold text-gray-900">{assignNode.variable}</span>
              <span className="text-gray-400">=</span>
              <span className="text-teal-600 font-semibold">"{assignNode.value}"</span>
            </div>
          </div>
        </motion.div>
      );
    }

    case 'include': {
      const incNode = node as IncludeNode;
      return (
        <motion.div
          layout
          onClick={handleSelect}
          className={`flex items-start gap-3 p-3.5 border rounded-xl cursor-pointer transition-all duration-300 max-w-xl ${getStatusBorder()} ${getStatusBg()} ${selectedNodeId === node.id ? 'ring-2 ring-indigo-500 ring-offset-1' : ''}`}
        >
          <div className="p-2 rounded-lg bg-sky-50 text-sky-600">
            <FileText className="w-4 h-4" />
          </div>
          <div className="flex-1 min-w-0">
            <div className="flex items-center justify-between gap-2">
              <span className="text-[10px] font-bold text-sky-500 uppercase tracking-wider">
                Include Template
              </span>
              <div className="flex items-center gap-1.5" onClick={(e) => e.stopPropagation()}>
                <StatusBadge isActive={isActive} isExecuted={isExecuted} isSkipped={isSkipped} />
                <button
                  onClick={() => onDeleteNode(node.id)}
                  className="p-1 rounded text-gray-400 hover:text-rose-500 hover:bg-rose-50 transition cursor-pointer"
                  title="Delete node"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
            <p className="text-xs font-semibold text-gray-800 mt-1 font-mono">
              "{incNode.path}"
            </p>
            {incNode.parameters && (
              <div className="flex items-center gap-1 mt-1.5">
                <span className="text-[9px] text-gray-400 uppercase font-semibold">Send Context:</span>
                <div className="flex flex-wrap gap-1">
                  {incNode.parameters.map((p) => (
                    <span key={p} className="text-[10px] font-mono bg-sky-50 text-sky-700 px-1.5 py-0.5 rounded">
                      {p}
                    </span>
                  ))}
                </div>
              </div>
            )}
          </div>
        </motion.div>
      );
    }

    case 'import': {
      const impNode = node as ImportNode;
      return (
        <motion.div
          layout
          onClick={handleSelect}
          className={`flex items-start gap-3 p-3.5 border rounded-xl cursor-pointer transition-all duration-300 max-w-xl ${getStatusBorder()} ${getStatusBg()} ${selectedNodeId === node.id ? 'ring-2 ring-indigo-500 ring-offset-1' : ''}`}
        >
          <div className="p-2 rounded-lg bg-indigo-50 text-indigo-600">
            <Link className="w-4 h-4" />
          </div>
          <div className="flex-1 min-w-0">
            <div className="flex items-center justify-between gap-2">
              <span className="text-[10px] font-bold text-indigo-500 uppercase tracking-wider">
                Import Script
              </span>
              <div className="flex items-center gap-1.5" onClick={(e) => e.stopPropagation()}>
                <StatusBadge isActive={isActive} isExecuted={isExecuted} isSkipped={isSkipped} />
                <button
                  onClick={() => onDeleteNode(node.id)}
                  className="p-1 rounded text-gray-400 hover:text-rose-500 hover:bg-rose-50 transition cursor-pointer"
                  title="Delete node"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
            <p className="text-xs font-semibold text-gray-800 mt-1 font-mono">
              "{impNode.file}"
            </p>
          </div>
        </motion.div>
      );
    }

    case 'jump': {
      const jumpNode = node as JumpNode;
      return (
        <motion.div
          layout
          onClick={handleSelect}
          className={`flex items-start gap-3 p-3.5 border rounded-xl cursor-pointer transition-all duration-300 max-w-xl ${getStatusBorder()} ${getStatusBg()} ${selectedNodeId === node.id ? 'ring-2 ring-indigo-500 ring-offset-1' : ''}`}
        >
          <div className="p-2 rounded-lg bg-amber-50 text-amber-600">
            <ArrowRight className="w-4 h-4" />
          </div>
          <div className="flex-1 min-w-0">
            <div className="flex items-center justify-between gap-2">
              <span className="text-[10px] font-bold text-amber-500 uppercase tracking-wider">
                Jump Unconditional
              </span>
              <div className="flex items-center gap-1.5" onClick={(e) => e.stopPropagation()}>
                <StatusBadge isActive={isActive} isExecuted={isExecuted} isSkipped={isSkipped} />
                <button
                  onClick={() => onDeleteNode(node.id)}
                  className="p-1 rounded text-gray-400 hover:text-rose-500 hover:bg-rose-50 transition cursor-pointer"
                  title="Delete node"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
            <div className="flex items-center gap-1.5 mt-1 text-xs">
              <span className="text-gray-500">Jump to label:</span>
              <span className="font-mono font-bold text-amber-600 bg-amber-50 px-1.5 py-0.5 rounded">
                {jumpNode.target}
              </span>
            </div>
          </div>
        </motion.div>
      );
    }

    case 'label': {
      const labelNode = node as LabelNode;
      return (
        <motion.div
          layout
          onClick={handleSelect}
          className={`relative flex items-center justify-between -ml-[25px] w-fit p-1.5 px-3 border rounded-lg cursor-pointer bg-transparent border-slate-200 hover:border-slate-300 transition-all gap-3 ${selectedNodeId === node.id ? 'ring-2 ring-indigo-500 ring-offset-1' : ''}`}
        >
          <div className="flex items-center gap-2">
            <div className="w-2.5 h-2.5 rounded-full bg-slate-400 border-2 border-white shadow" />
            <span className="text-[10px] font-bold text-slate-500 font-mono tracking-wider">
              {labelNode.name}::
            </span>
          </div>
          <div className="flex items-center gap-1.5" onClick={(e) => e.stopPropagation()}>
            {isActive && (
              <span className="w-2 h-2 rounded-full bg-indigo-500 animate-ping mr-1" />
            )}
            <button
              onClick={() => onDeleteNode(node.id)}
              className="p-0.5 rounded text-gray-400 hover:text-rose-500 hover:bg-rose-50 transition cursor-pointer"
              title="Delete node"
            >
              <Trash2 className="w-3 h-3" />
            </button>
          </div>
        </motion.div>
      );
    }

    case 'return': {
      return (
        <motion.div
          layout
          onClick={handleSelect}
          className={`flex items-start gap-3 p-3.5 border rounded-xl cursor-pointer transition-all duration-300 max-w-xl ${getStatusBorder()} ${getStatusBg()} ${selectedNodeId === node.id ? 'ring-2 ring-indigo-500 ring-offset-1' : ''}`}
        >
          <div className="p-2 rounded-lg bg-rose-50 text-rose-600">
            <LogOut className="w-4 h-4" />
          </div>
          <div className="flex-1 min-w-0">
            <div className="flex items-center justify-between gap-2">
              <span className="text-[10px] font-bold text-rose-500 uppercase tracking-wider">
                Halt Return
              </span>
              <div className="flex items-center gap-1.5" onClick={(e) => e.stopPropagation()}>
                <StatusBadge isActive={isActive} isExecuted={isExecuted} isSkipped={isSkipped} />
                <button
                  onClick={() => onDeleteNode(node.id)}
                  className="p-1 rounded text-gray-400 hover:text-rose-500 hover:bg-rose-50 transition cursor-pointer"
                  title="Delete node"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
            <p className="text-xs text-rose-700 font-semibold mt-1">
              Terminate Rules Execution (Success)
            </p>
          </div>
        </motion.div>
      );
    }

    case 'validation': {
      const valNode = node as ValidationNode;
      const condText = typeof valNode.condition === 'string' ? valNode.condition : conditionToString(valNode.condition);
      return (
        <motion.div
          layout
          onClick={handleSelect}
          className={`flex items-start gap-3 p-3.5 border rounded-xl cursor-pointer transition-all duration-300 max-w-xl ${getStatusBorder()} ${getStatusBg()} ${selectedNodeId === node.id ? 'ring-2 ring-indigo-500 ring-offset-1' : ''}`}
        >
          <div className="p-2 rounded-lg bg-rose-50 text-rose-600">
            <AlertOctagon className="w-4 h-4" />
          </div>
          <div className="flex-1 min-w-0">
            <div className="flex items-center justify-between gap-2">
              <span className="text-[10px] font-bold text-rose-500 uppercase tracking-wider">
                Assertion Constraint
              </span>
              <div className="flex items-center gap-1.5" onClick={(e) => e.stopPropagation()}>
                <StatusBadge isActive={isActive} isExecuted={isExecuted} isSkipped={isSkipped} />
                <button
                  onClick={() => onDeleteNode(node.id)}
                  className="p-1 rounded text-gray-400 hover:text-rose-500 hover:bg-rose-50 transition cursor-pointer"
                  title="Delete node"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
            <div className="mt-1">
              <p className="text-xs text-gray-500">Require condition:</p>
              <p className="text-xs font-mono font-bold text-slate-800 mt-0.5 bg-slate-50 p-1 rounded border border-slate-100">
                {condText}
              </p>
              <div className="mt-2 text-xs text-rose-600 flex items-center gap-1.5 font-semibold bg-rose-50/50 p-1.5 rounded">
                <span className="text-[10px] bg-rose-200 text-rose-800 px-1 py-0.5 rounded font-bold uppercase">Or Error:</span>
                "{valNode.errorMessage}"
              </div>
            </div>
          </div>
        </motion.div>
      );
    }

    case 'api-call': {
      const apiNode = node as ApiCallNode;
      return (
        <motion.div
          layout
          onClick={handleSelect}
          className={`flex items-start gap-3 p-3.5 border rounded-xl cursor-pointer transition-all duration-300 max-w-xl ${getStatusBorder()} ${getStatusBg()} ${selectedNodeId === node.id ? 'ring-2 ring-indigo-500 ring-offset-1' : ''}`}
        >
          <div className="p-2 rounded-lg bg-violet-50 text-violet-600">
            <Database className="w-4 h-4" />
          </div>
          <div className="flex-1 min-w-0">
            <div className="flex items-center justify-between gap-2">
              <span className="text-[10px] font-bold text-violet-500 uppercase tracking-wider">
                Service API Call
              </span>
              <div className="flex items-center gap-1.5" onClick={(e) => e.stopPropagation()}>
                <StatusBadge isActive={isActive} isExecuted={isExecuted} isSkipped={isSkipped} />
                <button
                  onClick={() => onDeleteNode(node.id)}
                  className="p-1 rounded text-gray-400 hover:text-rose-500 hover:bg-rose-50 transition cursor-pointer"
                  title="Delete node"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
            <p className="text-xs font-semibold text-gray-800 mt-1 font-mono break-all bg-gray-50 p-1 rounded">
              {apiNode.url}
            </p>
            <div className="mt-2 flex flex-col gap-1 text-xs">
              {apiNode.parameters && apiNode.parameters.length > 0 && (
                <div className="flex items-center gap-1">
                  <span className="text-[9px] text-gray-400 font-bold uppercase">Payload send:</span>
                  <div className="flex gap-1">
                    {apiNode.parameters.map((p) => (
                      <span key={p} className="text-[9px] bg-slate-100 text-slate-600 px-1 py-0.2 rounded font-mono">{p}</span>
                    ))}
                  </div>
                </div>
              )}
              <div className="flex items-center gap-1.5">
                <span className="text-[9px] text-gray-400 font-bold uppercase">Bind result:</span>
                <span className="text-[10px] font-mono font-semibold text-violet-700 bg-violet-50 px-1 py-0.5 rounded">
                  {apiNode.responseVar}
                </span>
              </div>
            </div>
          </div>
        </motion.div>
      );
    }

    case 'loop': {
      const loopNode = node as LoopNode;
      return (
        <motion.div
          layout
          className={`border rounded-xl p-4 transition-all duration-300 max-w-xl ${getStatusBorder()} bg-transparent`}
        >
          <div
            onClick={handleSelect}
            className={`flex items-start gap-3 pb-3 cursor-pointer ${selectedNodeId === node.id ? 'bg-indigo-50/20 -mx-2 px-2 py-1 rounded' : ''}`}
          >
            <div className="p-2 rounded-lg bg-emerald-50 text-emerald-600">
              <Repeat className="w-4 h-4" />
            </div>
            <div className="flex-1">
              <div className="flex items-center justify-between gap-2">
                <span className="text-[10px] font-bold text-emerald-500 uppercase tracking-wider">
                  Loop Iteration
                </span>
                <div className="flex items-center gap-1.5" onClick={(e) => e.stopPropagation()}>
                  <StatusBadge isActive={isActive} isExecuted={isExecuted} isSkipped={isSkipped} />
                  <button
                    onClick={() => onDeleteNode(node.id)}
                    className="p-1 rounded text-gray-400 hover:text-rose-500 hover:bg-rose-50/50 transition cursor-pointer"
                    title="Delete node"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
              <div className="flex items-center gap-1 mt-1 text-xs text-gray-700">
                <span>For each</span>
                <span className="font-mono font-bold text-emerald-600 bg-emerald-50 px-1.5 rounded">{loopNode.itemVar}</span>
                <span>in</span>
                <span className="font-mono font-bold text-emerald-600 bg-emerald-50 px-1.5 rounded">{loopNode.collectionVar}</span>
              </div>
            </div>
          </div>

          {/* Loop Inner lanes */}
          <div className="relative pl-6 ml-4 border-l-2 border-dashed border-emerald-200 mt-2 space-y-4 pt-2">
            <div className="absolute top-0 left-0 -ml-[5px] w-2.5 h-2.5 rounded-full bg-emerald-300" />
            {loopNode.block.map((cb) => (
              <React.Fragment key={cb.id}>
                <NodeRenderer
                  node={cb}
                  activeNodeId={activeNodeId}
                  executedNodeIds={executedNodeIds}
                  skippedNodeIds={skippedNodeIds}
                  onSelectNode={onSelectNode}
                  selectedNodeId={selectedNodeId}
                  onAddNode={onAddNode}
                  onDeleteNode={onDeleteNode}
                />
                <AddNodeButton onAdd={(type) => onAddNode(cb.id, type)} className="-ml-[36px]" />
              </React.Fragment>
            ))}
          </div>
        </motion.div>
      );
    }

    case 'switch': {
      const switchNode = node as SwitchNode;
      return (
        <motion.div
          layout
          className={`border rounded-xl p-4 transition-all duration-300 max-w-xl ${getStatusBorder()} bg-transparent`}
        >
          <div
            onClick={handleSelect}
            className={`flex items-start gap-3 pb-3 cursor-pointer ${selectedNodeId === node.id ? 'bg-indigo-50/20 -mx-2 px-2 py-1 rounded' : ''}`}
          >
            <div className="p-2 rounded-lg bg-purple-50 text-purple-600">
              <GitBranch className="w-4 h-4 animate-pulse" />
            </div>
            <div className="flex-1">
              <div className="flex items-center justify-between gap-2">
                <span className="text-[10px] font-bold text-purple-500 uppercase tracking-wider">
                  Switch Selector
                </span>
                <div className="flex items-center gap-1.5" onClick={(e) => e.stopPropagation()}>
                  <StatusBadge isActive={isActive} isExecuted={isExecuted} isSkipped={isSkipped} />
                  <button
                    onClick={() => onDeleteNode(node.id)}
                    className="p-1 rounded text-gray-400 hover:text-rose-500 hover:bg-rose-50/50 transition cursor-pointer"
                    title="Delete node"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
              <div className="flex items-center gap-1 mt-1 text-xs text-gray-700">
                <span>Evaluate Cases on</span>
                <span className="font-mono font-bold text-purple-600 bg-purple-50 px-1.5 rounded">{switchNode.variable}</span>
              </div>
            </div>
          </div>

          {/* Switch Case lanes */}
          <div className="mt-3 space-y-4">
            {switchNode.cases.map((c, idx) => (
              <div key={idx} className="relative pl-6 ml-4 border-l border-purple-200">
                <div className="absolute top-2 left-0 -ml-[5px] w-2 h-2 rounded-full bg-purple-300" />
                <div className="flex items-center justify-between gap-2 mb-2">
                  <div className="flex items-center gap-2">
                    <span className="text-[10px] uppercase font-bold text-purple-400">Case Match:</span>
                    <span className="text-xs font-mono font-semibold bg-purple-50 text-purple-700 px-2 py-0.5 rounded border border-purple-100">
                      "{c.value}"
                    </span>
                  </div>
                </div>
                <div className="space-y-4 pt-1">
                  {c.block.map((cb) => (
                    <React.Fragment key={cb.id}>
                      <NodeRenderer
                        node={cb}
                        activeNodeId={activeNodeId}
                        executedNodeIds={executedNodeIds}
                        skippedNodeIds={skippedNodeIds}
                        onSelectNode={onSelectNode}
                        selectedNodeId={selectedNodeId}
                        onAddNode={onAddNode}
                        onDeleteNode={onDeleteNode}
                      />
                      <AddNodeButton onAdd={(type) => onAddNode(cb.id, type)} className="-ml-[36px]" />
                    </React.Fragment>
                  ))}
                </div>
              </div>
            ))}

            {switchNode.defaultBlock && (
              <div className="relative pl-6 ml-4 border-l border-purple-200">
                <div className="absolute top-2 left-0 -ml-[5px] w-2 h-2 rounded-full bg-slate-300" />
                <div className="flex items-center gap-2 mb-2">
                  <span className="text-[10px] uppercase font-bold text-slate-400">Default Case</span>
                </div>
                <div className="space-y-4 pt-1">
                  {switchNode.defaultBlock.map((cb) => (
                    <React.Fragment key={cb.id}>
                      <NodeRenderer
                        node={cb}
                        activeNodeId={activeNodeId}
                        executedNodeIds={executedNodeIds}
                        skippedNodeIds={skippedNodeIds}
                        onSelectNode={onSelectNode}
                        selectedNodeId={selectedNodeId}
                        onAddNode={onAddNode}
                        onDeleteNode={onDeleteNode}
                      />
                      <AddNodeButton onAdd={(type) => onAddNode(cb.id, type)} className="-ml-[36px]" />
                    </React.Fragment>
                  ))}
                </div>
              </div>
            )}
          </div>
        </motion.div>
      );
    }

    case NODE_TYPE.IF: {
      return <IfNodeRenderer
        node={node as IfNode}
        selectedNodeId={selectedNodeId}
        onSelect={handleSelect}
        onDelete={() => onDeleteNode(node.id)}
        statusBadge={statusBadge}
        getStatusBorder={getStatusBorder}
        renderNode={renderNestedNode}
        renderAddButton={renderAddButton}
      />
    }

    case NODE_TYPE.ONLY_IF: {
      return <OnlyIfNodeRenderer
        node={node as OnlyIfNode}
        selectedNodeId={selectedNodeId}
        onSelect={handleSelect}
        onDelete={() => onDeleteNode(node.id)}
        statusBadge={statusBadge}
        getStatusBorder={getStatusBorder}
        renderNode={renderNestedNode}
        getStatusBg={getStatusBg}
        renderAddButton={renderAddButton}
      />
    }

    case NODE_TYPE.CLEARSCREEN: {
      return (
        <motion.div
          layout
          onClick={handleSelect}
          className={`relative flex items-center justify-between -ml-[25px] w-fit p-1.5 px-3 border rounded-lg cursor-pointer bg-transparent border-slate-200 hover:border-slate-300 transition-all gap-3 ${selectedNodeId === node.id ? 'ring-2 ring-indigo-500 ring-offset-1' : ''}`}
        >
          <div className="flex items-center gap-2">
            <div className="w-2.5 h-2.5 rounded-full bg-slate-400 border-2 border-white shadow" />
            <span className="text-[10px] font-bold text-slate-500 font-mono tracking-wider">
              Clearscreen
            </span>
          </div>
          <div className="flex items-center gap-1.5" onClick={(e) => e.stopPropagation()}>
            {isActive && (
              <span className="w-2 h-2 rounded-full bg-indigo-500 animate-ping mr-1" />
            )}
            <button
              onClick={() => onDeleteNode(node.id)}
              className="p-0.5 rounded text-gray-400 hover:text-rose-500 hover:bg-rose-50 transition cursor-pointer"
              title="Delete node"
            >
              <Trash2 className="w-3 h-3" />
            </button>
          </div>
        </motion.div>
      );
    }

    case NODE_TYPE.GETKEY: {
      return <GetKeyNodeRenderer
        node={node}
        selectedNodeId={selectedNodeId}
        onSelect={handleSelect}
        onDelete={() => onDeleteNode(node.id)}
        statusBadge={<StatusBadge isActive={isActive} isExecuted={isExecuted} isSkipped={isSkipped} />}
        getStatusBorder={getStatusBorder}
        getStatusBg={getStatusBg}
      />
    }

    case NODE_TYPE.PROMPT: {
      return <PromptNodeRenderer
        node={node}
        selectedNodeId={selectedNodeId}
        onSelect={handleSelect}
        onDelete={() => onDeleteNode(node.id)}
        statusBadge={<StatusBadge isActive={isActive} isExecuted={isExecuted} isSkipped={isSkipped} />}
        getStatusBorder={getStatusBorder}
        getStatusBg={getStatusBg}
      />
    }

    case NODE_TYPE.MARCRO:
      return (
        <MacroNodeRenderer
          node={node as any}
          selectedNodeId={selectedNodeId}
          onSelect={handleSelect}
          onDelete={() => onDeleteNode(node.id)}
          statusBadge={statusBadge}
          getStatusBorder={getStatusBorder}
          renderNode={renderNestedNode}
          renderAddButton={renderAddButton}
        />
      );

    default:
      return null;
  }
}

interface StatusBadgeProps {
  isActive: boolean;
  isExecuted: boolean;
  isSkipped: boolean;
}

function StatusBadge({ isActive, isExecuted, isSkipped }: StatusBadgeProps) {
  if (isActive) {
    return (
      <span className="flex items-center gap-1 text-[9px] font-bold text-indigo-600 uppercase bg-indigo-50 px-1.5 py-0.5 rounded tracking-wide animate-pulse">
        <Play className="w-2.5 h-2.5 fill-indigo-600" /> Active
      </span>
    );
  }
  if (isExecuted) {
    return (
      <span className="flex items-center gap-0.5 text-[9px] font-bold text-emerald-600 uppercase bg-emerald-50 px-1.5 py-0.5 rounded tracking-wide">
        <CheckCircle2 className="w-2.5 h-2.5" /> Fired
      </span>
    );
  }
  if (isSkipped) {
    return (
      <span className="flex items-center gap-0.5 text-[9px] font-bold text-gray-400 uppercase bg-gray-100 px-1.5 py-0.5 rounded tracking-wide">
        <XCircle className="w-2.5 h-2.5" /> Skipped
      </span>
    );
  }
  return null;
}