import React from 'react';
import { Play, Pause, ChevronLeft, ChevronRight, Sliders, FileText, Database, Terminal, Hash, ToggleLeft, Type } from 'lucide-react';
import { TraceStep, VariableState } from '../types/bpl';
import TraceControls from './TraceControls';
import VariableEditor from './VariableEditor';

interface SimulatorTabProps {
  traceSteps: TraceStep[];
  currentStepIndex: number;
  setCurrentStepIndex: (idx: number | ((prev: number) => number)) => void;
  isPlaying: boolean;
  setIsPlaying: (playing: boolean | ((prev: boolean) => boolean)) => void;
  playbackSpeed: number;
  setPlaybackSpeed: (speed: number) => void;
  activeVariables: VariableState;
  activeLogs: string[];
  activeIncludes: any[];
  variables: VariableState;
  handleUpdateVariableValue: (key: string, val: any) => void;
  handleRemoveVariable: (key: string) => void;
}

export default function SimulatorTab({
  traceSteps,
  currentStepIndex,
  setCurrentStepIndex,
  isPlaying,
  setIsPlaying,
  playbackSpeed,
  setPlaybackSpeed,
  activeVariables,
  activeLogs,
  activeIncludes,
  variables,
  handleUpdateVariableValue,
  handleRemoveVariable
}: SimulatorTabProps) {

  const handleStepForward = () => {
    if (currentStepIndex < traceSteps.length - 1) {
      setCurrentStepIndex((prev) => prev + 1);
    }
  };

  const handleStepBackward = () => {
    if (currentStepIndex > 0) {
      setCurrentStepIndex((prev) => prev - 1);
    }
  };

  const handleResetTrace = () => {
    setCurrentStepIndex(0);
    setIsPlaying(false);
  };

  return (
    <div className="space-y-4 text-left">
      {/* 1. Playback trace controls */}
      <TraceControls
        currentStepIndex={currentStepIndex}
        totalSteps={traceSteps.length}
        isPlaying={isPlaying}
        onPlayToggle={() => setIsPlaying((p) => !p)}
        onStepForward={handleStepForward}
        onStepBackward={handleStepBackward}
        onResetTrace={handleResetTrace}
        speed={playbackSpeed}
        onChangeSpeed={setPlaybackSpeed}
        currentDescription={traceSteps[currentStepIndex].description ?? ''}
      />

      {/* 2. Variable Editor */}
      <VariableEditor
        variables={variables}
        handleUpdateVariableValue={handleUpdateVariableValue}
        handleRemoveVariable={handleRemoveVariable}
      />

      {/* 3. Live variables / watch values */}
      <div className="bg-white border border-gray-100 rounded-xl p-5 shadow-xs space-y-3.5">
        <div className="flex items-center justify-between border-b border-gray-50 pb-2">
          <div className="flex items-center gap-1.5 text-indigo-600 font-semibold text-xs uppercase tracking-wide">
            <Database className="w-4 h-4 text-indigo-500" /> State variables
          </div>
          <span className="text-[10px] text-gray-400 font-mono font-bold">Watchlist</span>
        </div>

        <div className="space-y-2 max-h-[14rem] overflow-y-auto pr-1">
          {Object.keys(activeVariables).length === 0 ? (
            <p className="text-[11px] text-gray-400 italic text-center py-2">
              No state variables declared in scope.
            </p>
          ) : (
            Object.entries(activeVariables).map(([key, val]) => {
              const isArray = Array.isArray(val) || typeof val === 'object';
              return (
                <div
                  key={key}
                  className="flex items-center justify-between gap-4 p-2.5 bg-gray-50 hover:bg-gray-100/60 border border-gray-200 rounded-xl transition"
                >
                  <div className="flex items-center gap-1.5 min-w-0">
                    {typeof val === 'number' && <Hash className="w-3.5 h-3.5 text-blue-500 shrink-0" />}
                    {typeof val === 'boolean' && <ToggleLeft className="w-3.5 h-3.5 text-amber-500 shrink-0" />}
                    {typeof val === 'string' && <Type className="w-3.5 h-3.5 text-teal-500 shrink-0" />}
                    {isArray && <Database className="w-3.5 h-3.5 text-purple-500 shrink-0" />}
                    <span className="text-xs font-mono font-semibold text-gray-700 truncate" title={key}>
                      {key}
                    </span>
                  </div>
                  <div className="font-mono text-xs font-bold text-gray-800 select-all shrink-0 max-w-[50%] truncate">
                    {isArray ? (
                      <span className="text-purple-600 font-semibold" title={JSON.stringify(val)}>
                        {JSON.stringify(val)}
                      </span>
                    ) : typeof val === 'boolean' ? (
                      <span className="text-amber-600">
                        {val ? 'TRUE' : 'FALSE'}
                      </span>
                    ) : typeof val === 'number' ? (
                      <span className="text-blue-600">
                        {val}
                      </span>
                    ) : (
                      <span className="text-teal-600">
                        "{val}"
                      </span>
                    )}
                  </div>
                </div>
              );
            })
          )}
        </div>
      </div>

      {/* 4. Active output documents */}
      <div className="bg-white border border-gray-100 rounded-xl p-5 shadow-xs space-y-3">
        <div className="flex items-center gap-1.5 text-indigo-600 font-semibold text-xs border-b border-gray-50 pb-2 uppercase tracking-wider">
          <FileText className="w-4 h-4 text-sky-500" /> Document Outputs
        </div>
        {activeIncludes.length === 0 ? (
          <p className="text-[11px] text-gray-400 italic text-center py-4 select-none">
            No include rules matched. Included templates will display here as active document outputs.
          </p>
        ) : (
          <div className="space-y-2">
            {activeIncludes.map((inc, i) => (
              <div
                key={i}
                className="p-2.5 bg-sky-50 border border-sky-100 rounded-xl flex items-center justify-between"
              >
                <div className="min-w-0">
                  <span className="text-[10px] font-bold text-sky-700 font-mono block break-all">
                    {inc.path}
                  </span>
                  <span className="text-[9px] text-gray-400 block mt-0.5">
                    Status: Included & Rendered
                  </span>
                </div>
                <span className="text-[9px] bg-sky-200 text-sky-800 px-1.5 py-0.5 rounded font-bold uppercase tracking-wider select-none shrink-0">
                  PDF Chunk
                </span>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* 5. Terminal style system logs */}
      <div className="bg-slate-900 border border-slate-850 rounded-xl p-5 shadow-lg flex-1 flex flex-col space-y-3 min-h-[14rem] overflow-hidden">
        <div className="flex items-center gap-1.5 text-slate-300 font-mono text-xs font-semibold border-b border-slate-800 pb-2 select-none uppercase tracking-wider">
          <Terminal className="w-4 h-4 text-teal-400" /> Diagnostic Logs
        </div>
        <div className="flex-1 overflow-y-auto font-mono text-[10px] text-slate-300 space-y-2 select-text pr-1">
          {activeLogs.length === 0 ? (
            <p className="text-slate-500 italic text-center py-8">
              No logs printed. Click Play or Step Forward.
            </p>
          ) : (
            activeLogs.map((log, i) => {
              let textClass = 'text-slate-300';
              if (log.includes('[Assign]')) textClass = 'text-teal-300';
              if (log.includes('[Include]')) textClass = 'text-sky-300';
              if (log.includes('[Jump]')) textClass = 'text-amber-300';
              if (log.includes('[ValidationError]')) textClass = 'text-rose-400 font-bold';
              if (log.includes('[System]')) textClass = 'text-indigo-400 font-semibold';

              return (
                <div key={i} className="flex gap-1">
                  <span className="text-slate-600 select-none">&gt;</span>
                  <p className={`${textClass} leading-relaxed break-words`}>{log}</p>
                </div>
              );
            })
          )}
        </div>
      </div>
    </div>
  );
}
