import { BplAstNode, SwitchNode } from "@/components/bpl-builder/types/bpl"

interface SwitchNodeEditorProps {
    node: SwitchNode,
    onUpdateNodeProperty: (nodeId: string, updatedFields: Partial<BplAstNode>) => void;
}

export const SwitchNodeEditor = ({ node, onUpdateNodeProperty }: SwitchNodeEditorProps) => {
    return <div className="space-y-1.5">
        <label className="text-[10px] uppercase font-bold text-gray-400 block">
            Switch Variable Name
        </label>
        <input
            type="text"
            value={(node as SwitchNode).variable}
            onChange={(e) =>
                onUpdateNodeProperty(node.id, { variable: e.target.value })
            }
            placeholder="e.g. scoreRating, riskLevel"
            className="w-full px-2.5 py-1.5 border border-gray-200 rounded-lg text-xs font-mono focus:ring-1 focus:ring-indigo-500 focus:outline-none bg-slate-50/50"
        />
    </div>
}