import { AssignNode, BplAstNode } from "@/components/bpl-builder/types/bpl"
import { Database, Type } from "lucide-react";

interface AssignNodeEditorProps {
    node: AssignNode,
    onUpdateNodeProperty: (nodeId: string, updatedFields: Partial<BplAstNode>) => void;
}

export const AssignNodeEditor = ({ node, onUpdateNodeProperty }: AssignNodeEditorProps) => {
    return <div className="space-y-3">
        <div>
            <label className="text-[10px] uppercase font-bold text-gray-400 block mb-1">
                Target Variable
            </label>
            <div className="relative">
                <Database className="absolute left-2.5 top-2 w-3.5 h-3.5 text-gray-400" />
                <input
                    type="text"
                    value={(node as AssignNode).variable}
                    onChange={(e) =>
                        onUpdateNodeProperty(node.id, { variable: e.target.value })
                    }
                    placeholder="e.g. approvedCount, discount"
                    className="w-full pl-8 pr-2.5 py-1.5 border border-gray-200 rounded-lg text-xs font-mono focus:ring-1 focus:ring-indigo-500 focus:outline-none bg-slate-50/50 font-bold"
                />
            </div>
        </div>

        <div>
            <label className="text-[10px] uppercase font-bold text-gray-400 block mb-1">
                Expression / Value
            </label>
            <div className="relative flex items-center">
                <input
                    type="text"
                    value={(node as AssignNode).value}
                    onChange={(e) =>
                        onUpdateNodeProperty(node.id, { value: e.target.value })
                    }
                    placeholder={(node as AssignNode).isValueIdentifier ? "e.g. age, scoreRating" : "e.g. 10, Approved, true"}
                    className="w-full pl-3 pr-8 py-1.5 border border-gray-200 rounded-lg text-xs font-mono focus:ring-1 focus:ring-indigo-500 focus:outline-none bg-slate-50/50"
                />
                <button
                    type="button"
                    onClick={() =>
                        onUpdateNodeProperty(node.id, {
                            isValueIdentifier: !(node as AssignNode).isValueIdentifier,
                        })
                    }
                    className={`absolute right-2 p-1.5 rounded transition cursor-pointer ${(node as AssignNode).isValueIdentifier
                        ? 'text-indigo-600 bg-indigo-50 hover:bg-indigo-100'
                        : 'text-gray-400 hover:bg-gray-100'
                        }`}
                    title={(node as AssignNode).isValueIdentifier ? "Assigning value of another variable (dynamic)" : "Assigning constant literal (static)"}
                >
                    {(node as AssignNode).isValueIdentifier ? <Database className="w-4 h-4" /> : <Type className="w-4 h-4" />}
                </button>
            </div>
        </div>
    </div>
}