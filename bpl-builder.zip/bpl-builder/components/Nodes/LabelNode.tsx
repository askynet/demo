import { BplAstNode, LabelNode } from "@/components/bpl-builder/types/bpl"
import { GitCommit } from "lucide-react";

interface LabelNodeEditorProps {
    node: LabelNode,
    onUpdateNodeProperty: (nodeId: string, updatedFields: Partial<BplAstNode>) => void;
}

export const LabelNodeEditor = ({ node, onUpdateNodeProperty }: LabelNodeEditorProps) => {
    return <div className="space-y-1.5">
        <label className="text-[10px] uppercase font-bold text-gray-400 block">
            Label Name
        </label>
        <div className="relative">
            <GitCommit className="absolute left-2.5 top-2 w-3.5 h-3.5 text-amber-500" />
            <input
                type="text"
                value={(node as LabelNode).name}
                onChange={(e) =>
                    onUpdateNodeProperty(node.id, { name: e.target.value })
                }
                placeholder="e.g. exitEarly, processDetails"
                className="w-full pl-8 pr-2.5 py-1.5 border border-gray-200 rounded-lg text-xs font-mono focus:ring-1 focus:ring-indigo-500 focus:outline-none bg-slate-50/50 text-amber-700 font-bold"
            />
        </div>
    </div>
}