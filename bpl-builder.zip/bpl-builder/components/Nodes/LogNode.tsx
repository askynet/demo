import { BplAstNode, LogNode } from "@/components/bpl-builder/types/bpl"

interface LogNodeEditorProps {
    node: LogNode,
    onUpdateNodeProperty: (nodeId: string, updatedFields: Partial<BplAstNode>) => void;
}

export const LogNodeEditor = ({ node, onUpdateNodeProperty }: LogNodeEditorProps) => {
    return <div className="space-y-1.5">
        <label className="text-[10px] uppercase font-bold text-gray-400 block">
            Log Message
        </label>
        <textarea
            rows={2}
            value={(node as LogNode).message}
            onChange={(e) =>
                onUpdateNodeProperty(node.id, { message: e.target.value })
            }
            placeholder="System message. Supports variables like ${user.name}"
            className="w-full px-2.5 py-1.5 border border-gray-200 rounded-lg text-xs font-mono focus:ring-1 focus:ring-indigo-500 focus:outline-none bg-slate-50/50 leading-relaxed"
        />
    </div>
}