import { Database } from 'lucide-react';
import { BplAstNode, PromptNode } from '../../types/bpl';
import { MessageSquare, Trash2 } from 'lucide-react';

interface PromptNodeEditorProps {
    node: PromptNode;
    onUpdateNodeProperty: (nodeId: string, updatedFields: Partial<BplAstNode>) => void;
}

export function PromptNodeEditor({ node, onUpdateNodeProperty }: PromptNodeEditorProps) {
    return (
        <div className="space-y-3.5 font-mono text-[11px]">
            <div>
                <label className="text-[10px] uppercase font-bold text-gray-400 block mb-1">
                    Prompt Message Label
                </label>
                <textarea
                    rows={2}
                    value={node.message}
                    onChange={(e) => onUpdateNodeProperty(node.id, { message: e.target.value })}
                    placeholder="Display text for the user input prompt"
                    className="w-full px-2.5 py-1.5 border border-gray-200 rounded-lg text-xs font-mono focus:ring-1 focus:ring-indigo-500 focus:outline-none bg-slate-50/50 leading-relaxed"
                />
            </div>

            <div>
                <label className="text-[10px] uppercase font-bold text-gray-400 block mb-1">
                    Target Storage Variable
                </label>
                <div className="relative">
                    <Database className="absolute left-2.5 top-2 w-3.5 h-3.5 text-indigo-400" />
                    <input
                        type="text"
                        value={node.variable || ''}
                        onChange={(e) => onUpdateNodeProperty(node.id, { variable: e.target.value })}
                        placeholder="e.g. telehealth_net_ov_coins"
                        className="w-full pl-8 pr-2.5 py-1.5 border border-gray-200 rounded-lg text-xs font-mono focus:ring-1 focus:ring-indigo-500 focus:outline-none bg-slate-50/50 font-bold"
                    />
                </div>
            </div>
        </div>
    );
}


interface PromptNodeRendererProps {
    node: PromptNode;
    selectedNodeId: string | null;
    onSelect: (e: React.MouseEvent) => void;
    onDelete: () => void;
    statusBadge: React.ReactNode;
    getStatusBorder: () => string;
    getStatusBg: () => string;
}

export function PromptNodeRenderer({
    node,
    selectedNodeId,
    onSelect,
    onDelete,
    statusBadge,
    getStatusBorder,
    getStatusBg,
}: PromptNodeRendererProps) {
    return (
        <div
            onClick={onSelect}
            className={`flex items-start gap-3 p-3.5 border rounded-xl cursor-pointer transition-all duration-300 max-w-xl ${getStatusBorder()} ${getStatusBg()} ${selectedNodeId === node.id ? 'ring-2 ring-indigo-500 ring-offset-1' : `${getStatusBorder()}`}`}
        >
            <div className="p-2 rounded-lg bg-indigo-50 text-indigo-600">
                <MessageSquare className="w-4 h-4" />
            </div>
            <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between gap-2">
                    <span className="text-[10px] font-bold text-indigo-500 uppercase tracking-wider font-mono">
                        Interactive Prompt
                    </span>
                    <div className="flex items-center gap-1.5" onClick={(e) => e.stopPropagation()}>
                        {statusBadge}
                        <button
                            onClick={onDelete}
                            className="p-1 rounded text-gray-400 hover:text-rose-500 hover:bg-rose-50 transition cursor-pointer"
                            title="Delete node"
                        >
                            <Trash2 className="w-3.5 h-3.5" />
                        </button>
                    </div>
                </div>
                <p className="text-xs text-gray-700 font-mono mt-1 bg-white border border-gray-150 p-2 rounded-lg leading-relaxed shadow-3xs">
                    "{node.message}"
                </p>
                {node.variable && (
                    <div className="mt-2 text-xs flex items-center gap-1.5 font-semibold bg-indigo-50/50 px-2 py-1 rounded-md w-fit">
                        <span className="text-[9px] text-indigo-500 uppercase font-bold">Store input in:</span>
                        <span className="font-mono text-indigo-700 bg-indigo-100/50 px-1 py-0.2 rounded">{node.variable}</span>
                    </div>
                )}
            </div>
        </div>
    );
}