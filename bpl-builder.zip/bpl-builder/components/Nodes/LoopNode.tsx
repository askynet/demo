import { BplAstNode, LoopNode } from "@/components/bpl-builder/types/bpl"

interface LoopNodeEditorProps {
    node: LoopNode,
    onUpdateNodeProperty: (nodeId: string, updatedFields: Partial<BplAstNode>) => void;
}

export const LoopNodeEditor = ({ node, onUpdateNodeProperty }: LoopNodeEditorProps) => {
    return <div className="space-y-3">
        <div>
            <label className="text-[10px] uppercase font-bold text-gray-400 block mb-1">
                Item Variable (Iterator)
            </label>
            <input
                type="text"
                value={(node as LoopNode).itemVar}
                onChange={(e) =>
                    onUpdateNodeProperty(node.id, { itemVar: e.target.value })
                }
                placeholder="e.g. item"
                className="w-full px-2.5 py-1.5 border border-gray-200 rounded-lg text-xs font-mono focus:ring-1 focus:ring-indigo-500 focus:outline-none bg-slate-50/50"
            />
        </div>
        <div>
            <label className="text-[10px] uppercase font-bold text-gray-400 block mb-1">
                Collection Variable
            </label>
            <input
                type="text"
                value={(node as LoopNode).collectionVar}
                onChange={(e) =>
                    onUpdateNodeProperty(node.id, { collectionVar: e.target.value })
                }
                placeholder="e.g. list, databaseRows"
                className="w-full px-2.5 py-1.5 border border-gray-200 rounded-lg text-xs font-mono focus:ring-1 focus:ring-indigo-500 focus:outline-none bg-slate-50/50"
            />
        </div>
    </div>
}