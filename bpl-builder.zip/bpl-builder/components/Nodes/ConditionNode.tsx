import { BplAstNode, BplCondition, BplConditionGroup, BplOperator } from "@/types/builder";
import { Database, Plus, Trash2, Type } from "lucide-react";

interface ConditionalNodeEditorProps {
    node: any,
    cond: BplCondition | BplConditionGroup | undefined,
    onUpdateNodeProperty: (nodeId: string, updatedFields: Partial<BplAstNode>) => void,
}

const OPERATORS: { value: BplOperator; label: string }[] = [
    { value: 'equals', label: 'Equals (==)' },
    { value: 'notEquals', label: 'Not Equals (!=)' },
    { value: 'greaterThan', label: 'Greater Than (>)' },
    { value: 'lessThan', label: 'Less Than (<)' },
    { value: 'greaterThanOrEqual', label: 'Greater Than or Equal (>=)' },
    { value: 'lessThanOrEqual', label: 'Less Than or Equal (<=)' },
    { value: 'contains', label: 'Contains' },
    { value: 'startsWith', label: 'Starts With' },
    { value: 'endsWith', label: 'Ends With' },
    { value: 'in', label: 'In List' },
    { value: 'notIn', label: 'Not In List' },
    { value: 'exists', label: 'Exists / Not Null' },
    { value: 'isEmpty', label: 'Is Empty' },
];

const getNormalizedConditionGroup = (
    cond: BplCondition | BplConditionGroup | undefined
): BplConditionGroup => {
    if (!cond) {
        return {
            type: 'condition-group',
            operator: 'AND',
            conditions: [],
        };
    }
    if ('type' in cond && cond.type === 'condition-group') {
        return cond as BplConditionGroup;
    }
    // Single condition -> coerce to group
    return {
        type: 'condition-group',
        operator: 'AND',
        conditions: [cond as BplCondition],
    };
};


export const ConditionalNodeEditor = ({ node, cond, onUpdateNodeProperty }: ConditionalNodeEditorProps) => {

    const handleConditionGroupChange = (updatedGroup: BplConditionGroup) => {
        onUpdateNodeProperty(node.id, {
            condition: updatedGroup,
        } as any);
    };

    const addConditionClause = (group: BplConditionGroup) => {
        const newClause: BplCondition = {
            field: 'status',
            operator: 'equals',
            value: 'active',
        };
        const updated = {
            ...group,
            conditions: [...group.conditions, newClause],
        };
        handleConditionGroupChange(updated);
    };

    const removeConditionClause = (group: BplConditionGroup, index: number) => {
        const updatedConditions = [...group.conditions];
        updatedConditions.splice(index, 1);
        const updated = {
            ...group,
            conditions: updatedConditions,
        };
        handleConditionGroupChange(updated);
    };

    const updateConditionClause = (
        group: BplConditionGroup,
        index: number,
        fields: Partial<BplCondition>
    ) => {
        const updatedConditions = group.conditions.map((c, i) => {
            if (i === index) {
                // If it is a group itself, we skip or handle, but normally we have flat clauses here
                if ('type' in c && c.type === 'condition-group') return c;
                return { ...(c as BplCondition), ...fields } as BplCondition;
            }
            return c;
        });
        const updated: BplConditionGroup = {
            ...group,
            conditions: updatedConditions,
        };
        handleConditionGroupChange(updated);
    };

    const group = getNormalizedConditionGroup(cond);

    return (
        <div className="space-y-3 p-3.5 bg-slate-50 border border-slate-200 rounded-xl">
            <div className="flex items-center justify-between">
                <div className="flex items-center gap-1.5">
                    <span className="text-[10px] font-bold text-gray-500 uppercase tracking-wider">
                        Logical Match:
                    </span>
                    <select
                        value={group.operator}
                        onChange={(e) =>
                            handleConditionGroupChange({
                                ...group,
                                operator: e.target.value as 'AND' | 'OR',
                            })
                        }
                        className="px-2 py-0.5 text-xs font-bold font-mono text-indigo-700 bg-white border border-gray-200 rounded-md focus:ring-1 focus:ring-indigo-500 focus:outline-none cursor-pointer"
                    >
                        <option value="AND">AND (All Match)</option>
                        <option value="OR">OR (Any Matches)</option>
                    </select>
                </div>

                <button
                    type="button"
                    onClick={() => addConditionClause(group)}
                    className="flex items-center gap-1 text-[10px] font-bold text-indigo-600 hover:text-indigo-800 bg-indigo-50 hover:bg-indigo-100 px-2 py-1 rounded-md transition"
                >
                    <Plus className="w-3 h-3" /> Add Clause
                </button>
            </div>

            <div className="space-y-2">
                {group.conditions.length === 0 ? (
                    <p className="text-[10px] text-gray-400 italic text-center py-2 bg-white rounded-lg border border-dashed border-gray-200">
                        No matching criteria. Click Add Clause to filter.
                    </p>
                ) : (
                    group.conditions.map((c, idx) => {
                        if ('type' in c && c.type === 'condition-group') {
                            return (
                                <div
                                    key={idx}
                                    className="p-2 border border-slate-200 bg-white rounded-lg text-[10px] text-gray-400 italic"
                                >
                                    Nested groups are editable in advanced code view.
                                </div>
                            );
                        }

                        const condClause = c as BplCondition;
                        return (
                            <div
                                key={idx}
                                className="flex flex-col sm:flex-row gap-1.5 p-2 bg-white border border-gray-200 rounded-lg shadow-2xs items-stretch"
                            >
                                <div className="flex-1 grid grid-cols-12 gap-1.5">
                                    {/* Field */}
                                    <input
                                        type="text"
                                        value={condClause.field}
                                        onChange={(e) =>
                                            updateConditionClause(group, idx, { field: e.target.value })
                                        }
                                        placeholder="field"
                                        className="col-span-4 px-2 py-1 border border-gray-200 rounded text-[11px] font-mono focus:ring-1 focus:ring-indigo-500 focus:outline-none"
                                    />

                                    {/* Operator */}
                                    <select
                                        value={condClause.operator}
                                        onChange={(e) =>
                                            updateConditionClause(group, idx, {
                                                operator: e.target.value as BplOperator,
                                            })
                                        }
                                        className="col-span-4 px-1.5 py-1 border border-gray-200 rounded text-[10px] font-mono focus:ring-1 focus:ring-indigo-500 focus:outline-none cursor-pointer"
                                    >
                                        {OPERATORS.map((op) => (
                                            <option key={op.value} value={op.value}>
                                                {op.label}
                                            </option>
                                        ))}
                                    </select>

                                    {/* Value */}
                                    <div className="col-span-4 relative flex items-center">
                                        <input
                                            type="text"
                                            disabled={['exists', 'isEmpty'].includes(condClause.operator)}
                                            value={condClause.value || ''}
                                            onChange={(e) =>
                                                updateConditionClause(group, idx, { value: e.target.value })
                                            }
                                            placeholder={
                                                ['exists', 'isEmpty'].includes(condClause.operator)
                                                    ? 'N/A'
                                                    : condClause.isValueIdentifier ? 'variable' : 'value'
                                            }
                                            className="w-full pl-2 pr-7 py-1 border border-gray-200 rounded text-[11px] font-mono focus:ring-1 focus:ring-indigo-500 focus:outline-none disabled:bg-gray-100"
                                        />
                                        {!['exists', 'isEmpty'].includes(condClause.operator) && (
                                            <button
                                                type="button"
                                                onClick={() =>
                                                    updateConditionClause(group, idx, {
                                                        isValueIdentifier: !condClause.isValueIdentifier,
                                                    })
                                                }
                                                className={`absolute right-1 p-1 rounded transition cursor-pointer ${condClause.isValueIdentifier
                                                    ? 'text-indigo-600 bg-indigo-50 hover:bg-indigo-100'
                                                    : 'text-gray-400 hover:bg-gray-100'
                                                    }`}
                                                title={condClause.isValueIdentifier ? "Comparing to dynamic variable" : "Comparing to static constant"}
                                            >
                                                {condClause.isValueIdentifier ? <Database className="w-3 h-3" /> : <Type className="w-3 h-3" />}
                                            </button>
                                        )}
                                    </div>
                                </div>

                                <button
                                    type="button"
                                    onClick={() => removeConditionClause(group, idx)}
                                    className="text-gray-400 hover:text-rose-600 hover:bg-rose-50 px-1.5 rounded transition shrink-0 self-center"
                                    title="Remove clause"
                                >
                                    <Trash2 className="w-3.5 h-3.5" />
                                </button>
                            </div>
                        );
                    })
                )}
            </div>
        </div>
    );
}