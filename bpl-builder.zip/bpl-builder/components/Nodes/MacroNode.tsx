import React from 'react';
import { Cpu, Trash2 } from 'lucide-react';
import { BplAstNode, MacroNode } from '../../types/bpl';

interface MacroNodeRendererProps {
    node: { id: string; type: 'macro'; name: string; block: any[] };
    onSelect: (e: React.MouseEvent) => void;
    selectedNodeId: string | null;
    onDelete: () => void;
    statusBadge: React.ReactNode;
    getStatusBorder: () => string;
    renderNode: (cb: any) => React.ReactNode;
    renderAddButton: (targetId: string, className?: string) => React.ReactNode;
}

export function MacroNodeRenderer({
    node,
    onSelect,
    selectedNodeId,
    onDelete,
    statusBadge,
    getStatusBorder,
    renderNode,
    renderAddButton,
}: MacroNodeRendererProps) {
    return (
        <div
            className={`p-4 transition-all duration-300 max-w-xl`}
        >
            <div
                onClick={onSelect}
                className={`flex items-start gap-3 pb-3 cursor-pointer border rounded-xl p-4 bg-white ${getStatusBorder()} ${selectedNodeId === node.id ? 'bg-indigo-50/20 ring-2 ring-indigo-500 ring-offset-1' : `${getStatusBorder()}`}`}
            >
                <div className="p-2 rounded-lg bg-indigo-50 text-indigo-600">
                    <Cpu className="w-4 h-4" />
                </div>
                <div className="flex-1">
                    <div className="flex items-center justify-between gap-2">
                        <span className="text-[10px] font-bold text-indigo-500 uppercase tracking-wider">
                            Macro Block
                        </span>
                        <div className="flex items-center gap-1.5" onClick={(e) => e.stopPropagation()}>
                            {statusBadge}
                            <button
                                onClick={onDelete}
                                className="p-1 rounded text-gray-400 hover:text-rose-500 hover:bg-rose-50/50 transition cursor-pointer"
                                title="Delete node"
                            >
                                <Trash2 className="w-3.5 h-3.5" />
                            </button>
                        </div>
                    </div>
                    <div className="flex items-center gap-1.5 mt-1 text-xs text-gray-700">
                        <span>Execute macro</span>
                        <span className="font-mono font-bold text-indigo-600 bg-indigo-50 px-1.5 rounded">{node.name}</span>
                    </div>
                </div>
            </div>

            {/* Macro Inner lanes */}
            <div className="relative pl-6 ml-4 border-l-2 border-dashed border-indigo-200 mt-2 space-y-4 pt-2">
                <div className="absolute top-0 left-0 -ml-[5px] w-2.5 h-2.5 rounded-full bg-indigo-300" />
                {node.block.length === 0 ? (
                    <div className="py-2 pl-2 border border-dashed border-indigo-100 rounded-lg bg-indigo-50/10 flex flex-col gap-2">
                        <span className="text-[10px] text-indigo-500 font-medium italic">Empty macro block (no children)</span>
                        {renderAddButton(`empty-macro-${node.id}`, "-ml-[36px]")}
                    </div>
                ) : (
                    node.block.map((cb) => (
                        <React.Fragment key={cb.id}>
                            {renderNode(cb)}
                            {renderAddButton(cb.id, "-ml-[36px]")}
                        </React.Fragment>
                    ))
                )}
            </div>
        </div>
    );
}

interface MacroNodeEditorProps {
    node: MacroNode;
    onUpdateNodeProperty: (nodeId: string, updatedFields: Partial<BplAstNode>) => void;
}

export function MacroNodeEditor({ node, onUpdateNodeProperty }: MacroNodeEditorProps) {
    return (
        <div className="space-y-3 font-mono text-[11px]">
            <div>
                <label className="text-[10px] uppercase font-bold text-gray-400 block mb-1">
                    Macro Name
                </label>
                <input
                    type="text"
                    value={node.name}
                    onChange={(e) => onUpdateNodeProperty(node.id, { name: e.target.value })}
                    placeholder="e.g. core_checks"
                    className="w-full px-2.5 py-1.5 border border-gray-200 rounded-lg text-xs font-mono focus:ring-1 focus:ring-indigo-500 focus:outline-none bg-slate-50/50"
                />
            </div>
        </div>
    );
}
