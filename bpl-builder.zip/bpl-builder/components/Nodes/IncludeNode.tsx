import { BplAstNode, IncludeNode } from "@/components/bpl-builder/types/bpl"
import { Folder } from "lucide-react";

interface IncludeNodeEditorProps {
    node: IncludeNode,
    onUpdateNodeProperty: (nodeId: string, updatedFields: Partial<BplAstNode>) => void;
}

export const IncludeNodeEditor = ({ node, onUpdateNodeProperty }: IncludeNodeEditorProps) => {
    return <div className="space-y-1.5">
        <label className="text-[10px] uppercase font-bold text-gray-400 block">
            Template Path
        </label>
        <div className="relative">
            <Folder className="absolute left-2.5 top-2 w-3.5 h-3.5 text-sky-500" />
            <input
                type="text"
                value={(node as IncludeNode).path}
                onChange={(e) =>
                    onUpdateNodeProperty(node.id, { path: e.target.value })
                }
                placeholder="e.g. core/policy-standards"
                className="w-full pl-8 pr-2.5 py-1.5 border border-gray-200 rounded-lg text-xs font-mono focus:ring-1 focus:ring-indigo-500 focus:outline-none bg-slate-50/50 text-sky-700 font-bold"
            />
        </div>
    </div>
}