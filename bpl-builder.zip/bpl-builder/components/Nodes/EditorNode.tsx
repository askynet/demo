import { BplAstNode, ErrorNode } from "@/components/bpl-builder/types/bpl"
import { AlertCircle, GitCommit } from "lucide-react";

interface ErrorNodeEditorProps {
    node: ErrorNode,
    onUpdateNodeProperty: (nodeId: string, updatedFields: Partial<BplAstNode>) => void;
}

export const ErrorNodeEditor = ({ node, onUpdateNodeProperty }: ErrorNodeEditorProps) => {
    return <div className="space-y-1.5">
        <label className="text-[10px] uppercase font-bold text-gray-400 block">
            Error / Exit Message
        </label>
        <div className="relative">
            <AlertCircle className="absolute left-2.5 top-2.5 w-3.5 h-3.5 text-rose-500" />
            <textarea
                rows={2}
                value={(node as ErrorNode).message}
                onChange={(e) =>
                    onUpdateNodeProperty(node.id, { message: e.target.value })
                }
                placeholder="Termination error description"
                className="w-full pl-8 pr-2.5 py-1.5 border border-gray-200 rounded-lg text-xs font-mono focus:ring-1 focus:ring-indigo-500 focus:outline-none bg-slate-50/50 leading-relaxed text-rose-700"
            />
        </div>
    </div>
}