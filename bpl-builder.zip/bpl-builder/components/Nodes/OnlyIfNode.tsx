import React from 'react';
import { Plus, Trash2, X, ToggleLeft, CornerDownRight } from 'lucide-react';
import { BplAstNode, OnlyIfNode } from '../../types/bpl';
import { AddNodeButton } from '../AddNodeButton';

interface OnlyIfNodeEditorProps {
    node: OnlyIfNode;
    onUpdateNodeProperty: (nodeId: string, updatedFields: Partial<BplAstNode>) => void;
}

export function OnlyIfNodeEditor({ node, onUpdateNodeProperty }: OnlyIfNodeEditorProps) {
    const handleVariableChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        onUpdateNodeProperty(node.id, { variable: e.target.value });
    };

    const handleAddCase = () => {
        const updatedCases = [
            ...(node.cases || []),
            {
                values: ['NewValue'],
                block: []
            }
        ];
        onUpdateNodeProperty(node.id, { cases: updatedCases });
    };

    const handleRemoveCase = (index: number) => {
        const updatedCases = (node.cases || []).filter((_, i) => i !== index);
        onUpdateNodeProperty(node.id, { cases: updatedCases });
    };

    const handleAddValue = (caseIndex: number) => {
        const updatedCases = (node.cases || []).map((c, i) => {
            if (i === caseIndex) {
                return {
                    ...c,
                    values: [...c.values, '']
                };
            }
            return c;
        });
        onUpdateNodeProperty(node.id, { cases: updatedCases });
    };

    const handleValueChange = (caseIndex: number, valueIndex: number, newValue: string) => {
        const updatedCases = (node.cases || []).map((c, i) => {
            if (i === caseIndex) {
                const newValues = [...c.values];
                newValues[valueIndex] = newValue;
                return {
                    ...c,
                    values: newValues
                };
            }
            return c;
        });
        onUpdateNodeProperty(node.id, { cases: updatedCases });
    };

    const handleRemoveValue = (caseIndex: number, valueIndex: number) => {
        const updatedCases = (node.cases || []).map((c, i) => {
            if (i === caseIndex) {
                const newValues = c.values.filter((_, vIdx) => vIdx !== valueIndex);
                return {
                    ...c,
                    values: newValues
                };
            }
            return c;
        });
        onUpdateNodeProperty(node.id, { cases: updatedCases });
    };

    return (
        <div className="space-y-4 font-mono text-[11px]">
            <div className="space-y-1.5">
                <label className="text-[10px] uppercase font-bold text-gray-400 block">
                    Evaluation Variable
                </label>
                <input
                    type="text"
                    value={node.variable}
                    onChange={handleVariableChange}
                    placeholder="e.g. telehealth_net_ov_option"
                    className="w-full px-2.5 py-1.5 border border-gray-200 rounded-lg text-xs font-mono focus:ring-1 focus:ring-indigo-500 focus:outline-none bg-slate-50/50"
                />
            </div>

            <div className="border-t border-gray-100 pt-3 space-y-3">
                <div className="flex items-center justify-between">
                    <label className="text-[10px] uppercase font-bold text-gray-400">
                        Cases & Matches
                    </label>
                    <button
                        onClick={handleAddCase}
                        className="flex items-center gap-1 text-[10px] bg-teal-50 hover:bg-teal-100 text-teal-700 px-2 py-1 rounded-md transition cursor-pointer animate-in fade-in zoom-in-95 duration-150"
                    >
                        <Plus className="w-3 h-3" /> Add Case
                    </button>
                </div>

                <div className="space-y-3 max-h-[300px] overflow-y-auto pr-1">
                    {(node.cases || []).map((c, caseIdx) => (
                        <div key={caseIdx} className="bg-slate-50 border border-slate-100 rounded-lg p-2.5 space-y-2 relative">
                            <div className="flex items-center justify-between">
                                <span className="text-[9px] font-bold text-slate-400 uppercase">Case #{caseIdx + 1}</span>
                                <button
                                    onClick={() => handleRemoveCase(caseIdx)}
                                    className="p-1 rounded text-gray-400 hover:text-rose-500 hover:bg-rose-50/50 transition cursor-pointer"
                                    title="Remove case block"
                                >
                                    <Trash2 className="w-3 h-3" />
                                </button>
                            </div>

                            <div className="space-y-1.5">
                                <div className="flex items-center justify-between">
                                    <span className="text-[9px] text-gray-500 font-semibold uppercase">Match values:</span>
                                    <button
                                        onClick={() => handleAddValue(caseIdx)}
                                        className="text-[9.5px] text-teal-600 hover:underline flex items-center gap-0.5"
                                    >
                                        <Plus className="w-2.5 h-2.5" /> Add match
                                    </button>
                                </div>

                                <div className="space-y-1">
                                    {c.values.map((val, valIdx) => (
                                        <div key={valIdx} className="flex items-center gap-1">
                                            <input
                                                type="text"
                                                value={val}
                                                onChange={(e) => handleValueChange(caseIdx, valIdx, e.target.value)}
                                                placeholder="e.g. A"
                                                className="flex-1 px-2 py-1 border border-gray-200 rounded text-[11px] font-mono focus:ring-1 focus:ring-teal-500 focus:outline-none bg-white"
                                            />
                                            {c.values.length > 1 && (
                                                <button
                                                    onClick={() => handleRemoveValue(caseIdx, valIdx)}
                                                    className="p-1 rounded text-gray-400 hover:text-rose-500 hover:bg-rose-50 transition cursor-pointer"
                                                >
                                                    <X className="w-3 h-3" />
                                                </button>
                                            )}
                                        </div>
                                    ))}
                                </div>
                            </div>
                        </div>
                    ))}

                    {(node.cases || []).length === 0 && (
                        <div className="text-center py-4 border border-dashed border-gray-150 rounded-lg text-gray-400 italic">
                            No matching cases. Click 'Add Case' above to begin.
                        </div>
                    )}
                </div>
            </div>
        </div>
    );
}
interface OnlyIfNodeRendererProps {
    node: OnlyIfNode;
    selectedNodeId: string | null;
    onSelect: (e: React.MouseEvent) => void;
    onDelete: (id: string) => void;
    statusBadge: React.ReactNode;
    getStatusBorder: () => string;
    getStatusBg: () => string;
    renderAddButton: (id: string, className: any) => React.ReactNode;
    renderNode: (child: any) => React.ReactNode;
}

export function OnlyIfNodeRenderer({
    node,
    selectedNodeId,
    onSelect,
    onDelete,
    statusBadge,
    getStatusBorder,
    getStatusBg,
    renderAddButton,
    renderNode,
}: OnlyIfNodeRendererProps) {
    return (
        <div
            className={`p-4 transition-all duration-300 max-w-xl`}
        >
            <div
                onClick={onSelect}
                className={`flex items-start gap-3 pb-3 cursor-pointer border rounded-xl p-4 bg-white ${getStatusBorder()} ${selectedNodeId === node.id ? 'bg-indigo-50/20 ring-2 ring-indigo-500 ring-offset-1' : `${getStatusBorder()}`}`}
            >
                <div className="p-2 rounded-lg bg-amber-50 text-amber-600">
                    <ToggleLeft className="w-4 h-4" />
                </div>
                <div className="flex-1">
                    <div className="flex items-center justify-between gap-2">
                        <span className="text-[10px] font-bold text-amber-500 uppercase tracking-wider font-mono">
                            Only If Block
                        </span>
                        <div className="flex items-center gap-1.5" onClick={(e) => e.stopPropagation()}>
                            {statusBadge}
                            <button
                                onClick={() => onDelete(node.id)}
                                className="p-1 rounded text-gray-400 hover:text-rose-500 hover:bg-rose-50/50 transition cursor-pointer"
                                title="Delete node"
                            >
                                <Trash2 className="w-3.5 h-3.5" />
                            </button>
                        </div>
                    </div>
                    <div className="flex items-center gap-1 mt-1 text-xs text-gray-700">
                        <span>Execute nested rules ONLY if</span>
                        <span className="font-mono font-bold text-teal-600 bg-teal-50 px-1.5 rounded">{node.variable}</span>
                    </div>
                </div>
            </div>

            {/* Case lanes */}
            <div className="mt-3 space-y-4">
                {node.cases.map((c, idx) => (
                    <div key={idx} className="relative pl-6 ml-4 border-l border-teal-200">
                        <div className="absolute top-2 left-0 -ml-[5px] w-2 h-2 rounded-full bg-teal-300" />
                        <div className="flex items-center justify-between gap-2 mb-2">
                            <div className="flex items-center gap-2 flex-wrap">
                                <div className="text-[9px] uppercase font-bold text-emerald-500 tracking-wider flex items-center gap-1 mb-2">
                                    <CornerDownRight className="w-3 h-3" /> IF matches
                                </div>
                                {c.values.map((v, vIdx) => (
                                    <span key={vIdx} className="text-xs font-mono font-semibold bg-teal-50 text-teal-700 px-2 py-0.5 rounded border border-teal-100">
                                        "{v}"
                                    </span>
                                ))}
                            </div>
                        </div>
                        <div className="space-y-4 pt-1">
                            {c.block.length === 0 ? (
                                <div className="py-2 pl-2 border border-dashed border-teal-100 rounded-lg bg-teal-50/10 flex flex-col gap-2">
                                    <span className="text-[10px] text-teal-500 font-medium italic">Empty block (no children)</span>
                                    {renderAddButton(`empty-case-${node.id}-${idx}`, "-ml-[36px]")}
                                </div>
                            ) : (
                                c.block.map((cb) => (
                                    <React.Fragment key={cb.id}>
                                        {renderNode(cb)}
                                        {renderAddButton(cb.id, "-ml-[36px]")}
                                    </React.Fragment>
                                ))
                            )}
                        </div>
                    </div>
                ))}
            </div>
        </div>
    );
}
