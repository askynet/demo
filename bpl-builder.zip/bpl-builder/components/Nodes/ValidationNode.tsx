import { BplAstNode, ValidationNode } from "@/components/bpl-builder/types/bpl"
import { ConditionalNodeEditor } from "./ConditionNode"

interface ValidationNodeEditorProps {
    node: ValidationNode,
    onUpdateNodeProperty: (nodeId: string, updatedFields: Partial<BplAstNode>) => void,
}

export const ValidationNodeEditor = ({ node, onUpdateNodeProperty }: ValidationNodeEditorProps) => {
    return <div className="space-y-3.5">
        <div className="space-y-1.5">
            <label className="text-[10px] uppercase font-bold text-gray-400 block">
                Validation Condition Criteria
            </label>
            <ConditionalNodeEditor
                node={node}
                cond={(node as ValidationNode).condition}
                onUpdateNodeProperty={onUpdateNodeProperty}
            />
        </div>

        <div className="space-y-1.5">
            <label className="text-[10px] uppercase font-bold text-gray-400 block">
                On-Failure Error Message
            </label>
            <textarea
                rows={2}
                value={(node as ValidationNode).errorMessage}
                onChange={(e) =>
                    onUpdateNodeProperty(node.id, { errorMessage: e.target.value })
                }
                placeholder="Validation failed exception info"
                className="w-full px-2.5 py-1.5 border border-gray-200 rounded-lg text-xs font-mono focus:ring-1 focus:ring-indigo-500 focus:outline-none bg-slate-50/50 leading-relaxed text-rose-700"
            />
        </div>
    </div>
}