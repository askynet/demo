/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useRef, useEffect } from 'react';
import { ParserError } from '../types/bpl';
import { AlertCircle, FileCode, CheckCircle, RotateCcw, Sparkles } from 'lucide-react';

interface DslEditorProps {
  code: string;
  onChangeCode: (newCode: string) => void;
  errors: ParserError[];
  onFormat: () => void;
  onReset: () => void;
}

export default function DslEditor({
  code,
  onChangeCode,
  errors,
  onFormat,
  onReset,
}: DslEditorProps) {
  const lineCount = code.split('\n').length;
  const lineNumbers = Array.from({ length: Math.max(lineCount, 15) }, (_, i) => i + 1);

  return (
    <div className="flex flex-col h-full bg-slate-900 text-slate-100 rounded-xl overflow-hidden border border-slate-800 shadow-xl">
      {/* Editor Header */}
      <div className="flex items-center justify-between bg-slate-950 px-4 py-3 border-b border-slate-850">
        <div className="flex items-center gap-2">
          <FileCode className="w-4 h-4 text-indigo-400" />
          <span className="text-xs font-semibold uppercase tracking-wider text-slate-300 font-mono">
            bpl-script-editor.bpl
          </span>
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={onFormat}
            className="flex items-center gap-1.5 px-2.5 py-1 text-xs bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-md border border-slate-700 transition"
            title="Auto-format BPL syntax indentations"
          >
            <Sparkles className="w-3.5 h-3.5 text-indigo-400" /> Format
          </button>
          <button
            onClick={onReset}
            className="flex items-center gap-1.5 px-2.5 py-1 text-xs bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-md border border-slate-700 transition"
            title="Reset to sample default code"
          >
            <RotateCcw className="w-3.5 h-3.5" /> Reset
          </button>
        </div>
      </div>

      {/* Editor Body */}
      <div className="flex-1 flex overflow-hidden min-h-[30rem] font-mono text-xs">
        {/* Line Numbers Column */}
        <div className="w-12 bg-slate-950 text-slate-600 text-right pr-3 select-none py-4 border-r border-slate-850/50 leading-relaxed font-mono">
          {lineNumbers.map((lineNum) => {
            const hasError = errors.some((e) => e.line === lineNum);
            return (
              <div
                key={lineNum}
                className={`h-5 flex items-center justify-end ${hasError ? 'text-rose-500 font-bold bg-rose-950/20' : ''}`}
              >
                {lineNum}
              </div>
            );
          })}
        </div>

        {/* Text Area Input */}
        <div className="flex-1 relative bg-slate-900/95">
          <textarea
            value={code}
            onChange={(e) => onChangeCode(e.target.value)}
            className="absolute inset-0 w-full h-full p-4 py-4 bg-transparent text-slate-200 focus:outline-none resize-none overflow-y-auto leading-relaxed whitespace-pre font-mono selection:bg-indigo-500 selection:text-white"
            spellCheck="false"
            placeholder={`script "MY POLICY"\n{\n  log "Initializing..."\n}`}
          />
        </div>
      </div>

      {/* Parser Warnings & Errors footer */}
      <div className="bg-slate-950 border-t border-slate-850 p-4 min-h-[5rem] flex flex-col justify-center">
        {errors.length > 0 ? (
          <div className="space-y-2">
            <div className="flex items-center gap-2 text-rose-400 text-xs font-semibold">
              <AlertCircle className="w-4 h-4 text-rose-500" />
              <span>Compilation Error: Syntax is invalid</span>
            </div>
            {errors.map((err, idx) => (
              <p key={idx} className="text-[11px] text-rose-300 font-mono pl-6">
                Line <span className="font-bold">{err.line}</span>, Col <span className="font-bold">{err.column}</span>: {err.message}
              </p>
            ))}
          </div>
        ) : (
          <div className="flex items-center gap-2 text-emerald-400 text-xs font-semibold">
            <CheckCircle className="w-4 h-4 text-emerald-500" />
            <span>Syntax compiles successfully. Visual Flow Engine ready.</span>
          </div>
        )}
      </div>
    </div>
  );
}
