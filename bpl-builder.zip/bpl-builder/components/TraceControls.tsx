/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import {
    Play,
    Pause,
    SkipForward,
    SkipBack,
    RotateCcw,
    Zap,
    Info,
} from 'lucide-react';

interface TraceControlsProps {
    currentStepIndex: number;
    totalSteps: number;
    isPlaying: boolean;
    onPlayToggle: () => void;
    onStepForward: () => void;
    onStepBackward: () => void;
    onResetTrace: () => void;
    speed: number;
    onChangeSpeed: (newSpeed: number) => void;
    currentDescription: string;
}

export default function TraceControls({
    currentStepIndex,
    totalSteps,
    isPlaying,
    onPlayToggle,
    onStepForward,
    onStepBackward,
    onResetTrace,
    speed,
    onChangeSpeed,
    currentDescription,
}: TraceControlsProps) {
    const percentage = totalSteps > 1 ? (currentStepIndex / (totalSteps - 1)) * 100 : 0;

    return (
        <div className="bg-white border border-gray-100 rounded-xl shadow-sm p-4 space-y-4">
            {/* Step scrubber timeline */}
            <div className="space-y-1.5">
                <div className="flex items-center justify-between text-xs text-gray-500 font-semibold select-none">
                    <span className='uppercase tracking-wider'>Execution Debugger</span>
                    <span className="font-mono bg-indigo-50 text-indigo-700 px-2 py-0.5 rounded font-bold">
                        Step {totalSteps > 0 ? currentStepIndex + 1 : 0} of {totalSteps}
                    </span>
                </div>

                <div className="relative group flex items-center h-4">
                    <div className="absolute left-0 right-0 h-1.5 bg-gray-100 rounded-full overflow-hidden">
                        <div
                            className="h-full bg-indigo-500 transition-all duration-150"
                            style={{ width: `${percentage}%` }}
                        />
                    </div>
                    <input
                        type="range"
                        min="0"
                        max={Math.max(totalSteps - 1, 0)}
                        value={currentStepIndex}
                        onChange={(e) => {
                            const val = Number(e.target.value);
                            if (isPlaying) onPlayToggle(); // pause on manual scrub
                            // call parent setter via stepping handles
                            const diff = val - currentStepIndex;
                            if (diff > 0) {
                                for (let i = 0; i < diff; i++) onStepForward();
                            } else if (diff < 0) {
                                for (let i = 0; i < Math.abs(diff); i++) onStepBackward();
                            }
                        }}
                        className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                    />
                </div>
            </div>

            {/* Control Buttons row */}
            <div className="flex flex-wrap items-center justify-between gap-3">
                {/* Playback step actions */}
                <div className="flex items-center gap-1">
                    <button
                        onClick={onStepBackward}
                        disabled={currentStepIndex === 0}
                        className="p-2 bg-gray-50 hover:bg-gray-100 disabled:opacity-40 text-gray-600 rounded-lg border border-gray-200 transition cursor-pointer"
                        title="Step backward (Shift + Left)"
                    >
                        <SkipBack className="w-3 h-3" />
                    </button>

                    <button
                        onClick={onPlayToggle}
                        className={`p-2.5 px-4 rounded-xl font-semibold flex items-center gap-1.5 shadow-sm text-xs cursor-pointer transition ${isPlaying
                                ? 'bg-amber-500 hover:bg-amber-600 text-white'
                                : 'bg-indigo-600 hover:bg-indigo-700 text-white'
                            }`}
                    >
                        {isPlaying ? (
                            <>
                                <Pause className="w-3 h-3 fill-white" /> Pause
                            </>
                        ) : (
                            <>
                                <Play className="w-3 h-3 fill-white" /> Play
                            </>
                        )}
                    </button>

                    <button
                        onClick={onStepForward}
                        disabled={currentStepIndex >= totalSteps - 1}
                        className="p-2 bg-gray-50 hover:bg-gray-100 disabled:opacity-40 text-gray-600 rounded-lg border border-gray-200 transition cursor-pointer"
                        title="Step forward (Shift + Right)"
                    >
                        <SkipForward className="w-3 h-3" />
                    </button>

                    <button
                        onClick={onResetTrace}
                        className="p-2 bg-gray-50 hover:bg-gray-100 text-gray-500 rounded-lg border border-gray-200 transition cursor-pointer"
                        title="Restart interpreter to step 1"
                    >
                        <RotateCcw className="w-3 h-3" />
                    </button>
                </div>

                {/* Playback speed selector */}
                <div className="flex items-center gap-1.5 bg-gray-50 p-1 border border-gray-200 rounded-lg text-xs select-none">
                    <Zap className="w-3.5 h-3.5 text-indigo-500 ml-1.5" />
                    {[0.5, 1, 2].map((s) => (
                        <button
                            key={s}
                            onClick={() => onChangeSpeed(s)}
                            className={`px-2 py-1 rounded font-bold transition font-mono ${speed === s
                                    ? 'bg-indigo-600 text-white shadow-sm'
                                    : 'text-gray-500 hover:bg-gray-200 hover:text-gray-700'
                                }`}
                        >
                            {s}x
                        </button>
                    ))}
                </div>
            </div>

            {/* Prominent Action Callout explanation bubble */}
            {currentDescription && (
                <div className="bg-indigo-50/50 border border-indigo-100 rounded-xl p-3 flex items-start gap-2.5">
                    <Info className="w-3 h-3 text-indigo-500 shrink-0 mt-0.5" />
                    <p className="text-[11px] text-indigo-900 leading-relaxed font-mono select-text">
                        {currentDescription}
                    </p>
                </div>
            )}
        </div>
    );
}