/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import {
  BplAstNode,
  ScriptNode,
  BplConditionGroup,
  BplCondition,
  TraceStep,
  VariableState,
  VariableValue,
} from '../types/bpl';
import { conditionToString } from './parser';

/**
 * Checks if a condition matches under the current variables state
 */
export function evaluateCondition(
  cond: BplCondition | BplConditionGroup,
  vars: VariableState
): boolean {
  if ('type' in cond && cond.type === 'condition-group') {
    const group = cond as BplConditionGroup;
    if (group.operator === 'AND') {
      return group.conditions.every((c) => evaluateCondition(c, vars));
    } else {
      return group.conditions.some((c) => evaluateCondition(c, vars));
    }
  } else {
    const single = cond as BplCondition;
    const rawVal = vars[single.field];

    // exists operator
    if (single.operator === 'exists') {
      return rawVal !== undefined && rawVal !== null;
    }

    // isEmpty operator
    if (single.operator === 'isEmpty') {
      if (rawVal === undefined || rawVal === null) return true;
      if (typeof rawVal === 'string' && rawVal.trim() === '') return true;
      if (Array.isArray(rawVal) && rawVal.length === 0) return true;
      return false;
    }

    // If variable doesn't exist, we evaluate against undefined (except for exists/isEmpty checks)
    const varVal = rawVal;
    let checkVal = single.value;

    if (single.isValueIdentifier) {
      checkVal = String(vars[single.value] !== undefined ? vars[single.value] : '');
    }

    return compareValues(varVal, single.operator, checkVal);
  }
}

/**
 * Robust comparison of two values based on BPL operators
 */
function compareValues(varVal: any, operator: string, checkVal: string): boolean {
  // Coerce string representations
  const varStr = varVal !== undefined && varVal !== null ? String(varVal) : '';
  const checkStr = checkVal;

  // Check if both are numeric to do a numeric comparison
  const isNumeric = varVal !== undefined && !isNaN(Number(varStr)) && !isNaN(Number(checkStr)) && varStr !== '' && checkStr !== '';
  const vNum = isNumeric ? Number(varStr) : NaN;
  const cNum = isNumeric ? Number(checkStr) : NaN;

  // Boolean coercions
  const isVarBool = varStr === 'true' || varStr === 'false';
  const isCheckBool = checkStr === 'true' || checkStr === 'false';
  if (isVarBool && isCheckBool) {
    const vBool = varStr === 'true';
    const cBool = checkStr === 'true';
    if (operator === 'equals' || operator === '==') return vBool === cBool;
    if (operator === 'notEquals' || operator === '!=') return vBool !== cBool;
  }

  switch (operator) {
    case 'equals':
    case '==':
      if (isNumeric) return vNum === cNum;
      return varStr.toLowerCase() === checkStr.toLowerCase();

    case 'notEquals':
    case '!=':
      if (isNumeric) return vNum !== cNum;
      return varStr.toLowerCase() !== checkStr.toLowerCase();

    case 'greaterThan':
    case '>':
      if (isNumeric) return vNum > cNum;
      return varStr.toLowerCase() > checkStr.toLowerCase();

    case 'lessThan':
    case '<':
      if (isNumeric) return vNum < cNum;
      return varStr.toLowerCase() < checkStr.toLowerCase();

    case 'greaterThanOrEqual':
    case '>=':
      if (isNumeric) return vNum >= cNum;
      return varStr.toLowerCase() >= checkStr.toLowerCase();

    case 'lessThanOrEqual':
    case '<=':
      if (isNumeric) return vNum <= cNum;
      return varStr.toLowerCase() <= checkStr.toLowerCase();

    case 'contains':
      return varStr.toLowerCase().includes(checkStr.toLowerCase());

    case 'startsWith':
      return varStr.toLowerCase().startsWith(checkStr.toLowerCase());

    case 'endsWith':
      return varStr.toLowerCase().endsWith(checkStr.toLowerCase());

    case 'in': {
      const list = checkStr.split(',').map((x) => x.trim().toLowerCase());
      return list.includes(varStr.toLowerCase());
    }

    case 'notIn': {
      const list = checkStr.split(',').map((x) => x.trim().toLowerCase());
      return !list.includes(varStr.toLowerCase());
    }

    default:
      return false;
  }
}

/**
 * Resolves logs that contain variable placeholders (e.g. "Completed. Status: " + status, or "Total is: ${cartTotal}")
 */
function resolveLogMessage(message: string, vars: VariableState): string {
  // Match placeholders like ${varName} or ${user.name}
  let msg = message.replace(/\$\{([a-zA-Z_][a-zA-Z0-9_\.]*)\}/g, (_, varPath) => {
    const parts = varPath.split('.');
    let current: any = vars;
    for (const part of parts) {
      if (current === null || current === undefined) {
        return 'undefined';
      }
      current = current[part];
    }
    return current !== undefined ? String(current) : 'undefined';
  });

  // If message ends with "status: ", we try to append standard variable values
  const colonEnds = [
    'status: ', 'status:', 'completed. status: ', 'completed. status:',
    'reason: ', 'reason:', 'multiplier: ', 'multiplier:'
  ];
  const msgLower = msg.toLowerCase();
  for (const ending of colonEnds) {
    if (msgLower.endsWith(ending)) {
      const varName = ending.replace(':', '').replace('completed.', '').trim();
      if (vars[varName] !== undefined) {
        msg += String(vars[varName]);
      }
    }
  }

  return msg;
}

/**
 * BPL rules execution engine / interpreter
 */
export class BplInterpreter {
  private variables: VariableState = {};
  private steps: TraceStep[] = [];
  private logs: string[] = [];
  private outputIncludes: { path: string; params: string[] }[] = [];
  private jumpToLabel: string | null = null;
  private halted: boolean = false;

  execute(script: ScriptNode, initialVars: VariableState): TraceStep[] {
    this.variables = { ...initialVars };
    this.steps = [];
    this.logs = [];
    this.outputIncludes = [];
    this.jumpToLabel = null;
    this.halted = false;

    // Push initial start step
    this.steps.push({
      currentNodeId: script.id,
      nodeType: 'script',
      executed: true,
      variableSnapshot: { ...this.variables },
      logs: ['[System] Initializing rules execution.'],
      outputIncludes: [],
      description: `Starting BPL script "${script.name}"`,
    });

    this.evaluateBlock(script.children);

    // Push completion step
    this.steps.push({
      currentNodeId: script.id,
      nodeType: 'script',
      executed: true,
      variableSnapshot: { ...this.variables },
      logs: [...this.logs, '[System] Rule execution finished successfully.'],
      outputIncludes: [...this.outputIncludes],
      description: `Rule set completed with ${this.logs.length} logged statements.`,
    });

    return this.steps;
  }

  private evaluateBlock(nodes: BplAstNode[]) {
    for (const node of nodes) {
      if (this.halted) return;

      // Handle jumps: skip execution of statements until label matching the target is found
      if (this.jumpToLabel !== null) {
        if (node.type === 'label' && node.name === this.jumpToLabel) {
          // Found target label, clear flag and continue executing this label and onwards
          this.jumpToLabel = null;
          this.addStep(node, true, `Landing on label "${node.name}" from jumpto.`, `Label "${node.name}" reached.`);
        } else {
          // Skip other statement execution but still capture trace (as skipped)
          this.addStep(node, false, `Skipping statement (jumping to label "${this.jumpToLabel}").`, `Skipped node due to jumpto.`);
          continue;
        }
      }

      this.evaluateNode(node);
    }
  }

  private evaluateNode(node: BplAstNode) {
    if (this.halted) return;

    switch (node.type) {
      case 'label': {
        this.addStep(node, true, `Reaching label "${node.name}".`, `Label declaration "${node.name}"`);
        break;
      }

      case 'log': {
        const resolvedMsg = resolveLogMessage(node.message, this.variables);
        this.logs.push(`[Log] ${resolvedMsg}`);
        this.addStep(node, true, `Logging statement: "${resolvedMsg}"`, `Log: ${resolvedMsg}`);
        break;
      }

      case 'assign': {
        const assignNode = node as any;
        const originalVal = this.variables[assignNode.variable];
        let assignedVal: VariableValue = assignNode.value;

        // Try to evaluate value if it references another variable or is marked as identifier
        if (assignNode.isValueIdentifier) {
          assignedVal = this.variables[assignNode.value];
        } else if (assignNode.value === 'true') {
          assignedVal = true;
        } else if (assignNode.value === 'false') {
          assignedVal = false;
        } else if (!isNaN(Number(assignNode.value)) && assignNode.value !== '') {
          assignedVal = Number(assignNode.value);
        }

        this.variables[node.variable] = assignedVal;
        this.logs.push(`[Assign] Set ${node.variable} = ${String(assignedVal)} (was: ${String(originalVal !== undefined ? originalVal : 'undefined')})`);

        this.addStep(
          node,
          true,
          `Assigning value "${String(assignedVal)}" to variable "${node.variable}".`,
          `Set ${node.variable} = ${String(assignedVal)}`
        );
        break;
      }

      case 'jump': {
        this.jumpToLabel = node.target;
        this.logs.push(`[Jump] Unconditional branch to label "${node.target}"`);
        this.addStep(
          node,
          true,
          `Jumping directly to label "${node.target}". Skipping intermediate statements.`,
          `Jumpto "${node.target}"`
        );
        break;
      }

      case 'return': {
        this.halted = true;
        this.logs.push(`[Return] Explicit exit triggered`);
        this.addStep(node, true, `Triggered script exit. Halting all subsequent rules execution.`, 'Returned (Exit)');
        break;
      }

      case 'include': {
        const resolvedParams = node.parameters?.map((p) => `${p}: ${String(this.variables[p] ?? 'undefined')}`) || [];
        this.outputIncludes.push({
          path: node.path,
          params: node.parameters || [],
        });
        const paramStr = resolvedParams.length > 0 ? ` send(${resolvedParams.join(', ')})` : '';
        this.logs.push(`[Include] Rendered template fragment "${node.path}"${paramStr}`);
        this.addStep(
          node,
          true,
          `Including document/template block "${node.path}" with current context variables.`,
          `Include: ${node.path}`
        );
        break;
      }

      case 'import': {
        this.logs.push(`[Import] Loaded dynamic script file "${node.file}"`);
        this.addStep(node, true, `Importing rules schema from external file "${node.file}".`, `Import: ${node.file}`);
        break;
      }

      case 'validation': {
        const isPassed = evaluateCondition(node.condition, this.variables);
        if (isPassed) {
          this.addStep(
            node,
            true,
            `Validation condition check passed. Continuing.`,
            `Validate Passed`
          );
        } else {
          this.halted = true;
          this.logs.push(`[ValidationError] Validation failed: ${node.errorMessage}`);
          this.addStep(
            node,
            true,
            `Validation condition FAILED. Terminating execution with error: "${node.errorMessage}"`,
            `Validate Fail: ${node.errorMessage}`
          );
        }
        break;
      }

      case 'api-call': {
        // Resolve parameter values
        const paramsMap = node.parameters.map((p) => `${p}=${String(this.variables[p] ?? '')}`).join('&');
        const simulatedUrl = `${node.url}?${paramsMap}`;

        // Mock API response based on URL types
        let mockResponseValue: any = 720; // default score
        if (node.url.includes('credit')) {
          const age = Number(this.variables['age'] ?? 30);
          mockResponseValue = age > 25 ? 740 : 650;
        } else if (node.url.includes('risk')) {
          mockResponseValue = 'Medium';
        }

        this.variables[node.responseVar] = mockResponseValue;
        this.logs.push(`[API Call] Fetched ${simulatedUrl} -> Received ${node.responseVar} = ${mockResponseValue}`);
        this.addStep(
          node,
          true,
          `Simulating service call to ${node.url} with parameter payload. Received response value: ${mockResponseValue}`,
          `API ${node.responseVar} = ${mockResponseValue}`
        );
        break;
      }

      case 'switch': {
        const switchVal = String(this.variables[node.variable] ?? '');
        this.logs.push(`[Switch] Evaluating cases for ${node.variable} = "${switchVal}"`);

        let matched = false;

        this.addStep(
          node,
          true,
          `Switch node evaluating branches for "${node.variable}" (current value: "${switchVal}").`,
          `Switch on ${node.variable}`
        );

        for (const c of node.cases) {
          if (matched) break;

          if (String(c.value).toLowerCase() === switchVal.toLowerCase()) {
            matched = true;
            this.logs.push(`[Switch] Case "${c.value}" matched`);
            this.evaluateBlock(c.block);
          }
        }

        if (!matched && node.defaultBlock) {
          this.logs.push(`[Switch] No cases matched, executing default block`);
          this.evaluateBlock(node.defaultBlock);
        }
        break;
      }

      case 'error': {
        this.halted = true;
        this.logs.push(`[ValidationError] Script terminated with error: "${node.message}"`);
        this.addStep(
          node,
          true,
          `Script termination error reached: "${node.message}"`,
          `Error Exit: ${node.message}`
        );
        break;
      }

      case 'clearscreen': {
        this.logs.push(`[System] Screen Cleared`);
        this.addStep(node, true, `Clearing the console/screen.`, `Clearscreen`);
        break;
      }

      case 'prompt': {
        const originalVal = this.variables[node.variable];
        if (this.variables[node.variable] === undefined) {
          this.variables[node.variable] = 'SimulatedValue';
        }
        const newVal = this.variables[node.variable];
        this.logs.push(`[Prompt] "${node.message}" -> Set ${node.variable} = "${newVal}" (was: ${originalVal !== undefined ? originalVal : 'undefined'})`);
        this.addStep(node, true, `Prompted for variable "${node.variable}" with message "${node.message}".`, `Prompt: ${node.variable}`);
        break;
      }

      case 'getkey': {
        const originalVal = this.variables[node.variable];
        if (this.variables[node.variable] === undefined) {
          this.variables[node.variable] = 'Enter';
        }
        const newVal = this.variables[node.variable];
        this.logs.push(`[Getkey] Wait for key press -> Set ${node.variable} = "${newVal}" (was: ${originalVal !== undefined ? originalVal : 'undefined'})`);
        this.addStep(node, true, `Waiting for keypress, storing result in "${node.variable}".`, `Getkey: ${node.variable}`);
        break;
      }

      case 'only_if': {
        const switchVal = String(this.variables[node.variable] ?? '');
        this.logs.push(`[OnlyIf] Evaluating cases for ${node.variable} = "${switchVal}"`);

        let matched = false;

        this.addStep(
          node,
          true,
          `only_if block evaluating branches for "${node.variable}" (current value: "${switchVal}").`,
          `only_if ${node.variable}`
        );

        for (const c of node.cases) {
          if (matched) break;

          const isMatched = c.values.some(v => String(v).toLowerCase() === switchVal.toLowerCase());
          if (isMatched) {
            matched = true;
            this.logs.push(`[OnlyIf] matched value(s): ${c.values.join(', ')}`);
            this.evaluateBlock(c.block);
          }
        }
        break;
      }

      case 'loop': {
        const collection = this.variables[node.collectionVar];
        this.addStep(
          node,
          true,
          `Looping over "${node.collectionVar}" collection.`,
          `Loop over ${node.collectionVar}`
        );

        if (Array.isArray(collection) && collection.length > 0) {
          this.logs.push(`[Loop] Iterating over ${collection.length} items in "${node.collectionVar}"`);
          const backupItem = this.variables[node.itemVar];

          collection.forEach((item, index) => {
            if (this.halted) return;

            // Set loop item variable context
            if (typeof item === 'object') {
              // Flatten item fields into variable state temporarily, or set itemVar directly
              this.variables[node.itemVar] = item;
              Object.keys(item).forEach((k) => {
                this.variables[k] = item[k];
              });
            } else {
              this.variables[node.itemVar] = item;
            }

            this.logs.push(`[Loop] --- Item ${index + 1} ---`);
            this.evaluateBlock(node.block);
          });

          // Restore loop context
          if (backupItem !== undefined) {
            this.variables[node.itemVar] = backupItem;
          } else {
            delete this.variables[node.itemVar];
          }
        } else {
          this.logs.push(`[Loop] Loop collection "${node.collectionVar}" is empty or not an array. Skipping.`);
        }
        break;
      }

      case 'macro': {
        const macroNode = node as any;
        this.addStep(
          node,
          true,
          `Executing macro block: "${macroNode.name}"`,
          `Macro "${macroNode.name}"`
        );
        this.evaluateBlock(macroNode.block);
        break;
      }

      case 'if': {
        const result = evaluateCondition(node.condition, this.variables);

        this.addStep(
          node,
          result,
          `Evaluating condition: [${conditionToString(node.condition)}]. Evaluated to: ${result ? 'TRUE' : 'FALSE'}.`,
          `IF [${result ? 'True' : 'False'}]`
        );

        if (result) {
          this.logs.push(`[If] Condition matched. Executing then-block.`);
          this.evaluateBlock(node.thenBlock);
        } else {
          let elseifMatched = false;
          if (node.elseIfBlocks) {
            for (const elif of node.elseIfBlocks) {
              const elifResult = evaluateCondition(elif.condition, this.variables);

              this.addStep(
                node,
                elifResult,
                `Evaluating else-if condition: [${conditionToString(elif.condition)}]. Evaluated to: ${elifResult ? 'TRUE' : 'FALSE'}.`,
                `ELSE-IF [${elifResult ? 'True' : 'False'}]`
              );

              if (elifResult) {
                this.logs.push(`[If] Else-if matched. Executing else-if-block.`);
                this.evaluateBlock(elif.block);
                elseifMatched = true;
                break;
              }
            }
          }

          if (!elseifMatched && node.elseBlock) {
            this.logs.push(`[If] All conditions failed. Executing else-block.`);
            this.evaluateBlock(node.elseBlock);
          }
        }
        break;
      }
    }
  }

  private addStep(
    node: BplAstNode,
    executed: boolean,
    description: string,
    stepTitle: string
  ) {
    this.steps.push({
      currentNodeId: node.id,
      nodeType: node.type,
      executed,
      variableSnapshot: { ...this.variables },
      logs: [...this.logs],
      outputIncludes: [...this.outputIncludes],
      description: `${stepTitle} | ${description}`,
    });
  }
}