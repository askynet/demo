;FILE:  azet.bpl
;CREATED BY: MKP 11/14/95
;REVISION HISTORY:
;1. CREATED FOR AZ ET PROVISIONS FOR LARGE AND SMALL CASE
;**************************************************************************
script "AKASH ET FOR ARIZONA"
    {
    if ( medical equals "N" AND
        drugs equals "N" AND
        is_dental_care equals "N" AND
        vision equals "N" )
        jumpto bottom

    if ( funding equals "A" OR
        funding equals "E" )    ;insured or MPP
        include "cdbk/gen/broker/n1a"

    if ( medical equals "Y" )
        {
        if ( dependent_health equals "Y" )
            {
            if ( pre_exist_cond equals "Y" )  ;case has pre-existing
                include "book/az/etnotice/2a" send ( company )
            else  ;no pre-exist
                include "book/az/etnotice/2b" send ( company )
            }

        include "cdbk/gen/broker/n1b"
        }

    if ( product_type equals "A" OR
        product_type equals "B" )   ;plus or 500
        {
        if ( Key150_conversion equals "Y" )
            {
            if ( Key150_limitations equals "Y" )
                {
                if ( key150_conv_prior_funding equals "B" )
                    {
                    if ( single_employer_product_type equals "D" )  ;Aso Dry
                        include "book/az/etnotice/4a"
                    }
                
                else;  insured
                    include "book/az/etnotice/4a"
                }
            }
        }                                                    

    include "book/az/etnotice/5a"
    include "book/az/etnotice/6a"
    include "book/az/etnotice/7a"
    include "book/az/etnotice/8a"

    import "bzet.bpl"

    prompt "telehealth_net_ov_option: \v\n", telehealth_net_ov_option
    assign telehealth_net_ov_option to junk2
    prompt "telehealth_net_ov_ded_waived: \v\n", telehealth_net_ov_ded_waived
    assign telehealth_net_ov_ded_waived to junk2

    clearscreen

    only_if telehealth_net_ov_option
        {
        is "A"
        is "B"
            {    
            prompt "telehealth_net_ov_coins: \v\n", telehealth_net_ov_coins
            assign telehealth_net_ov_coins to junk2
            prompt "telehealth_net_ov_copay_amt: \v\n", telehealth_net_ov_copay_amt
            assign telehealth_net_ov_copay_amt to junk2
            }
        is "C"
        is "D"
            {
            prompt "telehealth_net_ov_coins: \v\n", telehealth_net_ov_coins
            assign telehealth_net_ov_coins to junk2
            prompt "telehealth_net_ov_copay_amt: \v\n", telehealth_net_ov_copay_amt
            assign telehealth_net_ov_copay_amt to junk2
            }    
        is "E"
            {
            prompt "telehealth_net_ov_coins: \v\n", telehealth_net_ov_coins
            assign telehealth_net_ov_coins to junk2
            prompt "telehealth_net_ov_copay_amt: \v\n", telehealth_net_ov_copay_amt
            assign telehealth_net_ov_copay_amt to junk2
            }    
        is "F"
            {
            prompt "telehealth_net_ov_coins: \v\n", telehealth_net_ov_coins
            assign telehealth_net_ov_coins to junk2
            prompt "telehealth_net_ov_copay_amt: \v\n", telehealth_net_ov_copay_amt
            assign telehealth_net_ov_copay_amt to junk2
            }    
        is "G"
            {
            prompt "telehealth_net_ov_coins: \v\n", telehealth_net_ov_coins
            assign telehealth_net_ov_coins to junk2
            prompt "telehealth_net_ov_copay_amt: \v\n", telehealth_net_ov_copay_amt
            assign telehealth_net_ov_copay_amt to junk2
            }    
        }    
end::
    getkey junk
    assign "" to junk
    assign "" to junk2
    assign "" to temp

bottom::
    }
