/**
 * Service to interact with the backend BPL Rules API
 */

import { BPL_SAMPLES } from "../data/samples";

export interface Rule {
  id: string;
  name: string;
  description: string;
  code?: string;
  ast?: any;
  nodes?: any[];
  defaultVariables: { [key: string]: any };
  createdAt?: string;
  updatedAt?: string;
  category?: string;
  isVirtual?: boolean;
}

export interface PaginatedRules {
  rules: Rule[];
  total: number;
  page: number;
  limit: number;
}

export const ruleService = {
  /**
   * Fetch stored rules from the API with pagination, search, and category filters
   */
  async fetchRules(
    search: string = '',
    page: number = 1,
    limit: number = 10,
    category: string = 'all'
  ): Promise<PaginatedRules> {
    return { rules: BPL_SAMPLES, total: 3, page: 1, limit: 10 };
    const params = new URLSearchParams({
      search,
      page: String(page),
      limit: String(limit),
      category
    });

    const response = await fetch(`/api/rules?${params.toString()}`);
    if (!response.ok) {
      const errData = await response.json().catch(() => ({}));
      throw new Error(errData.error || 'Failed to fetch rules');
    }
    return response.json();
  },

  /**
   * Fetch a single rule's full details
   */
  async fetchRuleById(id: string): Promise<Rule> {
    return BPL_SAMPLES[0];
    const response = await fetch(`/api/rules/${id}`);
    if (!response.ok) {
      const errData = await response.json().catch(() => ({}));
      throw new Error(errData.error || 'Failed to fetch rule details');
    }
    return response.json();
  },

  /**
   * Create a new rule
   */
  async createRule(rule: { name: string; description?: string; code?: string; ast?: any; nodes?: any[]; defaultVariables?: any }): Promise<Rule> {
    return { id: `${Math.random()}`, ...rule } as any;
    const response = await fetch('/api/rules', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(rule),
    });
    if (!response.ok) {
      const errData = await response.json().catch(() => ({}));
      throw new Error(errData.error || 'Failed to create rule');
    }
    return response.json();
  },

  /**
   * Update an existing rule
   */
  async updateRule(id: string, rule: Partial<Rule>): Promise<Rule> {
    const response = await fetch(`/api/rules/${id}`, {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(rule),
    });
    if (!response.ok) {
      const errData = await response.json().catch(() => ({}));
      throw new Error(errData.error || 'Failed to update rule');
    }
    return response.json();
  },

  /**
   * Delete a rule
   */
  async deleteRule(id: string): Promise<{ success: boolean; message: string }> {
    const response = await fetch(`/api/rules/${id}`, {
      method: 'DELETE',
    });
    if (!response.ok) {
      const errData = await response.json().catch(() => ({}));
      throw new Error(errData.error || 'Failed to delete rule');
    }
    return response.json();
  },
};
