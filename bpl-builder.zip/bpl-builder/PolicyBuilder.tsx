/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from 'react';
import {
  BplAstNode,
  ScriptNode,
  TraceStep,
  VariableState,
  IfNode,
  SwitchNode,
  LoopNode,
  LogNode,
  AssignNode,
  IncludeNode,
  JumpNode,
  ValidationNode,
  INodeType,
  OnlyIfNode,
  ImportNode,
  LabelNode,
  ReturnNode,
  ClearscreenNode,
  GetKeyNode,
  PromptNode,
  NODE_TYPE,
  MacroNode
} from './types/bpl';
import { BplParser, astToBpl, collectAllNodes, generateId } from './utils/parser';
import { BplInterpreter } from './utils/interpreter';
import { ruleService, Rule } from './services/ruleService';
import { motion, AnimatePresence } from 'motion/react';
import VisualFlow from './components/VisualFlow';
import NodeEditor from './components/NodeEditor';
import ValidationTab from './components/ValidationTab';
import SimulatorTab from './components/SimulatorTab';
import {
  FileText,
  Play,
  CheckCircle,
  Eye,
  AlertTriangle,
  ChevronRight,
  ChevronLeft,
  ChevronsLeft,
  ChevronsRight,
  Search,
  RefreshCw,
  Terminal,
  Cpu,
  Database,
  Upload,
  X,
  Trash2,
  Plus,
  Server,
  ArrowRightLeft,
  ArrowLeft,
  Copy,
  Download,
  Check,
  Layers,
  Settings,
  Sliders,
  Save,
  ToggleLeft
} from 'lucide-react';
import { BPL_SAMPLES } from './data/samples';
import { compileAstToBinary } from './services/compiler';

export function PolicyBuilder() {
  // Rules database state
  const [rules, setRules] = useState<Rule[]>([]);
  const [selectedRuleId, setSelectedRuleId] = useState<string>('');
  const [code, setCode] = useState(BPL_SAMPLES[0].code);
  const [variables, setVariables] = useState<VariableState>({});
  const [ast, setAst] = useState<ScriptNode | null>(null);
  const [errors, setErrors] = useState<any[]>([]);
  const [selectedNode, setSelectedNode] = useState<BplAstNode | null>(null);
  const isVisualUpdateRef = useRef(false);
  const [rightPanelTab, setRightPanelTab] = useState<'properties' | 'validate' | 'test'>('properties');
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);

  // Metadata editor state for selected rule
  const [ruleMetaName, setRuleMetaName] = useState('');
  const [ruleMetaDesc, setRuleMetaDesc] = useState('');
  const [ruleMetaCategory, setRuleMetaCategory] = useState('Financial');

  // New rule creation wizard states
  const [isNewRuleWizardOpen, setIsNewRuleWizardOpen] = useState(false);
  const [wizardStep, setWizardStep] = useState<'choice' | 'scratch' | 'import'>('choice');
  const [wizardName, setWizardName] = useState('');
  const [wizardDesc, setWizardDesc] = useState('');
  const [wizardCategory, setWizardCategory] = useState('Financial');
  const [wizardPasteCode, setWizardPasteCode] = useState('');
  const [dragActive, setDragActive] = useState(false);

  // Legacy BPL Importer states
  const [isLegacyImporterOpen, setIsLegacyImporterOpen] = useState(false);
  const [importerPasteCode, setImporterPasteCode] = useState('');
  const [importerName, setImporterName] = useState('Legacy Evaluator Rule');
  const [importerDesc, setImporterDesc] = useState('Legacy Booklet Policy parsed and compiled');
  const [importerCategory, setImporterCategory] = useState('Financial');
  const [importerErrors, setImporterErrors] = useState<any[]>([]);
  const [importerIsValid, setImporterIsValid] = useState(true);
  const [isOverwritingActiveRule, setIsOverwritingActiveRule] = useState(false);

  // API load state
  const [isApiLoading, setIsApiLoading] = useState(false);
  const [importNotification, setImportNotification] = useState<{ message: string; type: 'success' | 'error' } | null>(null);

  // Pagination & Filtering for high-scale Rules Table (145,000+ rules)
  const [dbSearch, setDbSearch] = useState('');
  const [dbPage, setDbPage] = useState(1);
  const [dbCategory, setDbCategory] = useState('all');
  const [totalRules, setTotalRules] = useState(0);
  const dbLimit = 8; // Row capacity per view limit

  // Interpreter trace states
  const [traceSteps, setTraceSteps] = useState<TraceStep[]>([]);
  const [currentStepIndex, setCurrentStepIndex] = useState(0);
  const [isPlaying, setIsPlaying] = useState(false);
  const [playbackSpeed, setPlaybackSpeed] = useState(1); // 0.5x, 1x, 2x, 5x
  const timerRef = useRef<NodeJS.Timeout | null>(null);
  const importerGutterRef = useRef<HTMLDivElement>(null);

  // Publisher simulation states
  const [publishProgress, setPublishProgress] = useState(0);
  const [publishLogs, setPublishLogs] = useState<string[]>([]);
  const [publishEnvironment, setPublishEnvironment] = useState<'staging' | 'prod-us-east' | 'prod-global-cdn'>('staging');
  const [isPublished, setIsPublished] = useState(false);
  const [publishedVersion, setPublishedVersion] = useState('v1.0.0');

  // Parser & Interpreter instances
  const parser = useRef(new BplParser());
  const interpreter = useRef(new BplInterpreter());

  // Reload rules list on search, page, or category change
  useEffect(() => {
    const loadRulesData = async () => {
      setIsApiLoading(true);
      try {
        const data = await ruleService.fetchRules(dbSearch, dbPage, dbLimit, dbCategory);
        setRules(data.rules);
        setTotalRules(data.total);

        // Auto-select first rule on load if none selected
        if (data.rules.length > 0 && !selectedRuleId && dbPage === 1 && !dbSearch) {
          const firstRule = data.rules[0];
          setSelectedRuleId(firstRule.id);
          const detailedRule = await ruleService.fetchRuleById(firstRule.id);
          let ruleCode = detailedRule.code;
          let ruleAst = detailedRule.ast;
          if (!ruleCode && ruleAst) {
            ruleCode = astToBpl(ruleAst);
          }
          setCode(ruleCode || '');
          setVariables(detailedRule.defaultVariables || {});
          setRuleMetaName(detailedRule.name);
          setRuleMetaDesc(detailedRule.description || '');
          setRuleMetaCategory(detailedRule.category || 'Financial');

          if (ruleAst) {
            setAst(ruleAst);
          } else if (ruleCode) {
            const { ast: parsedAst } = parser.current.parse(ruleCode);
            if (parsedAst) setAst(parsedAst);
          } else {
            setAst(null);
          }
        }
      } catch (err: any) {
        console.error('Error fetching rules:', err);
        setImportNotification({ message: 'Failed to fetch rules from backend database.', type: 'error' });
      } finally {
        setIsApiLoading(false);
      }
    };

    const delayDebounceFn = setTimeout(() => {
      loadRulesData();
    }, dbSearch ? 250 : 0);

    return () => clearTimeout(delayDebounceFn);
  }, [dbSearch, dbPage, dbCategory]);

  // Reset page to 1 on filter changes
  useEffect(() => {
    setDbPage(1);
  }, [dbSearch, dbCategory]);

  // Auto-clear notification toast
  useEffect(() => {
    if (importNotification) {
      const timer = setTimeout(() => {
        setImportNotification(null);
      }, 5000);
      return () => clearTimeout(timer);
    }
  }, [importNotification]);

  // Parse code on input change and sync AST
  useEffect(() => {
    if (isVisualUpdateRef.current) {
      isVisualUpdateRef.current = false;
      const { errors: parserErrors } = parser.current.parse(code);
      setErrors(parserErrors);
      return;
    }
    const { ast: parsedAst, errors: parserErrors } = parser.current.parse(code);
    setErrors(parserErrors);
    if (parsedAst) {
      setAst(parsedAst);
    }
  }, [code]);

  // Execute interpreter on AST or variables change to gather execution steps
  useEffect(() => {
    if (ast) {
      const steps = interpreter.current.execute(ast, variables);
      setTraceSteps(steps);
      setCurrentStepIndex(0);
    } else {
      setTraceSteps([]);
      setCurrentStepIndex(0);
    }
  }, [ast, variables]);

  // Auto playback trigger for trace sessions
  useEffect(() => {
    if (isPlaying) {
      const delay = 1000 / playbackSpeed;
      timerRef.current = setInterval(() => {
        setCurrentStepIndex((prev) => {
          if (prev < traceSteps.length - 1) {
            return prev + 1;
          } else {
            setIsPlaying(false);
            return prev;
          }
        });
      }, delay);
    } else {
      if (timerRef.current) {
        clearInterval(timerRef.current);
      }
    }

    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [isPlaying, playbackSpeed, traceSteps]);

  // Select active rule from DB
  const handleSelectRule = async (ruleId: string) => {
    setIsApiLoading(true);
    setSelectedNode(null);
    setRightPanelTab('properties');
    setIsSidebarOpen(false);
    try {
      const rule = await ruleService.fetchRuleById(ruleId);
      setSelectedRuleId(rule.id);
      let ruleCode = rule.code;
      let ruleAst = rule.ast;
      if (!ruleCode && ruleAst) {
        ruleCode = astToBpl(ruleAst);
      }
      setCode(ruleCode || '');
      setVariables(rule.defaultVariables || {});
      setRuleMetaName(rule.name);
      setRuleMetaDesc(rule.description || '');
      setRuleMetaCategory(rule.category || 'Financial');

      if (ruleAst) {
        setAst(ruleAst);
      } else if (ruleCode) {
        const { ast: parsedAst } = parser.current.parse(ruleCode);
        if (parsedAst) {
          setAst(parsedAst);
        } else {
          setAst(null);
        }
      } else {
        setAst(null);
      }
      setIsPlaying(false);
      setImportNotification({ message: `Loaded Policy: ${rule.name}`, type: 'success' });
    } catch (err: any) {
      console.error('Error loading rule details:', err);
      setImportNotification({ message: 'Failed to fetch rule details from database.', type: 'error' });
    } finally {
      setIsApiLoading(false);
    }
  };

  // Save current rule metadata & code to database
  const handleSaveCurrentRule = async () => {
    console.log('ast', JSON.stringify(ast));
    if (ast) {
      console.log('binary', compileAstToBinary(ast));
    }

    if (!selectedRuleId) {
      setImportNotification({ message: 'Select or create a rule before saving.', type: 'error' });
      return;
    }
    if (errors.length > 0) {
      setImportNotification({ message: 'Please fix a rule before saving.', type: 'error' });
      return;
    }
    setIsApiLoading(true);
    try {
      const nodesList = ast ? collectAllNodes(ast) : [];
      const updated = await ruleService.updateRule(selectedRuleId, {
        name: ruleMetaName,
        description: ruleMetaDesc,
        category: ruleMetaCategory,
        code: code,
        ast: ast,
        nodes: nodesList,
        defaultVariables: variables
      });
      // Update local rules array list
      setRules((prev) => prev.map((r) => (r.id === selectedRuleId ? updated : r)));
      setImportNotification({ message: `Saved changes to "${updated.name}" successfully!`, type: 'success' });
    } catch (err: any) {
      console.error('Error updating rule:', err);
      setImportNotification({ message: 'Failed to save changes to database server.', type: 'error' });
    } finally {
      setIsApiLoading(false);
    }
  };

  // Duplicate active rule
  const handleDuplicateRule = async (rule: Rule, e: React.MouseEvent) => {
    e.stopPropagation();
    setIsApiLoading(true);
    try {
      const cloneName = `${rule.name} (Copy)`;
      const nodesList = rule.ast ? collectAllNodes(rule.ast) : [];
      const newRule = await ruleService.createRule({
        name: cloneName,
        description: rule.description || 'Duplicated policy rule',
        code: rule.code,
        ...(rule.ast ? { ast: rule.ast, nodes: nodesList } : { code: rule.code }),
        defaultVariables: rule.defaultVariables || {}
      });

      // Update categories as well
      // await ruleService.updateRule(newRule.id, { category: rule.category || 'Financial' });

      setRules((prev) => [newRule, ...prev]);
      setTotalRules((t) => t + 1);
      setSelectedRuleId(newRule.id);
      let ruleCode = newRule.code;
      if (!ruleCode && newRule.ast) {
        ruleCode = astToBpl(newRule.ast);
      }
      setCode(ruleCode || '');
      setVariables(newRule.defaultVariables || {});
      setRuleMetaName(cloneName);
      setRuleMetaDesc(rule.description || '');
      setRuleMetaCategory(rule.category || 'Financial');

      setImportNotification({ message: `Duplicated rule into: "${cloneName}"`, type: 'success' });
    } catch (err: any) {
      console.error('Error duplicating rule:', err);
      setImportNotification({ message: 'Failed to duplicate rule on server.', type: 'error' });
    } finally {
      setIsApiLoading(false);
    }
  };

  // Delete rule
  const handleDeleteRule = async (ruleId: string, e: React.MouseEvent) => {
    e.stopPropagation();
    if (!window.confirm('Are you sure you want to permanently delete this rule from the database?')) return;

    setIsApiLoading(true);
    try {
      await ruleService.deleteRule(ruleId);
      const remaining = rules.filter((r) => r.id !== ruleId);
      setRules(remaining);
      setTotalRules((t) => t - 1);
      setImportNotification({ message: 'Rule deleted from database successfully.', type: 'success' });

      if (selectedRuleId === ruleId) {
        if (remaining.length > 0) {
          handleSelectRule(remaining[0].id);
        } else {
          setSelectedRuleId('');
          setCode('');
          setVariables({});
          setAst(null);
          setRuleMetaName('');
          setRuleMetaDesc('');
        }
      }
    } catch (err: any) {
      console.error('Error deleting rule:', err);
      setImportNotification({ message: 'Failed to delete rule from database.', type: 'error' });
    } finally {
      setIsApiLoading(false);
    }
  };

  // Wizard Handlers
  const handleWizardScratchSubmit = async () => {
    if (!wizardName.trim()) return;
    setIsApiLoading(true);
    try {
      const baseCode = `script "${wizardName}"
{
  log "Initial baseline verification for ${wizardName}..."
  assign "InitialValue" to status
}
`;
      const { ast: parsedAst } = parser.current.parse(baseCode);
      const nodesList = parsedAst ? collectAllNodes(parsedAst) : [];
      const newRule = await ruleService.createRule({
        name: wizardName,
        description: wizardDesc,
        code: baseCode,
        ast: parsedAst,
        nodes: nodesList,
        defaultVariables: { status: 'Pending' }
      });

      // Update category
      const updated = newRule;
      // const updated = await ruleService.updateRule(newRule.id, { category: wizardCategory });

      setRules((prev) => [updated, ...prev]);
      setTotalRules((t) => t + 1);
      setSelectedRuleId(updated.id);
      setCode(baseCode);
      setVariables(updated.defaultVariables || {});
      setRuleMetaName(updated.name);
      setRuleMetaDesc(updated.description || '');
      setRuleMetaCategory(updated.category || 'Financial');

      if (parsedAst) setAst(parsedAst);

      setImportNotification({ message: `Created rule "${updated.name}" from scratch!`, type: 'success' });
      closeNewRuleWizard();
    } catch (err: any) {
      console.error('Error creating scratch rule:', err);
      setImportNotification({ message: 'Failed to create new rule on database.', type: 'error' });
    } finally {
      setIsApiLoading(false);
    }
  };

  const handleWizardImportSubmit = async () => {
    if (!wizardName.trim() || !wizardPasteCode.trim()) return;
    setIsApiLoading(true);
    try {
      // Validate code first
      const { errors: parseErrors } = parser.current.parse(wizardPasteCode);
      if (parseErrors.length > 0) {
        throw new Error(`Syntax error: ${parseErrors[0].message} at line ${parseErrors[0].line}`);
      }

      const { ast: parsedAst } = parser.current.parse(wizardPasteCode);
      const nodesList = parsedAst ? collectAllNodes(parsedAst) : [];
      const newRule = await ruleService.createRule({
        name: wizardName,
        description: wizardDesc,
        code: wizardPasteCode,
        ast: parsedAst,
        nodes: nodesList,
        defaultVariables: { status: 'Imported' }
      });

      // Update category
      const updated = newRule;
      // const updated = await ruleService.updateRule(newRule.id, { category: wizardCategory });

      setRules((prev) => [updated, ...prev]);
      setTotalRules((t) => t + 1);
      setSelectedRuleId(updated.id);
      setCode(wizardPasteCode);
      setVariables(updated.defaultVariables || {});
      setRuleMetaName(updated.name);
      setRuleMetaDesc(updated.description || '');
      setRuleMetaCategory(updated.category || 'Financial');

      if (parsedAst) setAst(parsedAst);

      setImportNotification({ message: `Imported and compiled Booklet Policy: "${updated.name}"`, type: 'success' });
      closeNewRuleWizard();
    } catch (err: any) {
      console.error('Error importing rule:', err);
      setImportNotification({ message: err.message || 'Failed to import and compile policy.', type: 'error' });
    } finally {
      setIsApiLoading(false);
    }
  };

  const handleImporterFileUpload = (file: File) => {
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (e) => {
      const text = e.target?.result;
      if (typeof text === 'string') {
        handleImporterCodeChange(text);
        const scriptMatch = text.match(/script\s+"([^"]+)"/i);
        if (scriptMatch && scriptMatch[1] && !isOverwritingActiveRule) {
          setImporterName(scriptMatch[1]);
        }
      }
    };
    reader.readAsText(file);
  };

  const closeNewRuleWizard = () => {
    setIsNewRuleWizardOpen(false);
    setWizardStep('choice');
    setWizardName('');
    setWizardDesc('');
    setWizardPasteCode('');
    setWizardCategory('Financial');
  };

  // Helper to count nodes and compile metrics for pasted code
  const getImporterMetrics = () => {
    if (!importerPasteCode.trim()) return null;
    try {
      const { ast: parsedAst } = parser.current.parse(importerPasteCode);
      if (!parsedAst) return null;

      let logs = 0;
      let conditionals = 0;
      let assignments = 0;
      let validations = 0;
      let loops = 0;
      let switches = 0;
      let total = 0;

      const traverse = (n: BplAstNode) => {
        total++;
        if (n.type === 'log') logs++;
        else if (n.type === 'if') conditionals++;
        else if (n.type === 'assign') assignments++;
        else if (n.type === 'validation') validations++;
        else if (n.type === 'loop') loops++;
        else if (n.type === 'switch') switches++;

        if (n.type === 'script') {
          (n as any).children?.forEach(traverse);
        } else if (n.type === 'if') {
          const ifN = n as any;
          ifN.thenBlock?.forEach(traverse);
          ifN.elseIfBlocks?.forEach((elif: any) => elif.block?.forEach(traverse));
          ifN.elseBlock?.forEach(traverse);
        } else if (n.type === 'switch') {
          const swN = n as any;
          swN.cases?.forEach((c: any) => c.block?.forEach(traverse));
          swN.defaultBlock?.forEach(traverse);
        } else if (n.type === 'loop') {
          (n as any).block?.forEach(traverse);
        }
      };

      traverse(parsedAst);
      return { total, logs, conditionals, assignments, validations, loops, switches };
    } catch {
      return null;
    }
  };

  const handleImporterCodeChange = (val: string) => {
    setImporterPasteCode(val);
    if (!val.trim()) {
      setImporterErrors([]);
      setImporterIsValid(true);
      return;
    }
    const { errors: parseErrors } = parser.current.parse(val);
    setImporterErrors(parseErrors);
    setImporterIsValid(parseErrors.length === 0);
  };

  const handleImporterSubmit = async () => {
    if (!importerPasteCode.trim()) return;
    setIsApiLoading(true);

    try {
      // Validate code first
      const { ast: parsedAst, errors: parseErrors } = parser.current.parse(importerPasteCode);
      if (parseErrors.length > 0) {
        setImporterErrors(parseErrors);
        setImporterIsValid(false);
        throw new Error(`Syntax validation failed with ${parseErrors.length} error(s). Please correct them to import.`);
      }

      if (!parsedAst) {
        throw new Error("Could not construct visual flow from code.");
      }

      const nodesList = collectAllNodes(parsedAst);

      if (isOverwritingActiveRule) {
        // Overwrite active rule
        if (!selectedRuleId) {
          throw new Error("No active rule selected to overwrite.");
        }

        // const updated = await ruleService.updateRule(selectedRuleId, {
        //   code: importerPasteCode,
        //   ast: parsedAst,
        //   nodes: nodesList,
        // });

        // setRules((prev) => prev.map((r) => r.id === selectedRuleId ? updated : r));
        setCode(astToBpl(parsedAst));
        setAst(parsedAst);

        setImportNotification({
          message: `Overwrote and updated visual flow for "${ruleMetaName}"`,
          type: 'success',
        });
      } else {
        // Import as new rule
        const finalName = importerName.trim() || parsedAst.name || 'Legacy Imported Rule';
        const newRule = await ruleService.createRule({
          name: finalName,
          description: importerDesc,
          code: importerPasteCode,
          ast: parsedAst,
          nodes: nodesList,
          defaultVariables: { status: 'Legacy Imported' }
        });

        // Update category
        const updated = newRule; 
        // const updated = await ruleService.updateRule(newRule.id, { category: importerCategory });

        setRules((prev) => [updated, ...prev]);
        setTotalRules((t) => t + 1);
        setSelectedRuleId(updated.id);
        setCode(astToBpl(parsedAst));
        setVariables(updated.defaultVariables || {});
        setRuleMetaName(updated.name);
        setRuleMetaDesc(updated.description || '');
        setRuleMetaCategory(updated.category || 'Financial');
        setAst(parsedAst);

        setImportNotification({
          message: `Legacy policy "${updated.name}" imported and compiled to visual flow!`,
          type: 'success',
        });
      }

      setIsLegacyImporterOpen(false);
    } catch (err: any) {
      console.error('Importer error:', err);
      setImportNotification({
        message: err.message || 'Failed to import and convert legacy code.',
        type: 'error',
      });
    } finally {
      setIsApiLoading(false);
    }
  };

  const handleRemoveVariable = (key: string) => {
    setVariables((prev) => {
      const copy = { ...prev };
      delete copy[key];
      return copy;
    });
  };

  const handleUpdateVariableValue = (key: string, value: any) => {
    setVariables((prev) => ({ ...prev, [key]: value }));
  };

  // Tracing variables extraction for Test step
  const currentStep: TraceStep | undefined = traceSteps[currentStepIndex];
  const activeNodeId = currentStep ? currentStep.currentNodeId : null;
  const activeVariables = currentStep ? currentStep.variableSnapshot : variables;
  const activeLogs = currentStep ? currentStep.logs : [];
  const activeIncludes = currentStep ? currentStep.outputIncludes : [];

  // Download raw rule as BPL file
  const handleDownloadBplFile = (rule: Rule) => {
    // const element = document.createElement("a");
    // const file = new Blob([rule.code], { type: 'text/plain;charset=utf-8' });
    // element.href = URL.createObjectURL(file);
    // element.download = `${rule.name.toLowerCase().replace(/\s+/g, '_')}.bpl`;
    // document.body.appendChild(element);
    // element.click();
    // document.body.removeChild(element);
  };

  // Helper recursive functions for Visual AST updates
  const updateNodeInTree = (nodes: BplAstNode[], nodeId: string, fields: Partial<BplAstNode>): boolean => {
    for (let i = 0; i < nodes.length; i++) {
      const node = nodes[i];
      if (node.id === nodeId) {
        nodes[i] = { ...node, ...fields } as BplAstNode;
        return true;
      }
      if (node.type === 'if') {
        const ifNode = node as IfNode;
        if (updateNodeInTree(ifNode.thenBlock, nodeId, fields)) return true;
        if (ifNode.elseBlock && updateNodeInTree(ifNode.elseBlock, nodeId, fields)) return true;
        if (ifNode.elseIfBlocks) {
          for (const elif of ifNode.elseIfBlocks) {
            if (updateNodeInTree(elif.block, nodeId, fields)) return true;
          }
        }
      } else if (node.type === 'switch') {
        const swNode = node as SwitchNode;
        for (const c of swNode.cases) {
          if (updateNodeInTree(c.block, nodeId, fields)) return true;
        }
        if (swNode.defaultBlock && updateNodeInTree(swNode.defaultBlock, nodeId, fields)) return true;
      } else if (node.type === 'only_if') {
        const onlyIfNode = node as any;
        for (const c of onlyIfNode.cases) {
          if (updateNodeInTree(c.block, nodeId, fields)) return true;
        }
      } else if (node.type === 'loop') {
        const loopNode = node as LoopNode;
        if (updateNodeInTree(loopNode.block, nodeId, fields)) return true;
      }
    }
    return false;
  };

  const deleteNodeFromTree = (nodes: BplAstNode[], nodeId: string): boolean => {
    for (let i = 0; i < nodes.length; i++) {
      const node = nodes[i];
      if (node.id === nodeId) {
        nodes.splice(i, 1);
        return true;
      }
      if (node.type === 'if') {
        const ifNode = node as IfNode;
        if (deleteNodeFromTree(ifNode.thenBlock, nodeId)) return true;
        if (ifNode.elseBlock && deleteNodeFromTree(ifNode.elseBlock, nodeId)) return true;
        if (ifNode.elseIfBlocks) {
          for (const elif of ifNode.elseIfBlocks) {
            if (deleteNodeFromTree(elif.block, nodeId)) return true;
          }
        }
      } else if (node.type === 'switch') {
        const swNode = node as SwitchNode;
        for (const c of swNode.cases) {
          if (deleteNodeFromTree(c.block, nodeId)) return true;
        }
        if (swNode.defaultBlock && deleteNodeFromTree(swNode.defaultBlock, nodeId)) return true;
      } else if (node.type === 'only_if') {
        const onlyIfNode = node as any;
        for (const c of onlyIfNode.cases) {
          if (deleteNodeFromTree(c.block, nodeId)) return true;
        }
      } else if (node.type === 'loop') {
        const loopNode = node as LoopNode;
        if (deleteNodeFromTree(loopNode.block, nodeId)) return true;
      } else if (node.type === 'macro') {
        const loopNode = node as MacroNode;
        if (deleteNodeFromTree(loopNode.block, nodeId)) return true;
      }
    }
    return false;
  };

  const findNodeInTree = (nodes: BplAstNode[], nodeId: string): BplAstNode | null => {
    for (let i = 0; i < nodes.length; i++) {
      const node = nodes[i];
      if (node.id === nodeId) {
        return node;
      }
      if (node.type === 'if') {
        const ifNode = node as IfNode;
        const found = findNodeInTree(ifNode.thenBlock, nodeId);
        if (found) return found;
        if (ifNode.elseBlock) {
          const f = findNodeInTree(ifNode.elseBlock, nodeId);
          if (f) return f;
        }
        if (ifNode.elseIfBlocks) {
          for (const elif of ifNode.elseIfBlocks) {
            const f = findNodeInTree(elif.block, nodeId);
            if (f) return f;
          }
        }
      } else if (node.type === 'switch') {
        const swNode = node as SwitchNode;
        for (const c of swNode.cases) {
          const found = findNodeInTree(c.block, nodeId);
          if (found) return found;
        }
        if (swNode.defaultBlock) {
          const found = findNodeInTree(swNode.defaultBlock, nodeId);
          if (found) return found;
        }
      } else if (node.type === 'only_if') {
        const onlyIfNode = node as any;
        for (const c of onlyIfNode.cases) {
          const found = findNodeInTree(c.block, nodeId);
          if (found) return found;
        }
      } else if (node.type === 'loop') {
        const loopNode = node as LoopNode;
        const found = findNodeInTree(loopNode.block, nodeId);
        if (found) return found;
      } else if (node.type === 'macro') {
        const loopNode = node as MacroNode;
        const found = findNodeInTree(loopNode.block, nodeId);
        if (found) return found;
      }
    }
    return null;
  };

  const addNodeToTree = (nodes: BplAstNode[], targetNodeId: string, newNode: BplAstNode): boolean => {
    if (targetNodeId === 'root') {
      nodes.unshift(newNode);
      return true;
    }

    if (targetNodeId.startsWith('empty-')) {
      const parts = targetNodeId.split('-');
      const type = parts[1];
      const hasIndex = type === 'case' || type === 'elseif';
      const containerNodeId = hasIndex
        ? parts.slice(2, parts.length - 1).join('-')
        : parts.slice(2).join('-');
      const indexValue = hasIndex ? parseInt(parts[parts.length - 1], 10) : 0;

      const container = findNodeInTree(nodes, containerNodeId);
      if (container) {
        if (type === 'case') {
          const caseIdx = indexValue;
          if (container.type === 'switch') {
            const swNode = container as SwitchNode;
            if (swNode.cases[caseIdx]) {
              swNode.cases[caseIdx].block.push(newNode);
              return true;
            }
          } else if (container.type === 'only_if') {
            const onlyIfNode = container as any;
            if (onlyIfNode.cases[caseIdx]) {
              onlyIfNode.cases[caseIdx].block.push(newNode);
              return true;
            }
          }
        } else if (type === 'default') {
          if (container.type === 'switch') {
            const swNode = container as SwitchNode;
            if (!swNode.defaultBlock) {
              swNode.defaultBlock = [];
            }
            swNode.defaultBlock.push(newNode);
            return true;
          }
        } else if (type === 'then') {
          if (container.type === 'if') {
            const ifNode = container as IfNode;
            if (!ifNode.thenBlock) {
              ifNode.thenBlock = [];
            }
            ifNode.thenBlock.push(newNode);
            return true;
          }
        } else if (type === 'else') {
          if (container.type === 'if') {
            const ifNode = container as IfNode;
            if (!ifNode.elseBlock) {
              ifNode.elseBlock = [];
            }
            ifNode.elseBlock.push(newNode);
            return true;
          }
        } else if (type === 'elseif') {
          const elifIdx = indexValue;
          if (container.type === 'if') {
            const ifNode = container as IfNode;
            if (ifNode.elseIfBlocks && ifNode.elseIfBlocks[elifIdx]) {
              ifNode.elseIfBlocks[elifIdx].block.push(newNode);
              return true;
            }
          }
        } else if (type === 'loop') {
          if (container.type === 'loop') {
            const loopNode = container as LoopNode;
            if (!loopNode.block) {
              loopNode.block = [];
            }
            loopNode.block.push(newNode);
            return true;
          }
        } else if (type === 'macro') {
          if (container.type === 'macro') {
            const macroNode = container as any;
            if (!macroNode.block) {
              macroNode.block = [];
            }
            macroNode.block.push(newNode);
            return true;
          }
        }
      }
    }

    for (let i = 0; i < nodes.length; i++) {
      const node = nodes[i];
      if (node.id === targetNodeId) {
        nodes.splice(i + 1, 0, newNode);
        return true;
      }
      if (node.type === 'if') {
        const ifNode = node as IfNode;
        if (addNodeToTree(ifNode.thenBlock, targetNodeId, newNode)) return true;
        if (ifNode.elseBlock && addNodeToTree(ifNode.elseBlock, targetNodeId, newNode)) return true;
        if (ifNode.elseIfBlocks) {
          for (const elif of ifNode.elseIfBlocks) {
            if (addNodeToTree(elif.block, targetNodeId, newNode)) return true;
          }
        }
      } else if (node.type === 'switch') {
        const swNode = node as SwitchNode;
        for (const c of swNode.cases) {
          if (addNodeToTree(c.block, targetNodeId, newNode)) return true;
        }
        if (swNode.defaultBlock && addNodeToTree(swNode.defaultBlock, targetNodeId, newNode)) return true;
      } else if (node.type === 'only_if') {
        const onlyIfNode = node as any;
        for (const c of onlyIfNode.cases) {
          if (addNodeToTree(c.block, targetNodeId, newNode)) return true;
        }
      } else if (node.type === 'loop') {
        const loopNode = node as LoopNode;
        if (addNodeToTree(loopNode.block, targetNodeId, newNode)) return true;
      } else if (node.type === 'macro') {
        const loopNode = node as MacroNode;
        if (addNodeToTree(loopNode.block, targetNodeId, newNode)) return true;
      }
    }
    return false;
  };

  const handleVisualUpdateNodeProperty = (nodeId: string, updatedFields: Partial<BplAstNode>) => {
    if (!ast) return;
    const clone = JSON.parse(JSON.stringify(ast)) as ScriptNode;
    const found = updateNodeInTree(clone.children, nodeId, updatedFields);
    if (found) {
      isVisualUpdateRef.current = true;
      const newCode = astToBpl(clone);
      setCode(newCode);
      setAst(clone);
      if (selectedNode && selectedNode.id === nodeId) {
        setSelectedNode({ ...selectedNode, ...updatedFields } as BplAstNode);
      }
    }
  };

  const handleVisualDeleteNode = (nodeId: string) => {
    if (!ast) return;
    const clone = JSON.parse(JSON.stringify(ast)) as ScriptNode;
    const found = deleteNodeFromTree(clone.children, nodeId);
    if (found) {
      isVisualUpdateRef.current = true;
      const newCode = astToBpl(clone);
      setCode(newCode);
      setAst(clone);
      if (selectedNode?.id === nodeId) {
        setSelectedNode(null);
      }
      setImportNotification({ message: 'Node deleted successfully.', type: 'success' });
    }
  };

  const handleVisualAddNode = (targetNodeId: string, type: INodeType) => {
    console.log('add new', targetNodeId, type)
    if (!ast) return;
    let newNode: BplAstNode;

    if (type === 'log') {
      newNode = {
        id: generateId('log'),
        type: 'log',
        message: 'New system log statement'
      } as LogNode;
    } else if (type === 'assign') {
      newNode = {
        id: generateId('assign'),
        type: 'assign',
        variable: 'status',
        value: 'Approved',
        isValueIdentifier: false
      } as AssignNode;
    } else if (type === 'include') {
      newNode = {
        id: generateId('include'),
        type: 'include',
        path: 'core/shared-rules'
      } as IncludeNode;
    } else if (type === 'jump') {
      newNode = {
        id: generateId('jump'),
        type: 'jump',
        target: 'exitLabel'
      } as JumpNode;
    } else if (type === 'validation') {
      newNode = {
        id: generateId('validation'),
        type: 'validation',
        condition: {
          field: 'status',
          operator: 'equals',
          value: 'active'
        },
        errorMessage: 'Assertion constraint violated'
      } as ValidationNode;
    } else if (type === 'if') {
      newNode = {
        id: generateId('if'),
        type: 'if',
        condition: {
          field: 'status',
          operator: 'equals',
          value: 'active'
        },
        thenBlock: [
          {
            id: generateId('log'),
            type: 'log',
            message: 'Conditional block matched'
          }
        ],
        elseBlock: []
      } as IfNode;
    }
    else if (type === 'prompt') {
      newNode = {
        id: generateId('prompt'),
        type: 'prompt',
        message: 'Enter value:',
        variable: 'value',
      } as PromptNode;
    }
    else if (type === 'getkey') {
      newNode = {
        id: generateId('getkey'),
        type: 'getkey',
        variable: 'key',
      } as GetKeyNode;
    }
    else if (type === 'clearscreen') {
      newNode = {
        id: generateId('clearscreen'),
        type: 'clearscreen',
      } as ClearscreenNode;
    }
    else if (type === 'label') {
      newNode = {
        id: generateId('label'),
        type: 'label',
        name: 'newLabel',
      } as LabelNode;
    }
    else if (type === 'return') {
      newNode = {
        id: generateId('return'),
        type: 'return',
      } as ReturnNode;
    }
    else if (type === NODE_TYPE.ONLY_IF) {
      newNode = {
        id: generateId(NODE_TYPE.ONLY_IF),
        type: NODE_TYPE.ONLY_IF,
        variable: 'status',
        cases: [
          {
            values: ['A'],
            block: [],
          },
        ],
      } as OnlyIfNode;
    }
    else if (type === 'import') {
      newNode = {
        id: generateId('import'),
        type: 'import',
        file: 'shared/common.bpl',
      } as ImportNode;
    } else if (type === NODE_TYPE.MARCRO) {
      newNode = {
        id: generateId(NODE_TYPE.MARCRO),
        type: NODE_TYPE.MARCRO,
        name: 'custom_logic',
        block: []
      } as MacroNode;
    }
    else {
      return;
    }

    const clone = JSON.parse(JSON.stringify(ast)) as ScriptNode;
    const found = addNodeToTree(clone.children, targetNodeId, newNode);
    if (found) {
      isVisualUpdateRef.current = true;
      const newCode = astToBpl(clone);
      setCode(newCode);
      setAst(clone);
      setSelectedNode(newNode);
      setRightPanelTab('properties');
      setIsSidebarOpen(true);
      setImportNotification({ message: `Added new ${type} node to visual path.`, type: 'success' });
    }
  };

  // Walk the AST recursively to render a custom hierarchy component for Validate Step
  const renderAstNodeElement = (node: BplAstNode, depth: number = 0) => {
    const isNodeExecuting = activeNodeId === node.id;
    let detailsStr = '';
    let icon = <Layers className="w-3.5 h-3.5 text-indigo-500" />;

    if (node.type === 'log') {
      detailsStr = `message: "${(node as any).message}"`;
      icon = <Terminal className="w-3.5 h-3.5 text-teal-500" />;
    } else if (node.type === 'assign') {
      detailsStr = `var: "${(node as any).variable}" ➜ val: "${(node as any).value}"`;
      icon = <Sliders className="w-3.5 h-3.5 text-emerald-500" />;
    } else if (node.type === 'include') {
      detailsStr = `template: "${(node as any).path}"`;
      icon = <FileText className="w-3.5 h-3.5 text-sky-500" />;
    } else if (node.type === 'jump') {
      detailsStr = `target: "${(node as any).target}"`;
      icon = <ArrowRightLeft className="w-3.5 h-3.5 text-amber-500" />;
    } else if (node.type === 'if') {
      const ifNode = node as IfNode;
      const formatCond = (cond: any): string => {
        if (!cond) return '';
        if (cond.type === 'condition-group' || cond.conditions) {
          return (cond.conditions || []).map((c: any) => formatCond(c)).join(` ${cond.operator || 'AND'} `);
        }
        return `${cond.field || ''} ${cond.operator || ''} ${cond.value || ''}`;
      };
      detailsStr = `IF [ ${formatCond(ifNode.condition)} ]`;
      icon = <Sliders className="w-3.5 h-3.5 text-indigo-600" />;
    } else if (node.type === 'switch') {
      detailsStr = `SWITCH [ ${(node as any).variable} ]`;
      icon = <Layers className="w-3.5 h-3.5 text-violet-500" />;
    } else if (node.type === 'loop') {
      detailsStr = `LOOP over ${(node as any).collection}`;
      icon = <RefreshCw className="w-3.5 h-3.5 text-fuchsia-500 animate-spin-slow" />;
    } else if (node.type === NODE_TYPE.ONLY_IF) {
      detailsStr = `ONLY_IF [ ${(node as any).variable} ]`;
      icon = <ToggleLeft className="w-3.5 h-3.5 text-indigo-500" />;
    } else if (node.type === 'clearscreen') {
      detailsStr = `CLEAR SCREEN`;
      icon = <Layers className="w-3.5 h-3.5 text-orange-500" />;
    } else if (node.type === 'prompt') {
      detailsStr = `PROMPT [ ${(node as any).variable} ]: "${(node as any).message}"`;
      icon = <Terminal className="w-3.5 h-3.5 text-pink-500" />;
    } else if (node.type === 'getkey') {
      detailsStr = `GETKEY [ ${(node as any).variable} ]`;
      icon = <Terminal className="w-3.5 h-3.5 text-blue-500" />;
    } else if (node.type === 'error') {
      detailsStr = `ERROR EXIT: "${(node as any).message}"`;
      icon = <AlertTriangle className="w-3.5 h-3.5 text-red-500" />;
    }

    return (
      <div key={node.id} className="space-y-1">
        <div
          className={`flex items-center gap-2 px-3 py-2 rounded-xl text-xs border transition ${isNodeExecuting
            ? 'bg-indigo-50 border-indigo-200 text-indigo-900 font-semibold shadow-xs'
            : 'bg-white border-gray-150 hover:bg-slate-50 text-gray-700'
            }`}
          style={{ marginLeft: `${depth * 20}px` }}
        >
          <span className="text-[10px] uppercase font-mono font-bold bg-slate-150 text-slate-600 px-1.5 py-0.5 rounded">
            {node.type}
          </span>
          <div className="shrink-0">{icon}</div>
          <span className="font-mono text-gray-600 truncate">{detailsStr}</span>
          <span className="ml-auto text-[9px] font-mono text-gray-400">ID: {node.id.split('-')[1] || node.id}</span>
        </div>

        {/* Children Blocks */}
        {node.type === 'if' && (
          <div className="space-y-1">
            <div className="text-[9px] font-bold text-slate-400 uppercase tracking-widest pl-4" style={{ marginLeft: `${(depth + 1) * 20}px` }}>THEN Block</div>
            {(node as IfNode).thenBlock.map(child => renderAstNodeElement(child, depth + 1))}
            {(node as IfNode).elseBlock && (node as IfNode).elseBlock!.length > 0 && (
              <>
                <div className="text-[9px] font-bold text-slate-400 uppercase tracking-widest pl-4" style={{ marginLeft: `${(depth + 1) * 20}px` }}>ELSE Block</div>
                {(node as IfNode).elseBlock!.map(child => renderAstNodeElement(child, depth + 1))}
              </>
            )}
          </div>
        )}

        {node.type === 'switch' && (
          <div className="space-y-1">
            {(node as SwitchNode).cases.map((c, idx) => (
              <div key={idx} className="space-y-1">
                <div className="text-[9px] font-bold text-slate-400 uppercase tracking-widest pl-4" style={{ marginLeft: `${(depth + 1) * 20}px` }}>CASE: "{c.value}"</div>
                {c.block.map(child => renderAstNodeElement(child, depth + 1))}
              </div>
            ))}
            {(node as SwitchNode).defaultBlock && (
              <div className="space-y-1">
                <div className="text-[9px] font-bold text-slate-400 uppercase tracking-widest pl-4" style={{ marginLeft: `${(depth + 1) * 20}px` }}>DEFAULT CASE</div>
                {(node as SwitchNode).defaultBlock!.map(child => renderAstNodeElement(child, depth + 1))}
              </div>
            )}
          </div>
        )}

        {node.type === 'loop' && (
          <div className="space-y-1">
            <div className="text-[9px] font-bold text-slate-400 uppercase tracking-widest pl-4" style={{ marginLeft: `${(depth + 1) * 20}px` }}>LOOP Block</div>
            {(node as LoopNode).block.map(child => renderAstNodeElement(child, depth + 1))}
          </div>
        )}

        {node.type === NODE_TYPE.ONLY_IF && (
          <div className="space-y-1">
            {(node as any).cases.map((c: any, idx: number) => (
              <div key={idx} className="space-y-1">
                <div className="text-[9px] font-bold text-slate-400 uppercase tracking-widest pl-4" style={{ marginLeft: `${(depth + 1) * 20}px` }}>CASE: "{c.values.join(', ')}"</div>
                {c.block.map((child: any) => renderAstNodeElement(child, depth + 1))}
              </div>
            ))}
          </div>
        )}
      </div>
    );
  };

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col text-gray-800 antialiased font-sans">

      {/* 1. Header bar */}
      <header className="bg-white border-b border-gray-200/80 px-6 py-4 flex flex-col md:flex-row md:items-center justify-between gap-4 sticky top-0 z-40 shadow-xs">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-indigo-600 rounded-xl text-white shadow-md shadow-indigo-100">
            <Cpu className="w-5 h-5" />
          </div>
          <div>
            <h1 className="text-base font-bold text-gray-900 tracking-tight">
              BPL Rules Studio
            </h1>
            <p className="text-[10px] text-gray-400 font-semibold uppercase tracking-wider">
              Booklet Policy Language Enterprise IDE
            </p>
          </div>
        </div>

        {/* Global actions */}
        <div className="flex flex-wrap items-center gap-3">
          <button
            onClick={() => {
              setIsOverwritingActiveRule(false);
              setImporterPasteCode('');
              setImporterName('Legacy Evaluator Rule');
              setImporterDesc('Legacy Booklet Policy parsed and compiled');
              setImporterCategory('Financial');
              setImporterErrors([]);
              setImporterIsValid(true);
              setIsLegacyImporterOpen(true);
            }}
            className="flex items-center gap-1.5 px-3.5 py-1.5 bg-white hover:bg-slate-50 border border-gray-250 hover:border-gray-300 text-slate-700 rounded-xl text-xs font-bold shadow-xs transition cursor-pointer"
            id="btn-trigger-legacy-importer"
          >
            <Upload className="w-3.5 h-3.5 text-indigo-600 shrink-0" />
            <span>Import Legacy BPL</span>
          </button>

          <button
            onClick={() => setIsNewRuleWizardOpen(true)}
            className="flex items-center gap-1.5 px-3.5 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white border border-indigo-700 rounded-xl text-xs font-bold shadow-xs transition cursor-pointer"
            id="btn-trigger-new-wizard"
          >
            <Plus className="w-3.5 h-3.5" />
            New Rule
          </button>
        </div>
      </header>

      {/* 3. Workspace body block */}
      <main className="flex-1 p-6">
        <AnimatePresence mode="wait">
          {!selectedRuleId ? (
            <motion.div
              key="registry-table"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              className="space-y-6"
            >
              <div className="bg-white border border-gray-200/80 rounded-2xl shadow-sm overflow-hidden space-y-4 p-6">
                {/* Search and Filters toolbar */}
                <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-gray-100 pb-4">
                  <div>
                    <h2 className="text-base font-bold text-gray-900 tracking-tight">Enterprise Rules Registry</h2>
                    <p className="text-xs text-gray-400">Search and manage Booklet Policy scripts stored securely in server database.</p>
                  </div>

                  <div className="flex flex-wrap items-center gap-3">
                    {/* Search */}
                    <div className="relative w-64">
                      <Search className="w-4 h-4 text-gray-400 absolute left-3 top-2.5" />
                      <input
                        type="text"
                        value={dbSearch}
                        onChange={(e) => setDbSearch(e.target.value)}
                        placeholder="Search 145,000+ rules..."
                        className="w-full pl-9 pr-4 py-2 bg-slate-50 border border-gray-250 rounded-xl text-xs font-semibold focus:outline-none focus:ring-1 focus:ring-indigo-500 focus:bg-white transition"
                      />
                    </div>

                    {/* Category Pill select list */}
                    <div className="flex items-center gap-1.5 bg-slate-100 p-1 rounded-xl">
                      {['all', 'Financial', 'Healthcare', 'Insurance', 'Logistics'].map((cat) => (
                        <button
                          key={cat}
                          onClick={() => setDbCategory(cat)}
                          className={`px-3 py-1.5 rounded-lg text-xs font-bold transition cursor-pointer ${dbCategory === cat
                            ? 'bg-indigo-600 text-white shadow-xs'
                            : 'text-gray-500 hover:text-gray-800'
                            }`}
                        >
                          {cat === 'all' ? 'All' : cat}
                        </button>
                      ))}
                    </div>
                  </div>
                </div>

                {/* Rules table list */}
                <div className="overflow-x-auto">
                  {isApiLoading && rules.length === 0 ? (
                    <div className="py-24 text-center">
                      <RefreshCw className="w-8 h-8 animate-spin text-indigo-600 mx-auto mb-3" />
                      <span className="text-xs font-bold text-gray-500">Querying database indexes...</span>
                    </div>
                  ) : rules.length === 0 ? (
                    <div className="py-24 text-center">
                      <AlertTriangle className="w-8 h-8 text-amber-500 mx-auto mb-2" />
                      <p className="text-sm font-bold text-gray-700">No matching policies found</p>
                      <p className="text-xs text-gray-400 mt-1">Try clarifying filters or create a new policy script to start.</p>
                      <button
                        onClick={() => { setDbSearch(''); setDbCategory('all'); }}
                        className="mt-4 px-4 py-2 bg-indigo-550 hover:bg-indigo-600 text-white text-xs font-bold rounded-xl transition shadow-xs"
                      >
                        Reset Search Filters
                      </button>
                    </div>
                  ) : (
                    <table className="w-full border-collapse text-left text-xs">
                      <thead>
                        <tr className="border-b border-gray-200 text-gray-400 font-bold uppercase tracking-wider text-[10px] bg-slate-50/50">
                          <th className="py-3 px-4">Policy Code / Name</th>
                          <th className="py-3 px-4 hidden md:table-cell">Description</th>
                          <th className="py-3 px-4">Category</th>
                          <th className="py-3 px-4 hidden sm:table-cell">Variables</th>
                          <th className="py-3 px-4 text-right">Actions</th>
                        </tr>
                      </thead>
                      <tbody>
                        {rules.map((rule) => {
                          const varCount = Object.keys(rule.defaultVariables || {}).length;
                          return (
                            <tr
                              key={rule.id}
                              onClick={() => handleSelectRule(rule.id)}
                              className="border-b border-gray-100 hover:bg-slate-50/75 transition cursor-pointer select-none"
                            >
                              <td className="py-3 px-4 font-bold text-gray-900">
                                <div className="flex items-center gap-2">
                                  <div className="p-1.5 bg-indigo-50 text-indigo-600 rounded-lg">
                                    <FileText className="w-3.5 h-3.5" />
                                  </div>
                                  <div className="min-w-0">
                                    <span className="block truncate font-bold text-slate-800">{rule.name}</span>
                                    <span className="text-[9px] font-mono text-gray-400 font-semibold uppercase">{rule.id.split('-')[0]}</span>
                                  </div>
                                </div>
                              </td>
                              <td className="py-3 px-4 text-gray-500 hidden md:table-cell max-w-xs truncate">
                                {rule.description || 'No description provided.'}
                              </td>
                              <td className="py-3 px-4">
                                <span className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded-full text-[10px] font-bold bg-indigo-50 text-indigo-700 border border-indigo-100">
                                  {rule.category || 'Financial'}
                                </span>
                              </td>
                              <td className="py-3 px-4 hidden sm:table-cell">
                                <span className="font-mono font-bold text-slate-500 text-[11px] bg-slate-100 px-1.5 py-0.5 rounded-md">
                                  {varCount} declared
                                </span>
                              </td>
                              <td className="py-3 px-4 text-right" onClick={(e) => e.stopPropagation()}>
                                <div className="flex items-center justify-end gap-1">
                                  <button
                                    onClick={() => handleSelectRule(rule.id)}
                                    className="p-1.5 hover:bg-indigo-50 hover:text-indigo-600 rounded-lg transition cursor-pointer text-gray-500"
                                    title="Edit Policy"
                                  >
                                    <Eye className="w-4 h-4" />
                                  </button>
                                  <button
                                    onClick={(e) => handleDuplicateRule(rule, e)}
                                    className="p-1.5 hover:bg-indigo-50 hover:text-indigo-600 rounded-lg transition cursor-pointer text-gray-500"
                                    title="Duplicate Policy"
                                  >
                                    <Copy className="w-4 h-4" />
                                  </button>
                                  <button
                                    onClick={() => handleDownloadBplFile(rule)}
                                    className="p-1.5 hover:bg-indigo-50 hover:text-indigo-600 rounded-lg transition cursor-pointer text-gray-500"
                                    title="Download raw .bpl code"
                                  >
                                    <Download className="w-4 h-4" />
                                  </button>
                                  <button
                                    onClick={(e) => handleDeleteRule(rule.id, e)}
                                    className="p-1.5 hover:bg-rose-50 hover:text-rose-600 rounded-lg transition cursor-pointer text-gray-500 hover:text-rose-500"
                                    title="Delete permanently"
                                  >
                                    <Trash2 className="w-4 h-4" />
                                  </button>
                                </div>
                              </td>
                            </tr>
                          );
                        })}
                      </tbody>
                    </table>
                  )}
                </div>

                {/* Pagination Controls */}
                {totalRules > dbLimit && (
                  <div className="flex items-center justify-between border-t border-gray-100 pt-4 text-xs font-semibold select-none">
                    <span className="text-gray-400">Showing rows {((dbPage - 1) * dbLimit) + 1} - {Math.min(totalRules, dbPage * dbLimit)} of {totalRules} total entries</span>
                    <div className="flex items-center gap-1.5">
                      <button
                        onClick={() => setDbPage(1)}
                        disabled={dbPage === 1 || isApiLoading}
                        className="p-2 bg-white border border-gray-200 hover:border-gray-300 disabled:opacity-40 rounded-xl transition cursor-pointer"
                      >
                        <ChevronsLeft className="w-4 h-4" />
                      </button>
                      <button
                        onClick={() => setDbPage((p) => Math.max(1, p - 1))}
                        disabled={dbPage === 1 || isApiLoading}
                        className="p-2 bg-white border border-gray-200 hover:border-gray-300 disabled:opacity-40 rounded-xl transition cursor-pointer"
                      >
                        <ChevronLeft className="w-4 h-4" />
                      </button>

                      <div className="flex items-center gap-1 bg-slate-50 border px-3 py-1.5 rounded-xl font-mono">
                        <span className="text-[10px] text-gray-400 uppercase font-bold">Page</span>
                        <input
                          type="number"
                          min="1"
                          max={Math.ceil(totalRules / dbLimit)}
                          value={dbPage}
                          onChange={(e) => {
                            const val = parseInt(e.target.value, 10);
                            if (val > 0 && val <= Math.ceil(totalRules / dbLimit)) {
                              setDbPage(val);
                            }
                          }}
                          className="w-10 text-center font-bold text-indigo-600 bg-transparent focus:outline-none text-xs"
                        />
                        <span className="text-[10px] text-gray-400">/ {Math.ceil(totalRules / dbLimit)}</span>
                      </div>

                      <button
                        onClick={() => setDbPage((p) => Math.min(Math.ceil(totalRules / dbLimit), p + 1))}
                        disabled={dbPage >= Math.ceil(totalRules / dbLimit) || isApiLoading}
                        className="p-2 bg-white border border-gray-200 hover:border-gray-300 disabled:opacity-40 rounded-xl transition cursor-pointer"
                      >
                        <ChevronRight className="w-4 h-4" />
                      </button>
                      <button
                        onClick={() => setDbPage(Math.ceil(totalRules / dbLimit))}
                        disabled={dbPage >= Math.ceil(totalRules / dbLimit) || isApiLoading}
                        className="p-2 bg-white border border-gray-200 hover:border-gray-300 disabled:opacity-40 rounded-xl transition cursor-pointer"
                      >
                        <ChevronsRight className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                )}
              </div>
            </motion.div>
          ) : (
            /* Split screen layout: visual canvas + right tabs */
            <motion.div
              key="unified-designer"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              className="space-y-6"
            >
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">

                {/* Canvas (Col Span 12 if sidebar closed, else 8) */}
                <div className={`${isSidebarOpen ? 'lg:col-span-8' : 'lg:col-span-12'} flex flex-col space-y-6 transition-all duration-300`}>
                  <div className="bg-white border border-gray-200/80 rounded-2xl shadow-sm overflow-hidden flex flex-col h-full min-h-[550px]">

                    {/* Canvas Header */}
                    <div className="bg-slate-50 border-b border-gray-200/80 px-4 py-3 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 select-none">
                      <div className="flex items-center gap-3">
                        <button
                          onClick={() => setSelectedRuleId('')}
                          className="flex items-center gap-1.5 px-3 py-1.5 bg-white border border-gray-250 hover:bg-slate-100 hover:border-gray-300 text-slate-700 rounded-xl text-xs font-bold shadow-xs transition cursor-pointer"
                          title="Back to Table Registry"
                        >
                          <ArrowLeft className="w-3.5 h-3.5 text-indigo-600" />
                          <span>Registry</span>
                        </button>
                        <div className="h-5 w-px bg-gray-200/80 hidden sm:block" />
                        <Terminal className="w-4 h-4 text-indigo-500 hidden sm:block" />
                        <span className="text-xs font-bold text-slate-800 font-mono hidden sm:inline">Visual Flow Graph</span>
                        {errors.length > 0 ? (
                          <span className="flex items-center gap-1 text-[9px] bg-rose-50 text-rose-700 font-bold px-2 py-0.5 rounded-full border border-rose-100">
                            <AlertTriangle className="w-3 h-3 text-rose-500" /> Compiler Errors
                          </span>
                        ) : (
                          <span className="flex items-center gap-1 text-[9px] bg-emerald-50 text-emerald-700 font-bold px-2 py-0.5 rounded-full border border-emerald-100">
                            <CheckCircle className="w-3 h-3 text-emerald-500" /> Valid BPL Syntax
                          </span>
                        )}
                      </div>

                      {/* Sub-tab shortcuts */}
                      <div className="flex items-center gap-1.5 self-stretch sm:self-auto justify-end">
                        <button
                          onClick={() => {
                            if (isSidebarOpen && rightPanelTab === 'validate') {
                              setIsSidebarOpen(false);
                            } else {
                              setRightPanelTab('validate');
                              setIsSidebarOpen(true);
                              setSelectedNode(null);
                            }
                          }}
                          className={`px-2.5 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1 transition cursor-pointer ${isSidebarOpen && rightPanelTab === 'validate'
                            ? 'bg-indigo-600 text-white shadow-xs border border-indigo-700'
                            : 'text-gray-600 hover:text-gray-900 hover:bg-slate-100 border border-transparent'
                            }`}
                          title="Validation View"
                        >
                          <CheckCircle className="w-3.5 h-3.5" /> <span className="hidden md:inline">Validate</span>
                        </button>
                        <button
                          onClick={() => {
                            if (isSidebarOpen && rightPanelTab === 'test') {
                              setIsSidebarOpen(false);
                            } else {
                              setRightPanelTab('test');
                              setIsSidebarOpen(true);
                              setSelectedNode(null);
                            }
                          }}
                          className={`px-2.5 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1 transition cursor-pointer ${isSidebarOpen && rightPanelTab === 'test'
                            ? 'bg-indigo-600 text-white shadow-xs border border-indigo-700'
                            : 'text-gray-650 hover:text-gray-900 hover:bg-slate-100 border border-transparent'
                            }`}
                          title="Test Sandbox"
                        >
                          <Play className="w-3.5 h-3.5" /> <span>Test Sandbox</span>
                        </button>
                        <button
                          onClick={handleSaveCurrentRule}
                          className={`px-2.5 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1 transition text-gray-650 ${errors.length == 0 ? 'cursor-pointer' : 'cursor-not-allowed'} hover:${errors.length == 0 ? 'text-white' : 'text-gray-900'} hover:${errors.length == 0 ? 'bg-indigo-500' : 'bg-slate-100'} border border-transparent`}
                          title="Policy Settings"
                        >
                          <Save className="w-3.5 h-3.5" /> <span className="hidden md:inline">Save</span>
                        </button>
                      </div>
                    </div>

                    {/* Canvas body */}
                    <div className="flex-1 overflow-y-auto bg-slate-50">
                      {ast ? (
                        <VisualFlow
                          ast={ast}
                          activeNodeId={activeNodeId}
                          executedNodeIds={new Set(traceSteps.slice(0, currentStepIndex + 1).filter(s => s.executed).map(s => s.currentNodeId))}
                          skippedNodeIds={new Set(traceSteps.slice(0, currentStepIndex + 1).filter(s => !s.executed).map(s => s.currentNodeId))}
                          onSelectNode={(node) => {
                            setSelectedNode(node);
                            setRightPanelTab('properties');
                            setIsSidebarOpen(true);
                          }}
                          selectedNodeId={selectedNode ? selectedNode.id : null}
                          onAddNode={handleVisualAddNode}
                          onDeleteNode={handleVisualDeleteNode}
                        />
                      ) : (
                        <div className="flex-1 flex flex-col items-center justify-center py-24 text-center">
                          <AlertTriangle className="w-8 h-8 text-amber-500 mx-auto mb-2" />
                          <p className="text-sm font-bold text-gray-700">Invalid Syntax</p>
                          <p className="text-xs text-gray-400 mt-1">
                            Fix parser violations to render the flow.
                          </p>
                        </div>
                      )}
                    </div>

                    {/* Error indicator bar */}
                    {errors.length > 0 && (
                      <div className="bg-rose-50 border-t border-rose-100 p-3 flex items-start gap-2 text-[11px] text-rose-800 font-medium">
                        <AlertTriangle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
                        <div>
                          <span className="font-bold block">Line {errors[0].line || 1}: Syntax parsing failed</span>
                          <span className="text-rose-600">{errors[0].message}</span>
                        </div>
                      </div>
                    )}
                  </div>
                </div>

                {/* Sidebar (Col Span 4) */}
                {isSidebarOpen && (
                  <div className="lg:col-span-4 bg-white border border-gray-200/80 rounded-2xl shadow-sm overflow-hidden flex flex-col min-h-[550px]">

                    {/* Sidebar Header */}
                    <div className="bg-slate-50 border-b border-gray-200 flex items-center justify-between px-4 py-3 select-none shrink-0">
                      <div className="flex items-center gap-2 text-slate-800 font-bold text-xs tracking-tight">
                        {rightPanelTab === 'properties' && (
                          <>
                            <Sliders className="w-4 h-4 text-indigo-600" />
                            <span>Properties</span>
                          </>
                        )}
                        {rightPanelTab === 'validate' && (
                          <>
                            <CheckCircle className="w-4 h-4 text-indigo-600" />
                            <span>Syntax Validation</span>
                          </>
                        )}
                        {rightPanelTab === 'test' && (
                          <>
                            <Play className="w-4 h-4 text-indigo-600" />
                            <span>Test Sandbox</span>
                          </>
                        )}
                      </div>

                      {/* Close button */}
                      <button
                        onClick={() => {
                          setIsSidebarOpen(false);
                          setSelectedNode(null);

                          // stop debuging if any
                          setCurrentStepIndex(0);
                          setIsPlaying(false);
                        }}
                        className="p-1.5 hover:bg-slate-200/60 rounded-lg transition text-gray-450 hover:text-gray-700 cursor-pointer"
                        title="Collapse Sidebar"
                      >
                        <X className="w-4 h-4" />
                      </button>
                    </div>

                    {/* Sidebar Body */}
                    <div className="p-4 flex-1 overflow-y-auto max-h-[620px]">

                      {rightPanelTab === 'properties' && (
                        <div className="space-y-4">
                          {selectedNode && ast ? (
                            <NodeEditor
                              selectedNode={selectedNode}
                              onUpdateNodeProperty={handleVisualUpdateNodeProperty}
                              onClose={() => {
                                setSelectedNode(null);
                                setIsSidebarOpen(false);
                              }}
                              ast={ast}
                            />
                          ) : (
                            <div className="py-16 px-4 text-center space-y-4">
                              <div className="p-4 bg-indigo-50 border border-indigo-100 rounded-full inline-block text-indigo-600">
                                <Sliders className="w-8 h-8" />
                              </div>
                              <div>
                                <h3 className="text-xs font-bold text-gray-900 uppercase tracking-wider">No Block Selected</h3>
                                <p className="text-[11px] text-gray-400 mt-1.5 leading-relaxed">
                                  Click any conditional branch, logic block, or logging statement in the flow canvas on the left to inspect, modify variables, or change state properties instantly.
                                </p>
                              </div>
                            </div>
                          )}
                        </div>
                      )}

                      {rightPanelTab === 'validate' && (
                        <ValidationTab
                          errors={errors}
                          ast={ast}
                          renderAstNodeElement={renderAstNodeElement}
                        />
                      )}

                      {rightPanelTab === 'test' && (
                        <SimulatorTab
                          traceSteps={traceSteps}
                          currentStepIndex={currentStepIndex}
                          setCurrentStepIndex={setCurrentStepIndex}
                          isPlaying={isPlaying}
                          setIsPlaying={setIsPlaying}
                          playbackSpeed={playbackSpeed}
                          setPlaybackSpeed={setPlaybackSpeed}
                          activeVariables={activeVariables}
                          activeLogs={activeLogs}
                          activeIncludes={activeIncludes}
                          variables={variables}
                          handleUpdateVariableValue={handleUpdateVariableValue}
                          handleRemoveVariable={handleRemoveVariable}
                        />
                      )}
                    </div>
                  </div>
                )}

              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </main>

      {/* 4. CREATION WIZARD MODAL (Ask Option Import old .bpl file OR Start Scratch) */}
      <AnimatePresence>
        {isNewRuleWizardOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            {/* Backdrop */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={closeNewRuleWizard}
              className="absolute inset-0 bg-slate-900/60 backdrop-blur-xs"
            />

            {/* Modal Box */}
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 15 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 15 }}
              className="relative w-full max-w-lg bg-white border border-gray-200 rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]"
            >
              {/* Modal Header */}
              <div className="bg-gradient-to-r from-indigo-600 to-indigo-700 text-white px-6 py-4 flex items-center justify-between">
                <div className="flex items-center gap-2.5">
                  <div className="p-1 bg-white/10 rounded-lg">
                    <Database className="w-4 h-4 text-indigo-200" />
                  </div>
                  <div>
                    <h3 className="text-sm font-bold tracking-tight">Policy Rule Wizard</h3>
                    <p className="text-[10px] text-indigo-200/80">Integrate rules securely into database</p>
                  </div>
                </div>
                <button
                  onClick={closeNewRuleWizard}
                  className="p-1 rounded-lg hover:bg-white/10 text-white/80 hover:text-white transition cursor-pointer"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              {/* Modal Wizard Screens */}
              <div className="p-6 overflow-y-auto space-y-5">

                {/* SCREEN 1: CHOICE DECISION CARD SELECTION */}
                {wizardStep === 'choice' && (
                  <div className="space-y-4">
                    <div className="text-center">
                      <span className="text-xs font-bold text-gray-700">How would you like to build this policy?</span>
                      <p className="text-[11px] text-gray-400 mt-1">Choose starting from scratch or upload older .bpl source files.</p>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      {/* Scratch Card */}
                      <div
                        onClick={() => setWizardStep('scratch')}
                        className="p-5 border-2 border-gray-200 hover:border-indigo-500 hover:bg-slate-50/50 rounded-xl text-center cursor-pointer transition group"
                      >
                        <div className="p-3 bg-indigo-50 group-hover:bg-indigo-100 rounded-2xl text-indigo-600 inline-block mb-3 transition">
                          <Plus className="w-6 h-6" />
                        </div>
                        <h4 className="font-bold text-gray-900 text-xs">Start New (From Scratch)</h4>
                        <p className="text-[10px] text-gray-400 mt-1">Create baseline script template variables and start writing.</p>
                      </div>

                      {/* Import BPL Card */}
                      <div
                        onClick={() => {
                          setIsNewRuleWizardOpen(false);
                          setIsLegacyImporterOpen(true)
                        }}
                        className="p-5 border-2 border-gray-200 hover:border-indigo-500 hover:bg-slate-50/50 rounded-xl text-center cursor-pointer transition group"
                      >
                        <div className="p-3 bg-emerald-50 group-hover:bg-emerald-100 rounded-2xl text-emerald-600 inline-block mb-3 transition">
                          <Upload className="w-6 h-6" />
                        </div>
                        <h4 className="font-bold text-gray-900 text-xs">Import Old .bpl File</h4>
                        <p className="text-[10px] text-gray-400 mt-1">Upload existing .bpl script file or paste policy code segment.</p>
                      </div>
                    </div>
                  </div>
                )}

                {/* SCREEN 2: FROM SCRATCH DETAILS */}
                {wizardStep === 'scratch' && (
                  <div className="space-y-4">
                    <div className="flex items-center gap-1.5 text-xs text-indigo-600 font-bold cursor-pointer" onClick={() => setWizardStep('choice')}>
                      <ChevronLeft className="w-4 h-4" /> Change Creation Method
                    </div>

                    <div className="space-y-3.5">
                      <div className="space-y-1">
                        <label className="text-[10px] font-bold text-gray-400 uppercase tracking-wider block">Rule Script Name *</label>
                        <input
                          type="text"
                          value={wizardName}
                          onChange={(e) => setWizardName(e.target.value)}
                          placeholder="e.g. Credit Score Validation Policy"
                          className="w-full px-3.5 py-2 border border-gray-200 rounded-xl text-xs font-semibold focus:outline-none"
                          autoFocus
                        />
                      </div>

                      <div className="space-y-1">
                        <label className="text-[10px] font-bold text-gray-400 uppercase tracking-wider block">Description / Purpose</label>
                        <textarea
                          value={wizardDesc}
                          onChange={(e) => setWizardDesc(e.target.value)}
                          placeholder="Evaluate loan requests against applicant parameters..."
                          className="w-full h-20 px-3.5 py-2 border border-gray-200 rounded-xl text-xs font-semibold focus:outline-none"
                        />
                      </div>

                      <div className="space-y-1">
                        <label className="text-[10px] font-bold text-gray-400 uppercase tracking-wider block">Classification Category</label>
                        <select
                          value={wizardCategory}
                          onChange={(e) => setWizardCategory(e.target.value)}
                          className="w-full px-3 py-2 border border-gray-200 rounded-xl text-xs font-semibold focus:outline-none"
                        >
                          <option value="Financial">Financial Policy</option>
                          <option value="Healthcare">Healthcare Protocol</option>
                          <option value="Insurance">Insurance Underwriting</option>
                          <option value="Logistics">Logistics / Operations</option>
                          <option value="Security">Security Constraints</option>
                        </select>
                      </div>
                    </div>
                  </div>
                )}

              </div>

              {/* Modal Footer */}
              <div className="px-6 py-4 bg-gray-50 border-t border-gray-200 flex items-center justify-end gap-3">
                <button
                  onClick={closeNewRuleWizard}
                  className="px-4 py-2 border border-gray-200 rounded-xl text-xs font-bold text-gray-600 hover:bg-gray-100 transition cursor-pointer"
                >
                  Cancel
                </button>

                {wizardStep === 'scratch' && (
                  <button
                    disabled={!wizardName.trim() || isApiLoading}
                    onClick={handleWizardScratchSubmit}
                    className={`px-4 py-2 rounded-xl text-xs font-bold shadow-sm transition flex items-center gap-1.5 cursor-pointer ${wizardName.trim() && !isApiLoading
                      ? 'bg-indigo-600 text-white hover:bg-indigo-700'
                      : 'bg-gray-200 text-gray-400 cursor-not-allowed'
                      }`}
                  >
                    Create Baseline
                  </button>
                )}

                {wizardStep === 'import' && (
                  <button
                    disabled={!wizardName.trim() || !wizardPasteCode.trim() || isApiLoading}
                    onClick={handleWizardImportSubmit}
                    className={`px-4 py-2 rounded-xl text-xs font-bold shadow-sm transition flex items-center gap-1.5 cursor-pointer ${wizardName.trim() && wizardPasteCode.trim() && !isApiLoading
                      ? 'bg-indigo-600 text-white hover:bg-indigo-700'
                      : 'bg-gray-200 text-gray-400 cursor-not-allowed'
                      }`}
                  >
                    Compile & Import
                  </button>
                )}
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* 5. LEGACY BPL IMPORTER MODAL */}
      <AnimatePresence>
        {isLegacyImporterOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            {/* Backdrop */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsLegacyImporterOpen(false)}
              className="absolute inset-0 bg-slate-900/60 backdrop-blur-xs"
            />

            {/* Modal Box */}
            <motion.div
              initial={{ opacity: 0, scale: 0.97, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.97, y: 20 }}
              className="relative bg-white border border-gray-250 rounded-2xl shadow-2xl w-full max-w-[96vw] xl:max-w-7xl h-[92vh] md:h-[88vh] lg:h-[90vh] overflow-hidden flex flex-col z-10"
            >
              {/* Modal Header */}
              <div className="bg-white border-b border-gray-200 px-6 py-4 flex items-center justify-between shrink-0">
                <div className="flex items-center gap-2.5">
                  <Cpu className="w-5 h-5 text-indigo-600" />
                  <div>
                    <h3 className="text-sm font-bold tracking-tight text-gray-950">Legacy BPL Importer & Syntax Compiler</h3>
                    <p className="text-[10px] text-gray-500">Validate code syntax in real-time and convert to visual flows instantly</p>
                  </div>
                </div>
                <button
                  onClick={() => setIsLegacyImporterOpen(false)}
                  className="p-1.5 rounded-lg hover:bg-gray-100 text-gray-400 hover:text-gray-700 transition cursor-pointer"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              {/* Modal Content */}
              <div className="p-6 flex-1 overflow-hidden grid grid-cols-1 lg:grid-cols-12 gap-6 min-h-0">
                {/* Left Side: Inputs and Dark Code Editor Area (Col Span 7) */}
                <div className="lg:col-span-7 flex flex-col h-full overflow-hidden space-y-4 min-h-0">
                  {isOverwritingActiveRule ? (
                    <div className="bg-indigo-50/75 border border-indigo-100 rounded-xl p-4 text-xs space-y-1 shrink-0">
                      <div className="flex items-center gap-1.5 font-bold text-indigo-900">
                        <AlertTriangle className="w-4 h-4 text-indigo-600" />
                        <span>Replacing Active Rule Flow</span>
                      </div>
                      <p className="text-gray-650 leading-relaxed text-[11px]">
                        You are pasting legacy code to replace the visual flow of <strong className="text-indigo-950 font-bold">"{ruleMetaName}"</strong>. Saving will overwrite its active syntax and automatically redraw all nodes.
                      </p>
                    </div>
                  ) : (
                    <div className="grid grid-cols-1 sm:grid-cols-12 gap-4 shrink-0">
                      <div className="sm:col-span-8 space-y-1">
                        <label className="text-[10px] font-bold text-gray-400 uppercase tracking-wider block">Policy Name *</label>
                        <input
                          type="text"
                          value={importerName}
                          onChange={(e) => setImporterName(e.target.value)}
                          placeholder="e.g. Legacy Credit Verification Policy"
                          className="w-full px-3.5 py-2 bg-white border border-gray-200 rounded-xl text-xs font-semibold text-gray-800 focus:outline-none focus:ring-1 focus:ring-indigo-500/50 focus:border-indigo-500 transition"
                        />
                      </div>
                      <div className="sm:col-span-4 space-y-1">
                        <label className="text-[10px] font-bold text-gray-400 uppercase tracking-wider block">Category</label>
                        <select
                          value={importerCategory}
                          onChange={(e) => setImporterCategory(e.target.value)}
                          className="w-full px-3.5 py-2 bg-white border border-gray-200 rounded-xl text-xs font-semibold text-gray-800 focus:outline-none focus:ring-1 focus:ring-indigo-500/50 focus:border-indigo-500 transition"
                        >
                          <option value="Financial">Financial Policy</option>
                          <option value="Healthcare">Healthcare Protocol</option>
                          <option value="Insurance">Insurance Underwriting</option>
                          <option value="Logistics">Logistics / Operations</option>
                          <option value="Security">Security Constraints</option>
                        </select>
                      </div>
                      <div className="sm:col-span-12 space-y-1">
                        <label className="text-[10px] font-bold text-gray-400 uppercase tracking-wider block">Description / Context</label>
                        <input
                          type="text"
                          value={importerDesc}
                          onChange={(e) => setImporterDesc(e.target.value)}
                          placeholder="Provide context or description for this imported BPL script"
                          className="w-full px-3.5 py-2 bg-white border border-gray-200 rounded-xl text-xs font-semibold text-gray-800 focus:outline-none focus:ring-1 focus:ring-indigo-500/50 focus:border-indigo-500 transition"
                        />
                      </div>
                    </div>
                  )}

                  {/* Code Input Field Area */}
                  <div className="flex-1 flex flex-col space-y-2 overflow-hidden min-h-0">
                    <div className="flex items-center justify-between shrink-0">
                      <label className="text-[10px] font-bold text-gray-400 uppercase tracking-wider block">
                        BPL Source Code Editor
                      </label>

                      {/* Templates shortcuts */}
                      <div className="flex items-center gap-2">
                        <label
                          htmlFor="importer-file-uploader"
                          className="flex items-center gap-1 bg-indigo-500 hover:bg-indigo-600 border border-indigo-500 hover:border-indigo-600 text-white px-2.5 py-1 rounded cursor-pointer transition text-[9px] font-bold uppercase tracking-wide shrink-0"
                        >
                          <Upload className="w-3 h-3" />
                          <span>Upload BPL File</span>
                        </label>
                        <input
                          type="file"
                          id="importer-file-uploader"
                          accept=".bpl,.txt"
                          onChange={(e) => {
                            if (e.target.files && e.target.files[0]) {
                              handleImporterFileUpload(e.target.files[0]);
                            }
                            e.target.value = '';
                          }}
                          className="hidden"
                        />
                      </div>
                    </div>

                    {/* Custom Dark Theme IDE Code Editor */}
                    <div className="flex-1 min-h-0 rounded-xl bg-[#090D16] border border-slate-800/80 flex flex-col overflow-hidden shadow-inner">
                      {/* Editor Sub-Header / Info Bar */}
                      <div className="bg-[#0e1422] border-b border-slate-800/60 px-4 py-2 flex items-center justify-between text-[10px] font-mono text-slate-400 select-none shrink-0">
                        <div className="flex items-center gap-1.5">
                          <span className="w-1.5 h-1.5 rounded-full bg-indigo-500 animate-pulse"></span>
                          <span>• BOOKLET POLICY LANGUAGE (BPL) EDITOR</span>
                        </div>
                        <div className="flex items-center gap-3">
                          <span>Lines: {Math.max(1, importerPasteCode.split('\n').length)}</span>
                          <span>Chars: {importerPasteCode.length}</span>
                        </div>
                      </div>

                      {/* Editor Canvas Gutter + Area */}
                      <div className="flex-1 flex overflow-hidden min-h-0 relative">
                        {/* Gutter Line Numbers */}
                        <div
                          ref={importerGutterRef}
                          className="bg-[#05080e] border-r border-slate-800/60 text-slate-600 text-right pr-3 pl-4 select-none py-4 overflow-hidden font-mono text-[11px] leading-5 shrink-0"
                          style={{ pointerEvents: 'none' }}
                        >
                          {Array.from({ length: Math.max(1, importerPasteCode.split('\n').length) }).map((_, idx) => (
                            <div key={idx}>{idx + 1}</div>
                          ))}
                        </div>

                        {/* Textarea */}
                        <textarea
                          value={importerPasteCode}
                          onChange={(e) => handleImporterCodeChange(e.target.value)}
                          onScroll={(e) => {
                            if (importerGutterRef.current) {
                              importerGutterRef.current.scrollTop = e.currentTarget.scrollTop;
                            }
                          }}
                          placeholder={`script "My Old Policy"\n{\n  log "Evaluating legacy parameters"\n  assign "Verified" to status\n}`}
                          className="flex-1 bg-transparent text-[#e4e7eb] font-mono text-xs focus:outline-none resize-none leading-5 w-full h-full py-4 px-4 selection:bg-indigo-500/40 overflow-auto outline-none scrollbar-thin scrollbar-thumb-slate-800/80 scrollbar-track-transparent"
                          spellCheck="false"
                        />
                      </div>
                    </div>
                  </div>
                </div>

                {/* Right Side: Compiler Diagnostics & Live Stats (Col Span 5) */}
                <div className="lg:col-span-5 bg-slate-50 border border-gray-200 rounded-2xl p-6 flex flex-col h-full overflow-y-auto space-y-5 min-h-0">
                  <div className="shrink-0">
                    <h4 className="text-[10px] font-bold text-slate-500 uppercase tracking-wider">Compiler Diagnostics</h4>
                    <p className="text-[11px] text-gray-450 mt-0.5">Real-time parser feedback and statement visualization</p>
                  </div>

                  <div className="flex-1 flex flex-col justify-center min-h-0">
                    {!importerPasteCode.trim() ? (
                      <div className="text-center py-12 px-4 space-y-3">
                        <Terminal className="w-8 h-8 text-gray-300 mx-auto animate-pulse" />
                        <span className="text-[11px] font-bold text-slate-600 block">Waiting for BPL source code</span>
                        <p className="text-[10px] text-gray-400 leading-relaxed max-w-xs mx-auto">
                          Paste legacy Booklet Policy Language (BPL) rules in the dark editor or select a sample template above to begin.
                        </p>
                      </div>
                    ) : !importerIsValid ? (
                      <div className="bg-rose-50 border border-rose-100 rounded-xl p-5 space-y-4 text-left">
                        <div className="flex items-center gap-1.5 text-rose-800 font-bold text-xs">
                          <AlertTriangle className="w-4 h-4 text-rose-600" />
                          <span>Syntax Validation Failed</span>
                        </div>
                        <div className="space-y-2 text-[11px] text-rose-750 font-medium max-h-[220px] overflow-y-auto pr-1">
                          {importerErrors.map((err, i) => (
                            <div key={i} className="border-l-2 border-rose-400 pl-3 py-1.5 bg-rose-50/50 rounded-r text-left leading-relaxed">
                              <span className="font-bold text-rose-800">Line {err.line}, Col {err.column}:</span> {err.message}
                            </div>
                          ))}
                        </div>
                        <p className="text-[10px] text-gray-400 leading-relaxed pt-3 border-t border-rose-100/50 text-left">
                          BPL statements must be wrapped in a main "script Name" block. Ensure all parentheses, braces, and string quotes are closed properly.
                        </p>
                      </div>
                    ) : (
                      <div className="space-y-5 text-left h-full flex flex-col justify-start">
                        {/* Compiled successfully card */}
                        <div className="bg-emerald-50 border border-emerald-100 rounded-xl p-4 flex items-start gap-3.5 text-left shrink-0">
                          <CheckCircle className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
                          <div>
                            <span className="text-xs font-bold text-emerald-800 block">Syntax Validated Successfully!</span>
                            <span className="text-[10px] text-emerald-600 font-medium leading-normal">Ready to convert and generate interactive visual flow canvas.</span>
                          </div>
                        </div>

                        {/* Compiler statistics / metrics */}
                        {getImporterMetrics() && (
                          <div className="bg-white border border-gray-200 rounded-xl p-5 space-y-4 shadow-sm flex-1 overflow-y-auto">
                            <span className="text-[10px] font-bold text-slate-450 uppercase tracking-wider block">Flow Canvas Mapping Metrics</span>

                            <div className="grid grid-cols-2 gap-3.5 text-[11px]">
                              <div className="p-3 bg-slate-50 border border-gray-200/60 rounded-xl shadow-xs">
                                <span className="text-slate-400 block font-semibold text-[10px]">Total Nodes</span>
                                <strong className="text-slate-800 font-bold text-sm">{getImporterMetrics()?.total}</strong>
                              </div>
                              <div className="p-3 bg-slate-50 border border-gray-200/60 rounded-xl shadow-xs">
                                <span className="text-slate-400 block font-semibold text-[10px]">Conditionals (If)</span>
                                <strong className="text-indigo-600 font-bold text-sm">{getImporterMetrics()?.conditionals}</strong>
                              </div>
                              <div className="p-3 bg-slate-50 border border-gray-200/60 rounded-xl shadow-xs">
                                <span className="text-slate-400 block font-semibold text-[10px]">Assignments</span>
                                <strong className="text-slate-800 font-bold text-sm">{getImporterMetrics()?.assignments}</strong>
                              </div>
                              <div className="p-3 bg-slate-50 border border-gray-200/60 rounded-xl shadow-xs">
                                <span className="text-slate-400 block font-semibold text-[10px]">Terminal Logs</span>
                                <strong className="text-slate-800 font-bold text-sm">{getImporterMetrics()?.logs}</strong>
                              </div>
                            </div>

                            <div className="border-t border-gray-100 pt-4 space-y-2.5 text-[10px] text-slate-550 font-medium">
                              <span className="font-bold text-slate-600 block uppercase tracking-wider text-[9px]">Included Visual Node Generation:</span>
                              <div className="flex flex-wrap gap-1.5">
                                {getImporterMetrics()?.logs! > 0 && (
                                  <span className="px-2.5 py-1 bg-indigo-50 text-indigo-700 rounded-md border border-indigo-100 font-bold font-mono">
                                    {getImporterMetrics()?.logs} Logs
                                  </span>
                                )}
                                {getImporterMetrics()?.assignments! > 0 && (
                                  <span className="px-2.5 py-1 bg-slate-100 text-slate-700 rounded-md border border-slate-200 font-bold font-mono">
                                    {getImporterMetrics()?.assignments} State Vars
                                  </span>
                                )}
                                {getImporterMetrics()?.conditionals! > 0 && (
                                  <span className="px-2.5 py-1 bg-amber-50 text-amber-700 rounded-md border border-amber-100 font-bold font-mono">
                                    {getImporterMetrics()?.conditionals} Logic Decisions
                                  </span>
                                )}
                                {getImporterMetrics()?.validations! > 0 && (
                                  <span className="px-2.5 py-1 bg-emerald-50 text-emerald-700 rounded-md border border-emerald-100 font-bold font-mono">
                                    {getImporterMetrics()?.validations} Assertions
                                  </span>
                                )}
                                {getImporterMetrics()?.loops! > 0 && (
                                  <span className="px-2.5 py-1 bg-purple-50 text-purple-700 rounded-md border border-purple-100 font-bold font-mono">
                                    {getImporterMetrics()?.loops} Loops
                                  </span>
                                )}
                              </div>
                            </div>
                          </div>
                        )}
                      </div>
                    )}
                  </div>
                </div>
              </div>

              {/* Modal Footer */}
              <div className="px-6 py-4 bg-gray-50 border-t border-gray-200/80 flex items-center justify-end gap-3 shrink-0">
                <button
                  type="button"
                  onClick={() => setIsLegacyImporterOpen(false)}
                  className="px-4.5 py-2 border border-gray-200 text-gray-600 hover:bg-gray-100 rounded-xl text-xs font-bold transition cursor-pointer"
                >
                  Cancel
                </button>

                <button
                  disabled={!importerPasteCode.trim() || !importerIsValid || (!isOverwritingActiveRule && !importerName.trim()) || isApiLoading}
                  onClick={handleImporterSubmit}
                  className={`px-4.5 py-2 rounded-xl text-xs font-bold shadow-sm transition flex items-center gap-1.5 cursor-pointer ${importerPasteCode.trim() && importerIsValid && (isOverwritingActiveRule || importerName.trim()) && !isApiLoading
                    ? 'bg-indigo-600 text-white hover:bg-indigo-700'
                    : 'bg-gray-100 text-gray-400 cursor-not-allowed border border-gray-200'
                    }`}
                >
                  {isApiLoading ? (
                    <span>Compiling...</span>
                  ) : isOverwritingActiveRule ? (
                    <>
                      <Check className="w-3.5 h-3.5" />
                      <span>Compile & Overwrite Flow</span>
                    </>
                  ) : (
                    <>
                      <Check className="w-3.5 h-3.5" />
                      <span>Compile & Convert to Flow</span>
                    </>
                  )}
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Action Notification Toast */}
      <AnimatePresence>
        {importNotification && (
          <motion.div
            initial={{ opacity: 0, y: 20, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 20, scale: 0.95 }}
            className="fixed top-6 right-6 z-50"
          >
            <div className={`flex items-center gap-3 px-4 py-3 rounded-xl border shadow-lg ${importNotification.type === 'success'
              ? 'bg-emerald-50 border-emerald-100 text-emerald-800'
              : 'bg-rose-50 border-rose-100 text-rose-800'
              }`}>
              {importNotification.type === 'success' ? (
                <CheckCircle className="w-4 h-4 text-emerald-600 shrink-0" />
              ) : (
                <AlertTriangle className="w-4 h-4 text-rose-600 shrink-0" />
              )}
              <div className="text-xs font-bold">
                {importNotification.message}
              </div>
              <button
                onClick={() => setImportNotification(null)}
                className="p-0.5 rounded hover:bg-white/50 transition shrink-0 ml-1 cursor-pointer"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
