import { TraversingVisitor } from '../visitor/Visitor.js';
import { CompileError } from '../errors/CompileError.js';

/**
 * Converts `Jump("bottom")` into a resolved `Jump(labelId=N)` reference.
 *
 * Note on addresses: the *final* byte/instruction address for a label
 * isn't known until after the CFG has been built and optimized (dead
 * blocks removed, blocks merged, etc. — all of which shift offsets). So
 * this resolver's numeric output is a stable **label ID** (a symbol table
 * entry), not yet a physical address. `BytecodeGenerator` performs the
 * final labelId -> instruction-address patch once the optimized
 * instruction stream is laid out linearly (see Step 8-11 in the pipeline).
 */
export class LabelResolver extends TraversingVisitor {
  /** @param {import('../symbols/SymbolTable.js').SymbolTable} symbolTable */
  constructor(symbolTable) {
    super();
    this._symbolTable = symbolTable;
    /** @type {Map<string, number>} label name -> labelId */
    this._labelIdByName = new Map();
    /** @type {Map<string, number>} jump node id -> labelId */
    this.jumpTargetLabelId = new Map();
    /** @type {CompileError[]} */
    this.errors = [];
  }

  /**
   * @param {import('../ast/ScriptNode.js').ScriptNode} script
   * @returns {{ jumpTargetLabelId: Map<string, number>, labelIdByName: Map<string, number>, errors: CompileError[] }}
   */
  resolve(script) {
    this._labelIdByName = new Map();
    this.jumpTargetLabelId = new Map();
    this.errors = [];

    // First pass: allocate a labelId for every LabelNode.
    const labelCollector = new (class extends TraversingVisitor {})();
    const self = this;
    labelCollector.visitLabelNode = function (node) {
      const labelId = self._symbolTable.labels.getOrCreate(node.name);
      self._labelIdByName.set(node.name, labelId);
      return undefined;
    };
    script.accept(labelCollector);

    // Second pass: resolve every JumpNode's target name to that labelId.
    script.accept(this);

    return {
      jumpTargetLabelId: this.jumpTargetLabelId,
      labelIdByName: this._labelIdByName,
      errors: this.errors,
    };
  }

  visitJumpNode(node) {
    const labelId = this._labelIdByName.get(node.target);
    if (labelId === undefined) {
      this.errors.push(
        new CompileError(node.id, `Jump target "${node.target}" is not a defined label`, {}, 'error')
      );
    } else {
      this.jumpTargetLabelId.set(node.id, labelId);
    }
    return super.visitJumpNode(node);
  }
}
