import { TraversingVisitor } from '../visitor/Visitor.js';
import { CompileError } from '../errors/CompileError.js';

/**
 * Walks the AST and allocates a numeric IncludeID (via the shared
 * SymbolTable) for every distinct include path. No raw file paths survive
 * past this stage — downstream IR/bytecode only ever see IncludeIDs.
 */
export class IncludeResolver extends TraversingVisitor {
  /**
   * @param {import('../symbols/SymbolTable.js').SymbolTable} symbolTable
   * @param {{ rootPath?: string, includeGraph?: Map<string, string[]> }} [options]
   *   `includeGraph` maps an include path to the paths *it* includes, for
   *   cross-file circular-include detection when available.
   */
  constructor(symbolTable, options = {}) {
    super();
    this._symbolTable = symbolTable;
    this._rootPath = options.rootPath ?? null;
    this._includeGraph = options.includeGraph ?? new Map();
    /** @type {Map<string, number>} nodeId -> includeId */
    this.includeIdByNodeId = new Map();
    /** @type {CompileError[]} */
    this.errors = [];
  }

  /**
   * @param {import('../ast/ScriptNode.js').ScriptNode} script
   * @returns {{ includeIdByNodeId: Map<string, number>, errors: CompileError[] }}
   */
  resolve(script) {
    this.includeIdByNodeId = new Map();
    this.errors = [];
    script.accept(this);
    this._detectCycles();
    return { includeIdByNodeId: this.includeIdByNodeId, errors: this.errors };
  }

  visitIncludeNode(node) {
    if (this._rootPath && node.path === this._rootPath) {
      this.errors.push(
        new CompileError(node.id, `Include "${node.path}" includes its own root script`, {}, 'error')
      );
    }
    const includeId = this._symbolTable.includes.getOrCreate(node.path);
    this.includeIdByNodeId.set(node.id, includeId);
    return super.visitIncludeNode(node);
  }

  _detectCycles() {
    if (this._includeGraph.size === 0) return;

    const visiting = new Set();
    const visited = new Set();

    const visit = (path, chain) => {
      if (visited.has(path)) return;
      if (visiting.has(path)) {
        this.errors.push(
          new CompileError(
            'include-graph',
            `Circular include detected: ${[...chain, path].join(' -> ')}`,
            {},
            'error'
          )
        );
        return;
      }
      visiting.add(path);
      for (const next of this._includeGraph.get(path) ?? []) {
        visit(next, [...chain, path]);
      }
      visiting.delete(path);
      visited.add(path);
    };

    for (const path of this._includeGraph.keys()) visit(path, []);
  }
}
