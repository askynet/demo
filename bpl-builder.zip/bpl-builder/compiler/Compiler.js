import { FlowParser } from './parser/FlowParser.js';
import { SemanticValidator } from './semantic/SemanticValidator.js';
import { IncludeResolver } from './resolver/IncludeResolver.js';
import { LabelResolver } from './resolver/LabelResolver.js';
import { CfgBuilder } from './cfg/CfgBuilder.js';
import { Optimizer } from './optimizer/Optimizer.js';
import { BytecodeGenerator } from './bytecode/BytecodeGenerator.js';
import { BinarySerializer } from './serializer/BinarySerializer.js';
import { SymbolTable } from './symbols/SymbolTable.js';
import { CompileError } from './errors/CompileError.js';

/**
 * @typedef {Object} CompileResult
 * @property {boolean} success
 * @property {Buffer | null} buffer
 * @property {CompileError[]} errors
 * @property {import('./symbols/SymbolTable.js').SymbolTable | null} symbolTable
 * @property {import('./ir/Instruction.js').Instruction[] | null} instructions
 */

/**
 * @typedef {Object} CompilerOptions
 * @property {ReadonlySet<string>} [knownFunctions]
 * @property {(path: string) => boolean} [includeExists]
 * @property {string} [rootPath]
 * @property {Map<string, string[]>} [includeGraph]
 */

/**
 * Runs a Flow JSON document through the full compiler pipeline:
 *
 *   Parse -> AST -> Validate -> Resolve Includes -> Resolve Labels -> CFG
 *   -> Optimize -> IR/Bytecode -> Serialize
 *
 * Stops at the first stage that reports fatal errors rather than
 * continuing to build on a broken tree/graph.
 */
export class Compiler {
  /** @param {CompilerOptions} [options] */
  constructor(options = {}) {
    this._options = options;
    this._parser = new FlowParser();
  }

  /**
   * @param {any} flowJson
   * @returns {CompileResult}
   */
  compile(flowJson) {
    let ast;
    try {
      ast = this._parser.parse(flowJson);
    } catch (error) {
      const compileError = error instanceof CompileError ? error : new CompileError('root', error.message, {}, 'error');
      return { success: false, buffer: null, errors: [compileError], symbolTable: null, instructions: null, variableNames: [], templateNames: [] };
    }

    const validator = new SemanticValidator({
      knownFunctions: this._options.knownFunctions,
      includeExists: this._options.includeExists,
    });
    const validationErrors = validator.validate(ast);
    if (validationErrors.some((e) => e.severity === 'error')) {
      return { success: false, buffer: null, errors: validationErrors, symbolTable: null, instructions: null, variableNames: [], templateNames: [] };
    }

    const symbolTable = new SymbolTable();

    const includeResult = new IncludeResolver(symbolTable, {
      rootPath: this._options.rootPath,
      includeGraph: this._options.includeGraph,
    }).resolve(ast);

    const labelResult = new LabelResolver(symbolTable).resolve(ast);

    const resolverErrors = [...includeResult.errors, ...labelResult.errors];
    if (resolverErrors.length > 0) {
      return { success: false, buffer: null, errors: resolverErrors, symbolTable, instructions: null, variableNames: [], templateNames: [] };
    }

    const cfg = new CfgBuilder().build(ast);
    if (cfg.errors.length > 0) {
      return { success: false, buffer: null, errors: cfg.errors, symbolTable, instructions: null, variableNames: [], templateNames: [] };
    }

    const optimized = new Optimizer().optimize(cfg);
    const instructions = new BytecodeGenerator(symbolTable).generate(optimized);
    const buffer = new BinarySerializer().serialize(instructions, symbolTable);

    return { success: true, buffer, errors: [], symbolTable, instructions, variableNames: validator._variableReads.map((it) => it.name), templateNames: validator._includePaths };
  }
}
