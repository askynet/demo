import { BasicBlock } from './BasicBlock.js';
import { BranchType } from './BranchType.js';
import { CompileError } from '../errors/CompileError.js';
import { IfNode } from '../ast/IfNode.js';
import { BinaryExpression } from '../ast/expressions/BinaryExpression.js';

const LEAF_NODE_TYPES = new Set([
  'log',
  'assign',
  'include',
  'input',
  'fetch-attribute',
  'save-attribute',
  'call',
]);

/**
 * @typedef {Object} Cfg
 * @property {Map<string, BasicBlock>} blocks
 * @property {string} entryId
 * @property {CompileError[]} errors
 */

/**
 * Lowers a ScriptNode's statement tree into a Control Flow Graph of
 * BasicBlocks. Supports nested ifs, loops (with break/continue), switch
 * (desugared to an if/else-if chain over equality with the discriminant),
 * and return.
 */
export class CfgBuilder {
  build(scriptNode) {
    /** @type {Map<string, BasicBlock>} */
    this.blocks = new Map();
    this._blockCounter = 0;

    const ctx = {
      /** @type {Map<string, string>} label name -> block id */
      labelBlockId: new Map(),
      /** @type {Array<{ blockId: string, labelName: string, jumpNodeId: string }>} */
      pendingJumps: [],
      /** @type {Array<{ continueTarget: string, breakTarget: string }>} */
      loopStack: [],
      /** @type {CompileError[]} */
      errors: [],
    };

    const result = this._buildBlock(scriptNode.children, ctx);

    // Falling off the end of the script is an implicit return.
    if (result.exit) {
      result.exit.branchType = BranchType.RETURN;
    }

    for (const pending of ctx.pendingJumps) {
      const targetId = ctx.labelBlockId.get(pending.labelName);
      if (targetId === undefined) {
        ctx.errors.push(
          new CompileError(
            pending.jumpNodeId,
            `Jump target "${pending.labelName}" is not a defined label`,
            {},
            'error'
          )
        );
        continue;
      }
      const block = this.blocks.get(pending.blockId);
      block.target = targetId;
      this._link(pending.blockId, targetId);
    }

    return { blocks: this.blocks, entryId: 'b0', errors: ctx.errors };
  }

  _newBlock() {
    const block = new BasicBlock(`b${this._blockCounter++}`);
    this.blocks.set(block.id, block);
    return block;
  }

  _link(fromId, toId) {
    this.blocks.get(fromId).successors.add(toId);
    this.blocks.get(toId).predecessors.add(fromId);
  }

  /** @param {BasicBlock} block @param {string} targetId */
  _finalizeFallthrough(block, targetId) {
    block.branchType = BranchType.FALLTHROUGH;
    block.target = targetId;
    this._link(block.id, targetId);
  }

  /**
   * @param {ReadonlyArray<import('../ast/Node.js').Node>} nodes
   * @param {*} ctx
   * @returns {{ entryId: string, exit: BasicBlock | null }}
   */
  _buildBlock(nodes, ctx) {
    const entry = this._newBlock();
    let open = entry;
    for (const node of nodes) {
      if (open === null) open = this._newBlock(); // dead code after a terminator; cleaned up by the optimizer
      open = this._processNode(node, open, ctx);
    }
    return { entryId: entry.id, exit: open };
  }

  /**
   * @param {import('../ast/Node.js').Node} node
   * @param {BasicBlock} open
   * @param {*} ctx
   * @returns {BasicBlock | null}
   */
  _processNode(node, open, ctx) {
    if (LEAF_NODE_TYPES.has(node.type)) {
      open.statements.push(node);
      return open;
    }

    switch (node.type) {
      case 'label': {
        const target = this._newBlock();
        this._finalizeFallthrough(open, target.id);
        ctx.labelBlockId.set(node.name, target.id);
        return target;
      }

      case 'jump': {
        open.branchType = BranchType.UNCONDITIONAL;
        ctx.pendingJumps.push({ blockId: open.id, labelName: node.target, jumpNodeId: node.id });
        return null;
      }

      case 'return': {
        open.branchType = BranchType.RETURN;
        open.returnValue = node.value ?? null;
        return null;
      }

      case 'break': {
        const loop = ctx.loopStack[ctx.loopStack.length - 1];
        if (!loop) {
          ctx.errors.push(new CompileError(node.id, '"break" used outside of a loop', {}, 'error'));
          return null;
        }
        open.branchType = BranchType.UNCONDITIONAL;
        open.target = loop.breakTarget;
        this._link(open.id, loop.breakTarget);
        return null;
      }

      case 'continue': {
        const loop = ctx.loopStack[ctx.loopStack.length - 1];
        if (!loop) {
          ctx.errors.push(new CompileError(node.id, '"continue" used outside of a loop', {}, 'error'));
          return null;
        }
        open.branchType = BranchType.UNCONDITIONAL;
        open.target = loop.continueTarget;
        this._link(open.id, loop.continueTarget);
        return null;
      }

      case 'if':
        return this._processIf(node, open, ctx);

      case 'switch':
        return this._processSwitch(node, open, ctx);

      case 'loop':
        return this._processLoop(node, open, ctx);

      case 'clearscreen':
        return this._parseClearScreen(node, open, ctx);

      case 'import':
        return this._parseImport(node, open, ctx);

      case 'getkey':
        return this._parseGetKey(node, open, ctx);

      case 'prompt':
        return this._parsePrompt(node, open, ctx);

      case 'only_if':
        return this._parseOnlyIf(node, open, ctx);

      default:
        throw new CompileError(node.id, `CFG builder cannot lower node type "${node.type}"`, {}, 'error');
    }
  }

  _processIf(node, open, ctx) {
    open.branchType = BranchType.CONDITIONAL;
    open.condition = node.condition;
    open.conditionOwnerId = node.id;

    const thenResult = this._buildBlock(node.thenBlock, ctx);
    this._link(open.id, thenResult.entryId);
    open.consequent = thenResult.entryId;

    const merge = this._newBlock();

    if (node.elseBlock.length > 0) {
      const elseResult = this._buildBlock(node.elseBlock, ctx);
      this._link(open.id, elseResult.entryId);
      open.alternate = elseResult.entryId;
      if (elseResult.exit) this._finalizeFallthrough(elseResult.exit, merge.id);
    } else {
      open.alternate = merge.id;
      this._link(open.id, merge.id);
    }

    if (thenResult.exit) this._finalizeFallthrough(thenResult.exit, merge.id);

    return merge;
  }

  _processLoop(node, open, ctx) {
    const header = this._newBlock();
    this._finalizeFallthrough(open, header.id);

    header.branchType = BranchType.CONDITIONAL;
    header.condition = node.condition;
    header.conditionOwnerId = node.id;

    const afterLoop = this._newBlock();
    ctx.loopStack.push({ continueTarget: header.id, breakTarget: afterLoop.id });
    const bodyResult = this._buildBlock(node.body, ctx);
    ctx.loopStack.pop();

    this._link(header.id, bodyResult.entryId);
    header.consequent = bodyResult.entryId;
    header.alternate = afterLoop.id;
    this._link(header.id, afterLoop.id);

    if (bodyResult.exit) this._finalizeFallthrough(bodyResult.exit, header.id);

    return afterLoop;
  }

  _processSwitch(node, open, ctx) {
    if (node.cases.length === 0) {
      let current = open;
      for (const child of node.defaultCase) {
        if (current === null) current = this._newBlock();
        current = this._processNode(child, current, ctx);
      }
      return current;
    }
    return this._processIf(this._desugarSwitch(node), open, ctx);
  }

  /**
   * Desugars a SwitchNode into an equivalent chain of IfNodes comparing the
   * discriminant to each case's test value with `==`, falling through to
   * `defaultCase` at the end. Synthesized nodes reuse the switch's node id
   * with a suffix for diagnostics.
   * @param {import('../ast/SwitchNode.js').SwitchNode} node
   * @returns {IfNode}
   */
  _desugarSwitch(node) {
    let elseBlock = node.defaultCase;
    for (let i = node.cases.length - 1; i >= 0; i -= 1) {
      const c = node.cases[i];
      const test = new BinaryExpression('==', node.discriminant, c.test);
      elseBlock = [new IfNode(`${node.id}-case-${i}`, test, c.body, elseBlock)];
    }
    return elseBlock[0];
  }
}
