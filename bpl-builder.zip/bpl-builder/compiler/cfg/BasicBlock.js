/**
 * A straight-line sequence of non-branching statement nodes, terminated by
 * exactly one control-transfer decision. Unlike AST nodes, BasicBlocks are
 * intentionally mutable working objects: the CFG builder constructs them
 * incrementally and the Optimizer rewrites them in place (merging,
 * removing, re-targeting).
 */
export class BasicBlock {
  /** @param {string} id */
  constructor(id) {
    this.id = id;
    /** @type {import('../ast/Node.js').Node[]} straight-line statements (no branching). */
    this.statements = [];
    /** @type {import('./BranchType.js').BranchType | null} how control leaves this block. */
    this.branchType = null;
    /** @type {import('../ast/Expression.js').Expression | null} set when branchType === CONDITIONAL */
    this.condition = null;
    /** @type {string | null} node id of the if/loop that owns `condition`, for diagnostics */
    this.conditionOwnerId = null;
    /** @type {string | null} branch target when condition is truthy, or loop body entry */
    this.consequent = null;
    /** @type {string | null} branch target when condition is falsy, or after-loop block */
    this.alternate = null;
    /** @type {string | null} single target for FALLTHROUGH / UNCONDITIONAL */
    this.target = null;
    /** @type {import('../ast/Expression.js').Expression | null} set when branchType === RETURN */
    this.returnValue = null;
    /** @type {Set<string>} */
    this.successors = new Set();
    /** @type {Set<string>} */
    this.predecessors = new Set();
    /**
     * Whether this block must be addressable as an explicit jump target
     * in the final bytecode. Computed by the LabelRemoval optimizer pass;
     * defaults to true (conservative) until that pass runs.
     * @type {boolean}
     */
    this.requiresLabel = true;
  }

  /** @returns {boolean} true if this block has no statements and is a pure passthrough */
  isEmpty() {
    return this.statements.length === 0;
  }
}
