/**
 * How control leaves a BasicBlock.
 * - fallthrough: falls into the single successor with no test
 * - conditional: tests a condition, branches to consequent/alternate
 * - unconditional: unconditional jump to a single successor
 * - return: leaves the script entirely, no successors
 */
export const BranchType = Object.freeze({
  FALLTHROUGH: 'fallthrough',
  CONDITIONAL: 'conditional',
  UNCONDITIONAL: 'unconditional',
  RETURN: 'return',
});
