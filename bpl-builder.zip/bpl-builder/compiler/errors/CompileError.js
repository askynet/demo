/**
 * @typedef {'error' | 'warning'} Severity
 */

/**
 * Represents a single diagnostic produced anywhere in the compiler
 * pipeline (parser, validator, resolvers, optimizer). Immutable.
 */
export class CompileError extends Error {
  /**
   * @param {string} nodeId Id of the AST node the diagnostic refers to.
   * @param {string} message Human readable diagnostic message.
   * @param {{ line?: number, column?: number, path?: string }} [location]
   * @param {Severity} [severity]
   */
  constructor(nodeId, message, location = {}, severity = 'error') {
    super(message);
    this.name = 'CompileError';
    this.nodeId = nodeId;
    this.message = message;
    this.location = Object.freeze({ ...location });
    this.severity = severity;
    Object.freeze(this);
  }

  toJSON() {
    return {
      nodeId: this.nodeId,
      message: this.message,
      location: this.location,
      severity: this.severity,
    };
  }
}

/**
 * Thrown when the compiler pipeline cannot continue (e.g. unknown node
 * type during parsing, or one/more fatal semantic errors). Carries the
 * full list of CompileError diagnostics collected so far.
 */
export class CompileFailure extends Error {
  /**
   * @param {CompileError[]} errors
   */
  constructor(errors) {
    super(`Compilation failed with ${errors.length} error(s)`);
    this.name = 'CompileFailure';
    this.errors = Object.freeze([...errors]);
    Object.freeze(this);
  }
}
