/**
 * The instruction set executed by the Worker VM. Semantics assume a
 * single implicit accumulator register (ACC) plus the variable table
 * (shared namespace for both script variables and external input fields)
 * — deliberately no operand stack, since every operator here is at most
 * binary and short-circuit boolean composition (AND/OR) is handled by
 * codegen emitting explicit JUMP/JUMP_FALSE control flow instead.
 *
 * Base opcodes are exactly the set requested by the spec. A small number
 * of extension opcodes (marked below) were added because the Expression
 * grammar (Step 2: !=, >=, <=, IN, EXISTS, NOT, AND, OR) can't be lowered
 * onto COMPARE_EQ/COMPARE_GT/COMPARE_LT alone.
 */
export const Opcode = Object.freeze({
  // --- base opcodes (as specified) ---
  LOAD_ATTR: 0, // ACC = variables[operandA]
  STORE_ATTR: 1, // variables[operandA] = ACC
  LOAD_CONST: 2, // ACC = constant(operandA), operandB = type tag (0=string,1=number,2=boolean)
  COMPARE_EQ: 3, // ACC = (ACC == resolve(operandA, operandB))
  COMPARE_GT: 4, // ACC = (ACC > resolve(operandA, operandB))
  COMPARE_LT: 5, // ACC = (ACC < resolve(operandA, operandB))
  JUMP: 6, // pc = operandA
  JUMP_FALSE: 7, // if (!ACC) pc = operandA
  CALL: 8, // ACC = call(functions[operandA], argSlots[0..operandB-1]); operandC = 1 keeps ACC, 0 discards it
  RETURN: 9, // halts the script; operandA = 1 means "return ACC", 0 means "return nothing"
  INPUT: 10, // variables[operandA] = externalInput(strings[operandB])
  LOG: 11, // emit strings[operandA] to the execution log
  FETCH_DB: 12, // variables[operandB] = db.fetch(strings[operandA])
  SAVE_DB: 13, // db.save(strings[operandA], variables[operandB])
  IMPORT_BLK: 14, // renders includes[operandA] using argSlots[0..operandB-1] as parameters
  END: 15, // sentinel marking physical end of the instruction stream

  // --- extension opcodes (needed by the full Expression grammar) ---
  COMPARE_NEQ: 16, // ACC = (ACC != resolve(operandA, operandB))
  COMPARE_GTE: 17, // ACC = (ACC >= resolve(operandA, operandB))
  COMPARE_LTE: 18, // ACC = (ACC <= resolve(operandA, operandB))
  COMPARE_IN: 19, // ACC = resolve(operandA, operandB).includes(ACC)
  CHECK_EXISTS: 20, // ACC = variables[operandA] !== undefined/null
  LOGICAL_NOT: 21, // ACC = !ACC
});

/** @type {Map<number, string>} */
export const OPCODE_NAMES = new Map(Object.entries(Opcode).map(([name, value]) => [value, name]));

/**
 * Tags disambiguating whether a COMPARE_-family or LOAD-style operand
 * refers to a constant or a variable slot. Used as operandA on comparison opcodes.
 */
export const OperandKind = Object.freeze({
  CONST: 0,
  VAR: 1,
});
