import { OPCODE_NAMES } from './Opcode.js';

/**
 * A single flat instruction: opcode plus up to three numeric operands.
 * This is the only shape the Binary Serializer needs to understand —
 * everything upstream (AST, CFG, optimized blocks) has already been
 * lowered away by the time Instructions exist.
 */
export class Instruction {
  /**
   * @param {number} opcode One of the Opcode enum values.
   * @param {number} [operandA]
   * @param {number} [operandB]
   * @param {number} [operandC]
   */
  constructor(opcode, operandA = 0, operandB = 0, operandC = 0) {
    this.opcode = opcode;
    this.operandA = operandA;
    this.operandB = operandB;
    this.operandC = operandC;
    Object.freeze(this);
  }

  toString() {
    const name = OPCODE_NAMES.get(this.opcode) ?? `UNKNOWN(${this.opcode})`;
    return `${name} ${this.operandA}, ${this.operandB}, ${this.operandC}`;
  }
}
