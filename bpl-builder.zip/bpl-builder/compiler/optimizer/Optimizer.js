import { constantFoldingPass } from './passes/ConstantFolding.js';
import { deadCodeEliminationPass } from './passes/DeadCodeElimination.js';
import { unreachableBlockRemovalPass } from './passes/UnreachableBlockRemoval.js';
import { emptyBlockRemovalPass } from './passes/EmptyBlockRemoval.js';
import { sequentialMergePass } from './passes/SequentialMerge.js';
import { jumpOptimizationPass } from './passes/JumpOptimization.js';
import { labelRemovalPass } from './passes/LabelRemoval.js';

const MAX_ITERATIONS = 32;

/**
 * Runs the full optimization pipeline over a CFG to a fixpoint (or until
 * MAX_ITERATIONS is reached, as a safety valve against pass bugs causing
 * infinite oscillation). Order matters:
 *
 *  1. Constant Folding    - may turn a CONDITIONAL block into an UNCONDITIONAL one,
 *                            making one of its branches provably unreachable.
 *  2. Dead Code Elimination - removes shadowed same-block assigns.
 *  3. Unreachable Block Removal - drops anything constant folding just orphaned.
 *  4. Jump Optimization    - collapses jump-to-jump chains (branch threading).
 *  5. Empty Block Removal  - elides now-pointless zero-statement passthrough blocks.
 *  6. Sequential Merge     - folds exclusive fallthrough pairs into one block.
 *  7. Label Removal        - (final, not repeated) flags which surviving blocks
 *                            actually need an addressable label.
 */
export class Optimizer {
  /**
   * @param {import('../cfg/CfgBuilder.js').Cfg} cfg
   * @returns {import('../cfg/CfgBuilder.js').Cfg}
   */
  optimize(cfg) {
    const { blocks, entryId } = cfg;

    for (let iteration = 0; iteration < MAX_ITERATIONS; iteration += 1) {
      let changed = false;
      changed = constantFoldingPass(blocks) || changed;
      changed = deadCodeEliminationPass(blocks) || changed;
      changed = unreachableBlockRemovalPass(blocks, entryId) || changed;
      changed = jumpOptimizationPass(blocks) || changed;
      changed = emptyBlockRemovalPass(blocks, entryId) || changed;
      changed = sequentialMergePass(blocks) || changed;
      if (!changed) break;
    }

    // Final cleanup pass in case the last mutating iteration left orphans.
    unreachableBlockRemovalPass(blocks, entryId);
    labelRemovalPass(blocks, entryId);

    return { blocks, entryId, errors: cfg.errors };
  }
}
