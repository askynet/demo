import { BranchType } from '../../cfg/BranchType.js';

/**
 * A block only needs to be addressable as an explicit jump target if
 * something can reach it *other than* falling straight through from the
 * single block immediately before it. This pass computes `requiresLabel`
 * for every block so BytecodeGenerator can skip emitting a redundant
 * label/address marker when a block is laid out immediately after its
 * one and only fallthrough predecessor.
 *
 * @param {Map<string, import('../../cfg/BasicBlock.js').BasicBlock>} blocks
 * @param {string} entryId
 * @returns {boolean} whether any block's requiresLabel flag changed
 */
export function labelRemovalPass(blocks, entryId) {
  let changed = false;

  for (const block of blocks.values()) {
    const isSoleFallthroughTarget =
      block.predecessors.size === 1 &&
      (() => {
        const predId = [...block.predecessors][0];
        const pred = blocks.get(predId);
        return pred && pred.branchType === BranchType.FALLTHROUGH && pred.target === block.id;
      })();

    // The entry block is always addressable (it's where execution begins).
    const next = block.id === entryId ? true : !isSoleFallthroughTarget;
    if (block.requiresLabel !== next) {
      block.requiresLabel = next;
      changed = true;
    }
  }

  return changed;
}
