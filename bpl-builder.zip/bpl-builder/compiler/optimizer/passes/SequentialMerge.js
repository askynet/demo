import { BranchType } from '../../cfg/BranchType.js';

/**
 * Merges block B into block A whenever A's only successor is B and B's
 * only predecessor is A (A falls straight through into B with nothing
 * else able to reach B). A absorbs B's statements and takes over B's
 * terminator; B is deleted.
 *
 * @param {Map<string, import('../../cfg/BasicBlock.js').BasicBlock>} blocks
 * @returns {boolean} whether any change was made
 */
export function sequentialMergePass(blocks) {
  let changed = false;

  for (const a of [...blocks.values()]) {
    if (!blocks.has(a.id)) continue;
    if (a.branchType !== BranchType.FALLTHROUGH) continue;
    if (a.successors.size !== 1) continue;

    const bId = [...a.successors][0];
    if (bId === a.id) continue; // self-loop, not a candidate
    const b = blocks.get(bId);
    if (!b || b.predecessors.size !== 1) continue;

    a.statements.push(...b.statements);
    a.branchType = b.branchType;
    a.condition = b.condition;
    a.conditionOwnerId = b.conditionOwnerId;
    a.consequent = b.consequent;
    a.alternate = b.alternate;
    a.target = b.target;
    a.returnValue = b.returnValue;

    a.successors = new Set(b.successors);
    for (const succId of b.successors) {
      const succ = blocks.get(succId);
      if (succ) {
        succ.predecessors.delete(bId);
        succ.predecessors.add(a.id);
      }
    }

    blocks.delete(bId);
    changed = true;
  }

  return changed;
}
