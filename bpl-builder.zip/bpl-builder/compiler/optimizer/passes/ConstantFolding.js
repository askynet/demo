import { LiteralExpression } from '../../ast/expressions/LiteralExpression.js';
import { BinaryExpression } from '../../ast/expressions/BinaryExpression.js';
import { UnaryExpression } from '../../ast/expressions/UnaryExpression.js';
import { FunctionExpression } from '../../ast/expressions/FunctionExpression.js';
import { BranchType } from '../../cfg/BranchType.js';

/**
 * @param {import('../../ast/Expression.js').Expression} expr
 * @returns {import('../../ast/Expression.js').Expression}
 */
function fold(expr) {
  if (!expr) return expr;

  if (expr.kind === 'binary') {
    const left = fold(expr.left);
    const right = fold(expr.right);
    if (left.kind === 'literal' && right.kind === 'literal') {
      const value = evaluateBinary(expr.operator, left.value, right.value);
      if (value !== undefined) return new LiteralExpression(value);
    }
    return left === expr.left && right === expr.right
      ? expr
      : new BinaryExpression(expr.operator, left, right);
  }

  if (expr.kind === 'unary') {
    const operand = fold(expr.operand);
    if (operand.kind === 'literal' && expr.operator === 'NOT') {
      return new LiteralExpression(!operand.value);
    }
    return operand === expr.operand ? expr : new UnaryExpression(expr.operator, operand);
  }

  if (expr.kind === 'function') {
    const args = expr.args.map(fold);
    return args.every((a, i) => a === expr.args[i])
      ? expr
      : new FunctionExpression(expr.name, args);
  }

  return expr;
}

/**
 * @param {string} operator
 * @param {*} left
 * @param {*} right
 * @returns {boolean | undefined} undefined if the operator can't be folded statically
 */
function evaluateBinary(operator, left, right) {
  switch (operator) {
    case 'AND':
      return Boolean(left) && Boolean(right);
    case 'OR':
      return Boolean(left) || Boolean(right);
    case '==':
      return left === right;
    case '!=':
      return left !== right;
    case '>':
      return left > right;
    case '<':
      return left < right;
    case '>=':
      return left >= right;
    case '<=':
      return left <= right;
    case 'IN':
      return Array.isArray(right) && right.includes(left);
    default:
      return undefined;
  }
}

/**
 * Folds constant sub-expressions in every conditional block's condition,
 * and collapses a CONDITIONAL block whose condition folds to a literal
 * boolean into an UNCONDITIONAL edge, dropping the other branch entirely
 * (it becomes unreachable and is swept up by UnreachableBlockRemoval).
 *
 * @param {Map<string, import('../../cfg/BasicBlock.js').BasicBlock>} blocks
 * @returns {boolean} whether any change was made
 */
export function constantFoldingPass(blocks) {
  let changed = false;

  for (const block of blocks.values()) {
    if (block.branchType !== BranchType.CONDITIONAL || !block.condition) continue;

    const folded = fold(block.condition);
    if (folded !== block.condition) {
      block.condition = folded;
      changed = true;
    }

    if (folded.kind === 'literal') {
      const takenTarget = folded.value ? block.consequent : block.alternate;
      const droppedTarget = folded.value ? block.alternate : block.consequent;

      if (droppedTarget && droppedTarget !== takenTarget) {
        blocks.get(droppedTarget)?.predecessors.delete(block.id);
        block.successors.delete(droppedTarget);
      }

      block.branchType = BranchType.UNCONDITIONAL;
      block.target = takenTarget;
      block.condition = null;
      block.conditionOwnerId = null;
      block.consequent = null;
      block.alternate = null;
      changed = true;
    }
  }

  return changed;
}
