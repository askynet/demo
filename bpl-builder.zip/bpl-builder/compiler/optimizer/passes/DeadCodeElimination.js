/** @param {import('../../ast/Expression.js').Expression | null} expr @param {Set<string>} out */
function collectVariableNames(expr, out) {
  if (!expr) return;
  if (expr.kind === 'variable') out.add(expr.name);
  else if (expr.kind === 'binary') {
    collectVariableNames(expr.left, out);
    collectVariableNames(expr.right, out);
  } else if (expr.kind === 'unary') {
    collectVariableNames(expr.operand, out);
  } else if (expr.kind === 'function') {
    for (const arg of expr.args) collectVariableNames(arg, out);
  }
}

/**
 * @param {import('../../ast/Node.js').Node} statement
 * @returns {Set<string>} variable names this statement reads
 */
function readsOf(statement) {
  const out = new Set();
  if (statement.type === 'call') {
    for (const arg of statement.args) collectVariableNames(arg, out);
  } else if (statement.type === 'save-attribute') {
    out.add(statement.variable);
  }
  return out;
}

/**
 * Removes AssignNode statements whose value can never be observed.
 *
 * Deliberately narrow scope: this only eliminates same-block shadowing —
 * an earlier assign to X with no read of X before a later assign to X in
 * the same block is provably dead, because the later assign overwrites it
 * before anything else can run.
 *
 * A broader "X is never read anywhere in this CFG, therefore every assign
 * to X is dead" rule is intentionally *not* implemented: assign targets
 * here are frequently script-level outputs (e.g. "status", "reason") that
 * the Worker VM consumes after this script finishes, and are never read
 * via a VariableExpression inside this CFG at all. Treating "unread
 * in-CFG" as "dead" would silently delete real business-logic output —
 * unsafe without an explicit list of the flow's declared output variables.
 *
 * @param {Map<string, import('../../cfg/BasicBlock.js').BasicBlock>} blocks
 * @returns {boolean} whether any statement was removed
 */
export function deadCodeEliminationPass(blocks) {
  let changed = false;

  for (const block of blocks.values()) {
    const toRemove = new Set();
    /** @type {Map<string, number>} */
    const pendingAssignIndex = new Map();

    block.statements.forEach((stmt, index) => {
      for (const name of readsOf(stmt)) pendingAssignIndex.delete(name);

      if (stmt.type === 'assign') {
        if (pendingAssignIndex.has(stmt.variable)) {
          toRemove.add(pendingAssignIndex.get(stmt.variable));
        }
        pendingAssignIndex.set(stmt.variable, index);
      }
    });

    if (toRemove.size > 0) {
      block.statements = block.statements.filter((_, index) => !toRemove.has(index));
      changed = true;
    }
  }

  return changed;
}
