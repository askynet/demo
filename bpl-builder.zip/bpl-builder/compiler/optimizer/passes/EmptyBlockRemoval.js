import { BranchType } from '../../cfg/BranchType.js';

/**
 * @param {import('../../cfg/BasicBlock.js').BasicBlock} block
 */
function retarget(block, from, to) {
  if (block.target === from) block.target = to;
  if (block.consequent === from) block.consequent = to;
  if (block.alternate === from) block.alternate = to;
}

/**
 * Elides blocks that carry no statements and simply fall through to a
 * single successor (typically produced when a label or merge point sat
 * between two other blocks with nothing of its own to execute). Every
 * predecessor is rewired directly to the elided block's target.
 *
 * @param {Map<string, import('../../cfg/BasicBlock.js').BasicBlock>} blocks
 * @param {string} entryId Never elided, even if empty, so the CFG keeps a stable entry point.
 * @returns {boolean} whether any change was made
 */
export function emptyBlockRemovalPass(blocks, entryId) {
  let changed = false;

  for (const block of [...blocks.values()]) {
    if (block.id === entryId) continue;
    if (!blocks.has(block.id)) continue; // already removed this pass
    if (block.statements.length !== 0) continue;
    if (block.branchType !== BranchType.FALLTHROUGH && block.branchType !== BranchType.UNCONDITIONAL) continue;
    if (block.target === null || block.target === block.id) continue;

    const target = block.target;

    for (const predId of block.predecessors) {
      if (predId === block.id) continue;
      const pred = blocks.get(predId);
      if (!pred) continue;
      retarget(pred, block.id, target);
      pred.successors.delete(block.id);
      pred.successors.add(target);
      blocks.get(target).predecessors.add(predId);
    }

    blocks.get(target).predecessors.delete(block.id);
    blocks.delete(block.id);
    changed = true;
  }

  return changed;
}
