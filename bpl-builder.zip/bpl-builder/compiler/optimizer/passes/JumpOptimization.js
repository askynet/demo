import { BranchType } from '../../cfg/BranchType.js';

/**
 * @param {Map<string, import('../../cfg/BasicBlock.js').BasicBlock>} blocks
 * @param {string} id
 * @returns {string} the final destination after following any chain of
 *   trivial forwarding blocks (empty, single unconditional/fallthrough target)
 */
function chase(blocks, id) {
  const seen = new Set();
  let current = id;
  while (!seen.has(current)) {
    seen.add(current);
    const block = blocks.get(current);
    if (
      !block ||
      block.statements.length !== 0 ||
      (block.branchType !== BranchType.UNCONDITIONAL && block.branchType !== BranchType.FALLTHROUGH) ||
      !block.target
    ) {
      return current;
    }
    current = block.target;
  }
  return current; // cycle guard: stop at the repeated node rather than looping forever
}

/**
 * Branch-threading: retargets every consequent/alternate/target pointer
 * directly to the end of any chain of trivial forwarding blocks it points
 * through, so downstream bytecode never emits a jump that just lands on
 * another unconditional jump.
 *
 * @param {Map<string, import('../../cfg/BasicBlock.js').BasicBlock>} blocks
 * @returns {boolean} whether any pointer changed
 */
export function jumpOptimizationPass(blocks) {
  let changed = false;

  for (const block of blocks.values()) {
    for (const field of ['target', 'consequent', 'alternate']) {
      const original = block[field];
      if (!original) continue;
      const final = chase(blocks, original);
      if (final !== original) {
        blocks.get(original)?.predecessors.delete(block.id);
        blocks.get(final)?.predecessors.add(block.id);
        block.successors.delete(original);
        block.successors.add(final);
        block[field] = final;
        changed = true;
      }
    }
  }

  return changed;
}
