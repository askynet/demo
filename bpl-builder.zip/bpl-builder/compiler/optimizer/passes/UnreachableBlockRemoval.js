/**
 * Removes every block not reachable from `entryId` via successor edges,
 * and cleans up dangling predecessor/successor references left behind.
 *
 * @param {Map<string, import('../../cfg/BasicBlock.js').BasicBlock>} blocks
 * @param {string} entryId
 * @returns {boolean} whether any block was removed
 */
export function unreachableBlockRemovalPass(blocks, entryId) {
  const reachable = new Set();
  const stack = [entryId];
  while (stack.length > 0) {
    const id = stack.pop();
    if (reachable.has(id) || !blocks.has(id)) continue;
    reachable.add(id);
    for (const next of blocks.get(id).successors) stack.push(next);
  }

  let changed = false;
  for (const id of [...blocks.keys()]) {
    if (!reachable.has(id)) {
      blocks.delete(id);
      changed = true;
    }
  }

  for (const block of blocks.values()) {
    for (const pred of [...block.predecessors]) {
      if (!blocks.has(pred)) block.predecessors.delete(pred);
    }
    for (const succ of [...block.successors]) {
      if (!blocks.has(succ)) block.successors.delete(succ);
    }
  }

  return changed;
}
