const MAGIC = Buffer.from([0x50, 0x46, 0x43, 0x31]); // "PFC1"
const COMPILER_VERSION = 1;

/** @param {ReadonlyArray<string>} names @returns {Buffer[]} */
function encodeNameTable(names) {
  const parts = [Buffer.alloc(4)];
  parts[0].writeUInt32LE(names.length, 0);
  for (const name of names) {
    const utf8 = Buffer.from(name, 'utf8');
    const lengthPrefix = Buffer.alloc(2);
    lengthPrefix.writeUInt16LE(utf8.length, 0);
    parts.push(lengthPrefix, utf8);
  }
  return parts;
}

/**
 * @param {Buffer} buffer
 * @param {number} offset
 * @returns {{ names: string[], nextOffset: number }}
 */
function decodeNameTable(buffer, offset) {
  let cursor = offset;
  const count = buffer.readUInt32LE(cursor);
  cursor += 4;
  const names = [];
  for (let i = 0; i < count; i += 1) {
    const length = buffer.readUInt16LE(cursor);
    cursor += 2;
    names.push(buffer.toString('utf8', cursor, cursor + length));
    cursor += length;
  }
  return { names, nextOffset: cursor };
}

/**
 * Serializes the compiled Instruction stream and SymbolTable into the
 * final binary artifact. Layout:
 *
 *   MAGIC (4 bytes "PFC1") | VERSION (uint16) | INSTRUCTION_COUNT (uint32)
 *   | STRING_TABLE | SYMBOL_TABLE (variables, labels, includes, functions)
 *   | INSTRUCTIONS (opcode: uint8, operandA/B/C: uint32 each)
 *
 * No JSON, no Gob — everything is hand-packed with Buffer.writeUInt*LE.
 */
export class BinarySerializer {
  /**
   * @param {import('../ir/Instruction.js').Instruction[]} instructions
   * @param {import('../symbols/SymbolTable.js').SymbolTable} symbolTable
   * @returns {Buffer}
   */
  serialize(instructions, symbolTable) {
    const header = Buffer.alloc(4 + 2 + 4);
    MAGIC.copy(header, 0);
    header.writeUInt16LE(COMPILER_VERSION, 4);
    header.writeUInt32LE(instructions.length, 6);

    const stringTable = encodeNameTable(symbolTable.strings.entries());
    const symbolTables = [
      ...encodeNameTable(symbolTable.variables.entries()),
      ...encodeNameTable(symbolTable.labels.entries()),
      ...encodeNameTable(symbolTable.includes.entries()),
      ...encodeNameTable(symbolTable.functions.entries()),
    ];

    const instructionBuffer = Buffer.alloc(instructions.length * 13);
    instructions.forEach((instr, index) => {
      const base = index * 13;
      instructionBuffer.writeUInt8(instr.opcode, base);
      instructionBuffer.writeUInt32LE(instr.operandA >>> 0, base + 1);
      instructionBuffer.writeUInt32LE(instr.operandB >>> 0, base + 5);
      instructionBuffer.writeUInt32LE(instr.operandC >>> 0, base + 9);
    });

    return Buffer.concat([header, ...stringTable, ...symbolTables, instructionBuffer]);
  }

  /**
   * @param {Buffer} buffer
   * @returns {{
   *   version: number,
   *   strings: string[], variables: string[], labels: string[],
   *   includes: string[], functions: string[],
   *   instructions: Array<{ opcode: number, operandA: number, operandB: number, operandC: number }>
   * }}
   */
  deserialize(buffer) {
    if (!buffer.subarray(0, 4).equals(MAGIC)) {
      throw new Error('Invalid binary: bad magic number');
    }
    const version = buffer.readUInt16LE(4);
    const instructionCount = buffer.readUInt32LE(6);

    let offset = 10;
    const strings = decodeNameTable(buffer, offset);
    offset = strings.nextOffset;
    const variables = decodeNameTable(buffer, offset);
    offset = variables.nextOffset;
    const labels = decodeNameTable(buffer, offset);
    offset = labels.nextOffset;
    const includes = decodeNameTable(buffer, offset);
    offset = includes.nextOffset;
    const functions = decodeNameTable(buffer, offset);
    offset = functions.nextOffset;

    const instructions = [];
    for (let i = 0; i < instructionCount; i += 1) {
      const base = offset + i * 13;
      instructions.push({
        opcode: buffer.readUInt8(base),
        operandA: buffer.readUInt32LE(base + 1),
        operandB: buffer.readUInt32LE(base + 5),
        operandC: buffer.readUInt32LE(base + 9),
      });
    }

    return {
      version,
      strings: strings.names,
      variables: variables.names,
      labels: labels.names,
      includes: includes.names,
      functions: functions.names,
      instructions,
    };
  }
}
