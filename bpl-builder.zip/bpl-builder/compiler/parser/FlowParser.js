import { CompileError } from '../errors/CompileError.js';
import { ExpressionParser } from './ExpressionParser.js';
import { ScriptNode } from '../ast/ScriptNode.js';
import { IfNode } from '../ast/IfNode.js';
import { AssignNode } from '../ast/AssignNode.js';
import { IncludeNode } from '../ast/IncludeNode.js';
import { JumpNode } from '../ast/JumpNode.js';
import { LabelNode } from '../ast/LabelNode.js';
import { LogNode } from '../ast/LogNode.js';
import { InputNode } from '../ast/InputNode.js';
import { FetchAttributeNode } from '../ast/FetchAttributeNode.js';
import { SaveAttributeNode } from '../ast/SaveAttributeNode.js';
import { CallNode } from '../ast/CallNode.js';
import { ReturnNode } from '../ast/ReturnNode.js';
import { SwitchNode } from '../ast/SwitchNode.js';
import { LoopNode } from '../ast/LoopNode.js';
import { BreakNode } from '../ast/BreakNode.js';
import { ContinueNode } from '../ast/ContinueNode.js';
import { ClearScreenNode } from '../ast/ClearScreenNode.js';
import { GetKeyNode } from '../ast/GetKeyNode.js';
import { PromptNode } from '../ast/PromptNode.js';
import { OnlyIfNode } from '../ast/OnlyIfNode.js';
import { ImportNode } from '../ast/ImportNode.js';

/**
 * Converts raw Flow JSON into an immutable AST. Never leaves raw JSON
 * lying around afterwards — every field the rest of the pipeline touches
 * is a real AST node or Expression instance.
 */
export class FlowParser {
  constructor() {
    this._expressionParser = new ExpressionParser();

    /** @type {Map<string, (json: any) => import('../ast/Node.js').Node>} */
    this._handlers = new Map([
      ['script', (j) => this._parseScript(j)],
      ['if', (j) => this._parseIf(j)],
      ['assign', (j) => this._parseAssign(j)],
      ['include', (j) => this._parseInclude(j)],
      ['jump', (j) => this._parseJump(j)],
      ['label', (j) => this._parseLabel(j)],
      ['log', (j) => this._parseLog(j)],
      ['input', (j) => this._parseInput(j)],
      ['fetch-attribute', (j) => this._parseFetchAttribute(j)],
      ['save-attribute', (j) => this._parseSaveAttribute(j)],
      ['call', (j) => this._parseCall(j)],
      ['return', (j) => this._parseReturn(j)],
      ['switch', (j) => this._parseSwitch(j)],
      ['loop', (j) => this._parseLoop(j)],
      ['break', (j) => this._parseBreak(j)],
      ['continue', (j) => this._parseContinue(j)],
      ['clearscreen', (j) => this._parseClearScreen(j)],
      ['getkey', (j) => this._parseGetKey(j)],
      ['prompt', (j) => this._parsePrompt(j)],
      ['only_if', (j) => this._parseOnlyIf(j)],
      ['import', (j) => this._parseImport(j)],
    ]);
  }

  /**
   * @param {any} flowJson
   * @returns {ScriptNode}
   */
  parse(flowJson) {
    if (!flowJson || typeof flowJson !== 'object') {
      throw new CompileError('root', 'Flow JSON must be an object', {}, 'error');
    }
    if (flowJson.type !== 'script') {
      throw new CompileError(
        flowJson.id ?? 'root',
        `Root node must be of type "script", got "${flowJson.type}"`,
        {},
        'error'
      );
    }
    return /** @type {ScriptNode} */ (this._parseNode(flowJson));
  }

  /**
   * @param {any} json
   * @returns {import('../ast/Node.js').Node}
   */
  _parseNode(json) {
    if (!json || typeof json !== 'object' || typeof json.id !== 'string') {
      throw new CompileError('unknown', 'Every AST node requires a string "id"', {}, 'error');
    }
    const handler = this._handlers.get(json.type);
    if (!handler) {
      throw new CompileError(json.id, `Unknown node type "${json.type}"`, {}, 'error');
    }
    return handler(json);
  }

  /** @param {ReadonlyArray<any>} children */
  _parseBlock(children) {
    if (!Array.isArray(children)) return [];
    return children.map((c) => this._parseNode(c));
  }

  _parseScript(json) {
    return new ScriptNode(json.id, json.name ?? '', this._parseBlock(json.children));
  }

  _parseIf(json) {
    const condition = this._expressionParser.parseCondition(json.condition, json.id);
    return new IfNode(
      json.id,
      condition,
      this._parseBlock(json.thenBlock),
      this._parseBlock(json.elseBlock)
    );
  }

  _parseAssign(json) {
    if (typeof json.variable !== 'string') {
      throw new CompileError(json.id, 'assign node requires a string "variable"', {}, 'error');
    }
    return new AssignNode(json.id, json.variable, json.value, Boolean(json.isValueIdentifier));
  }

  _parseInclude(json) {
    if (typeof json.path !== 'string' || json.path.length === 0) {
      throw new CompileError(json.id, 'include node requires a non-empty "path"', {}, 'error');
    }
    return new IncludeNode(json.id, json.path, json.parameters ?? []);
  }

  _parseJump(json) {
    if (typeof json.target !== 'string') {
      throw new CompileError(json.id, 'jump node requires a string "target"', {}, 'error');
    }
    return new JumpNode(json.id, json.target);
  }

  _parseLabel(json) {
    if (typeof json.name !== 'string') {
      throw new CompileError(json.id, 'label node requires a string "name"', {}, 'error');
    }
    return new LabelNode(json.id, json.name);
  }

  _parseLog(json) {
    return new LogNode(json.id, json.message ?? '');
  }

  _parseInput(json) {
    if (typeof json.variable !== 'string') {
      throw new CompileError(json.id, 'input node requires a string "variable"', {}, 'error');
    }
    return new InputNode(json.id, json.variable, json.prompt ?? '');
  }

  _parseFetchAttribute(json) {
    if (typeof json.attribute !== 'string' || typeof json.variable !== 'string') {
      throw new CompileError(
        json.id,
        'fetch-attribute node requires string "attribute" and "variable"',
        {},
        'error'
      );
    }
    return new FetchAttributeNode(json.id, json.attribute, json.variable);
  }

  _parseSaveAttribute(json) {
    if (typeof json.attribute !== 'string' || typeof json.variable !== 'string') {
      throw new CompileError(
        json.id,
        'save-attribute node requires string "attribute" and "variable"',
        {},
        'error'
      );
    }
    return new SaveAttributeNode(json.id, json.attribute, json.variable);
  }

  _parseCall(json) {
    if (typeof json.functionName !== 'string') {
      throw new CompileError(json.id, 'call node requires a string "functionName"', {}, 'error');
    }
    const args = (json.args ?? []).map((a) => this._expressionParser.parseExpression(a, json.id));
    return new CallNode(json.id, json.functionName, args, json.resultVariable ?? '');
  }

  _parseReturn(json) {
    const value =
      json.value === undefined || json.value === null
        ? null
        : this._expressionParser.parseExpression(json.value, json.id);
    return new ReturnNode(json.id, value);
  }

  _parseSwitch(json) {
    const discriminant = this._expressionParser.parseCondition(json.discriminant, json.id);
    const cases = (json.cases ?? []).map((c) => ({
      test: this._expressionParser.parseCondition(c.test, json.id),
      body: this._parseBlock(c.body),
    }));
    return new SwitchNode(json.id, discriminant, cases, this._parseBlock(json.defaultCase));
  }

  _parseLoop(json) {
    const condition = this._expressionParser.parseCondition(json.condition, json.id);
    return new LoopNode(json.id, condition, this._parseBlock(json.body));
  }

  _parseBreak(json) {
    return new BreakNode(json.id);
  }

  _parseContinue(json) {
    return new ContinueNode(json.id);
  }

  _parseClearScreen(json) {
    return new ClearScreenNode(json.id);
  }

  _parseGetKey(json) {
    return new GetKeyNode(json.id);
  }

  _parseOnlyIf(json) {
    return new OnlyIfNode(json.id);
  }

  _parsePrompt(json) {
    return new PromptNode(json.id);
  }

  _parseImport(json) {
    return new ImportNode(json.id);
  }
}