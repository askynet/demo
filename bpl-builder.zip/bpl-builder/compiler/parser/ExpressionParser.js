import { CompileError } from '../errors/CompileError.js';
import { BinaryExpression } from '../ast/expressions/BinaryExpression.js';
import { UnaryExpression } from '../ast/expressions/UnaryExpression.js';
import { VariableExpression } from '../ast/expressions/VariableExpression.js';
import { LiteralExpression } from '../ast/expressions/LiteralExpression.js';
import { FunctionExpression } from '../ast/expressions/FunctionExpression.js';

/** Maps the Flow JSON's human-readable leaf operators to AST operators. */
const LEAF_OPERATOR_MAP = Object.freeze({
  equals: '==',
  not_equals: '!=',
  greater_than: '>',
  less_than: '<',
  greater_than_or_equal: '>=',
  less_than_or_equal: '<=',
  in: 'IN',
  exists: 'EXISTS',
});

const GROUP_OPERATORS = new Set(['AND', 'OR', 'NOT']);

/**
 * Parses the condition-group / leaf-condition JSON shape used by `if`,
 * `loop`, and `switch` case tests, as well as the lower-level raw
 * expression node shape (binary/unary/variable/literal/function) used
 * inside `call` arguments and `return` values.
 */
export class ExpressionParser {
  /**
   * Entry point for `if`/`loop` conditions and `switch` case tests. Accepts
   * either a condition-group, a leaf condition, or a raw expression node.
   * @param {any} json
   * @param {string} ownerNodeId Id of the owning statement node, for diagnostics.
   * @returns {import('../ast/Expression.js').Expression}
   */
  parseCondition(json, ownerNodeId) {
    if (!json || typeof json !== 'object') {
      throw new CompileError(ownerNodeId, 'Condition must be an object', {}, 'error');
    }

    if (json.type === 'condition-group') {
      return this._parseConditionGroup(json, ownerNodeId);
    }

    if (typeof json.field === 'string' && typeof json.operator === 'string') {
      return this._parseLeafCondition(json, ownerNodeId);
    }

    // Fall through to the raw expression grammar (binary/unary/variable/literal/function).
    return this.parseExpression(json, ownerNodeId);
  }

  /**
   * @param {any} json
   * @param {string} ownerNodeId
   * @returns {import('../ast/Expression.js').Expression}
   */
  _parseConditionGroup(json, ownerNodeId) {
    const operator = json.operator;
    if (!GROUP_OPERATORS.has(operator)) {
      throw new CompileError(
        ownerNodeId,
        `Unknown condition-group operator "${operator}"`,
        {},
        'error'
      );
    }

    const conditions = Array.isArray(json.conditions) ? json.conditions : [];
    if (conditions.length === 0) {
      throw new CompileError(ownerNodeId, 'condition-group has no conditions', {}, 'error');
    }

    const parsed = conditions.map((c) => this.parseCondition(c, ownerNodeId));

    if (operator === 'NOT') {
      if (parsed.length !== 1) {
        throw new CompileError(
          ownerNodeId,
          'NOT condition-group must contain exactly one condition',
          {},
          'error'
        );
      }
      return new UnaryExpression('NOT', parsed[0]);
    }

    // AND / OR: left-fold the list into a chain of BinaryExpressions.
    return parsed.reduce((acc, expr) => (acc ? new BinaryExpression(operator, acc, expr) : expr), null);
  }

  /**
   * @param {{ field: string, operator: string, value?: any }} json
   * @param {string} ownerNodeId
   * @returns {import('../ast/Expression.js').Expression}
   */
  _parseLeafCondition(json, ownerNodeId) {
    const mapped = LEAF_OPERATOR_MAP[json.operator];
    if (!mapped) {
      throw new CompileError(
        ownerNodeId,
        `Unknown leaf condition operator "${json.operator}"`,
        {},
        'error'
      );
    }

    const field = new VariableExpression(json.field);
    if (mapped === 'EXISTS') {
      return new UnaryExpression('EXISTS', field);
    }
    return new BinaryExpression(mapped, field, new LiteralExpression(json.value));
  }

  /**
   * Parses the raw expression grammar: binary / unary / variable / literal / function.
   * @param {any} json
   * @param {string} ownerNodeId
   * @returns {import('../ast/Expression.js').Expression}
   */
  parseExpression(json, ownerNodeId) {
    if (json === null || (typeof json !== 'object' && typeof json !== 'undefined')) {
      // Bare literal shorthand, e.g. args: [5, "Eligible"]
      return new LiteralExpression(json);
    }
    if (!json || typeof json !== 'object') {
      throw new CompileError(ownerNodeId, 'Invalid expression', {}, 'error');
    }

    switch (json.type) {
      case 'binary':
        return new BinaryExpression(
          json.operator,
          this.parseExpression(json.left, ownerNodeId),
          this.parseExpression(json.right, ownerNodeId)
        );
      case 'unary':
        return new UnaryExpression(json.operator, this.parseExpression(json.operand, ownerNodeId));
      case 'variable':
        return new VariableExpression(json.name);
      case 'literal':
        return new LiteralExpression(json.value);
      case 'function':
        return new FunctionExpression(
          json.name,
          (json.args || []).map((a) => this.parseExpression(a, ownerNodeId))
        );
      case 'condition-group':
        return this._parseConditionGroup(json, ownerNodeId);
      default:
        throw new CompileError(
          ownerNodeId,
          `Unknown expression node type "${json.type}"`,
          {},
          'error'
        );
    }
  }
}
