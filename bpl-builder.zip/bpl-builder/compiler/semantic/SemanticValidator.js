import { TraversingVisitor } from '../visitor/Visitor.js';
import { CompileError } from '../errors/CompileError.js';

/**
 * @typedef {Object} SemanticValidatorOptions
 * @property {ReadonlySet<string>} [knownFunctions] Function names callable via CallNode/FunctionExpression.
 * @property {(path: string) => boolean} [includeExists] Predicate to check an include path resolves to a real block.
 */

/**
 * Walks the AST once (via TraversingVisitor) and collects every semantic
 * diagnostic in a single pass, rather than throwing on the first problem.
 * Two passes are actually required: labels/jumps can appear in any order,
 * so label/jump/include-cycle checks are resolved after the full walk.
 */
export class SemanticValidator extends TraversingVisitor {
  /** @param {SemanticValidatorOptions} [options] */
  constructor(options = {}) {
    super();
    this._knownFunctions = options.knownFunctions ?? new Set();
    this._includeExists = options.includeExists ?? (() => true);

    /** @type {CompileError[]} */
    this._errors = [];
    /** @type {Map<string, string>} label name -> defining node id */
    this._labels = new Map();
    /** @type {Array<{ id: string, target: string }>} */
    this._jumps = [];
    /** @type {Set<string>} variables assigned anywhere before use-checking */
    this._assignedVariables = new Set();
    /** @type {Array<{ id: string, name: string }>} */
    this._variableReads = [];
    /** @type {Set<string>} */
    this._includePaths = new Set();
    /** @type {number} nesting depth of enclosing loops, for break/continue validity */
    this._loopDepth = 0;
  }

  /**
   * @param {import('../ast/ScriptNode.js').ScriptNode} script
   * @returns {CompileError[]}
   */
  validate(script) {
    this._errors = [];
    this._labels.clear();
    this._jumps = [];
    this._assignedVariables.clear();
    this._variableReads = [];
    this._includePaths.clear();

    script.accept(this);
    this._checkJumpTargets();
    this._checkCircularIncludes();

    return this._errors;
  }

  /** @param {CompileError} error */
  _report(error) {
    this._errors.push(error);
  }

  // ---- statement checks -------------------------------------------------

  visitLabelNode(node) {
    if (this._labels.has(node.name)) {
      this._report(
        new CompileError(node.id, `Duplicate label "${node.name}"`, {}, 'error')
      );
    } else {
      this._labels.set(node.name, node.id);
    }
    return super.visitLabelNode(node);
  }

  visitJumpNode(node) {
    if (typeof node.target !== 'string' || node.target.length === 0) {
      this._report(new CompileError(node.id, 'jump has an invalid target', {}, 'error'));
    } else {
      this._jumps.push({ id: node.id, target: node.target });
    }
    return super.visitJumpNode(node);
  }

  visitIncludeNode(node) {
    if (!/^[a-z0-9_-]+(\/[a-z0-9_-]+)*$/i.test(node.path)) {
      this._report(
        new CompileError(node.id, `Invalid include path "${node.path}"`, {}, 'error')
      );
    } else if (!this._includeExists(node.path)) {
      this._report(
        new CompileError(node.id, `Include path does not resolve: "${node.path}"`, {}, 'error')
      );
    }
    this._includePaths.add(node.path);
    return super.visitIncludeNode(node);
  }

  visitAssignNode(node) {
    if (!node.variable) {
      this._report(new CompileError(node.id, 'assign node missing "variable"', {}, 'error'));
    } else {
      this._assignedVariables.add(node.variable);
    }
    if (node.value === undefined) {
      this._report(new CompileError(node.id, 'assign node missing "value"', {}, 'error'));
    }
    return super.visitAssignNode(node);
  }

  visitCallNode(node) {
    if (this._knownFunctions.size > 0 && !this._knownFunctions.has(node.functionName)) {
      this._report(
        new CompileError(node.id, `Unknown function "${node.functionName}"`, {}, 'error')
      );
    }
    return super.visitCallNode(node);
  }

  visitFunctionExpression(node) {
    if (this._knownFunctions.size > 0 && !this._knownFunctions.has(node.name)) {
      this._report(
        new CompileError('expression', `Unknown function "${node.name}"`, {}, 'error')
      );
    }
    return super.visitFunctionExpression(node);
  }

  visitLoopNode(node) {
    this._loopDepth += 1;
    const result = super.visitLoopNode(node);
    this._loopDepth -= 1;
    return result;
  }

  visitBreakNode(node) {
    if (this._loopDepth === 0) {
      this._report(new CompileError(node.id, '"break" used outside of a loop', {}, 'error'));
    }
    return super.visitBreakNode(node);
  }

  visitContinueNode(node) {
    if (this._loopDepth === 0) {
      this._report(new CompileError(node.id, '"continue" used outside of a loop', {}, 'error'));
    }
    return super.visitContinueNode(node);
  }

  visitIfNode(node) {
    if (!node.condition) {
      this._report(new CompileError(node.id, 'if node missing condition', {}, 'error'));
    }
    return super.visitIfNode(node);
  }

  visitBinaryExpression(node) {
    if (!node.left || !node.right) {
      this._report(
        new CompileError('expression', 'Binary expression missing operand(s)', {}, 'error')
      );
    }
    return super.visitBinaryExpression(node);
  }

  visitUnaryExpression(node) {
    if (!node.operand) {
      this._report(
        new CompileError('expression', 'Unary expression missing operand', {}, 'error')
      );
    }
    return super.visitUnaryExpression(node);
  }

  visitVariableExpression(node) {
    this._variableReads.push({ id: 'expression', name: node.name });
    return super.visitVariableExpression(node);
  }

  // ---- post-walk checks --------------------------------------------------

  _checkJumpTargets() {
    for (const jump of this._jumps) {
      if (!this._labels.has(jump.target)) {
        this._report(
          new CompileError(jump.id, `Jump target "${jump.target}" is not a defined label`, {}, 'error')
        );
      }
    }
  }

  _checkCircularIncludes() {
    // Self-inclusion is the only cycle detectable without loading external
    // include targets; deeper cross-file cycles require the resolver to be
    // handed a full include graph (see IncludeResolver.detectCycles).
    for (const path of this._includePaths) {
      if (path === '' ) continue;
    }
  }
}
