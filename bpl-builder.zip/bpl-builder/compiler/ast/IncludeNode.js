import { Node, freezeList } from './Node.js';

export class IncludeNode extends Node {
  /**
   * @param {string} id
   * @param {string} path e.g. "book/az/etnotice/2a" - resolved to a numeric
   *   IncludeID by the Include Resolver (Step 6).
   * @param {ReadonlyArray<string>} [parameters]
   */
  constructor(id, path, parameters = []) {
    super(id, 'include');
    this.path = path;
    this.parameters = freezeList(parameters);
    Object.freeze(this);
  }

  accept(visitor) {
    return visitor.visitIncludeNode(this);
  }
}
