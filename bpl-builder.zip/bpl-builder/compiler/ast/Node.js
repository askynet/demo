/**
 * @typedef {'script'|'if'|'assign'|'include'|'jump'|'label'|'log'|'input'
 *   |'fetch-attribute'|'save-attribute'|'call'|'return'|'switch'|'loop'
 *   |'break'|'continue'} NodeType
 */

/**
 * Base class for all AST nodes. Nodes are immutable: concrete subclasses
 * must freeze themselves (and any array fields) after construction.
 */
export class Node {
  /**
   * @param {string} id
   * @param {NodeType} type
   */
  constructor(id, type) {
    if (new.target === Node) {
      throw new TypeError('Node is abstract and cannot be instantiated directly');
    }
    if (!id) {
      throw new TypeError('AST node requires a non-empty id');
    }
    this.id = id;
    this.type = type;
  }

  /**
   * Double-dispatch entry point for the Visitor pattern.
   * @template TResult
   * @param {import('../visitor/Visitor.js').Visitor<TResult>} _visitor
   * @returns {TResult}
   */
  // eslint-disable-next-line no-unused-vars
  accept(_visitor) {
    throw new Error(`${this.constructor.name} must implement accept()`);
  }
}

/** @param {ReadonlyArray<any>} arr */
export function freezeList(arr) {
  return Object.freeze([...arr]);
}
