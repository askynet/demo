import { Node, freezeList } from './Node.js';

export class OnlyIfNode extends Node {
  /**
   * @param {string} id
   * @param {string} variable
   * @param {ReadonlyArray<Node>} cases
   */
  constructor(id, variable, cases = []) {
    super(id, 'log');
    this.variable = variable;
    this.cases = freezeList(cases);
    Object.freeze(this);
  }

  accept(visitor) {
    return visitor.visitOnlyIfNode(this);
  }
}
