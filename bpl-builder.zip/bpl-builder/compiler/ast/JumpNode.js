import { Node } from './Node.js';

export class JumpNode extends Node {
  /**
   * @param {string} id
   * @param {string} target Label name as authored; resolved to a numeric
   *   address by the Label Resolver (Step 7).
   */
  constructor(id, target) {
    super(id, 'jump');
    this.target = target;
    Object.freeze(this);
  }

  accept(visitor) {
    return visitor.visitJumpNode(this);
  }
}
