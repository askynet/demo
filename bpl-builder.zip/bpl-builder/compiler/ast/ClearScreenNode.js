import { Node } from './Node.js';

export class ClearScreenNode extends Node {
    /**
     * @param {string} id
     * @param {import('./Expression.js').Expression} condition
     * @param {ReadonlyArray<Node>} thenBlock
     * @param {ReadonlyArray<Node>} [elseBlock]
     */
    constructor(id) {
        super(id, 'clearscreen');
        Object.freeze(this);
    }

    accept(visitor) {
        return visitor.visitClearScreenNode(this);
    }
}
