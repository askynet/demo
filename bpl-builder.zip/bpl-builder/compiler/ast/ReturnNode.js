import { Node } from './Node.js';

export class ReturnNode extends Node {
  /**
   * @param {string} id
   * @param {import('./Expression.js').Expression | null} [value]
   */
  constructor(id, value = null) {
    super(id, 'return');
    this.value = value;
    Object.freeze(this);
  }

  accept(visitor) {
    return visitor.visitReturnNode(this);
  }
}
