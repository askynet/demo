import { Node, freezeList } from './Node.js';

export class ScriptNode extends Node {
  /**
   * @param {string} id
   * @param {string} name
   * @param {ReadonlyArray<Node>} children
   */
  constructor(id, name, children) {
    super(id, 'script');
    this.name = name;
    this.children = freezeList(children);
    Object.freeze(this);
  }

  accept(visitor) {
    return visitor.visitScriptNode(this);
  }
}
