import { Node } from './Node.js';

export class AssignNode extends Node {
  /**
   * @param {string} id
   * @param {string} variable
   * @param {string | number | boolean} value
   */
  constructor(id, variable, value) {
    super(id, 'assign');
    this.variable = variable;
    this.value = value;
    Object.freeze(this);
  }

  accept(visitor) {
    return visitor.visitAssignNode(this);
  }
}
