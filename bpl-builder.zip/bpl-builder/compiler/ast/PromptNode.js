import { Node } from './Node.js';

export class PromptNode extends Node {
  /**
   * @param {string} id
   * @param {string} message
   */
  constructor(id, message) {
    super(id, 'log');
    this.message = message;
    Object.freeze(this);
  }

  accept(visitor) {
    return visitor.visitPromptNode(this);
  }
}
