import { Node } from './Node.js';

export class SaveAttributeNode extends Node {
  /**
   * @param {string} id
   * @param {string} attribute Name of the DB-backed attribute to save to.
   * @param {string} variable Local variable whose value is persisted.
   */
  constructor(id, attribute, variable) {
    super(id, 'save-attribute');
    this.attribute = attribute;
    this.variable = variable;
    Object.freeze(this);
  }

  accept(visitor) {
    return visitor.visitSaveAttributeNode(this);
  }
}
