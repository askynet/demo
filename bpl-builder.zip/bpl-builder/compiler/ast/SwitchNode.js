import { Node, freezeList } from './Node.js';

/**
 * @typedef {Object} SwitchCase
 * @property {import('./Expression.js').Expression} test
 * @property {ReadonlyArray<Node>} body
 */

export class SwitchNode extends Node {
  /**
   * @param {string} id
   * @param {import('./Expression.js').Expression} discriminant
   * @param {ReadonlyArray<SwitchCase>} cases
   * @param {ReadonlyArray<Node>} [defaultCase]
   */
  constructor(id, discriminant, cases, defaultCase = []) {
    super(id, 'switch');
    this.discriminant = discriminant;
    this.cases = freezeList(
      cases.map((c) => Object.freeze({ test: c.test, body: freezeList(c.body) }))
    );
    this.defaultCase = freezeList(defaultCase);
    Object.freeze(this);
  }

  accept(visitor) {
    return visitor.visitSwitchNode(this);
  }
}
