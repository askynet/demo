import { Node, freezeList } from './Node.js';

export class CallNode extends Node {
  /**
   * @param {string} id
   * @param {string} functionName
   * @param {ReadonlyArray<import('./Expression.js').Expression>} args
   * @param {string} [resultVariable] Optional variable to store the return value.
   */
  constructor(id, functionName, args = [], resultVariable = '') {
    super(id, 'call');
    this.functionName = functionName;
    this.args = freezeList(args);
    this.resultVariable = resultVariable;
    Object.freeze(this);
  }

  accept(visitor) {
    return visitor.visitCallNode(this);
  }
}
