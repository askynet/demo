import { Node } from './Node.js';

export class LogNode extends Node {
  /**
   * @param {string} id
   * @param {string} message
   */
  constructor(id, message) {
    super(id, 'log');
    this.message = message;
    Object.freeze(this);
  }

  accept(visitor) {
    return visitor.visitLogNode(this);
  }
}
