import { Node } from './Node.js';

export class ContinueNode extends Node {
  /** @param {string} id */
  constructor(id) {
    super(id, 'continue');
    Object.freeze(this);
  }

  accept(visitor) {
    return visitor.visitContinueNode(this);
  }
}
