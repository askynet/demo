/**
 * @typedef {'AND'|'OR'|'NOT'|'=='|'!='|'>'|'<'|'>='|'<='|'IN'|'EXISTS'} ExpressionOperator
 */

/**
 * Base class for all expression nodes (conditions, values, function calls).
 * Expressions are visited via the same Visitor used for statement nodes,
 * so they share the `accept()` contract.
 */
export class Expression {
  /**
   * @param {string} kind
   */
  constructor(kind) {
    if (new.target === Expression) {
      throw new TypeError('Expression is abstract and cannot be instantiated directly');
    }
    this.kind = kind;
  }

  /**
   * @template TResult
   * @param {import('../visitor/Visitor.js').Visitor<TResult>} _visitor
   * @returns {TResult}
   */
  // eslint-disable-next-line no-unused-vars
  accept(_visitor) {
    throw new Error(`${this.constructor.name} must implement accept()`);
  }
}
