import { Node } from './Node.js';

export class BreakNode extends Node {
  /** @param {string} id */
  constructor(id) {
    super(id, 'break');
    Object.freeze(this);
  }

  accept(visitor) {
    return visitor.visitBreakNode(this);
  }
}
