import { Node } from './Node.js';

export class InputNode extends Node {
  /**
   * @param {string} id
   * @param {string} variable Variable that receives the input value.
   * @param {string} [prompt]
   */
  constructor(id, variable, prompt = '') {
    super(id, 'input');
    this.variable = variable;
    this.prompt = prompt;
    Object.freeze(this);
  }

  accept(visitor) {
    return visitor.visitInputNode(this);
  }
}
