import { Node } from './Node.js';

export class GetKeyNode extends Node {
    /**
     * @param {string} id
     * @param {string} variable
     */
    constructor(id, variable) {
        super(id, 'log');
        this.variable = variable;
        Object.freeze(this);
    }

    accept(visitor) {
        return visitor.visitGetKeyNode(this);
    }
}
