import { Expression } from '../Expression.js';

/**
 * Two-operand expression: AND, OR, ==, !=, >, <, >=, <=, IN.
 */
export class BinaryExpression extends Expression {
  /**
   * @param {import('../Expression.js').ExpressionOperator} operator
   * @param {Expression} left
   * @param {Expression} right
   */
  constructor(operator, left, right) {
    super('binary');
    this.operator = operator;
    this.left = left;
    this.right = right;
    Object.freeze(this);
  }

  accept(visitor) {
    return visitor.visitBinaryExpression(this);
  }
}
