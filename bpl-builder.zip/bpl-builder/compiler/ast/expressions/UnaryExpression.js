import { Expression } from '../Expression.js';

/**
 * Single-operand expression: NOT, EXISTS.
 */
export class UnaryExpression extends Expression {
  /**
   * @param {import('../Expression.js').ExpressionOperator} operator
   * @param {Expression} operand
   */
  constructor(operator, operand) {
    super('unary');
    this.operator = operator;
    this.operand = operand;
    Object.freeze(this);
  }

  accept(visitor) {
    return visitor.visitUnaryExpression(this);
  }
}
