import { Expression } from '../Expression.js';
import { freezeList } from '../Node.js';

/**
 * Function invocation used inside an expression, e.g. AGE(dob) > 65.
 */
export class FunctionExpression extends Expression {
  /**
   * @param {string} name
   * @param {ReadonlyArray<Expression>} args
   */
  constructor(name, args) {
    super('function');
    this.name = name;
    this.args = freezeList(args);
    Object.freeze(this);
  }

  accept(visitor) {
    return visitor.visitFunctionExpression(this);
  }
}
