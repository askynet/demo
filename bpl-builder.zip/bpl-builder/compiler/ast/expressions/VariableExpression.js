import { Expression } from '../Expression.js';

/**
 * Reference to a field/variable by name (e.g. "medical", "status").
 */
export class VariableExpression extends Expression {
  /**
   * @param {string} name
   */
  constructor(name) {
    super('variable');
    this.name = name;
    Object.freeze(this);
  }

  accept(visitor) {
    return visitor.visitVariableExpression(this);
  }
}
