import { Expression } from '../Expression.js';

/**
 * Constant literal value (string, number, boolean, or array for IN).
 */
export class LiteralExpression extends Expression {
  /**
   * @param {string | number | boolean | Array<string|number|boolean>} value
   */
  constructor(value) {
    super('literal');
    this.value = value;
    Object.freeze(this);
  }

  accept(visitor) {
    return visitor.visitLiteralExpression(this);
  }
}
