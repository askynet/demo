import { Node, freezeList } from './Node.js';

export class IfNode extends Node {
  /**
   * @param {string} id
   * @param {import('./Expression.js').Expression} condition
   * @param {ReadonlyArray<Node>} thenBlock
   * @param {ReadonlyArray<Node>} [elseBlock]
   */
  constructor(id, condition, thenBlock, elseBlock = []) {
    super(id, 'if');
    this.condition = condition;
    this.thenBlock = freezeList(thenBlock);
    this.elseBlock = freezeList(elseBlock);
    Object.freeze(this);
  }

  accept(visitor) {
    return visitor.visitIfNode(this);
  }
}
