import { Node } from './Node.js';

export class ImportNode extends Node {
    /**
     * @param {string} id
     * @param {string} file
     */
    constructor(id, file) {
        super(id, 'log');
        this.file = file;
        Object.freeze(this);
    }

    accept(visitor) {
        return visitor.visitImportNode(this);
    }
}
