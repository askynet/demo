import { Node } from './Node.js';

export class FetchAttributeNode extends Node {
  /**
   * @param {string} id
   * @param {string} attribute Name of the DB-backed attribute to fetch.
   * @param {string} variable Local variable to store the fetched value in.
   */
  constructor(id, attribute, variable) {
    super(id, 'fetch-attribute');
    this.attribute = attribute;
    this.variable = variable;
    Object.freeze(this);
  }

  accept(visitor) {
    return visitor.visitFetchAttributeNode(this);
  }
}
