import { Node } from './Node.js';

export class LabelNode extends Node {
  /**
   * @param {string} id
   * @param {string} name
   */
  constructor(id, name) {
    super(id, 'label');
    this.name = name;
    Object.freeze(this);
  }

  accept(visitor) {
    return visitor.visitLabelNode(this);
  }
}
