import { Node, freezeList } from './Node.js';

export class LoopNode extends Node {
  /**
   * @param {string} id
   * @param {import('./Expression.js').Expression} condition Evaluated before each iteration.
   * @param {ReadonlyArray<Node>} body
   */
  constructor(id, condition, body) {
    super(id, 'loop');
    this.condition = condition;
    this.body = freezeList(body);
    Object.freeze(this);
  }

  accept(visitor) {
    return visitor.visitLoopNode(this);
  }
}
