/**
 * Abstract Visitor contract for AST traversal. Every AST node type
 * (statement or expression) has a corresponding `visitXNode` /
 * `visitXExpression` method. Concrete visitors (parser diagnostics,
 * validator, printers, lowering passes) extend `TraversingVisitor` rather
 * than this class directly, so they only need to override what they
 * actually care about.
 *
 * @template TResult
 */
export class Visitor {
  /** @param {import('../ast/ScriptNode.js').ScriptNode} _node @returns {TResult} */
  visitScriptNode(_node) { throw new Error('visitScriptNode not implemented'); }
  /** @param {import('../ast/IfNode.js').IfNode} _node @returns {TResult} */
  visitIfNode(_node) { throw new Error('visitIfNode not implemented'); }
  /** @param {import('../ast/AssignNode.js').AssignNode} _node @returns {TResult} */
  visitAssignNode(_node) { throw new Error('visitAssignNode not implemented'); }
  /** @param {import('../ast/IncludeNode.js').IncludeNode} _node @returns {TResult} */
  visitIncludeNode(_node) { throw new Error('visitIncludeNode not implemented'); }
  /** @param {import('../ast/JumpNode.js').JumpNode} _node @returns {TResult} */
  visitJumpNode(_node) { throw new Error('visitJumpNode not implemented'); }
  /** @param {import('../ast/LabelNode.js').LabelNode} _node @returns {TResult} */
  visitLabelNode(_node) { throw new Error('visitLabelNode not implemented'); }
  /** @param {import('../ast/LogNode.js').LogNode} _node @returns {TResult} */
  visitLogNode(_node) { throw new Error('visitLogNode not implemented'); }
  /** @param {import('../ast/InputNode.js').InputNode} _node @returns {TResult} */
  visitInputNode(_node) { throw new Error('visitInputNode not implemented'); }
  /** @param {import('../ast/FetchAttributeNode.js').FetchAttributeNode} _node @returns {TResult} */
  visitFetchAttributeNode(_node) { throw new Error('visitFetchAttributeNode not implemented'); }
  /** @param {import('../ast/SaveAttributeNode.js').SaveAttributeNode} _node @returns {TResult} */
  visitSaveAttributeNode(_node) { throw new Error('visitSaveAttributeNode not implemented'); }
  /** @param {import('../ast/CallNode.js').CallNode} _node @returns {TResult} */
  visitCallNode(_node) { throw new Error('visitCallNode not implemented'); }
  /** @param {import('../ast/ReturnNode.js').ReturnNode} _node @returns {TResult} */
  visitReturnNode(_node) { throw new Error('visitReturnNode not implemented'); }
  /** @param {import('../ast/SwitchNode.js').SwitchNode} _node @returns {TResult} */
  visitSwitchNode(_node) { throw new Error('visitSwitchNode not implemented'); }
  /** @param {import('../ast/LoopNode.js').LoopNode} _node @returns {TResult} */
  visitLoopNode(_node) { throw new Error('visitLoopNode not implemented'); }
  /** @param {import('../ast/BreakNode.js').BreakNode} _node @returns {TResult} */
  visitBreakNode(_node) { throw new Error('visitBreakNode not implemented'); }
  /** @param {import('../ast/ContinueNode.js').ContinueNode} _node @returns {TResult} */
  visitContinueNode(_node) { throw new Error('visitContinueNode not implemented'); }
  /** @param {import('../ast/ClearScreenNode.js').ClearScreenNode} _node @returns {TResult} */
  visitClearScreenNode(_node) { throw new Error('visitClearScreenNode not implemented'); }
  /** @param {import('../ast/GetKeyNode.js').GetKeyNode} _node @returns {TResult} */
  visitGetKeyNode(_node) { throw new Error('visitGetKeyNode not implemented'); }
  /** @param {import('../ast/PromptNode.js').PromptNode} _node @returns {TResult} */
  visitPromptNode(_node) { throw new Error('visitPromptNode not implemented'); }
  /** @param {import('../ast/OnlyIfNode.js').OnlyIfNode} _node @returns {TResult} */
  visitOnlyIfNode(_node) { throw new Error('visitOnlyIfNode not implemented'); }
  /** @param {import('../ast/ImportNode.js').ImportNode} _node @returns {TResult} */
  visitImportNode(_node) { throw new Error('visitImportNode not implemented'); }

  /** @param {import('../ast/expressions/BinaryExpression.js').BinaryExpression} _node @returns {TResult} */
  visitBinaryExpression(_node) { throw new Error('visitBinaryExpression not implemented'); }
  /** @param {import('../ast/expressions/UnaryExpression.js').UnaryExpression} _node @returns {TResult} */
  visitUnaryExpression(_node) { throw new Error('visitUnaryExpression not implemented'); }
  /** @param {import('../ast/expressions/VariableExpression.js').VariableExpression} _node @returns {TResult} */
  visitVariableExpression(_node) { throw new Error('visitVariableExpression not implemented'); }
  /** @param {import('../ast/expressions/LiteralExpression.js').LiteralExpression} _node @returns {TResult} */
  visitLiteralExpression(_node) { throw new Error('visitLiteralExpression not implemented'); }
  /** @param {import('../ast/expressions/FunctionExpression.js').FunctionExpression} _node @returns {TResult} */
  visitFunctionExpression(_node) { throw new Error('visitFunctionExpression not implemented'); }
}

/**
 * A Visitor that walks the whole tree by default (statements and nested
 * expressions), doing nothing at each node. Subclasses override only the
 * `visitXNode` methods they care about, and call `super.visitXNode(node)`
 * (or `this.visitChildren(node)`) to keep descending.
 *
 * @template TResult
 * @extends {Visitor<TResult>}
 */
export class TraversingVisitor extends Visitor {
  visitScriptNode(node) {
    for (const child of node.children) child.accept(this);
    return undefined;
  }

  visitIfNode(node) {
    node.condition.accept(this);
    for (const child of node.thenBlock) child.accept(this);
    for (const child of node.elseBlock) child.accept(this);
    return undefined;
  }

  visitAssignNode(_node) { return undefined; }
  visitIncludeNode(_node) { return undefined; }
  visitJumpNode(_node) { return undefined; }
  visitLabelNode(_node) { return undefined; }
  visitLogNode(_node) { return undefined; }
  visitInputNode(_node) { return undefined; }
  visitFetchAttributeNode(_node) { return undefined; }
  visitSaveAttributeNode(_node) { return undefined; }

  visitCallNode(node) {
    for (const arg of node.args) arg.accept(this);
    return undefined;
  }

  visitReturnNode(node) {
    if (node.value) node.value.accept(this);
    return undefined;
  }

  visitSwitchNode(node) {
    node.discriminant.accept(this);
    for (const c of node.cases) {
      c.test.accept(this);
      for (const child of c.body) child.accept(this);
    }
    for (const child of node.defaultCase) child.accept(this);
    return undefined;
  }

  visitLoopNode(node) {
    node.condition.accept(this);
    for (const child of node.body) child.accept(this);
    return undefined;
  }

  visitBreakNode(_node) { return undefined; }
  visitContinueNode(_node) { return undefined; }
  visitClearScreenNode(_node) { return undefined; }
  visitGetKeyNode(_node) { return undefined; }
  visitPromptNode(_node) { return undefined; }
  visitImportNode(_node) { return undefined; }

  visitOnlyIfNode(node) {
    for (const c of node.cases) {
      for (const child of c.block) child.accept(this);
    }
    return undefined;
  }

  visitBinaryExpression(node) {
    node.left.accept(this);
    node.right.accept(this);
    return undefined;
  }

  visitUnaryExpression(node) {
    node.operand.accept(this);
    return undefined;
  }

  visitVariableExpression(_node) { return undefined; }
  visitLiteralExpression(_node) { return undefined; }

  visitFunctionExpression(node) {
    for (const arg of node.args) arg.accept(this);
    return undefined;
  }
}