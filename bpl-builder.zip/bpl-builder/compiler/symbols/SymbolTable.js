/**
 * A single append-only, deduplicated name -> numeric ID table.
 * IDs are assigned in first-seen order starting at 0.
 */
class NameTable {
  constructor() {
    /** @type {Map<string, number>} */
    this._idsByName = new Map();
    /** @type {string[]} */
    this._namesById = [];
  }

  /**
   * @param {string} name
   * @returns {number} existing or newly allocated ID
   */
  getOrCreate(name) {
    const existing = this._idsByName.get(name);
    if (existing !== undefined) return existing;
    const id = this._namesById.length;
    this._idsByName.set(name, id);
    this._namesById.push(name);
    return id;
  }

  /**
   * @param {string} name
   * @returns {number | undefined}
   */
  lookup(name) {
    return this._idsByName.get(name);
  }

  /** @param {number} id @returns {string | undefined} */
  nameOf(id) {
    return this._namesById[id];
  }

  has(name) {
    return this._idsByName.has(name);
  }

  /** @returns {ReadonlyArray<string>} names in ID order */
  entries() {
    return this._namesById;
  }

  get size() {
    return this._namesById.length;
  }
}

/**
 * Central symbol table for a single compilation unit. Everything the
 * bytecode ultimately references by numeric ID (variables, strings,
 * labels, includes, functions) is allocated here so no raw strings or
 * file paths leak into generated instructions.
 */
export class SymbolTable {
  constructor() {
    this.variables = new NameTable();
    this.strings = new NameTable();
    this.labels = new NameTable();
    this.includes = new NameTable();
    this.functions = new NameTable();
  }

  /**
   * Serializes all tables into a plain object suitable for the Binary
   * Serializer's string/symbol table section.
   */
  toJSON() {
    return {
      variables: this.variables.entries(),
      strings: this.strings.entries(),
      labels: this.labels.entries(),
      includes: this.includes.entries(),
      functions: this.functions.entries(),
    };
  }
}
