import { Instruction } from '../ir/Instruction.js';
import { Opcode } from '../ir/Opcode.js';
import { BranchType } from '../cfg/BranchType.js';
import { ExpressionCompiler } from './ExpressionCompiler.js';

/**
 * Turns an optimized CFG into a single flat, resolved Instruction[]. Block
 * order is chosen so FALLTHROUGH targets and CONDITIONAL consequents land
 * immediately after their source block whenever possible, so most control
 * flow costs nothing (no jump instruction emitted at all) — an explicit
 * JUMP is only emitted as a fallback when a block couldn't be placed
 * adjacently (e.g. it was already reached from elsewhere first).
 */
export class BytecodeGenerator {
  /** @param {import('../symbols/SymbolTable.js').SymbolTable} symbolTable */
  constructor(symbolTable) {
    this._symbolTable = symbolTable;
    this._expressionCompiler = new ExpressionCompiler(symbolTable);
  }

  /**
   * @param {import('../cfg/CfgBuilder.js').Cfg} cfg
   * @returns {Instruction[]}
   */
  generate(cfg) {
    const order = this._computeBlockOrder(cfg);

    /** @type {Instruction[]} */
    const instructions = [];
    /** @type {Map<string, number>} */
    const blockAddress = new Map();
    /** @type {Array<{ index: number, targetBlockId: string }>} */
    const patches = [];

    order.forEach((blockId, position) => {
      const block = cfg.blocks.get(blockId);
      blockAddress.set(blockId, instructions.length);

      for (const statement of block.statements) {
        this._emitStatement(statement, instructions);
      }

      const nextBlockId = order[position + 1] ?? null;
      this._emitTerminator(block, nextBlockId, instructions, patches);
    });

    instructions.push(new Instruction(Opcode.END));

    for (const patch of patches) {
      const address = blockAddress.get(patch.targetBlockId);
      const original = instructions[patch.index];
      instructions[patch.index] = new Instruction(original.opcode, address, original.operandB, original.operandC);
    }

    return instructions;
  }

  /**
   * DFS block ordering that greedily keeps a FALLTHROUGH block's target,
   * or a CONDITIONAL block's consequent, immediately after it.
   * @param {import('../cfg/CfgBuilder.js').Cfg} cfg
   * @returns {string[]}
   */
  _computeBlockOrder(cfg) {
    const visited = new Set();
    const order = [];

    const visit = (id) => {
      if (visited.has(id) || !cfg.blocks.has(id)) return;
      visited.add(id);
      order.push(id);
      const block = cfg.blocks.get(id);
      if (block.branchType === BranchType.FALLTHROUGH) {
        visit(block.target);
      } else if (block.branchType === BranchType.CONDITIONAL) {
        visit(block.consequent);
      }
    };

    visit(cfg.entryId);
    for (const id of cfg.blocks.keys()) visit(id);

    return order;
  }

  /** @param {import('../ast/Node.js').Node} statement @param {Instruction[]} out */
  _emitStatement(statement, out) {
    const st = this._symbolTable;
    switch (statement.type) {
      case 'log':
        out.push(new Instruction(Opcode.LOG, st.strings.getOrCreate(statement.message)));
        return;

      case 'assign': {
        const typeTag = typeof statement.value === 'number' ? 1 : typeof statement.value === 'boolean' ? 2 : 0;
        out.push(new Instruction(Opcode.LOAD_CONST, st.strings.getOrCreate(JSON.stringify(statement.value)), typeTag));
        out.push(new Instruction(Opcode.STORE_ATTR, st.variables.getOrCreate(statement.variable)));
        return;
      }

      case 'include': {
        statement.parameters.forEach((paramName, index) => {
          out.push(new Instruction(Opcode.LOAD_ATTR, st.variables.getOrCreate(paramName)));
          out.push(new Instruction(Opcode.STORE_ATTR, this._expressionCompiler.argSlot(index)));
        });
        out.push(
          new Instruction(Opcode.IMPORT_BLK, st.includes.getOrCreate(statement.path), statement.parameters.length)
        );
        return;
      }

      case 'input':
        out.push(
          new Instruction(Opcode.INPUT, st.variables.getOrCreate(statement.variable), st.strings.getOrCreate(statement.prompt))
        );
        return;

      case 'fetch-attribute':
        out.push(
          new Instruction(Opcode.FETCH_DB, st.strings.getOrCreate(statement.attribute), st.variables.getOrCreate(statement.variable))
        );
        return;

      case 'save-attribute':
        out.push(
          new Instruction(Opcode.SAVE_DB, st.strings.getOrCreate(statement.attribute), st.variables.getOrCreate(statement.variable))
        );
        return;

      case 'call':
        this._expressionCompiler.compileCallNode(statement, out);
        return;

      default:
        throw new Error(`BytecodeGenerator cannot emit statement type "${statement.type}"`);
    }
  }

  /**
   * @param {import('../cfg/BasicBlock.js').BasicBlock} block
   * @param {string | null} nextBlockId
   * @param {Instruction[]} out
   * @param {Array<{ index: number, targetBlockId: string }>} patches
   */
  _emitTerminator(block, nextBlockId, out, patches) {
    switch (block.branchType) {
      case BranchType.RETURN: {
        if (block.returnValue) {
          this._expressionCompiler.compileToAcc(block.returnValue, out);
          out.push(new Instruction(Opcode.RETURN, 1));
        } else {
          out.push(new Instruction(Opcode.RETURN, 0));
        }
        return;
      }

      case BranchType.UNCONDITIONAL: {
        if (block.target !== nextBlockId) {
          patches.push({ index: out.push(new Instruction(Opcode.JUMP, 0)) - 1, targetBlockId: block.target });
        }
        return;
      }

      case BranchType.FALLTHROUGH: {
        if (block.target !== nextBlockId) {
          patches.push({ index: out.push(new Instruction(Opcode.JUMP, 0)) - 1, targetBlockId: block.target });
        }
        return;
      }

      case BranchType.CONDITIONAL: {
        this._expressionCompiler.compileToAcc(block.condition, out);
        patches.push({
          index: out.push(new Instruction(Opcode.JUMP_FALSE, 0)) - 1,
          targetBlockId: block.alternate,
        });
        if (block.consequent !== nextBlockId) {
          patches.push({ index: out.push(new Instruction(Opcode.JUMP, 0)) - 1, targetBlockId: block.consequent });
        }
        return;
      }

      default:
        throw new Error(`Block "${block.id}" has no terminator (branchType is ${block.branchType})`);
    }
  }
}
