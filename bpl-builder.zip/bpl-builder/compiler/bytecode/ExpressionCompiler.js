import { Instruction } from '../ir/Instruction.js';
import { Opcode, OperandKind } from '../ir/Opcode.js';

const COMPARE_OPCODE_BY_OPERATOR = Object.freeze({
  '==': Opcode.COMPARE_EQ,
  '!=': Opcode.COMPARE_NEQ,
  '>': Opcode.COMPARE_GT,
  '<': Opcode.COMPARE_LT,
  '>=': Opcode.COMPARE_GTE,
  '<=': Opcode.COMPARE_LTE,
  IN: Opcode.COMPARE_IN,
});

const MAX_CALL_ARGS = 8;

/**
 * Lowers Expression AST nodes into a flat sequence of Instructions,
 * leaving the result in the implicit accumulator (ACC). No operand stack
 * is used: AND/OR are compiled as explicit short-circuiting jumps, binary
 * comparisons stash their right-hand side in a scratch variable so ACC is
 * free to hold the left-hand side, and CALL arguments are passed through a
 * small fixed pool of reusable "argument slot" variables.
 */
export class ExpressionCompiler {
  /** @param {import('../symbols/SymbolTable.js').SymbolTable} symbolTable */
  constructor(symbolTable) {
    this._symbolTable = symbolTable;
    this._scratchCounter = 0;
  }

  /** @returns {number} a fresh scratch variable id, unique for this compilation unit */
  _allocScratch() {
    const id = this._symbolTable.variables.getOrCreate(`__scratch${this._scratchCounter}`);
    this._scratchCounter += 1;
    return id;
  }

  /** @param {number} index @returns {number} variable id for the Nth call-argument slot (public: also used for include parameters) */
  argSlot(index) {
    return this._argSlot(index);
  }

  /** @param {number} index @returns {number} variable id for the Nth call-argument slot */
  _argSlot(index) {
    if (index >= MAX_CALL_ARGS) {
      throw new Error(`Call has more than the supported maximum of ${MAX_CALL_ARGS} arguments`);
    }
    return this._symbolTable.variables.getOrCreate(`__arg${index}`);
  }

  /** @param {string | number | boolean} value @returns {number} type tag: 0=string,1=number,2=boolean */
  _typeTagFor(value) {
    if (typeof value === 'number') return 1;
    if (typeof value === 'boolean') return 2;
    return 0;
  }

  /** @param {*} value @returns {number} string-table id of the constant's serialized form */
  _constIdFor(value) {
    return this._symbolTable.strings.getOrCreate(JSON.stringify(value));
  }

  /**
   * Compiles `expr` so that, once these instructions run, ACC holds its value.
   * @param {import('../ast/Expression.js').Expression} expr
   * @param {Instruction[]} out
   */
  compileToAcc(expr, out) {
    switch (expr.kind) {
      case 'literal':
        out.push(new Instruction(Opcode.LOAD_CONST, this._constIdFor(expr.value), this._typeTagFor(expr.value)));
        return;

      case 'variable':
        out.push(new Instruction(Opcode.LOAD_ATTR, this._symbolTable.variables.getOrCreate(expr.name)));
        return;

      case 'function':
        this._compileArgsAndCall(expr.args, this._symbolTable.functions.getOrCreate(expr.name), out, true);
        return;

      case 'binary':
        this._compileBinary(expr, out);
        return;

      case 'unary':
        this._compileUnary(expr, out);
        return;

      default:
        throw new Error(`ExpressionCompiler cannot lower expression kind "${expr.kind}"`);
    }
  }

  /**
   * Compiles a CallNode statement: pushes its arguments into the argument
   * slots, emits CALL, and — if the node has a resultVariable — stores the
   * return value there.
   * @param {import('../ast/CallNode.js').CallNode} node
   * @param {Instruction[]} out
   */
  compileCallNode(node, out) {
    const functionId = this._symbolTable.functions.getOrCreate(node.functionName);
    const keepResult = Boolean(node.resultVariable);
    this._compileArgsAndCall(node.args, functionId, out, keepResult);
    if (node.resultVariable) {
      out.push(new Instruction(Opcode.STORE_ATTR, this._symbolTable.variables.getOrCreate(node.resultVariable)));
    }
  }

  /**
   * @param {ReadonlyArray<import('../ast/Expression.js').Expression>} args
   * @param {number} functionId
   * @param {Instruction[]} out
   * @param {boolean} keepResult whether the caller wants ACC preserved after CALL
   */
  _compileArgsAndCall(args, functionId, out, keepResult) {
    args.forEach((arg, index) => {
      this.compileToAcc(arg, out);
      out.push(new Instruction(Opcode.STORE_ATTR, this._argSlot(index)));
    });
    out.push(new Instruction(Opcode.CALL, functionId, args.length, keepResult ? 1 : 0));
  }

  /** @param {import('../ast/expressions/BinaryExpression.js').BinaryExpression} expr @param {Instruction[]} out */
  _compileBinary(expr, out) {
    if (expr.operator === 'AND') {
      this.compileToAcc(expr.left, out);
      const jumpFalseIndex = out.push(new Instruction(Opcode.JUMP_FALSE, 0)) - 1;
      this.compileToAcc(expr.right, out);
      out[jumpFalseIndex] = new Instruction(Opcode.JUMP_FALSE, out.length);
      return;
    }

    if (expr.operator === 'OR') {
      this.compileToAcc(expr.left, out);
      const jumpToTryRightIndex = out.push(new Instruction(Opcode.JUMP_FALSE, 0)) - 1;
      const jumpToEndIndex = out.push(new Instruction(Opcode.JUMP, 0)) - 1;
      out[jumpToTryRightIndex] = new Instruction(Opcode.JUMP_FALSE, out.length);
      this.compileToAcc(expr.right, out);
      out[jumpToEndIndex] = new Instruction(Opcode.JUMP, out.length);
      return;
    }

    const opcode = COMPARE_OPCODE_BY_OPERATOR[expr.operator];
    if (!opcode) {
      throw new Error(`Unknown binary operator "${expr.operator}"`);
    }

    // Evaluate the right-hand side first and park it in a scratch variable,
    // so ACC is free for the left-hand side and the COMPARE_* instruction
    // can uniformly reference "ACC vs a variable slot" regardless of how
    // complex the right-hand expression was.
    this.compileToAcc(expr.right, out);
    const scratch = this._allocScratch();
    out.push(new Instruction(Opcode.STORE_ATTR, scratch));
    this.compileToAcc(expr.left, out);
    out.push(new Instruction(opcode, OperandKind.VAR, scratch));
  }

  /** @param {import('../ast/expressions/UnaryExpression.js').UnaryExpression} expr @param {Instruction[]} out */
  _compileUnary(expr, out) {
    if (expr.operator === 'NOT') {
      this.compileToAcc(expr.operand, out);
      out.push(new Instruction(Opcode.LOGICAL_NOT));
      return;
    }

    if (expr.operator === 'EXISTS') {
      if (expr.operand.kind !== 'variable') {
        throw new Error('EXISTS can only be applied to a variable reference');
      }
      out.push(
        new Instruction(Opcode.CHECK_EXISTS, this._symbolTable.variables.getOrCreate(expr.operand.name))
      );
      return;
    }

    throw new Error(`Unknown unary operator "${expr.operator}"`);
  }
}
