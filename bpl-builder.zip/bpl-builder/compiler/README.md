# Policy Flow Compiler

Compiles a Business Rules / Policy Flow JSON document into an optimized
binary instruction stream for a Worker VM. Runs only at **Publish** time —
this is a compiler, not a JSON interpreter.

## Pipeline

```
Flow JSON
  -> FlowParser            (src/compiler/parser)       JSON -> AST
  -> SemanticValidator      (src/compiler/semantic)      duplicate labels, missing labels,
                                                          invalid includes, bad expressions, etc.
  -> IncludeResolver        (src/compiler/resolver)      file path -> numeric IncludeID
  -> LabelResolver           (src/compiler/resolver)      jump target name -> label ID
  -> CfgBuilder              (src/compiler/cfg)           AST -> BasicBlock graph
  -> Optimizer                (src/compiler/optimizer)    7 passes to a fixpoint
  -> BytecodeGenerator          (src/compiler/bytecode)   CFG -> flat resolved Instruction[]
  -> BinarySerializer            (src/compiler/serializer) Instruction[] -> Buffer
```

`Compiler.compile(flowJson)` runs the whole pipeline and stops at the
first stage reporting fatal errors. `CompilerService.publish(policyId, flowJson)`
wraps that with persistence (compiled binary + original source JSON) via
`PolicyStore`.

## Instruction set

See `src/compiler/ir/Opcode.js`. A single implicit accumulator register
(ACC) plus the shared variable table — no operand stack. AND/OR are
compiled to explicit short-circuit JUMP/JUMP_FALSE; everything else is a
single instruction.

## Binary format

`MAGIC ("PFC1") | VERSION (u16) | INSTRUCTION_COUNT (u32) | STRING_TABLE |
SYMBOL_TABLE (variables, labels, includes, functions) | INSTRUCTIONS
(opcode: u8, 3x u32 operands)`. Hand-packed with `Buffer.writeUInt*LE` —
no JSON, no Gob.

## Run

```bash
npm install
npm start                # POST /api/policies/:id/publish
npm test                 # vitest — 37 tests across parser/validator/cfg/
                          # optimizer/ir/serializer/compiler/API
```

## Extending

- New AST node type: add a class under `src/compiler/ast/`, a
  `visitXNode` method to `Visitor`/`TraversingVisitor`, a parser branch in
  `FlowParser`, and a case in `CfgBuilder._processNode` or
  `BytecodeGenerator._emitStatement`.
- New optimizer pass: add a file under `src/compiler/optimizer/passes/`
  and wire it into `Optimizer.optimize()`.
- New opcode: add it to `Opcode.js`, emit it from `BytecodeGenerator` or
  `ExpressionCompiler`, no serializer changes needed (opcode is just a u8).
